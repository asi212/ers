/* free function */
/* Copyright 2003-2010, 2005 IAR Systems AB.  */

#include "FreeRTOS.h"
#include "task.h"
#include "xinstantiate.h"


_STD_BEGIN
void free( void * ptr ){
    vPortFree(ptr);
}

_INSTANTIATE(free);

_STD_END
