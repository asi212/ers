/* malloc function */
/* Copyright 2003-2010, 2005 IAR Systems AB.  */

#include "FreeRTOS.h"
#include "task.h"
#include "xinstantiate.h"

_STD_BEGIN

void * malloc( size_t size ){
    return pvPortMalloc( size );
}

_INSTANTIATE(malloc);

_STD_END
