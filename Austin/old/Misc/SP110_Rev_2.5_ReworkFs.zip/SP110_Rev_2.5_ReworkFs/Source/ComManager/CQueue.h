#ifndef C_QUEUE_H
#define C_QUEUE_H

#include <cstring>

template <class T>
class CQueue{
    private:
        T m_t[32];
        int m_size;
        int m_head;
        int m_tail;
        
    public:
        //*******************
        CQueue()
        {
            m_size = 0;
            m_head = 0;
            m_tail = 0;
        };        
        //*******************
        void push( T & t )
        {
            if( m_size < 32)
            {
                m_t[m_head++] = t;
                if( m_head >= 31)
                {
                    m_head = 0;
                }
                m_size++;
            }            
        };        
        //*******************
        T &  front()
        {
            return m_t[m_tail];
        };
        //*******************
        void pop()
        {
            if( m_size > 0 ){
                m_tail++;
                if( m_tail >= 31){
                    m_tail = 0;
                }
                m_size--;
            }
        };
        //*******************
        int size()
        {
            return m_size;
        }
        //*******************
        void clear()
        {
            m_size = 0;
            m_head = 0;
            m_tail = 0;
        };
        //*******************
        bool empty()
        {
            if( m_size > 0 )
            {
                return false;
            }
            else{
                return true;
            }
        };
};
#endif