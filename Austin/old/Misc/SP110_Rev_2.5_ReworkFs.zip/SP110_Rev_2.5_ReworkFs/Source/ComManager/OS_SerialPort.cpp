/******************** (C) ERS Electronic GmbH ********************
* File Name          : serial_device.cpp
* Author             : Khaukha-Mabinda Paddy
* Date First Issued  : 23/06/2009 : Version 1.0
* Description        : Serial device Classes
********************************************************************************
* History:
* 23/06/2009 : Version 1.0
*********************************************************************************/


#include "91x_type.h"
extern "C"
{
    #include "91x_uart.h"
    #include "FreeRTOS.h"
    #include "task.h"
}
#include "protocol.h"
#include "OS_SerialPort.h"

Protocol *OS_SerialPort::m_protocol=0;

/*******************************************************************************
* Method Name  	 : Class Constructor
* Description    : Initializes the OS_SerialPort Object. UART and m_protocol are
*				   initialized to 0. Before using the class the InitSerialDevice
*				   method has to be called with a valid UART structure and protocol
*                  object.
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/

OS_SerialPort::OS_SerialPort()
{
}

OS_SerialPort::~OS_SerialPort()
{

}

/*******************************************************************************
* Method Name  	 : InitSerialProtocol
* Description    : Initializes the OS_SerialPort Object UART and m_protocol
*                  object.
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void OS_SerialPort::InitSerialProtocol( Protocol *protocol )
{
    m_protocol = protocol;
    /* Create the queues used to hold Rx characters. */
    m_OsQRx = xQueueCreate( 256, ( unsigned portBASE_TYPE ) sizeof( char ) );
    m_OsQTx = xQueueCreate( 256, ( unsigned portBASE_TYPE ) sizeof( char ) );
    vQueueAddToRegistry( m_OsQRx, "Proto Port Receive" );
    vQueueAddToRegistry( m_OsQTx, "Proto Port Send" );

}


/*******************************************************************************
* Method Name  	 : ToggleTxInterrupt
* Description    : Switches Transmit interrupt on and off
*
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void OS_SerialPort::ToggleTxInterrupt( FunctionalState NewState)
{
	UART_ITConfig(UART0, UART_IT_Transmit,NewState);
}
/*******************************************************************************
* Method Name  	 : BeginTransmit
* Description    :
*
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void OS_SerialPort::BeginTransmit(u8 data)
{
    char ch;
    u8 len;
    
    // wait FIFO to get empty
    // this ensures that the last message was completely send 
    while(UART_GetFlagStatus(UART0, UART_FLAG_TxFIFOEmpty) == RESET) vTaskDelay(1); 
    
    //Put next Message to TX Queue
    do{    
       len = m_protocol->OnTransmit(&ch);
       if( len == 1 )
       {
            xQueueSend( m_OsQTx, &ch, 0);
       }
       else if( len == 0){
            m_protocol->OnTransmitComplete();
       }
    } while( len == 1 );

    //Enable TX Interrupt and send first char to trigger 
    Transmit(data);

    while( UART_GetFlagStatus( UART0, UART_FLAG_TxFIFOFull) == RESET )
    {
        if( xQueueReceive( m_OsQTx, &ch, 0) == pdTRUE )
        {
            Transmit(ch); // send data
        }
        else{
            break;
        }
    }
    ToggleTxInterrupt(ENABLE);    

}
/*******************************************************************************
* Method Name  	 : Transmit
* Description    :
*
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void OS_SerialPort::Transmit(u8 data)
{
    UART_SendData(UART0,data); // send data
}

/**
    Cyclic execution 
*/
void OS_SerialPort::cycExec()
{
    char ch;

    if( xQueueReceive( m_OsQRx, &ch, 0 ) == pdTRUE ){
        m_protocol->OnReceive(ch);
    }
}
    


/*******************************************************************************
* Method Name  	 : uart0_handler
* Description    :
*
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void OS_SerialPort::uart0_handler(void)
{
    char ch;
    
    portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;

    //TX Interrupt handling
    if( (UART_GetITStatus(UART0, UART_IT_Receive) == SET) ||
        (UART_GetITStatus(UART0, UART_IT_ReceiveTimeOut) == SET) )
    {         
        while(  UART_GetFlagStatus( UART0, UART_FLAG_RxFIFOEmpty) == RESET )
        {
            ch = UART_ReceiveData(UART0);
            xQueueSendFromISR( m_OsQRx, &ch, &xHigherPriorityTaskWoken );
        }
        UART_ClearITPendingBit(UART0,UART_IT_Receive | UART_IT_ReceiveTimeOut);
    }
    //TX Interrupt handling
    if(UART_GetITStatus(UART0, UART_IT_Transmit ) == SET )
    {   
        while( UART_GetFlagStatus( UART0, UART_FLAG_TxFIFOFull) == RESET )
        {
            if( xQueueReceiveFromISR( m_OsQTx, &ch, &xHigherPriorityTaskWoken) == pdTRUE )
            {
                UART_SendData(UART0,ch); // send data
            }
            else
            {
                UART_ITConfig(UART0, UART_IT_Transmit, DISABLE);
                UART_ClearITPendingBit(UART0, UART_IT_Transmit);
                break;
            }
        }
    }
    portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}

