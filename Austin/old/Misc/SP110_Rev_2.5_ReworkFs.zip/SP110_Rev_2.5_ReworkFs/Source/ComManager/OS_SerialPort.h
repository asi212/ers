/******************** (C) ERS Electronic GmbH ********************
* File Name          : serial_device.h
* Author             : Khaukha-Mabinda Paddy
* Date First Issued  : 23/06/2009 : Version 1.0
* Description        : Serial device Classes
********************************************************************************
* History:
* 23/06/2009 : Version 1.0
*********************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __SERIAL_DEVICE_H
#define __SERIAL_DEVICE_H

#include "91x_uart.h"
#include "ers_types.h"
extern "C"{
    #include "FreeRTOS.h"
    #include "queue.h"
}

class Protocol;

class OS_SerialPort
{
	public:
	OS_SerialPort();
        ~OS_SerialPort();
        
        void cycExec();

        void InitSerialProtocol( Protocol *protocol );
	void BeginTransmit(u8 data);
	void Transmit(u8 data);
        void uart0_handler(void);
     

    private:
        xQueueHandle m_OsQRx;
        xQueueHandle m_OsQTx;
        static void ToggleTxInterrupt( FunctionalState NewState);

private:
        static Protocol *m_protocol;
};


#endif // __SERIAL_DEVICE_H
