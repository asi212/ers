/******************** (C) ERS Electronic GmbH ********************
* File Name          : ers_types.h
* Author             : Khaukha-Mabinda Paddy
* Date First Issued  : 29/06/2009 : Version 1.0
* Description        : ProtocolManager class
********************************************************************************
* History:
* 29/06/2009 : Version 1.0
*********************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __ERS_TYPES_H
#define __ERS_TYPES_H

#define PROBER_MSG_EVENT (1)
#define MAX_OS_SERIAL_PORTS 3
#define MAX_ALL_SERIAL_PORTS 3
#define MAX_COMM_CHANNELS 4
#define	MAX_MSG_LEN 256

#ifndef ASCII_CR
#define ASCII_CR 0x0D
#define ASCII_LF 0x0A
#endif

typedef struct SysEvents
{
	bool readyFlag;
	char EventMask;
	//OS_TASK*  TCBPROB;
}SYS_EVENTS;

static SysEvents SystemEvents[MAX_COMM_CHANNELS];

#endif // __ERS_TYPES