/******************** (C) ERS Electronic GmbH ********************
* File Name          : lcddef.h
* Author             : Khaukha-Mabinda Paddy
* Date First Issued  : 04/08/2009 : Version 1.0
* Description        : Display Classes
********************************************************************************
* History:
* 04/08/2009 : Version 1.0
*********************************************************************************/
/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __LCDDEF_H
#define __LCDDEF_H

// define constants here
#define NC_VALUE -900
#define INVALID_VALUE -999
static const char *NC_Str[]={"N.C"};
static const char *INVALID_Str[]={"------"};
static const char *INVALID_Str2[]={"  ------  "};

static const char *RaumTemp[] = {"+25.0"};
#define MAX_SETTEMP_COUNT 8
#define MSG_MAX 256
#define DIAG_Y_OFFSET 29

/* 60.000mS = 1 Minute */
#define DIM_TIMEOUT 60000
class ViewObject;


/* Key Control Codes */
#define KEY_NONE 0
#define ESCAPE 27
#define BACKSPACE 8
#define ENTER 13
#define PLUSMINUS 45
#define CLEAR 127
#define R_KEY 82
#define T_KEY 84
#define SYSSTAT_BTN 100
#define EXIT_SYSSTAT_BTN 202
#define SYSSTAT_PURGE_BTN 203
#define SYSSTAT_DEFROST_BTN 204
#define DIM_KEY 220
#define PURGE_BTN 102
#define DIAG_BTN 103
#define DEFROST_BTN 104
#define CONFIG_BTN 105


/* Every display fields has an identifier and coordinates. Given the identifier, the coordinates are loaded. */
/* command format: #ZCX,YText0x00. In order to remain flexible, font choice is part of the command */
/* Before adding a new field, an identifier in the E_DISPLAY_FIELD should be defined */

typedef enum _controlParameters
{
    CP_SET_TEMP,
    CP_CHUCK_TEMP,
    CP_RANGE_MIN,
    CP_RANGE_MAX,
    CP_OP_MODE,
    CP_SYS_INFO,
    CP_ERROR_CODE,
    CP_KEY_LOCK,
    CP_HOLD,
    CP_DEFROST_MODE,
    CP_PURGE_MODE,
    CP_USAGE_MODE,
    CP_DEW_POINT,
		CP_MOD_STAT
}E_CONTROL_PARAMS;

typedef enum _systemOptions
{
    E_NONE_SYS_OPTION,
    E_UNI_SYS_OPTION,
    E_DUO_SYS_OPTION,
    E_TRIO_SYS_OPTION,
    E_QUAD_SYS_OPTION
}E_SYS_OPTIONS;


typedef enum _displayStatus
{
	S_DP_NONE,
	S_REQUEST_BUF_INFO,
	S_PROCESS_INFO,
	S_SEND_MESSAGE,
        S_UPDATE_DISPLAY,
        S_COM_TIMEOUT
}E_DISPLAY_STATUS;

typedef enum _returncode
{
	E_RETURN_EXIT,
    E_RETURN_CONFIRM,
	E_RETURN_CANCEL
}E_RETURN_CODE;

typedef enum _displayCommands
{
    E_CMD_NONE,
    E_CMD_REQ_BUF_INFO,
    E_CMD_REQ_BUF_CONTENT,
    E_CMD_KEYB_DISPLAY,
    E_CMD_SET_DISPLAY,
    E_CMD_CLEAR_KEYB_DISP,
    E_CMD_CLEAR_SET_DISP,
    E_CMD_CLEAR_PV_DISP,
    E_CMD_PV_DISPLAY,
    E_CMD_LOAD_KEYB,
    E_CMD_UPDATE_STATUS,
    E_CMD_LOAD_MAIN_MENU,
    E_CMD_DIM_DISPLAY,
    E_CMD_RESTORE_DISP_BRIGHTNESS,
    E_CMD_LOAD_SYSSTAT_VIEW,
    E_CMD_UPDATE_SYS_STATUS,
    E_CMD_SEND_MESSAGE,
    E_CMD_SET_ACTIVE_VIEW,
    E_CMD_CLOSE_ACTIVE_VIEW,
    E_CMD_NEW_DATA,
    E_CMD_NEW_EVENT

}E_DISPLAY_CMDS;

typedef enum _MainViewsFieldID
{
    E_MV_SET_TEMP,
    E_MV_UNI_TEMP_1,
    E_MV_DUO_TEMP_1,
    E_MV_DUO_TEMP_2,
    E_MV_QUAD_TEMP_1,
    E_MV_QUAD_TEMP_2,
    E_MV_QUAD_TEMP_3,
    E_MV_QUAD_TEMP_4
}E_MV_FIELDID;

typedef enum _DisplayFieldID
{
    E_SYS_VERSION,
    E_SYS_MODEL,
    E_CLOCK_DATE_TIME,
    E_UNI_TEMP_1,
    E_TEMP_1,
    E_TEMP_2,
    E_QUAD_TEMP_1,
    E_QUAD_TEMP_2,
    E_QUAD_TEMP_3,
    E_QUAD_TEMP_4,
    E_STATUS_TEXT,
    E_ERROR_TEXT,
    E_STATUS_MODE,
    E_SET_TEMP,
    E_SYS_INFO,
    E_SYS_VALUE,
    E_SYS_TEMP
}E_DISPLAY_FIELDID;


typedef enum _DisplayView
{
	E_INIT_VIEW,
	E_MAIN_VIEW_UNI,
	E_MAIN_VIEW_DUO,
	E_MAIN_VIEW_TRIO,
	E_MAIN_VIEW_QUAD,
	E_KEYB_VIEW_NUM,
	E_KEYB_VIEW_ANUM,
        E_DIAG_VIEW,
        E_SYSSTAT_VIEW,
	E_CONFIG_VIEW

} E_DISPLAY_VIEW;

typedef struct _ExecuteInfo
{
    E_DISPLAY_CMDS cmd;
    E_DISPLAY_VIEW vId;
    ViewObject *ActiveView;
    ViewObject *parent;
    union
    {
      char *msg;
      float *fd;
    }data;
    u8 len;
}CALLBACK_EXCUTE_INFO;


typedef enum _systemEvents
{
    E_CHUCK_COUNT_EVENT,
    E_CHUCK_SELECT_EVENT,
    E_SET_TEMP_EVENT,
    E_PURGE_EVENT,
    E_DEFROST_EVENT
}E_SYS_EVENTS;

typedef struct _EventInfo
{
    E_SYS_EVENTS event;
    float fdata;
    int option;
}SYS_EVENT_INFO;



#define MAX_VIEWS 9



/* Field command format: */
/* define fore and background colors, Font number, text command: (ZC=centered,ZL=Left, and ZR=Right adjusted), */
 /*   X,Y coordinates. */
 /* Colors: 1=BLACK, 2=BLUE, 3=RED, 4=GREEN,5=CYAN,6=MEGENTA,7=YELLOW,8=WHITE */
 /*               9=DARK GRAY,10=ORANGE,11=PINK,12=VIOLET,13=LIGHT GREEN,14=VERY LIGHT GREEN */
 /*              15=LIGHT BLUE, 16=LIGHT GRAY */

#define MAX_FIELDS 17  // always add or reduce this count
#define FIELD_COUNT 3

/* Main Views updatable fields */
#define MAX_MV_FIELDS 8
static const char *MVS_DisplayFields[MAX_MV_FIELDS][FIELD_COUNT]=
{
    {"#FZ8,2","#ZF9","#ZC90,340"},  /* SET TEMP = WHITE on BLUE, Font=8,x= y= */
    {"#FZ3,1","#ZF9","#ZC162,123"}, 	/* UNI TEMP 1= RED on BLACK, Font=9,x= y= Single */
    {"#FZ3,1","#ZF9","#ZC162,90"}, 	/* #ZC162,90 TEMP 1= RED on BLACK, Font=9,x= y= */
    {"#FZ3,1","#ZF9","#ZC162,155"},  /* #ZC162,155 TEMP 2= RED on BLACK, Font=9,x= y= */
    {"#FZ3,1","#ZF6","#ZL16,107"}, 	/* TEMP_Q 1= RED on BLACK, Font=9,x= y= */
    {"#FZ3,1","#ZF6","#ZL16,172"},  /* TEMP_Q 2= RED on BLACK, Font=9,x= y= */
    {"#FZ3,1","#ZF6","#ZL147,107"}, 	/* TEMP_Q 3= RED on BLACK, Font=9,x= y= */
    {"#FZ3,1","#ZF6","#ZL147,172"}  /* TEMP_Q 4= RED on BLACK, Font=9,x= y= */
};

static const char *DIAG_DisplayFields[5][FIELD_COUNT]=
{
    {"#FZ4,2","#ZF5","#ZL175,120"},  /* SET TEMP = GREEN on BLUE, Font=8,x= y= */
    {"#FZ4,2","#ZF6","#ZL64,78"},  /* Status info = GREEN on BLUE, Font=8,x= y= */
    {"#FZ4,2","#ZF5","#ZL175,410"},  /* Compressor = GREEN on BLUE, Font=8,x= y= */
    {"#FZ3,2","#ZF6","#ZL64,78"},  /* ERROR = RED on BLUE, Font=8,x= y= */
    {"#FZ8,9","#ZF5","#ZC196,58"}    /* VERSION = WHITE on GRAY, Font=5,x=210 y=90 */
};

static const char *DisplayFields[MAX_FIELDS][FIELD_COUNT]=
 {
   {"#FZ8,9","#ZF5","#ZC196,58"},    /* VERSION = WHITE on GRAY, Font=5,x=210 y=90 */
   {"#FZ8,9","#ZF5","#ZC210,130"},  /* MODEL = WHITE on GRAY, Font=5,x=210 y=130 */
   {"#FZ8,9","#ZF5","#ZC250,130"},	 /* CLOCK = WHITE on GRAY, Font=5,x=250 y=130 */
   {"#FZ3,1","#ZF9","#ZC162,123"}, 	/* UNI TEMP 1= RED on BLACK, Font=9,x= y= Single */
   {"#FZ3,1","#ZF9","#ZL68,90"}, 	/* #ZC162,90 TEMP 1= RED on BLACK, Font=9,x= y= */
   {"#FZ3,1","#ZF9","#ZL68,155"},  /* #ZC162,155 TEMP 2= RED on BLACK, Font=9,x= y= */
   {"#FZ3,1","#ZF9","#ZC162,90"}, 	/* TEMP_Q 1= RED on BLACK, Font=9,x= y= */
   {"#FZ3,1","#ZF9","#ZC162,155"},  /* TEMP_Q 2= RED on BLACK, Font=9,x= y= */
   {"#FZ3,1","#ZF9","#ZC162,90"}, 	/* TEMP_Q 3= RED on BLACK, Font=9,x= y= */
   {"#FZ3,1","#ZF9","#ZC162,155"},  /* TEMP_Q 4= RED on BLACK, Font=9,x= y= */
   {"#FZ4,1","#ZF6","#ZL20,255"},  /* STATUS TEXT= GREEN on BLACK, Font=8,x= y= */
   {"#FZ3,1","#ZF6","#ZL20,255"},  /* ERROR TEXT= RED on BLACK, Font=8,x= y= */
   {"#FZ4,1","#ZF11","#ZC235,250"},  /* STATUS MODE= GREEN on BLACK, Font=9,x= y= */
   {"#FZ8,2","#ZF9","#ZC90,350"},  /* SET TEMP = WHITE on BLUE, Font=8,x= y= */
   {"#FZ4,2","#ZF6","#ZL110,78"},  /* System status info = GREEN on BLUE, Font=8,x= y= */
   {"#FZ2,8","#ZF5","#ZL175,120"},  /* System status value = WHITE on BLUE, Font=8,x= y= */
   {"#FZ2,8","#ZF5","#ZL70,310"}  /* System Temp 1 -4 ,5-8 value = WHITE on BLUE, Font=8,x= y= */
};
/* clear fields uses Macros to clear the fields. The macros: 191 - 209 */
static const char *ClearFields[MAX_FIELDS][1]=
{
    {""},									/* None for Version */
    {""},									/* None for Model */
    {""},									/* None for Clock */
    {"#MN191"},			/* clear TEMP UNI 1 */
    {"#MN191"},			/* clear TEMP 1 */
    {"#MN192"},			/* clear TEMP 2 */
    {"#MN191"},			/* clear TEMP 1 */
    {"#MN192"},			/* clear TEMP 2 */
    {"#MN191"},			/* clear TEMP 3 */
    {"#MN192"},			/* clear TEMP 4 */
    {"#MN193"},			/* clear Status Text */
    {"#MN193"},			/* clear Error Text */
    {"#MN194"},			/* clear Status mode */
    {"#MN195"},			/* clear set temp. field */
    {""},			/* clear set system status info */
    {""},			/* clear set system status value */
    {""}			/* clear set system status temp */
};

static const char *ClearFields2[MAX_FIELDS][2]=
{
    {"",""},									/* None for Version */
    {"",""},									/* None for Model */
    {"",""},									/* None for Clock */
    {"#FZ3,1","#MN191"},			/* clear TEMP 1 */
    {"#FZ3,1","#MN191"},			/* clear TEMP 1 */
    {"#FZ3,1","#MN192"},			/* clear TEMP 2 */
    {"#FZ3,1","#MN191"},			/* clear TEMP 1 */
    {"#FZ3,1","#MN192"},			/* clear TEMP 2 */
    {"#FZ3,1","#MN191"},			/* clear TEMP 3 */
    {"#FZ3,1","#MN192"},			/* clear TEMP 4 */
    {"#FZ4,1","#MN193"},			/* clear Status Text */
    {"#FZ4,1","#MN193"},			/* clear Error Text */
    {"#FZ4,1","#MN194"},			/* clear Status mode */
    {"#FZ8,2","#MN195"},			/* clear set temp. field */
    {"",""},			        /* System status info */
    {"",""},			        /* System status value */
    {"",""},			        /* System status value */
};

// Select Menus
static const char *DisplayViews[MAX_VIEWS][1]=
{
  {"#MN000"},   /* Initialization view */
  {"#MN240"},   /* Main View UNI */
  {"#MN241"},   /* Main View DUO */
  {"#MN242"},   /* Main View TRIO */
  {"#MN242"},   /* Main View Quad*/
  {"#MN243"},   /* KEYBoard */
  {"#MN244"},   /* Keyboard Alphanumeric */
  {"#MN245"},    /* System status view */
  {"#MN246"}    /* System status view */

};

/**********************************************
 * For Systemstatus display
 *============================================*/
#define STAT_X_OFFSET 139
#define STAT_Y_OFFSET 30     /* line below */

#endif //__CDDEF_H
