/*******************************************************************************
* File Name          : probercmds.cpp
* Author             : Khaukha-Mabinda Paddy
* Date First Issued  : 25/11/2009 : Version 1.0
* Description        : Prober command set Class
********************************************************************************
* History:
* 25/11/2009 : Version 1.0
********************************************************************************
* 07/02/2012 : Version 1.01 Author Khaukha-Mabinda Paddy
* Changes:
*  1. Changes to SetControlRange. Values of the type SR+05-05/SR+5-5/SR+5-05/SR+05-5
*
*
*********************************************************************************/

#include "91x_type.h"

#include "lcddefs.h"
#include "probercmds.h"
#include "sysinit.h"
#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "../Toolbox/Toolbox.h"

CMD_SET_OPTION ProberCmdSet::m_cmdSetOption = E_TSK_OPTION;
int  ProberCmdSet::m_ControlStatus = 0;
float ProberCmdSet::m_Rangeneg = -1.2;
float ProberCmdSet::m_Rangepos = +1.2;
float ProberCmdSet::m_RevOffset = 0.0;
int ProberCmdSet::m_ErrorCode = 0;
#define MAX_CMD_COUNT 23


/*******************************************************************************
* Method Name  	 : Class Constructor
* Description    : Initializes the ProberCmdSet object
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
ProberCmdSet::ProberCmdSet( CEventManager* pEventManager )
{
    m_EventManager = pEventManager;
    strcpy( m_PCmds[0].cmd, "ST"); m_PCmds[0].func = ProberCmdSet::SetTemperature;
    strcpy( m_PCmds[1].cmd, "SR"); m_PCmds[1].func = ProberCmdSet::SetControlRange;
    strcpy( m_PCmds[2].cmd, "SL"); m_PCmds[2].func = ProberCmdSet::SetKeyLock;
    strcpy( m_PCmds[3].cmd, "SH"); m_PCmds[3].func = ProberCmdSet::SetHold;
    strcpy( m_PCmds[4].cmd, "SO"); m_PCmds[4].func = ProberCmdSet::SetOperationMode;
    strcpy( m_PCmds[5].cmd, "SU"); m_PCmds[5].func = ProberCmdSet::SetUsageMode;
    strcpy( m_PCmds[6].cmd, "SV"); m_PCmds[6].func = ProberCmdSet::SetRevisionTemperature;
    strcpy( m_PCmds[7].cmd, "SMS");m_PCmds[7].func = ProberCmdSet::SetModuleStatus;
    strcpy( m_PCmds[8].cmd, "RC"); m_PCmds[8].func = ProberCmdSet::GetChuckTemperature;
    strcpy( m_PCmds[9].cmd, "RE"); m_PCmds[9].func = ProberCmdSet::GetErrorCode;
    strcpy( m_PCmds[10].cmd, "RT"); m_PCmds[10].func = ProberCmdSet::GetSetTemperature;
    strcpy( m_PCmds[11].cmd, "RI"); m_PCmds[11].func = ProberCmdSet::GetSystemInfo;
    strcpy( m_PCmds[12].cmd, "RR"); m_PCmds[12].func = ProberCmdSet::GetControlRange;
    strcpy( m_PCmds[13].cmd, "RL"); m_PCmds[13].func = ProberCmdSet::GetKeyLock;
    strcpy( m_PCmds[14].cmd, "RH"); m_PCmds[14].func = ProberCmdSet::GetHoldStatus;
    strcpy( m_PCmds[15].cmd, "RO"); m_PCmds[15].func = ProberCmdSet::GetOperationMode;
    strcpy( m_PCmds[16].cmd, "RF"); m_PCmds[16].func = ProberCmdSet::GetDewPoint;
    strcpy( m_PCmds[17].cmd, "Rd"); m_PCmds[17].func = ProberCmdSet::GetDewPointRd;
    strcpy( m_PCmds[18].cmd, "RU"); m_PCmds[18].func = ProberCmdSet::GetUsageMode;
    strcpy( m_PCmds[19].cmd, "RD"); m_PCmds[19].func = ProberCmdSet::GetDewPointStatus;
    strcpy( m_PCmds[20].cmd, "Rc"); m_PCmds[20].func = ProberCmdSet::GetChuckTemperatureHU;
    strcpy( m_PCmds[21].cmd, "RMS"); m_PCmds[21].func = ProberCmdSet::GetModuleStatus;
    strcpy( m_PCmds[22].cmd, "RM"); m_PCmds[22].func = ProberCmdSet::GetMaxMin;
    
    m_cmdCount = 23;    // set MAX_CMD_COUNT to this value.
    m_HoldMode = 0;
    m_ErrorCode = 0;
    m_SetTemp = 25.0;
    m_RevOffset = 0;
   
}
/*******************************************************************************
* Method Name  	 : SetProberCmdSet
* Description    : Initializes the ProberCmdSet object with a Prober Option
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void ProberCmdSet::SetProberCmdSet(CMD_SET_OPTION cso)
{
	m_cmdSetOption = cso;
}
/*******************************************************************************
* Method Name  	 : GetProberCmdSet
* Description    : Returns the current Prober Option
*******************************************************************************/
CMD_SET_OPTION ProberCmdSet::GetProberCmdSet( void )
{
	return m_cmdSetOption;
}

/**
Init dient zum registrieren der Event- Handler
*/
void ProberCmdSet::Init()
{
    m_EventManager->AddEventHandler( CEventNames::set_hold_mode, ProberCmdSet::set_hold_modeEventWrapper, this );    
    m_EventManager->AddEventHandler( CEventNames::set_temp1_changed, ProberCmdSet::SetTempEventWrapper, this );
    m_EventManager->AddEventHandler( CEventNames::temp_1_comp, ProberCmdSet::ActTempEventWrapper, this );
    m_EventManager->AddEventHandler( CEventNames::NEW_PORB_ERROR, ProberCmdSet::SetErrorCodeEventWrapper, this );
    m_EventManager->AddEventHandler( CEventNames::set_limits_1, ProberCmdSet::SetTempLimitsEventWrapper, this );
}

/*******************************************************************************
* Method Name  	 : Class destructor
* Description    :
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
ProberCmdSet::~ProberCmdSet()
{

}

/********************************************************************************************
* Method Name  	 : GenerateResponse
* Description    : returns a reponse for Set commands and negative paramsonse in case
+				   a command or request is not invalid.
* Input          : 
*       *params  - point to a char buffer that holds the message to be sent back to the Prober 
*       ok       - boolean value indicating whether the response is positive or negative.
*                  true means a positive response is sent back.
* Output         :
        *params  - message to be sent back to the Prober
* Return         : length of message
************************************************************************************************/
u8 ProberCmdSet::GenerateResponse(char *params, bool ok)
{
    u8 len = 0;
    
    switch(m_cmdSetOption)
    {
    
        case E_TSK_OPTION:
            if(ok)
                params[0] = 0x06;
            else
                params[0] = 0x18;
                len = 1;
        break;
        
        case E_TELP8_OPTION:
            if(ok)
            {
                params[0] = 'O';
                params[1] = 'K';
                len = 2;
            }
            else
            {
                params[0]= '?';
                len = 1;
            }
        break;
        
        
        case E_TELP12_OPTION:
            if(ok)
            {
                params[0] = 'O';
                params[1] = 'K';
                len = 2;
            }
            else
            {
                params[0]= '?';
                len = 1;
            }
        break;
        
        case E_EG_OPTION:
            if(ok)
                params[0] = 'Y';
            else
                params[0] = 'N';
            len = 1;
        break;
    }
    
    return len;

}
/********************************************************************************
* Method Name  	 : formatToASCII
* Description    : formats an integer value to ASCII
+
* Input          : 
*            val  - integer value to be converted and formatted to ASCII
*            buf  - buffer to hold the converted string
*            len  - number of significant poistions
* Output         :  
*        buf     -  ASCII string in buf
* Return         : None
*******************************************************************************/
void ProberCmdSet::formatToASCII(int val, char *buf, u8 len )
{
    char p[8];
    char format[] = "%0+5d";
    format[3] = len + 0x30;
    if( val > 0)
    {
        sprintf(&buf[0],format, val);
    }
    else
    {
        len = (len > 6) ? 6: len;
        strncpy(&buf[0],"-00000",len);
        int i = sprintf(&p[0],"%d", val);
        len++;
        strncpy(&buf[len-i],&p[1],i-1);
    }
}

/*******************************************************************************
* Method Name  	 : SetTempEvent
* Description    : sets the member variable m_setTemp with a value passed in f
+
* Input          : 
            float f - new Set Temperature
* Output         : None
* Return         : None
*******************************************************************************/

void ProberCmdSet::SetTempEvent( float f )
{
     m_SetTemp = f;
}

void ProberCmdSet::SetTempLimitsEvent( _set_limits_EventArgument a )
{
	m_MaxTemp = a.limitMax;
	m_MinTemp = a.limitMin;
}

/*******************************************************************************
* Method Name  	 : SetTemperature
* Description    : reads the new temperature and stores it in the internal buffer
+
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::SetTemperature(char *params, float* fdata, void * par, void* pObject)
{
    u8 len;
    
    float f = atof(&params[0]) / 10.0;
    
    if ( f < ((ProberCmdSet*)pObject)->m_MinTemp )
        f = ((ProberCmdSet*)pObject)->m_MinTemp;
    if( f > ((ProberCmdSet*)pObject)->m_MaxTemp )
      f = ((ProberCmdSet*)pObject)->m_MaxTemp;
 
    _event<float> e("aggregate", CEventNames::set_temp1_changed, f );
     ((ProberCmdSet*)(pObject))->m_EventManager->RaiseEvent(e);  
      fdata[CP_OP_MODE] = 1; // set Operation Mode to  Normal
      *((int*)par) = 1;
        
     m_RevOffset = 0;
     
    // We always send a positive feedback, otherwise some probers would go into communication error state
    len = GenerateResponse(params,true);
    
    return len;
}
/*******************************************************************************
* Method Name  	 : SetRevisionTemperature
* Description    : reads the new temperature offsset and raises an event
+
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::SetRevisionTemperature(char *params, float* fdata, void * par, void* pObject)
{
    u8 len;
    
    m_RevOffset = atof(&params[0]) / 10.0;
    if( m_RevOffset > 10.0 )
     m_RevOffset = 10.0;
    else if(m_RevOffset < -10 )
     m_RevOffset = -10.0;       
    

    fdata[CP_OP_MODE] = 1; // set Operation Mode to  Normal
    *((int*)par) = 1;
    
    // We always send a positive feedback, otherwise some probers would go into communication error state
    len = GenerateResponse(params,true);
    
    return len;
}


/*******************************************************************************
* Method Name  	 : SetKeyLock
* Description    : reads the new Lock code and stores it in the internal buffer
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::SetKeyLock(char *params, float* fdata, void * par, void* pObject)
{
    float f = atof(&params[0]);
    fdata[CP_KEY_LOCK] = f;
    u8 len = GenerateResponse(params,true);
    
    _event<int> e( "ProberCmds", CEventNames::key_lock_symbol, (int)f);
    ((ProberCmdSet*)pObject)->m_EventManager->RaiseEvent(e);
    
    return len;
}
/*******************************************************************************
* Method Name  	 : SetHold
* Description    : reads the new range and stores it in the internal buffer
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
void ProberCmdSet::set_hold_modeEvent( bool b )
{
  m_HoldMode = b;
}

u8 ProberCmdSet::SetHold(char *params, float* fdata, void * par, void* pObject)
{
    _event<bool> e( "ProberCmds", CEventNames::set_hold_mode, params[0] == '1' );
    ((ProberCmdSet*)pObject)->m_EventManager->RaiseEvent(e);
    u8 len = GenerateResponse(params,true);    
    return len;
}

/*******************************************************************************
* Method Name  	 : SetControlRange
* Description    : reads the new range and stores it in the internal buffer
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
/*
u8 ProberCmdSet::SetControlRange(char *params, float* fdata, void * par, void* pObject)
{
    char cTemp[3];
    memcpy( cTemp, params, 3 );
    float f = atof(cTemp);
    fdata[CP_RANGE_MAX] = f / 10.0;
    f = atof(&params[3]);
    fdata[CP_RANGE_MIN] = f / 10.0;
    u8 len = GenerateResponse(params,true);

    return len;
}
*/

/*******************************************************************************
* Method Name  	 : SetControlRange
* Description    : reads the new range and stores it in the internal buffer
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*
* Due to how different probers set ready width that is less than 1�C, this 
* Routine has to consider all possible combinations.
* Expected: SR+05-05
* Possible combinations: SR+5-5, SR+5-05, SR05-5
*******************************************************************************/
u8 ProberCmdSet::SetControlRange(char *params, float* fdata, void * par, void* pObject)
{
    int index = 0;
    int i = 0;
    u8 len = 0;
    
    while( (params[index] != 0x0D)&&(params[index] != 0x0A) )
    {
        if( params[index] == '-')
            i= index;
        
        index++;
        
        if( index > 6 ) // longest string is SR+12-12 =>+12-12
            break;
    }
    if(( i > 0)&&( (params[0]=='+')&&((index==4)||(index==5)||(index==6)) ) )
    {
        params[i] = 0;
        params[index] = 0;
        float fpositive = atof(&params[0]);
        float fnegative = atof(&params[i+1]); 
 
        m_Rangepos =  fpositive/10.0;
        m_Rangeneg =  fnegative/-10.0;
        
        fdata[CP_RANGE_MAX] = m_Rangepos;
        fdata[CP_RANGE_MIN] = m_Rangeneg;
         
        len = GenerateResponse(params,true);
    }
    else
        len = GenerateResponse(params,false);
    
    return len;
}
/*******************************************************************************
* Method Name    : SetProberReadySignal
* Description    : Set the Prober Ready Signal
*
* Input          - float fPV: Present Value (Chucktemp), float fSV: Set Value (Solltemp)
* Output         : None
* Return         : None
*
*
*******************************************************************************/
void ProberCmdSet::SetProberReadySignal(float fPV, float fSV)
{
   float diff =  fPV - fSV;
   if( (diff >= m_Rangeneg) && (diff <= m_Rangepos) )
    {
       m_ControlStatus = 0;
    }
    else 
    {
        if( diff < 0 )
            m_ControlStatus = 1;
        else 
           m_ControlStatus = 2;
    }
}

/*******************************************************************************
* Method Name  	 : SetOperationsMode
* Description    : Set a new Operation Mode
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*
* Comment:
* Possible Operation Modes are: 1 = Normal Mode, 2 = Standby Mode, 3 = Defrost Mode.
*******************************************************************************/
u8 ProberCmdSet::SetOperationMode(  char *params, float* fdata, void * par, void* pObject)
{
    int i = atoi(&params[0]);
    u8 len = GenerateResponse(params,true);
    
    switch( i ){
        case 2:
            fdata[CP_SET_TEMP] = 25.0;
            *((int*)par) = 2;
            fdata[CP_OP_MODE] = 2;
        break;
        
        case 3:
            *((int*)par) = 10;
            fdata[CP_OP_MODE] = 3;
        break;

        default:
            *((int*)par) = 1;
            fdata[CP_OP_MODE] = 1;
        break;
    }

    return len;
}

/*******************************************************************************
* Method Name  	 : SetUsageMode
* Description    : Sets the Usage Mode of the Controller
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*
* Comment:
* This Functionality is implemented for backword compatibility. The Usage Mode
* was supposed to be High of Low Temperature Mode. Controller capabel low Temperature
* are supposed to support the Prock lock functionality by temperature below +14.5�C
* due to DEW on chucks
*******************************************************************************/
u8 ProberCmdSet::SetUsageMode(  char *params, float* fdata, void * par, void* pObject)
{
    float f = atof(&params[0]);
    fdata[CP_USAGE_MODE] = f;
    u8 len = GenerateResponse(params,true);
    
    return len;
}

/*******************************************************************************
* Method Name  	 : SetModuleStatus
* Description    : Sets different Module States of the Controller
*
* Input          : params, pointer to command parameters
*		 : fdata, pointer to internal buffer for storing current values of controller variables 
*		 : par, pointer to a buffer for storing function results
* Return         : length of message to transfer
*
* Comment:
* This command is needed for the TELP12XL prober, which wants to switch
* power, chuck heating and run status on and off.
*******************************************************************************/
u8 ProberCmdSet::SetModuleStatus( char *params, float* fdata, void * par, void* pObject )
{	
		// Power on/off flag
	if (params[0] == '1') ((ProberCmdSet*)pObject)->m_ModStat |= MOD_STAT_PWR;
		else  ((ProberCmdSet*)pObject)->m_ModStat &= ~MOD_STAT_PWR;

		// Heater on/off flag
	if (params[1] == '1') ((ProberCmdSet*)pObject)->m_ModStat |= MOD_STAT_HEAT;
		else  ((ProberCmdSet*)pObject)->m_ModStat &= ~MOD_STAT_HEAT;

		// Run on/off flag
	if (params[2] == '1') ((ProberCmdSet*)pObject)->m_ModStat |= MOD_STAT_RUN;
		else  ((ProberCmdSet*)pObject)->m_ModStat &= ~MOD_STAT_RUN;

	// Raise event to inform all modules
	_event<char> e("aggregate", CEventNames::mod_stat_changed, ((ProberCmdSet*)pObject)->m_ModStat );
	((ProberCmdSet*)(pObject))->m_EventManager->RaiseEvent(e);                  

	u8 len = GenerateResponse(params,true);
    
    	return len;
}

/*******************************************************************************
* Method Name  	 : GetChuckTemperature
* Description    : Reads the binary value and formats it to 5 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
void ProberCmdSet::ActTempEvent( float f )
{
     m_ActTemp = f;
}
u8 ProberCmdSet::GetChuckTemperature( char *params, float* fdata, void * par, void* pObject)
{
    u8 len = 6;
    if( params[0] == 'T' || params[0] == 'P' || params[0] == 'R' )
    {
        //Sonderfall, ist der RCR Befehl, sommit raus hier
        return 0;
    }
    
    int temp = (int)(((ProberCmdSet*)(pObject))->m_ActTemp * 10);
    
    formatToASCII(temp, &params[1],5);
    
    params[0] = 'C';
    
    return len;
}
/*******************************************************************************
* Method Name  	 : GetChuckTemperatureHU
* Description    : Reads the binary value and formats it to 6 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::GetChuckTemperatureHU( char *params, float* fdata, void * par, void* pObject)
{
    u8 len = 7;
    
    if( params[0] == 'T' || params[0] == 'P' || params[0] == 'R' )
    {
        //Sonderfall, ist der RCR Befehl, sommit raus hier
        return 0;
    }
  
    int temp = (int)(((ProberCmdSet*)(pObject))->m_ActTemp * 100);
    
    formatToASCII(temp, &params[1],6);
    
    params[0] = 'C';
    
    return len;
}
/*******************************************************************************
* Method Name  	 : GetChuckTemperature
* Description    : Reads the binary value and formats it to 3 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
/**
    EventHandler
*/
void ProberCmdSet::SetErrorCodeEvent( int i )
{
    m_ErrorCode = i;
}

u8 ProberCmdSet::GetErrorCode(char *params,  float* fdata, void * par, void* pObject)
{
    u8 len = 4;
    int temp = (int)(((ProberCmdSet*)(pObject))->m_ErrorCode);
    formatToASCII(temp, &params[0],4);
    params[0] = 'E';

    return len;
}

/*******************************************************************************
* Method Name  	 : GetSetTemperature
* Description    : Reads the binary value and formats it to 3 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::GetSetTemperature(char *params,  float* fdata, void * par, void* pObject)
{
    u8 len = 6;

    int temp = (int)(((ProberCmdSet*)(pObject))->m_SetTemp * 10.0);
    formatToASCII(temp, &params[1],5);
    params[0] = 'T';

    return len;
}

/*******************************************************************************
* Method Name  	 : GetSystemInfo
* Description    : Reads the binary value and formats it to 3 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::GetSystemInfo(char *params,  float* fdata, void * par, void* pObject)
{
    u8 len = 2;
    params[0] = 'I';
    if( m_ErrorCode == 0)
         params[1] = (char)m_ControlStatus + 0x30;
    else
         params[1] = '8';
    return len;
}
/*******************************************************************************
* Method Name  	 : GetSystemInfoEx
* Description    : Reads the binary value and formats it to 3 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::GetSystemInfoEx(char *params,  float* fdata, void * par, void* pObject)
{
    u8 len = 2;

    params[0] = 'I';
    float diff = fdata[CP_CHUCK_TEMP] - fdata[CP_SET_TEMP];
    
    if( (diff >= fdata[CP_RANGE_MIN]) && (diff <= fdata[CP_RANGE_MAX]) )
    {
        fdata[CP_SYS_INFO] = 0;
    }
    else 
    {
        if( diff < 0 )
            fdata[CP_SYS_INFO] = 1;
        else 
            fdata[CP_SYS_INFO] = 2;
    }
        
    int temp = (int)(fdata[CP_SYS_INFO]);
    params[1] = (char)temp + 0x30;

    return len;
}


/*******************************************************************************
* Method Name  	 : EventHandler
* Description    : Sets the new Control Mode
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
void ProberCmdSet::SetControlStatus( int i )
{      
   m_ControlStatus = i;  
}
/*******************************************************************************
* Method Name  	 : GetControlRange
* Description    : Reads the binary value and formats it to 3 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::GetControlRange(char *params, float* fdata, void * par, void* pObject)
{
    u8 len = 7;

    int temp = (int)(fdata[CP_RANGE_MAX] * 10.0);
    params[0] = 'R';
    formatToASCII(temp, &params[1],3); // R12-12
    temp = (int)(fdata[CP_RANGE_MIN]*10.0);
    formatToASCII(temp, &params[4],3);

    return len;
}

/*******************************************************************************
* Method Name  	 : GetMaxMin
* Description    : Reads the max/min allowed chuck set temperature values 
*                  and formats them to 3 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::GetMaxMin(char *params, float* fdata, void * par, void* pObject)
{
    u8 len = 11;

    params[0] = 'M';

    int temp = (int)(SysInit::m_usersettings.ChuckTempMinLimit * 10.0);
		formatToASCII(temp, &params[1],5); // R12-12
		
    temp = (int)(SysInit::m_usersettings.ChuckTempMaxLimit * 10.0);
    formatToASCII(temp, &params[6],5);

    return len;
}

/*******************************************************************************
* Method Name  	 : GetKeyLock
* Description    : Reads the binary value and formats it to 3 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::GetKeyLock(char *params, float* fdata, void * par, void* pObject)
{
    u8 len = 2;

    int temp = (int)(fdata[CP_KEY_LOCK]) ;
    params[0] = 'L';
    params[1] = (char)temp + 0x30;

    return len;

}
/*******************************************************************************
* Method Name  	 : GetHoldStatus
* Description    : Reads the binary value and formats it to 3 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::GetHoldStatus(char *params, float* fdata, void * par, void* pObject)
{
    u8 len = 2;

    params[0] = 'H';
    params[1] = ((ProberCmdSet*)pObject)->m_HoldMode ? 0x31 : 0x30;

    return len;

}

/*******************************************************************************
* Method Name  	 : GetModuleStatus
* Description    : Gets different Module States of the Controller
*
* Input          : params, pointer to command parameters
*								 : fdata, pointer to internal buffer for storing current values of controller variables 
*								 : par, pointer to a buffer for storing function results
* Return         : length of message to transfer
*
* Comment:
* This command is needed for the TELP12XL prober, which wants to switch
* power, chuck heating and run status on and off.
*******************************************************************************/
u8 ProberCmdSet::GetModuleStatus( char *params, float* fdata, void * par, void* pObject )
{	
    	u8 len = 4;

	params[0] = 'S';

	// Power on/off flag
	if ( (((ProberCmdSet*)pObject)->m_ModStat & MOD_STAT_PWR) != 0x00 ) params[1] = '1';
	else params[1] = '0';

	// Heater on/off flag
	if ( (((ProberCmdSet*)pObject)->m_ModStat & MOD_STAT_HEAT) != 0x00 ) params[2] = '1';
	else params[2] = '0';

	// Run on/off flag
	if ( (((ProberCmdSet*)pObject)->m_ModStat & MOD_STAT_RUN) != 0x00 ) params[3] = '1';
	else params[3] = '0';
    
    	return len;
}
/*******************************************************************************
* Method Name  	 : GetOperationMode
* Description    : Reads the binary value and formats it to 3 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::GetOperationMode(char *params,float* fdata, void * par, void* pObject)
{
    u8 len = 2;

    int temp = (int)(fdata[CP_OP_MODE]) ;
    params[0] = 'O';
    params[1] = (char)temp + 0x30;


    return len;
}

/*******************************************************************************
* Method Name  	 : GetDewPoint
* Description    : Reads the binary value and formats it to 3 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::GetDewPoint(char *params,float* fdata, void * par, void* pObject)
{
    u8 len = 6;

    int temp = (int)(fdata[CP_DEW_POINT] * 10.0) ;
    formatToASCII(temp, &params[1],5);
    params[0] = 'F';


    return len;
}

/*******************************************************************************
* Method Name  	 : GetDewPointRd
* Description    : Reads the binary value and formats it to 3 significant digits
*                  Same as command RF, but named Rd, therefore we have to start answer
*                  with 'd' insteaf 'F'. 
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::GetDewPointRd(char *params,float* fdata, void * par, void* pObject)
{
    u8 len;

		len = GetDewPoint(params,fdata, par, pObject);	
    params[0] = 'd';


    return len;
}

/*******************************************************************************
* Method Name  	 : GetDewPointStatus
* Description    : Return of the Dewpoint tracking user choice. If the it is active
*                  1 is returned otherwise 0
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::GetDewPointStatus(char *params, float* fdata, void * par, void* pObject)
{
    u8 len = 2;

    params[0] = 'D';
    if( SysInit::m_usersettings.DewpointTrackingActive )
      params[1] = 0x31;
    else    
      params[1] = 0x30;

    return len;

}

/*******************************************************************************
* Method Name  	 : GetUsageMode
* Description    : Reads the binary value and formats it to 3 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::GetUsageMode(char *params,float* fdata, void * par, void* pObject)
{
    u8 len = 2;

    int temp = (int)(fdata[CP_USAGE_MODE]) ;
    params[0] = 'U';
    params[1] = (char)temp + 0x30;


    return len;
}

/*******************************************************************************
* Method Name  	 : GetOperationMode
* Description    : Reads the binary value and formats it to 3 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSet::ProcessMessage(char cmd[4], char *params, float* fdata, void * par)
{
    u8 len = 0;
    bool found = false;
    if( m_cmdCount > MAX_CMD_COUNT )
       m_cmdCount = MAX_CMD_COUNT;
    
    for (int i = 0; i < m_cmdCount; i++)
    {
        if (strncmp (cmd, (const char *)&m_PCmds[i].cmd, strlen(m_PCmds[i].cmd)) == 0)
        {
            len = m_PCmds[i].func(&params[strlen(m_PCmds[i].cmd)-2],fdata, par, this );/* execute command function    */
            if( len > 0 )
            {
                found = true;
                break;
            }
        }
    }
    if( found == false )
    {
       len = GenerateResponse(params,false);          
    }
 
    return len;
}

/**
Konstruktor f�r die Cascade- Comm Klasse
*/
ProberCmdSetCascade::ProberCmdSetCascade( CEventManager* pEventManager ) : ProberCmdSet(pEventManager)
{
    strcpy( m_PCmds[m_cmdCount].cmd, "St"); m_PCmds[m_cmdCount++].func = ProberCmdSetCascade::SetTemperatureCenti;
    strcpy( m_PCmds[m_cmdCount].cmd, "SCI"); m_PCmds[m_cmdCount++].func = ProberCmdSetCascade::CreateCompTable;
    strcpy( m_PCmds[m_cmdCount].cmd, "SCP"); m_PCmds[m_cmdCount++].func = ProberCmdSetCascade::SetCompTableEntry;
    strcpy( m_PCmds[m_cmdCount].cmd, "SCS"); m_PCmds[m_cmdCount++].func = ProberCmdSetCascade::SaveCompTable;
    strcpy( m_PCmds[m_cmdCount].cmd, "SCC"); m_PCmds[m_cmdCount++].func = ProberCmdSetCascade::CloseCompTable;
    strcpy( m_PCmds[m_cmdCount].cmd, "SCT"); m_PCmds[m_cmdCount++].func = ProberCmdSetCascade::SelectCompTable;
    strcpy( m_PCmds[m_cmdCount].cmd, "Rc"); m_PCmds[m_cmdCount++].func = ProberCmdSetCascade::GetChuckTemperatureCenti;
    strcpy( m_PCmds[m_cmdCount].cmd, "Rt"); m_PCmds[m_cmdCount++].func = ProberCmdSetCascade::GetSetTemperatureCenti;
    strcpy( m_PCmds[m_cmdCount].cmd, "RCT"); m_PCmds[m_cmdCount++].func = ProberCmdSetCascade::GetCompTable;
    strcpy( m_PCmds[m_cmdCount].cmd, "RCP"); m_PCmds[m_cmdCount++].func = ProberCmdSetCascade::GetCompTableEntry;
    m_EditCompTable = -1;
}

/**
    Initialisierung der Cascade Klasse, f�gt weiter Event Handler ein
*/
void ProberCmdSetCascade::Init()
{
    ProberCmdSet::Init();
    m_EventManager->AddEventHandler( CEventNames::set_active_comp_table, ProberCmdSetCascade::set_active_comp_tableEventWrapper, this );
    m_EventManager->AddEventHandler( CEventNames::receive_table1, ProberCmdSetCascade::receive_table1EventWrapper, this );
    m_EventManager->AddEventHandler( CEventNames::receive_table2, ProberCmdSetCascade::receive_table2EventWrapper, this );
    m_EventManager->AddEventHandler( CEventNames::receive_table3, ProberCmdSetCascade::receive_table3EventWrapper, this );
    m_EventManager->AddEventHandler( CEventNames::send_table1, ProberCmdSetCascade::receive_table1EventWrapper, this );
    m_EventManager->AddEventHandler( CEventNames::send_table2, ProberCmdSetCascade::receive_table2EventWrapper, this );
    m_EventManager->AddEventHandler( CEventNames::send_table3, ProberCmdSetCascade::receive_table3EventWrapper, this );
    
}

/*******************************************************************************
* Method Name  	 : SetTemperatureCenti
* Description    : reads the new temperature and stores it in the internal buffer
+
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSetCascade::SetTemperatureCenti(char *params, float* fdata, void * par, void* pObject)
{
    u8 len;
    
    float f = atof(&params[0]) / 100.0;
    
    if ( f < ((ProberCmdSet*)pObject)->m_MinTemp )
            f = ((ProberCmdSet*)pObject)->m_MinTemp;
    if(f > ((ProberCmdSet*)pObject)->m_MaxTemp )
        f = ((ProberCmdSet*)pObject)->m_MaxTemp;

    _event<float> e("aggregate", CEventNames::set_temp1_changed, f );
    ((ProberCmdSetCascade*)(pObject))->m_EventManager->RaiseEvent(e);                  
    
    // We always send a positive feedback, otherwise some probers would go into communication error state
	  len = GenerateResponse(params,true);
    
    return len;
}

/*******************************************************************************
* Method Name  	 : CreateCompTable
* Description    : reads the new temperature and stores it in the internal buffer
+
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSetCascade::CreateCompTable(char *params, float* fdata, void * par, void* pObject)
{
    u8 len;
    ((ProberCmdSetCascade*)pObject)->m_EditCompTable = atoi(params) - 1;
    if( ((ProberCmdSetCascade*)pObject)->m_EditCompTable >= 0 && ((ProberCmdSetCascade*)pObject)->m_EditCompTable < 3 )
    {
        for( int i = 0; i < 20; i++ )
        {
            ((ProberCmdSetCascade*)pObject)->m_compTable[((ProberCmdSetCascade*)pObject)->m_EditCompTable][0][i] = 2222;
            ((ProberCmdSetCascade*)pObject)->m_compTable[((ProberCmdSetCascade*)pObject)->m_EditCompTable][1][i] = 2222;
        }
        len = GenerateResponse(&params[-1],true);    
    }
    else
    { 
        len = GenerateResponse(&params[-1],false);    
    }
    return len;
}

/*******************************************************************************
* Method Name  	 : SetCompTableEntry
* Description    : reads the new temperature and stores it in the internal buffer
+
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSetCascade::SetCompTableEntry(char *params, float* fdata, void * par, void* pObject)
{
    u8 len;
    int iPos = atoi( &params[0] );
    float fTemp = atof( &params[2] ) / 10.0;
    float fCorr = atof( &params[8] ) / 10.0;
    if( iPos >= 0 && iPos < 10 && ((ProberCmdSetCascade*)pObject)->m_EditCompTable >= 0 && ((ProberCmdSetCascade*)pObject)->m_EditCompTable < 3)
    {
        ((ProberCmdSetCascade*)pObject)->m_compTable[((ProberCmdSetCascade*)pObject)->m_EditCompTable][0][iPos] = fTemp;
        ((ProberCmdSetCascade*)pObject)->m_compTable[((ProberCmdSetCascade*)pObject)->m_EditCompTable][1][iPos] = fCorr;
        len = GenerateResponse(&params[-1],true);    
    }
    else{
        len = GenerateResponse(&params[-1],false);            
    }
    return len;
}

/*******************************************************************************
* Method Name  	 : SaveCompTable
* Description    : reads the new temperature and stores it in the internal buffer
+
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSetCascade::SaveCompTable(char *params, float* fdata, void * par, void* pObject)
{
    u8 len;
    if( ((ProberCmdSetCascade*)pObject)->m_EditCompTable >= 0 & ((ProberCmdSetCascade*)pObject)->m_EditCompTable < 3 )
    {
        doublearray_bubblesort( 
                               ((ProberCmdSetCascade*)pObject)->m_compTable[((ProberCmdSetCascade*)pObject)->m_EditCompTable][0],
                               ((ProberCmdSetCascade*)pObject)->m_compTable[((ProberCmdSetCascade*)pObject)->m_EditCompTable][1]
                               );
        _event<void*> e( "ProberCmdSetCascade", (CEventNames::_event_name)(CEventNames::send_table1 + ((ProberCmdSetCascade*)pObject)->m_EditCompTable), ((ProberCmdSetCascade*)pObject)->m_compTable[((ProberCmdSetCascade*)pObject)->m_EditCompTable]);
        ((ProberCmdSetCascade*)pObject)->m_EventManager->RaiseEvent(e);
        _event<void*> e1( "ProberCmdSetCascade", (CEventNames::_event_name)(CEventNames::receive_table1 + ((ProberCmdSetCascade*)pObject)->m_EditCompTable), ((ProberCmdSetCascade*)pObject)->m_compTable[((ProberCmdSetCascade*)pObject)->m_EditCompTable]);
        ((ProberCmdSetCascade*)pObject)->m_EventManager->RaiseEvent(e1);
        len = GenerateResponse(&params[-1],true);    
    }
    else
    {
        len = GenerateResponse(&params[-1],false);    
    }
    return len;
}

/*******************************************************************************
* Method Name  	 : CloseCompTable
* Description    : reads the new temperature and stores it in the internal buffer
+
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSetCascade::CloseCompTable(char *params, float* fdata, void * par, void* pObject)
{
    ((ProberCmdSetCascade*)pObject)->m_EditCompTable = -1;
    u8 len = GenerateResponse(&params[-1],true);    
    return len;
}


/*******************************************************************************
* Method Name  	 : SelectCompTable
* Description    : Writes Compensation Table number
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
void ProberCmdSetCascade::set_active_comp_tableEvent( int i )
{
    m_ActiveCompTable = i;
}
u8 ProberCmdSetCascade::SelectCompTable(char *params, float* fdata, void * par, void* pObject)
{
    _event<int> e("ProberCommands", CEventNames::set_active_comp_table, atoi(params) );
    ((ProberCmdSetCascade*)(pObject))->m_EventManager->RaiseEvent(e);                  

    u8 len = GenerateResponse(&params[-1],true);
    
    return len;

}

/*******************************************************************************
* Method Name  	 : GetChuckTemperature
* Description    : Reads the binary value and formats it to 5 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSetCascade::GetChuckTemperatureCenti( char *params, float* fdata, void * par, void* pObject)
{
    u8 len = 7;
    
    int temp = (int)(((ProberCmdSetCascade*)(pObject))->m_ActTemp * 100);
    
    formatToASCII(temp, &params[1],6);
    
    params[0] = 'C';
    
    return len;
}


/*******************************************************************************
* Method Name  	 : GetSetTemperatureCenti
* Description    : Reads the binary value and formats it to 4 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSetCascade::GetSetTemperatureCenti(char *params,  float* fdata, void * par, void* pObject)
{
    u8 len = 7;

    int temp = (int)(((ProberCmdSetCascade*)(pObject))->m_SetTemp * 100.0);
    formatToASCII(temp, &params[1],6);
    params[0] = 'T';

    return len;
}

/*******************************************************************************
* Method Name  	 : GetOperationMode
* Description    : Reads the binary value and formats it to 3 significant digits
*
* Input          : None
* Output         : None
* Return         : length of message to transfer
*******************************************************************************/
u8 ProberCmdSetCascade::GetCompTable(char *params,float* fdata, void * par, void* pObject)
{
    u8 len = 3;
    
    params[-1] = 'C';
    params[0] = 'R';
    params[1] = ((ProberCmdSetCascade*)(pObject))->m_ActiveCompTable + 0x30;

    return len;
}

/**
Bearbeiten der Kompensationstabellen �ber die Schnittstelle
*/
void ProberCmdSetCascade::receive_table1Event( void * p){
  float *p_table[2];
  p_table[0] = p;
  p_table[1] = ((float*)p)+20;
  for (int i=0; i<2;i++)
  {
      for (int k=0; k<20; k++)
      {
          m_compTable[0][i][k] = *(p_table[i] + k); //Tabelle 1
      }
  }
}
void ProberCmdSetCascade::receive_table2Event( void * p){
  float *p_table[2];
  p_table[0] = p;
  p_table[1] = ((float*)p)+20;
  for (int i=0; i<2;i++)
  {
      for (int k=0; k<20; k++)
      {
          m_compTable[1][i][k] = *(p_table[i] + k); //Tabelle 1
      }
  }
}
void ProberCmdSetCascade::receive_table3Event( void * p){
  float *p_table[2];
  p_table[0] = p;
  p_table[1] = ((float*)p)+20;
  for (int i=0; i<2;i++)
  {
      for (int k=0; k<20; k++)
      {
          m_compTable[2][i][k] = *(p_table[i] + k); //Tabelle 1
      }
  }
}
u8 ProberCmdSetCascade::GetCompTableEntry(char *params,  float* fdata, void * par, void* pObject)
{
    u8 len = 15;
    int col = atoi(params);
    if( col > 9 || ((ProberCmdSetCascade*)pObject)->m_ActiveCompTable <= 0 || ((ProberCmdSetCascade*)pObject)->m_ActiveCompTable > 3)
    {
        return 0;
    }

    params[-1] = 'C';
    params[0] = 'P';
    params[1] = col + 0x30;
    params[2] = ';';
    int temp = (int)(((ProberCmdSetCascade*)pObject)->m_compTable[((ProberCmdSetCascade*)pObject)->m_ActiveCompTable-1][0][col] * 10.0);
    formatToASCII(temp, &params[3],5);
    temp = (int)(((ProberCmdSetCascade*)pObject)->m_compTable[((ProberCmdSetCascade*)pObject)->m_ActiveCompTable-1][1][col] * 10.0);
    params[8] = ';';
    formatToASCII(temp, &params[9],5);

    return len;
}