/******************** (C) ERS Electronic GmbH ********************
* File Name          : probercmds.h
* Author             : Khaukha-Mabinda Paddy
* Date First Issued  : 27/11/2009 : Version 1.0
* Description        : Prober commands Class
********************************************************************************
* History:
* 25/11/2009 : Version 1.0
*********************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __PROBERCMDS_H
#define __PROBERCMDS_H
#include "91x_type.h"

#include "../MailboxSystem/CEventManager.h"

typedef enum _commandsetoptions
{
	E_TSK_OPTION,
	E_TELP8_OPTION,
	E_TELP12_OPTION,
	E_EG_OPTION
}CMD_SET_OPTION;


typedef struct ProberCmds
{
		char  cmd[4];
		u8 (*func)(char *params,float* fdata, void * par, void* pObject );

}PROBER_CMDS;

/**
 * Definition of flag positions for Module Status */
#define MOD_STAT_PWR 	0x04
#define MOD_STAT_HEAT 0x02
#define MOD_STAT_RUN 	0x01

class ProberCmdSet
{


	public:
		ProberCmdSet( CEventManager* pEventManager );
		~ProberCmdSet();


	/* command functions */
		static void SetProberCmdSet(CMD_SET_OPTION cso);
		static CMD_SET_OPTION GetProberCmdSet( void );

		static u8 GenerateResponse(char *params, bool ok);
		static void formatToASCII(int val, char *buf, u8 len );

		static u8 SetTemperature(char *params, float* fdata, void * par, void* pObject);
            static u8 SetRevisionTemperature(char *params, float* fdata, void * par, void* pObject);
  		static u8 SetControlRange(char *params, float* fdata, void * par, void* pObject);
		static u8 SetKeyLock(char *params, float* fdata, void * par, void* pObject);
		static u8 SetHold(char *params, float* fdata, void * par, void* pObject);
		static u8 SetOperationMode(  char *params, float* fdata, void * par, void* pObject);
		static u8 SetUsageMode(  char *params, float* fdata, void * par, void* pObject);
		static u8 GetChuckTemperature( char *params, float* fdata, void * par, void* pObject);
		static u8 GetErrorCode(char *params,  float* fdata, void * par, void* pObject);
		static u8 GetSetTemperature(char *params, float* fdata, void * par, void* pObject);
                static u8 SetModuleStatus( char *params, float* fdata, void * par, void* pObject );
                // Requests
		static u8 GetSystemInfo(char *params, float* fdata, void * par, void* pObject);
		static u8 GetControlRange(char *params, float* fdata, void * par, void* pObject);
		static u8 GetKeyLock(char *params, float* fdata, void * par, void* pObject);
		static u8 GetHoldStatus(char *params, float* fdata, void * par, void* pObject);
		static u8 GetOperationMode(char *params,float* fdata, void * par, void* pObject);
		static u8 GetUsageMode(char *params,float* fdata, void * par, void* pObject);
		static u8 GetDewPoint(char *params,float* fdata, void * par, void* pObject);
		static u8 GetDewPointRd(char *params,float* fdata, void * par, void* pObject);
		static u8 GetDewPointStatus(char *params,float* fdata, void * par, void* pObject);
		static u8 GetChuckTemperatureHU( char *params, float* fdata, void * par, void* pObject);
            static u8 GetModuleStatus( char *params, float* fdata, void * par, void* pObject );
            static u8 GetMaxMin( char *params, float* fdata, void * par, void* pObject );
            u8 GetSystemInfoEx(char *params,  float* fdata, void * par, void* pObject);
            void SetControlStatus( int i );
            void SetProberReadySignal(float fPV, float fSV);    
            u8 ProcessMessage(char cmd[4], char *params, float* fdata, void * par);
            static float GetProberRevisionOffset(void){return m_RevOffset;};

	public:
            static CMD_SET_OPTION m_cmdSetOption;
            static int   m_ControlStatus;
            virtual void Init();
            //MB Event Handler
            static void set_hold_modeEventWrapper( void * pObject, bool b ){ ((ProberCmdSet*)pObject)->set_hold_modeEvent( b );};
            void set_hold_modeEvent( bool b );
            static void SetTempEventWrapper( void * pObject, float parameter){ ((ProberCmdSet*)pObject)->SetTempEvent(parameter);};
            void SetTempEvent( float );
            static void ActTempEventWrapper( void * pObject, float parameter){ ((ProberCmdSet*)pObject)->ActTempEvent(parameter);};
            void ActTempEvent( float );
            static void SetErrorCodeEventWrapper( void * pObject, int i){ ((ProberCmdSet*)pObject)->SetErrorCodeEvent(i);};
            void SetErrorCodeEvent( int i );
            static void SetTempLimitsEventWrapper( void * pObject, _set_limits_EventArgument a){ ((ProberCmdSet*)pObject)->SetTempLimitsEvent(a);};
            void SetTempLimitsEvent( _set_limits_EventArgument a );
                
						float m_MaxTemp;	// Maximal allowed set temperature
						float m_MinTemp;  // Minimal allowed set temperature
    
	protected:
        CEventManager* m_EventManager;
        float m_SetTemp;
        float m_ActTemp;
        static float m_RevOffset; 
        bool  m_HoldMode;
        static int   m_ErrorCode;
        static float m_Rangeneg;
        static float m_Rangepos;
	  char  m_ModStat;
         PROBER_CMDS m_PCmds[30];
        
        int m_cmdCount;



};

class ProberCmdSetCascade : public ProberCmdSet
{
    public:
        ProberCmdSetCascade( CEventManager* pEventManager );
        void Init();
        
	static u8 SetTemperatureCenti(char *params, float* fdata, void * par, void* pObject);
        static u8 CreateCompTable(char *params, float* fdata, void * par, void* pObject);
        static u8 SetCompTableEntry(char *params, float* fdata, void * par, void* pObject);
        static u8 SaveCompTable(char *params, float* fdata, void * par, void* pObject);
        static u8 CloseCompTable(char *params, float* fdata, void * par, void* pObject);
        static u8 SelectCompTable(char *params, float* fdata, void * par, void* pObject);
        static u8 GetChuckTemperatureCenti( char *params, float* fdata, void * par, void* pObject);
        static u8 GetSetTemperatureCenti(char *params, float* fdata, void * par, void* pObject);
        static u8 GetCompTable(char *params, float* fdata, void * par, void* pObject);
        static u8 GetCompTableEntry(char *params, float* fdata, void * par, void* pObject);
        //MB Event Handler
        static void set_active_comp_tableEventWrapper( void * pObject, int i){ ((ProberCmdSetCascade*)pObject)->set_active_comp_tableEvent(i);};
        void set_active_comp_tableEvent( int i );
        static void receive_table1EventWrapper( void * pObject, void* p){ ((ProberCmdSetCascade*)pObject)->receive_table1Event(p);};
        void receive_table1Event( void* p );
        static void receive_table2EventWrapper( void * pObject, void* p){ ((ProberCmdSetCascade*)pObject)->receive_table2Event(p);};
        void receive_table2Event( void* p );
        static void receive_table3EventWrapper( void * pObject, void* p){ ((ProberCmdSetCascade*)pObject)->receive_table3Event(p);};
        void receive_table3Event( void* p );

    protected:
        int m_ActiveCompTable;
        int m_EditCompTable;
        float m_compTable[3][2][20];

};

#endif // PROBERCMDS