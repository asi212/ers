/******************** (C) ERS Electronic GmbH ********************
* File Name          : protocol.cpp
* Author             : Khaukha-Mabinda Paddy
* Date First Issued  : 23/06/2009 : Version 1.0
* Description        : Serial device Classes
********************************************************************************
* History:
* 23/06/2009 : Version 1.0
*********************************************************************************/

#include "91x_type.h"
#include "OS_SerialPort.h"
#include "protocolmgr.h"
#include "protocol.h"
#include "CSetup.h"

Protocol::Protocol()
{
    m_pQTransmit = 0;
}
Protocol::~Protocol()
{
}
/*******************************************************************************
* Method Name  	 : Class Constructor
* Description    : Initializes the Protocol Object. SerialDevice and m_protocol are
*				   initialized to 0. Before using the class the InitProtocol
*				   method has to be called with a valid initialized objects
*                  object.
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
ASCII_CRLFProtocol::ASCII_CRLFProtocol() : m_SDevice(0),m_protocolMgr(0)
{
}

ASCII_CRLFProtocol::~ASCII_CRLFProtocol()
{
    m_SDevice 	  = 0;
    m_protocolMgr = 0;
}

/*******************************************************************************
* Method Name  	 : InitSerialDevice
* Description    : Initializes the OS_SerialPort Object UART and m_protocol
*                  object.
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void ASCII_CRLFProtocol::InitProtocol(OS_SerialPort* sd, ProtocolManager* pm )
{
    m_SDevice 	= sd;
    m_protocolMgr   = pm;
    m_msgReady      = false;
}

/**
    Receive on char, put it to the receive queue and if the frame termination
    char is received trigger receive complete

    Last Modified by
    Michael Brunner
*/
void ASCII_CRLFProtocol::OnReceive(char ch)
{
    if( ch == ASCII_LF || m_QReceive.size() >= 30 )      //Limit Size to 30 bytes to avoid buffer overflow
    {
        m_msgReady = true;
        m_protocolMgr->OnReceiveComplete(m_QReceive);
        m_QReceive.clear();
     }
    else{
        m_QReceive.push(ch);
    }
}


/*******************************************************************************
* Method Name  	 : OnTransmit
* Description    :
*
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
u8 ASCII_CRLFProtocol::OnTransmit(char* data)
{
	//MBif( (m_MBTransmit != 0)&&( ::OS_GetMailCond1(m_MBTransmit, &data[0]) == 0) )
    if( m_pQTransmit->size() > 1 )
    {
        m_pQTransmit->pop();
        *data = m_pQTransmit->front();
        return 1;
    }
    else{
	return 0;
    }
}

/**************************************************************************************
* Method Name  	 : FormatMessage
* Description    :
*
* Input          :  msg, len
* Output         : None
* Return         :
* REMARKS		 : Since this is an Embedded environment, the Mailboxes and Queues
* 				   and their memory blocks should be declared as objects not pointers.
*				   It is recommended that these variables are declared in a Global files.
*    Here is an example:
* 	OS_MAILBOX MBRx; an Object
*   char MsgBuf[MSG_SIZE],
*   OS_CREATEMB(&MBRx,1,sizeof(MsgBuf), &MsgBuf);
*   Transmit(&MBRx);
***************************************************************************************/

int ASCII_CRLFProtocol::FormatMessage( char *msg, int len )
{
    msg[len++] = (char)ASCII_CR;
    msg[len++] = (char)ASCII_LF;

    return len;
}

/**
   Initilize Transmit, pointer to transmit queue
*/
void ASCII_CRLFProtocol::Transmit(CQueue<char>* q)
{
    char data;
    m_pQTransmit = q;
    if( m_pQTransmit->size() > 0)
    {
        m_SDevice->BeginTransmit(m_pQTransmit->front());
    }
}

/*******************************************************************************
* Method Name  	 : OnTransmitComplete
* Description    :
*
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void ASCII_CRLFProtocol::OnTransmitComplete(void)
{
	m_protocolMgr->OnTransmitComplete();
}

/*******************************************************************************
* Method Name  	 : Class Constructor
* Description    : Initializes the Protocol Object. SerialDevice and m_protocol are
*				   initialized to 0. Before using the class the InitProtocol
*				   method has to be called with a valid initialized objects
*                  object.
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
ASCII_ENQACKProtocol::ASCII_ENQACKProtocol() : m_SDevice(0),m_protocolMgr(0)
{
    m_txState     =  E_STATE_IDLE;
    m_rxState     =  E_STATE_IDLE;

}

ASCII_ENQACKProtocol::~ASCII_ENQACKProtocol()
{
    m_SDevice 	  = 0;
    m_protocolMgr = 0;
    m_txState     =  E_STATE_IDLE;
    m_rxState     =  E_STATE_IDLE;

}

/*******************************************************************************
* Method Name  	 : InitSerialDevice
* Description    : Initializes the OS_SerialPort Object UART and m_protocol
*                  object.
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void ASCII_ENQACKProtocol::InitProtocol(OS_SerialPort* sd, ProtocolManager* pm)
{
	m_SDevice 	= sd;
	m_protocolMgr   = pm;
	m_msgReady      = false;
	m_sendData 	= false;
      m_txState     =  E_STATE_IDLE;
      m_rxState     =  E_STATE_IDLE;

}



/**************************************************************************************
* Method Name  	 : FormatMessage
* Description    :
*
* Input          :  msg, len
* Output         : None
* Return         :
* REMARKS		 : Since this is an Embedded environment, the Mailboxes and Queues
* 				   and their memory blocks should be declared as objects not pointers.
*				   It is recommended that these variables are declared in a Global files.
*    Here is an example:
* 	OS_MAILBOX MBRx; an Object
*   char MsgBuf[MSG_SIZE],
*   OS_CREATEMB(&MBRx,1,sizeof(MsgBuf), &MsgBuf);
*   Transmit(&MBRx);
***************************************************************************************/

int ASCII_ENQACKProtocol::FormatMessage( char *msg, int len )
{
	u8 crc = STX;

        /**** Addition: First byte get trancated therefore the STX is just added */
// 11.10.2012 PM
        int j = len;
        for( int i = len -1; i >= 0;  i--)
        {
          msg[j--] = msg[i];
        }
        msg[0] = STX;
        len++;
/*********** END **************/
	msg[len++] = ETX;

	for( int i = 1; i < len; i++)
	{
		crc ^= msg[i];
	}

    msg[len++] =  (char)crc;

    return len;
}

/**
    Begin Transmit of frame
*/
void ASCII_ENQACKProtocol::Transmit(CQueue<char>* q)
{

	m_pQTransmit = q;
// 	m_SDevice->BeginTransmit(ENQ); // send ENQ
        m_SDevice->Transmit(ENQ);
        m_txState = E_STATE_TX_ENQ_ACK;

}

/*******************************************************************************
* Method Name  	 : OnTransmitComplete
* Description    :
*
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void ASCII_ENQACKProtocol::OnTransmitComplete(void)
{
	m_protocolMgr->OnTransmitComplete();
}

/*******************************************************************************
* Function Name  : CoordinateTransmission
* Description    : coordinates transmission
* Input          : char ch
* Output         : None
* Return         : None
*******************************************************************************/
void ASCII_ENQACKProtocol::CoordinateTransmision(char ch)
{

    switch(m_txState)
    {
          case E_STATE_TX_ENQ_ACK:    //we have send ENQ (xmitting), waiting for ACK
               if( ch == ACK )
               {
                  m_txState = E_STATE_TX_DATA; // xmit Data STX,.....ETX,CRC
                   m_SDevice->BeginTransmit(STX); // 11.10.2012 PM
               }
               else
               {
                  m_txState = E_STATE_IDLE; // abort we got a different char from the sender !
                  OnTransmitComplete();    // Empty buffer
               }

          break;

          case E_STATE_TX_DATA:
               if( ch == ACK )
               {
                  m_txState = E_STATE_IDLE; // done, go back to sleep
               }
              else if( (ch == NACK)||(ch == cCAN) )
               {
                  m_txState = E_STATE_IDLE; // done, go back to sleep
               }
          break;
          default:
          break;
     }

}
/*******************************************************************************
* Function Name  : InterpreteChar
* Description    : Interpretes the recieved char and decides what to do next.
*                : While sending only ACK,NACK or cCAN can be send from the receiver.
*				 : This method ensures that DUPLEX communication is possible.
*
* Input          : char ch
* Output         : None
* Return         : None
*
*******************************************************************************/
void ASCII_ENQACKProtocol::InterpreteChar( char ch)
{

	if( m_txState != E_STATE_IDLE )
        CoordinateTransmision(ch);

  switch(m_rxState)
	{
	  case E_STATE_IDLE:
		   if( ch == ENQ )
		   {
			   m_SDevice->Transmit(ACK);
			   m_rxState = E_STATE_RX_STX;
			   m_msgReady = false;
		   }
	  break;

	  case E_STATE_RX_STX:  //received ENQ waiting for STX
		   if(ch == STX)
		   {
			  m_rxState = E_STATE_RX_DATA;
			  m_CRC    = STX;
		   }
		   else
		   {
			   if( ch == ENQ )
			   {
				   m_SDevice->Transmit(ACK);
			   }
			   else
			   {
				   m_rxState = E_STATE_IDLE;
			   }
		   }
	  break;

        case E_STATE_RX_DATA: // receive data
            m_CRC ^= ch;
            if( ch != ETX || m_QReceive.size() > 30  ) // Limit receive size to 30 bytes to avoid buffer overflow
            {
                m_QReceive.push(ch );       // save only data (payload, no control codes)
            }
            else
            {
                  m_rxState = E_STATE_RX_CRC;
            }

        break;

	  case E_STATE_RX_CRC:   // received ETX wait for CRC
		   if( ch == m_CRC )
		   {
			   m_msgReady = true;
		   }
		   else
		   {
			   m_SDevice->Transmit(NACK );
		   }
		   m_rxState = E_STATE_IDLE;
	  break;

	  default:
	  break;
	}

}
/*******************************************************************************
* Method Name  	 : OnTransmit
* Description    :
*
* Input          : None
* Output         : None
* Return         : 0: Data transmission completed.
*                  1: Data available
*                  2: waiting for ACK
*******************************************************************************/
u8 ASCII_ENQACKProtocol::OnTransmit(char* data)
{
	u8 retcode = 0;

    switch(m_txState)
    {
          case E_STATE_TX_ENQ_ACK:  //we have send ENQ (xmitting), waiting for ACK
              retcode = 2;
	  					break;								// just wait

          case E_STATE_TX_DATA:
            if( m_pQTransmit->size() > 1 )
	    {
                 m_pQTransmit->pop();
                 *data = m_pQTransmit->front();
                  retcode = 1;
	    }
          break;

          default:
            retcode = 3;
          break;
     }


	return retcode;
}

/*******************************************************************************
* Method Name  	 : OnReceive
* Description    :
*
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void ASCII_ENQACKProtocol::OnReceive(char ch)
{

    InterpreteChar(ch);
    if( m_msgReady == true)
    {
        m_msgReady = false;
        m_protocolMgr->OnReceiveComplete(m_QReceive);
        m_QReceive.clear();
    }
}
/*******************************************************************************
* Method Name  	 : IoSendChar
* Description    :
*
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void ASCII_ENQACKProtocol::IoSendChar(char io)
{
     m_SDevice->Transmit(io);
}

