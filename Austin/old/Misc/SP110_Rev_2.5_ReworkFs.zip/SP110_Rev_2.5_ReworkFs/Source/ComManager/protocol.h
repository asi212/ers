/******************** (C) ERS Electronic GmbH ********************
* File Name          : protocol.h
* Author             : Khaukha-Mabinda Paddy
* Date First Issued  : 23/06/2009 : Version 1.0
* Description        : Serial device Classes
* Rework             : Michael Brunner
*                    : 12.04.2011
********************************************************************************
* History:
* 23/06/2009 : Version 1.0
*********************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __PROTOCOL_H
#define __PROTOCOL_H
#include "CQueue.h"


extern "C"{
    #include "FreeRTOS.h"
    #include "queue.h"
}

// Due to lack of Interface definition, I have decided to define the class a pure abstract class.
// It cannot be initialized.

#define STX  0x02
#define ETX  0x03
#define ENQ  0x05
#define ACK  0x06
#define NACK 0x15
#define cCAN 0x18
#define _CR  0x13
#define _LF  0x10

typedef enum
{
    E_STATE_IDLE,
    E_STATE_RX_STX,
    E_STATE_RX_DATA,
    E_STATE_RX_CRC,
    E_STATE_TX_ENQ_ACK,
    E_STATE_TX_DATA,
    E_STATE_TX_ACK
}E_PROT_CMD_STATE;

typedef enum _deviceType
{
  E_DEVICE_CONTROLLER,
  E_DEVICE_TERMINAL
}E_DEVICE_TYPE;


class OS_SerialPort;
class ProtocolManager;

class Protocol
{
	public:
            Protocol();
             ~Protocol();

            virtual void InitProtocol(OS_SerialPort*,ProtocolManager*) = 0;
            virtual void OnReceive(char ch) = 0;
            virtual u8 OnTransmit(char* data) = 0;
            virtual void Transmit(CQueue<char> *) = 0;
            virtual void OnTransmitComplete(void) = 0;
            virtual bool IsMessageReady(void) = 0;
            virtual void ClearMessageFlag(void) = 0;
            virtual int FormatMessage( char *msg, int len )= 0;
            virtual void SetDeviceType(E_DEVICE_TYPE eType)=0;
            virtual void IoSendChar(char) = 0;
            
    protected:
        CQueue<char> m_QReceive;
        CQueue<char> *m_pQTransmit;

};


class ASCII_CRLFProtocol : public Protocol
{
	public:
            ASCII_CRLFProtocol();
            ~ASCII_CRLFProtocol();


            void InitProtocol(OS_SerialPort*,ProtocolManager* pm );
            void OnReceive(char ch);
            u8 OnTransmit(char* data);
            void Transmit(CQueue<char> *);
            void OnTransmitComplete(void);
            int FormatMessage( char *msg, int len );

            inline bool IsMessageReady(void){return m_msgReady;}
            inline void ClearMessageFlag(void){ m_msgReady = 0;}
            inline void SetDeviceType(E_DEVICE_TYPE eType){m_dType = eType;}
            void IoSendChar(char){;}
   
	private:
		OS_SerialPort* m_SDevice;
		ProtocolManager* m_protocolMgr;
                bool  m_msgReady;
                E_DEVICE_TYPE m_dType;

};

class ASCII_ENQACKProtocol : public Protocol
{
	public:
            ASCII_ENQACKProtocol();
            ~ASCII_ENQACKProtocol();


            void InitProtocol(OS_SerialPort*,ProtocolManager* pm );
            void OnReceive(char ch);
            u8   OnTransmit(char* data);
            void Transmit(CQueue<char> *);
            void OnTransmitComplete(void);
            int FormatMessage( char *msg, int len );
            inline void SetDeviceType(E_DEVICE_TYPE eType){m_dType = eType;}
                               
            inline bool IsMessageReady(void){return m_msgReady;}
            inline void ClearMessageFlag(void){ m_msgReady = 0;}
            void IoSendChar(char iocode);
  
    private:
    	void CoordinateTransmision( char ch);
    	void InterpreteChar( char ch);


    private:
        OS_SerialPort* m_SDevice;
        ProtocolManager* m_protocolMgr;
        bool m_msgReady;
        bool m_sendData;
        E_PROT_CMD_STATE m_rxState;
        E_PROT_CMD_STATE m_txState;
        char    m_CRC;
        E_DEVICE_TYPE m_dType;
      
};



#endif //__PROTOCOL_H
