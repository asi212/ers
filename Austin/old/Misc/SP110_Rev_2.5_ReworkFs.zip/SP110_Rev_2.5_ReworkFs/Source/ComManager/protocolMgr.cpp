/******************** (C) ERS Electronic GmbH ********************
* File Name          : protocolmgr.cpp
* Author             : Khaukha-Mabinda Paddy
* Date First Issued  : 23/06/2009 : Version 1.0
* Description        : ProtocolManager Class
********************************************************************************
* History:
* 23/06/2009 : Version 1.0
*********************************************************************************/

#include "91x_type.h"
#include "OS_SerialPort.h"
#include "protocol.h"
#include "protocolmgr.h"
#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "lcddefs.h"

/*******************************************************************************
* Method Name  	 : Class Constructor
* Description    : Initializes the Protocol Object. SerialDevice and m_protocol are
*				   initialized to 0. Before using the class the InitProtocol
*				   method has to be called with a valid initialized objects
*                  object.
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
ProtocolManager::ProtocolManager( CEventManager* pEventManager, ProberCmdSet* pCmdSet ): m_protocol(0), m_msgCount(0)
{
    m_ProberCmdSet = pCmdSet;
    m_EventManager = pEventManager;
    semaTX = false;
    m_ComTOut = 0;
}
/*******************************************************************************
* Method Name  	 : Class destructor
* Description    : Initializes the Protocol Object. SerialDevice and m_protocol are
*				   initialized to 0. Before using the class the InitProtocol
*				   method has to be called with a valid initialized objects
*                  object.
* Input          : None
* Output         : None
* Return         :
    m_receiveQ   = 0;
    m_transmitMB = 0;
    m_protocol   = 0;
    m_transmitQ  = 0;
    m_TCBu	 = 0;
*******************************************************************************/
ProtocolManager::~ProtocolManager()
{
    m_protocol  = 0;
    m_msgCount  = 0;
}
    
/*******************************************************************************
* Method Name  	 : InitProtocolManager
* Description    :
*
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void ProtocolManager::InitProtocolManager(Protocol* proto)
{
    m_protocol  = proto;
    m_protocol->SetDeviceType(E_DEVICE_TERMINAL);
    InitParameters();
    
}

void ProtocolManager::DewPointEvent( float f )
{
    m_fdata[CP_DEW_POINT] = f;
}

void ProtocolManager::DefrostEvent( int i )
{
    if( i == 0 ){
        m_fdata[CP_OP_MODE] = 1.0;
    }
    else{
        m_fdata[CP_OP_MODE] = 3.0;
    }                    
}


void ProtocolManager::StandbyEvent( int i )
{
    if( i == 0 ){
        m_fdata[CP_OP_MODE] = 1.0;
    }
    else{
        m_fdata[CP_OP_MODE] = 2.0;
    }                    
}

/*******************************************************************************
* Method Name  	 : InitParameters
* Description    :
*
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void ProtocolManager::InitParameters(void)
{
    memset(m_fdata,0,sizeof(m_fdata));
    m_fdata[0] = +25.0; // solltemp
    m_fdata[1] = +25.0;  // isttemp
    m_fdata[2] = -1.2;  // range -
    m_fdata[3] = +1.2;  // range +
    m_fdata[4] = 1.0;    // operation mode
   
}

/*******************************************************************************
* Method Name  	 : OnTransmitComplete
* Description    :
*
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void ProtocolManager::OnTransmitComplete(void)
{
    m_transmitQ.pop(); // remove message from Queue
    semaTX = false;
    //if( m_transmitQ.size() > 0) // get next message
    //{
        //m_protocol->Transmit(&m_transmitQ.front()); 
    //}
}

/*******************************************************************************
* Method Name  	 : OnReceiveComplete
* Description    :
*
* Input          : None
* Output         : None
* Return         :
* REMARKS	 : Since this method is being called ("bubbled") from the device
*                  Interrupt, we cannot called into the Message processor, what
*                  otherwise might otherwise take long to be processed.
*                  being calling the SignalEventz function, we terminate the
*                  calling chain here!
*******************************************************************************/
void ProtocolManager::OnReceiveComplete(CQueue<char> & q)
{
    if( m_receiveQ.size() < 5 ){        //Limit number of messagest to 5 to avoid buffer overflow
        m_receiveQ.push(q);
        m_msgCount++;
    }
}


/*******************************************************************************
* Method Name  	 : ProcessMessages
* Description    :
*
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void ProtocolManager::ProcessMessages( void )
{

    int index;
    char param[32];
    char cmd[4];
    u8  length;
    
    if( m_receiveQ.size() > 0)
    {
        CQueue<char> & q_Receive = m_receiveQ.front();
        m_msgCount--;
        index = 0;
        for( int i=0; !q_Receive.empty() && i < 34; i++) // if len is 0 not message will be copied!
        {
            //Dispose 
            if( i >= 4 ){
                param[index++] = q_Receive.front();
            }
            else if( i >= 2 )
            {
                param[index] = q_Receive.front();
                cmd[i] = param[index++];
            }
            else
            {
                cmd[i] = q_Receive.front();
            }
            q_Receive.pop();                
        }
        m_receiveQ.pop();                           //Remove message from queue
        int iRet = 0;
        length = m_ProberCmdSet->ProcessMessage( cmd, param, &m_fdata, &iRet );
        //pop command to queue
        if( iRet != 0 )
        {
            int newmode = (int)m_fdata[CP_OP_MODE];
            _event<int> emode( "aggregat", CEventNames::operation_mode_changed, newmode ); // signal change of operation Mode.
             m_EventManager->RaiseEvent(emode);    
        }
                        
        //Generate answer 
        if( length > 0)
        {
            if( ProberCmdSet::m_cmdSetOption == E_TSK_OPTION)
            {
              if( length == 1)
                 m_protocol->IoSendChar(param[0]);
              else
              {
                m_protocol->IoSendChar(0x06);
                TransmitMessage(param,length);
              }
            }
            else
            {
                TransmitMessage(param,length);
            }

            //Prober Com Timeout Monitoring Online Command
            if( m_ComTOut <= 0 )
            {
                _event<bool> e("aggregate", CEventNames::chiller_comm_symbol, true );
                m_EventManager->RaiseEvent(e);                  
            }
            m_ComTOut = 2000;

        } 
    }
    else
		{
         //Prober Com Timeout Monitoring Offline Command
        if( m_ComTOut > 0 )
        {            
            if( --m_ComTOut < 1 ){
                _event<bool> e("aggregate", CEventNames::chiller_comm_symbol, false );
                m_EventManager->RaiseEvent(e);                  
            }
        }
    }

    
    //Trigger new Transmit if port is not blocked,
    if( semaTX == false && m_transmitQ.size() > 0 )
    {
        semaTX = true;
        m_protocol->Transmit(&m_transmitQ.front());
    }
}

/*******************************************************************************
* Method Name  	 : TransmitMessage
* Description    :
*
* Input          : None
* Output         : None
* Return         :
*******************************************************************************/
void ProtocolManager::TransmitMessage(char* data, int len)
{
        char p[32];
        len = (len < 31)? len : 31;
        strncpy(p,data,len);
        len = m_protocol->FormatMessage( &p[0], len);
        CQueue<char> q;
        for( int i = 0; i < len; i++ ) q.push(p[i] );
        if( m_transmitQ.size() < 5 ){  //Limit number of messages waiting
            m_transmitQ.push(q);
        }
        
        
}




