/******************** (C) ERS Electronic GmbH ********************
* File Name          : protocolmgr.h
* Author             : Khaukha-Mabinda Paddy
* Date First Issued  : 23/06/2009 : Version 1.0
* Description        : ProtocolManager class
********************************************************************************
* History:
* 23/06/2009 : Version 1.0
*********************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __PROTOCOLMGR_H
#define __PROTOCOLMGR_H

#include "protocol.h"
#include "probercmds.h"

#include "../MailboxSystem/CEventManager.h"

extern "C"{
    #include "FreeRTOS.h"
    #include "queue.h"
}
    
#define PROBER_MSG_SIZE   40
#define PROBER_MSG_CNT	  4


class ProtocolManager
{
	public:
            ProtocolManager( CEventManager* pEventManager, ProberCmdSet* pCmdSet );
            ~ProtocolManager();
            CEventManager* m_EventManager;

            void OnTransmitComplete(void);
            void OnReceiveComplete(CQueue<char> &);
            void ProcessMessages( void );
            void ProcessMessagesEX( void );
            void TransmitMessage(char *msg, int len);
            void InitProtocolManager(Protocol* proto);
            inline u8 IsMessageReady(void){return m_msgCount;}
            
            static void ErrorEventWrapper( void * pObject, int parameter){ ((ProtocolManager*)pObject)->ErrorEvent(parameter);};
            static void DewPointEventWrapper( void * pObject, float parameter){ ((ProtocolManager*)pObject)->DewPointEvent(parameter);};
            static void DefrostEventWrapper( void * pObject, int parameter){ ((ProtocolManager*)pObject)->DefrostEvent(parameter);};
            static void StandbyEventWrapper( void * pObject, int parameter){ ((ProtocolManager*)pObject)->StandbyEvent(parameter);};
            
        protected:
            void ErrorEvent( int );
            void DewPointEvent( float );
            void DefrostEvent( int );
            void StandbyEvent( int );
            
	private:
           void InitParameters(void);

        private:
            ProberCmdSet* m_ProberCmdSet;
            Protocol*	m_protocol;
            u8          m_msgCount;
            float       m_fdata[20];
            bool semaTX;
            int         m_ComTOut;      //Timer to monitor comm timout to prober
            
            
        
            CQueue< CQueue<char> > m_receiveQ;
            CQueue< CQueue<char> > m_transmitQ;
            static int m_InstCount;
 };


#endif //__PROTOCOLMGR_H
