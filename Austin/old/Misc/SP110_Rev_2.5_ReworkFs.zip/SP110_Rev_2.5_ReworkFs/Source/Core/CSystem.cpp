#include "CSystem.h"



CSystem::CSystem(void){

}

void CSystem::initHW(void){
  //SCU_MCLKSourceConfig(SCU_MCLK_OSC);   /* Use OSC as the default clock source */
  SCU_PCLKDivisorConfig(SCU_PCLK_Div1); /* ARM Peripheral bus clokdivisor = 1  */

  SCU_Configuration();  /* Configure the system clocks */
  EMI_Configuration();  /* Configure the EMI Interface */
  GPIO_Configuration(); /* Configure the GPIO ports    */
  UART_Configuration(); /* Configure the Uart          */
  CAN_Configuration();  /* Configure the CAN Bus Interface */
  ADC_Configuration();  /* ADC Configuration           */
  RTC_DeInit();
  RTC_SRAMBattPowerCmd(ENABLE);
}

/*******************************************************************************
* Function Name  : SCU_Configuration
* Description    : Configures the system clocks.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void CSystem::SCU_Configuration(void){

  /* Enable the UART0 Clock */
  SCU_APBPeriphClockConfig(__UART0, ENABLE);
  SCU_APBPeriphClockConfig(__UART2, ENABLE);

  /* Enable the RTC Clock */
  SCU_APBPeriphClockConfig(__RTC, ENABLE);

  /* Enable the GPIO3 Clock */
  SCU_APBPeriphClockConfig(__GPIO1, ENABLE);
  SCU_APBPeriphClockConfig(__GPIO3, ENABLE);
  SCU_APBPeriphClockConfig(__GPIO4, ENABLE);
  SCU_APBPeriphClockConfig(__GPIO5, ENABLE);
  SCU_APBPeriphClockConfig(__GPIO6, ENABLE);

  SCU_APBPeriphClockConfig(__ADC, ENABLE);    /* Enable the clock for the ADC */
  SCU_APBPeriphClockConfig(__CAN, ENABLE);    /* Enable the clock for the ADC */


  /* Enable the clock for EMI*/
  SCU_AHBPeriphClockConfig(__EMI | __EMI_MEM_CLK, ENABLE);
  SCU_EMIBCLKDivisorConfig(SCU_EMIBCLK_Div1);

  /*Enable the Non-mux mode*/
//  SCU_EMIModeConfig(SCU_EMI_DEMUX);
  SCU_EMIModeConfig(SCU_EMI_MUX);

  /* Enable the GPIO7 Clock */
  SCU_APBPeriphClockConfig(__GPIO7, ENABLE);

  /*Enable Ethernet MAX*/
  SCU_AHBPeriphClockConfig(__ENET, ENABLE);
  SCU_AHBPeriphReset(__ENET,DISABLE);
  SCU_PHYCLKConfig(ENABLE);

}

/*******************************************************************************
* Function Name  : GPIO_Configuration
* Description    : Configures the different GPIO ports.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void CSystem::GPIO_Configuration(void){

    /* Configure ENET GPIO */
    GPIO_DeInit(GPIO1);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2 |GPIO_Pin_3 |GPIO_Pin_4 |GPIO_Pin_7 ;
    GPIO_InitStructure.GPIO_Type = GPIO_Type_PushPull;
    GPIO_InitStructure.GPIO_Direction = GPIO_PinOutput;
    GPIO_InitStructure.GPIO_IPInputConnected = GPIO_IPInputConnected_Disable;
    GPIO_InitStructure.GPIO_Alternate=GPIO_OutputAlt2;
    GPIO_Init(GPIO1, &GPIO_InitStructure);

        
    /*Gonfigure UART2_Rx pin GPIO3.0*/
    GPIO_DeInit(GPIO3);
    GPIO_InitStructure.GPIO_Direction = GPIO_PinOutput;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Type = GPIO_Type_PushPull ;
    GPIO_InitStructure.GPIO_IPInputConnected = GPIO_IPInputConnected_Disable;
    GPIO_InitStructure.GPIO_Alternate = GPIO_OutputAlt2;
    GPIO_Init (GPIO3, &GPIO_InitStructure);
    /*Gonfigure UART2_Tx pin GPIO3.1*/
    GPIO_InitStructure.GPIO_Direction = GPIO_PinInput;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Type = GPIO_Type_PushPull ;
    GPIO_InitStructure.GPIO_IPInputConnected = GPIO_IPInputConnected_Enable;
    GPIO_InitStructure.GPIO_Alternate = GPIO_InputAlt1;
    GPIO_Init (GPIO3, &GPIO_InitStructure);
    
    GPIO_DeInit(GPIO4);                         /* GPIO4 Deinitialization */
    /* Configure the GPIO4 pin 6 as analog input */
    GPIO_ANAPinConfig(GPIO_ANAChannel0, ENABLE);
    GPIO_ANAPinConfig(GPIO_ANAChannel1, ENABLE);
    GPIO_ANAPinConfig(GPIO_ANAChannel2, ENABLE);
    GPIO_ANAPinConfig(GPIO_ANAChannel3, ENABLE);
    GPIO_ANAPinConfig(GPIO_ANAChannel4, ENABLE);
    GPIO_ANAPinConfig(GPIO_ANAChannel5, ENABLE);
    GPIO_ANAPinConfig(GPIO_ANAChannel6, ENABLE);
    GPIO_ANAPinConfig(GPIO_ANAChannel7, ENABLE);
    
    /* Configure the CAN Bus Pins */
    GPIO_DeInit(GPIO5);
    GPIO_InitStructure.GPIO_Direction = GPIO_PinInput;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Type = GPIO_Type_PushPull;
    GPIO_InitStructure.GPIO_IPInputConnected = GPIO_IPInputConnected_Enable;
    GPIO_InitStructure.GPIO_Alternate = GPIO_InputAlt1;
    GPIO_Init (GPIO5, &GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Direction = GPIO_PinOutput;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Type = GPIO_Type_PushPull;
    GPIO_InitStructure.GPIO_IPInputConnected = GPIO_IPInputConnected_Disable;
    GPIO_InitStructure.GPIO_Alternate = GPIO_OutputAlt2;
    GPIO_Init (GPIO5, &GPIO_InitStructure);
    
    //Ethernet
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Type = GPIO_Type_PushPull;
    GPIO_InitStructure.GPIO_Direction = GPIO_PinOutput;
    GPIO_InitStructure.GPIO_IPInputConnected = GPIO_IPInputConnected_Disable;
    GPIO_InitStructure.GPIO_Alternate=GPIO_OutputAlt2;
    GPIO_Init (GPIO5, &GPIO_InitStructure);
    /*Gonfigure GPIO 5 for EMI-CS Function*/
    GPIO_InitStructure.GPIO_Direction = GPIO_PinOutput;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Type = GPIO_Type_PushPull ;
    GPIO_InitStructure.GPIO_IPInputConnected = GPIO_IPInputConnected_Disable;
    GPIO_InitStructure.GPIO_Alternate = GPIO_OutputAlt3;
    GPIO_Init (GPIO5, &GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Direction = GPIO_PinOutput;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Type = GPIO_Type_PushPull ;
    GPIO_InitStructure.GPIO_IPInputConnected = GPIO_IPInputConnected_Disable;
    GPIO_InitStructure.GPIO_Alternate = GPIO_OutputAlt3;
    GPIO_Init (GPIO5, &GPIO_InitStructure);

    /*Gonfigure UART0_Rx pin GPIO6.6*/
    GPIO_DeInit(GPIO6);
    GPIO_InitStructure.GPIO_Direction = GPIO_PinInput;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Type = GPIO_Type_PushPull ;
    GPIO_InitStructure.GPIO_IPInputConnected = GPIO_IPInputConnected_Enable;
    GPIO_InitStructure.GPIO_Alternate = GPIO_InputAlt1;
    GPIO_Init (GPIO6, &GPIO_InitStructure);
    /*Gonfigure UART0_Tx pin GPIO6.7*/
    GPIO_InitStructure.GPIO_Direction = GPIO_PinOutput;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Type = GPIO_Type_PushPull ;
    GPIO_InitStructure.GPIO_IPInputConnected = GPIO_IPInputConnected_Disable;
    GPIO_InitStructure.GPIO_Alternate = GPIO_OutputAlt3;
    GPIO_Init (GPIO6, &GPIO_InitStructure);    
    /*Gonfigure RS485 pin GPIO6.2*/
    //Bughunt Comment Block:
    
    GPIO_InitStructure.GPIO_Direction = GPIO_PinOutput;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Type = GPIO_Type_PushPull ;
    GPIO_InitStructure.GPIO_IPInputConnected = GPIO_IPInputConnected_Disable;
    GPIO_InitStructure.GPIO_Alternate = GPIO_OutputAlt1;
    GPIO_Init (GPIO6, &GPIO_InitStructure);
    
    /* GPIO8,GPIO9 Configuration*/
    GPIO_EMIConfig(ENABLE);
    /* GPIO7 Configuration */
    GPIO_DeInit(GPIO7);
    GPIO_InitStructure.GPIO_Direction = GPIO_PinOutput;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 |
                                GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Type = GPIO_Type_PushPull;
    GPIO_InitStructure.GPIO_IPInputConnected = GPIO_IPInputConnected_Disable;
    GPIO_InitStructure.GPIO_Alternate = GPIO_OutputAlt2;
    GPIO_Init (GPIO7, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
    
    /*EMI-A7 mode 8bits*/
    GPIO_InitStructure.GPIO_Alternate = GPIO_OutputAlt3;
    
    GPIO_Init (GPIO7, &GPIO_InitStructure);


}

void CSystem::UART_Configuration(){
  /* UART0 configuration -------------------------------------------------------*/
  /* UART0 configured as follow:
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - BaudRate = 115200 baud
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
        - Receive and transmit FIFOs are disabled
        - Transmit and Receive FIFOs levels have 8 bytes depth
  */
    UART_InitStructure.UART_WordLength = UART_WordLength_8D;
    UART_InitStructure.UART_StopBits = UART_StopBits_1;
    UART_InitStructure.UART_Parity = UART_Parity_No;
    UART_InitStructure.UART_BaudRate = 115200;
    UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None;
    UART_InitStructure.UART_Mode = UART_Mode_Tx_Rx;
    UART_InitStructure.UART_FIFO = UART_FIFO_Disable; //UART_FIFO_Enable;
    UART_InitStructure.UART_TxFIFOLevel = UART_FIFOLevel_1_2; /* FIFO size 16 bytes, FIFO level 8 bytes */
    UART_InitStructure.UART_RxFIFOLevel = UART_FIFOLevel_3_4; /* FIFO size 16 bytes, FIFO level 8 bytes */

    UART_DeInit(UART2);
    UART_Init(UART2, &UART_InitStructure);
    UART_ITConfig( UART2, UART_IT_Receive | UART_IT_ReceiveTimeOut, ENABLE );
    UART_Cmd(UART2, ENABLE);      /* Enable the UART2 */

    UART_DeInit(UART0);
    UART_InitStructure.UART_BaudRate = 9600;
    UART_InitStructure.UART_TxFIFOLevel = UART_FIFOLevel_1_8; /* FIFO size 16 bytes, FIFO level 8 bytes */
    UART_InitStructure.UART_RxFIFOLevel = UART_FIFOLevel_1_8; /* FIFO size 16 bytes, FIFO level 8 bytes */
    //UART_InitStructure.UART_FIFO = UART_FIFO_Disable;
    UART_Init(UART0, &UART_InitStructure);
    UART_ITConfig( UART0, UART_IT_Receive | UART_IT_ReceiveTimeOut, ENABLE );
    UART_Cmd(UART0, ENABLE);   /* Enable the UART0 */
    
    /* Configure the VIC for the UART interrupts. */			
    VIC_Config( UART0_ITLine, VIC_IRQ, 10 );
    VIC_ITCmd( UART0_ITLine, ENABLE );
    VIC_Config( UART2_ITLine, VIC_IRQ, 11 );
    VIC_ITCmd( UART2_ITLine, ENABLE );
    //VIC_ITCmd( UART2_ITLine, DISABLE );


}

void CSystem::EMI_Configuration(){
  /* EMI default configuration : Reset configuration*/
  EMI_DeInit();

  /**************************EMI configuration*********************************/

  EMI_StructInit(&EMI_InitStruct);

  /* Number of bus turnaround cycles added between read and write accesses.*/
  EMI_InitStruct.EMI_Bank_IDCY = 0x0F;

  /* Number of wait states for read accesses*/
  EMI_InitStruct.EMI_Bank_WSTRD = 0x04;

  /* Number of wait states for write accesses*/
  EMI_InitStruct.EMI_Bank_WSTWR = 0x04;

  /*Output enable assertion delay from chip select assertion*/
  EMI_InitStruct.EMI_Bank_WSTROEN = 0x02;

  /*Write enable assertion delay from chip select assertion*/
  EMI_InitStruct.EMI_Bank_WSTWEN = 0x02;

  /*This member Controls the memory width*/
  EMI_InitStruct.EMI_Bank_MemWidth = EMI_Width_HalfWord;

  /*Write protection feature */
  EMI_InitStruct.EMI_Bank_WriteProtection =  EMI_Bank_NonWriteProtect;

  /* Normal mode read*/
  EMI_InitStruct.EMI_Burst_and_PageModeRead_Selection =  EMI_NormalMode;

  /*Use Bank0 (CS0)*/
  EMI_Init( EMI_Bank0, &EMI_InitStruct);

  EMI_InitStruct.EMI_Bank_MemWidth = EMI_Width_Byte;

  EMI_InitStruct.EMI_Bank_WSTRD   = 0x1F;
  EMI_InitStruct.EMI_Bank_WSTWR   = 0x1F ;
  EMI_InitStruct.EMI_Bank_WSTROEN = 0x04;
  EMI_InitStruct.EMI_Bank_WSTWEN  = 0x04;

  EMI_Init( EMI_Bank2, &EMI_InitStruct);


  EMI_InitStruct.EMI_Bank_MemWidth = EMI_Width_HalfWord;
  EMI_Init( EMI_Bank1, &EMI_InitStruct);

}

void CSystem::ADC_Configuration(){

  ADC_DeInit();                               /* ADC Deinitialization */
  /* ADC Structure Initialization */
  ADC_StructInit(&ADC_InitStructure);

  /* Configure the ADC in continuous mode conversion */
  ADC_InitStructure.ADC_Channel_0_Mode = ADC_NoThreshold_Conversion;
  ADC_InitStructure.ADC_Channel_1_Mode = ADC_NoThreshold_Conversion;
  ADC_InitStructure.ADC_Channel_2_Mode = ADC_NoThreshold_Conversion;
  ADC_InitStructure.ADC_Channel_3_Mode = ADC_NoThreshold_Conversion;
  ADC_InitStructure.ADC_Channel_4_Mode = ADC_NoThreshold_Conversion;
  ADC_InitStructure.ADC_Channel_5_Mode = ADC_NoThreshold_Conversion;
  ADC_InitStructure.ADC_Channel_6_Mode = ADC_NoThreshold_Conversion;
  ADC_InitStructure.ADC_Channel_7_Mode = ADC_NoThreshold_Conversion;
  ADC_InitStructure.ADC_Scan_Mode = ENABLE;
  ADC_InitStructure.ADC_Conversion_Mode = ADC_Single_Mode;

  /* ADC interrupt config */
  ADC_ITConfig(ADC_IT_ECV, DISABLE );
  /* Enable the ADC */
  ADC_Cmd(ENABLE);
  /* Prescaler config */
  ADC_PrescalerConfig(0xFF);
  /* Configure the ADC */
  ADC_Init(&ADC_InitStructure);
  /* Start the conversion */
  ADC_ConversionCmd(ADC_Conversion_Start);

}

void CSystem::CAN_Configuration()
{
  CAN_InitTypeDef CAN_InitStructure;
  CAN_DeInit();
  CAN_InitStructure.CAN_ConfigParameters=0x0;
  CAN_InitStructure.CAN_Bitrate=CAN_BITRATE_500K;
  CAN_Init(&CAN_InitStructure);
  CAN_EnterInitMode(CAN_CR_CCE);
  //CAN_SetTiming(8, 7, 4, 12);
  //CAN_SetTiming(6, 8, 4, 12);
  CAN_SetTiming( 14, 7, 4, 8);
  CAN_LeaveInitMode();

}
