#ifndef CSYSTEM_H
#define CSYSTEM_H

#include <cstring>

extern "C"{
  #include "91x_lib.h"
//  #include "c2315.h"
  #include "c2635.h"
}


class CSystem{

  private:

  protected:
    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;
    EMI_InitTypeDef   EMI_InitStruct;
    ADC_InitTypeDef   ADC_InitStructure;

    void EnableISR(void);
    void TIM_Config(void);

  public:
    CSystem(void);
    void SCU_Configuration(void);
    void GPIO_Configuration(void);
    void UART_Configuration(void);
    void EMI_Configuration(void);
    void ADC_Configuration(void);
    void CAN_Configuration(void);
	  void initHW(void);

};

#endif //CSYSTEM_H