/******************** (C) ERS Electronic GmbH **********************************
* File Name          : sysinit.cpp
* Author             : Khaukha-Mabinda Paddy
* Date First Issued  : 15.03.2012 : Version 1.0
* Description        : System Initialization Class
**==============================================================================
* Comment:
* This class is used only once during System Inintialization. The Class can not
* be initiated, hence only static methods are defined.
********************************************************************************
* History:
* 15.03.2012 : Version 1.0
*********************************************************************************/


#include "91x_type.h"
#include "sysinit.h"
#include "CFiles.h"
#include "EAeDIPTFT43A.h"
#include "toolbox.h"
#include "CSetup.h"
#include "CBackup.h"
#include "CChuckList.h"
#include "CEventManager.h"
#include "CGlobalExchange.h"
#include "CTerminal.h"	/**< Terminal on LCD display	      		*/ 
#include "version.h"

#include <stdio.h>

extern "C"
{
  //Library includes.
  #include "91x_lib.h"
  //Dateisystem
  #include "FS.h" //PowerPac File System

	#include "FS_NOR_PHY_M29W128G.h"
	#include "c2635.h"

}

// Global variables handled by this class
CSetup   c_CSetup;            	// Class for configuration (setup) data
CSetup * p_CSetup = &c_CSetup;  // Pointer to this class
extern CEventManager EventManager;			// Reference to EventManager class
CChuckList c_CChuckList( &EventManager );
CChuckList *pChucklist = &c_CChuckList;
//CChuckList *pChucklist = new CChuckList(&EventManager);
 
//CGlobalExchange *pCGlobEx = new CGlobalExchange();	// Object for intertask exchange of values
//CGlobalExchange c_CGlobEx /* @ "EXRAM"  = new CGlobalExchange()*/ ; 
CGlobalExchange c_CGlobEx;
CGlobalExchange *pCGlobEx = &c_CGlobEx;

// Backup related objects
CTerminal cTerm; 								    /**< Terminal object to print debug output on LCD    */
CBackup  c_CBackup;  								/**< Class for backup handling											 */
CBackup *p_CBackup = &c_CBackup;    /**< Pointer to this class								    			 */


// increase the Version whenever, changes are made to this struct !!
UserSettings SysInit::m_usersettings = {0x100,E_STANDARD_CONTROL,false,5.0,0,E_OPTIONS_BUTTON_STATIC_TEMP,0.1,50.0,-10.0,true};


/*******************************************************************************
* Method Name  	 : LoadSetup
* Description    : Loads configuration data from filesystem
*
*                  LoadSetup loads data into a global pointer p_CSetup, 
* 								 pointing to class CSetup. This pointer is declared within 
*                  this class. All modules using it have to declare it as 
*                  'extern CSetup * p_CSetup'.
*                  Data is loaded from following files:
*		      - OFFSET.INI
*                     - SETUP.INI
*                     - CONFIG.INI
*                     - PID00.INI
*
* Return         : E_SYSINIT_STATE
*******************************************************************************/
E_SYSINIT_STATE SysInit::LoadSetup( void )
{
    E_SYSINIT_STATE state = E_SYSINIT_STATE_INITIALIZED;
     extern CFiles * p_CFiles;
    E_VOLUME_STATE mounted =  p_CFiles->mountFileSystem();
    
    // If not formatted format first, initialize and write default *.ini files
    if (mounted == E_VOLUME_UNKNOWN)
    {
        p_CFiles->formatDisk();
        mounted =  p_CFiles->mountFileSystem();
        if( mounted != E_VOLUME_UNKNOWN ) 
            InitializeSetupFiles(); // initialize and write default *.ini files
    }    
    if( mounted != E_VOLUME_UNKNOWN )  
    {
        p_CSetup->readOffsetTable();  //Achtung offsettabelle zuerst laden
        p_CSetup->readSetup();
        p_CSetup->readConfig();
        p_CSetup->readPIDSet(p_CSetup->getPidSetNr());      //PID Parameter auch zuerst
//        p_CSetup->readPIDSet(0);      //PID Parameter auch zuerst 
    }
    
    return state;	
}

/*******************************************************************************
* Method Name  	 : LoadDefaultSetup
* Description    : Loads configuration data from filesystem
*
*                  first formats disk, before writting default files
*                  LoadSetup loads data into a global pointer p_CSetup, 
* 								 pointing to class CSetup. This pointer is declared within 
*                  this class. All modules using it have to declare it as 
*                  'extern CSetup * p_CSetup'.
*                  Data is loaded from following files:
*		      - OFFSET.INI
*                     - SETUP.INI
*                     - CONFIG.INI
*                     - PID00.INI
*
* Return         : E_SYSINIT_STATE
*******************************************************************************/
E_SYSINIT_STATE SysInit::LoadDefaultSetup( void )
{
    extern CFiles * p_CFiles;
    E_SYSINIT_STATE state = E_SYSINIT_STATE_INITIALIZED;
    
    E_VOLUME_STATE mounted =  p_CFiles->mountFileSystem();
    if (mounted != E_VOLUME_UNKNOWN)
        p_CFiles->UnMountFileSystem();
     
     p_CFiles->formatDisk();
     mounted =  p_CFiles->mountFileSystem();     
    
    if (mounted != E_VOLUME_UNKNOWN)
    {
        InitializeSetupFiles();
        p_CSetup->readOffsetTable();  //Achtung offsettabelle zuerst laden
        p_CSetup->readSetup();
        p_CSetup->readConfig();
        p_CSetup->readPIDSet(p_CSetup->getPidSetNr());      //PID Parameter auch zuerst
    }
 
    
    return state;	
}

/*******************************************************************************
* Method Name  	 : InitializeIPAddress
* Description    : Initializes the IP-Address by loading a file
*
*                  The file content is expected to have the following format:
*                  IP=AAA.BBB.CCC.DDD
*                  MASK=WWW.XXX.YYY.ZZZ
*                  
*                  The octets of IP and MASK may consist of 1 to 3 digits,
*                  e.g. IP=172.30.240.1.
*
*                  After reading and evaluating the file content, IP-Address
*                  and mask are stored in global variables
*
* Input          : port -indicating the time of file to use. L = localhost and C=Chiller 
* Output         : None
* Return         : E_SYSINIT_STATE ;
*
*******************************************************************************/
E_SYSINIT_STATE SysInit::InitializeIPAddress(char p)
{
    E_SYSINIT_STATE state = E_SYSINIT_STATE_INITIALIZED;
    extern int ipAddr[4], ipMask[4];
    extern int chiller_ipaddr[4],chiller_ipmask[4] ;
    
    if( p == 'L' ) // localhost
    {
       InitializeItemIPAddress("IPADDR.INI",  &ipAddr[0], &ipMask[0]); 
    }
    else if( p == 'C' )
    {
      InitializeItemIPAddress("IPCHILL.INI",  &chiller_ipaddr[0], &chiller_ipmask[0]); 
      if( chiller_ipaddr[3] == 99 ) // standard IP-Address if the file doesn't exist.
             chiller_ipaddr[3]  = 254; // 172.30.240.254 
    }
    return  state;
}
/*******************************************************************************
* Method Name  	 : InitializeItemIPAddress
* Description    : Initializes the IP-Address by loading a file
*
*                  The file content is expected to have the following format:
*                  IP=AAA.BBB.CCC.DDD
*                  MASK=WWW.XXX.YYY.ZZZ
*                  
*                  The octets of IP and MASK may consist of 1 to 3 digits,
*                  e.g. IP=172.30.240.1.
*
*                  After reading and evaluating the file content, IP-Address
*                  and mask are stored in global variables
*
* Input          : filename, IPAddr-buffer and Mask-Buffer 
* Output         : None
* Return         : E_SYSINIT_STATE ;
*
*******************************************************************************/
E_SYSINIT_STATE SysInit::InitializeItemIPAddress(char *filename, int *ip_addr, int *ip_mask)
{
	string buffer(18,0x00);
  extern CFiles * p_CFiles;
//	extern int ipAddr[4], ipMask[4];
  bool found = false, err = false;
 	E_SYSINIT_STATE state = E_SYSINIT_STATE_INITIALIZED;

	/**** IP-ADRESS ****/
	
	// Read IP-Address from file
	found = p_CFiles->getIPInfo( "IP", &buffer,filename );
	// If got one, then decode string and store octets in global array
	if (found) {
		size_t pos = 0; 		
		// Read the first 3 octets from buffer
		for (int oct = 0; oct < 3; oct++) {
			// Find the next '.'
			int len = buffer.find(".", pos+1)-pos;  // for method string.find, pos=1 is beginning of string	
			// No dot found? Error!
			if (len == string::npos) err = true;
			// convert the substring between curr pos and dot into integer
			// and store it in global variable array
			ip_addr[oct] = atoi(buffer.substr(pos,len).data());
			// Update current position
			pos += (len+1); // Length + 1 because of '.' !
		}
		// The last octet from curr pos to end of buffer
		ip_addr[3] = atoi(buffer.substr(pos).data());
	}
	// Evaluation of IP-Address
	for (int oct = 0; oct < 4; oct++) {
		if (ip_addr[oct] < 0 || ip_addr[oct] > 255) err = true;
	}

	// Default-Address in case of any error
	if (!found || err) {
		ip_addr[0] = uipIP_ADDR0;
		ip_addr[1] = uipIP_ADDR1;
		ip_addr[2] = uipIP_ADDR2;
		ip_addr[3] = uipIP_ADDR3;
	}
	
	/**** IP-MASK ****/
	// Read IP-Mask from file
	found = p_CFiles->getIPInfo( "MASK", &buffer,filename );
	// If got one, then decode string and store octets in global array
	if (found) {
		size_t pos = 0; 		
		// Read the first 3 octets from buffer
		for (int oct = 0; oct < 3; oct++) {
			// Find the next '.'
			int len = buffer.find(".", pos+1)-pos;  // for method string.find, pos=1 is beginning of string	
			// No dot found? Error!
			if (len == string::npos) err = true;
			// convert the substring between curr pos and dot into integer
			// and store it in global variable array
			ip_mask[oct] = atoi(buffer.substr(pos,len).data());
			// Update current position
			pos += (len+1); // Length + 1 because of '.' !
		}
		// The last octet from curr pos to end of buffer
		ip_mask[3] = atoi(buffer.substr(pos).data());
	}
	// Evaluation of IP-Mask
	for (int oct = 0; oct < 4; oct++) {
		if (ip_mask[oct] < 0 || ip_mask[oct] > 255) err = true;
	}
	
	// Default-Address in case of any error
	if (!found || err) {
		ip_mask[0] = uipNET_MASK0;
		ip_mask[1] = uipNET_MASK1;
		ip_mask[2] = uipNET_MASK2;
		ip_mask[3] = uipNET_MASK3;
	}
			
	return state;
}


/*******************************************************************************
* Method Name  	 : InitializeUart
* Description    : Initializes UARTs by calling their init-method
*
*                  This  method  mainly creates and registers queues
*                  for each initialized UART.
*                  
*                  Currently, only UART2 and UART3 are initialized here.
*                  More may be added, if a code redesign is done for them.
*
* Input          : None
* Output         : None
* Return         : E_SYSINIT_STATE ;
*
*******************************************************************************/
E_SYSINIT_STATE SysInit::InitializeUarts( void )
{
 	E_SYSINIT_STATE state = E_SYSINIT_STATE_INITIALIZED;
	return state;	
}

/*******************************************************************************
* Method Name  	 : LoadUserSettings
* Description    : Initializes the UserSettings
*
*
* Input          : None
* Output         : None
* Return         : UserSettings 
*
*******************************************************************************/
UserSettings SysInit::LoadUserSettings(void)
{
     extern CFiles * p_CFiles;
     
     int size = p_CFiles->ReadUserSettings(&m_usersettings,sizeof(UserSettings) );
     // if the file doesn't exist or it is an different version (mostly an older one) create a new file.
     if( size != sizeof(UserSettings))
     {
          // We use values from CONFIG.INI for chuck temperature limits
          m_usersettings.ChuckTempMaxLimit = p_CSetup->getTempParamSet(1)->getMaxLimit();
          m_usersettings.ChuckTempMinLimit = p_CSetup->getTempParamSet(1)->getMinLimit();
					
          p_CFiles->WriteUserSettings(&m_usersettings,sizeof(UserSettings));
     }
     
     return m_usersettings;
}

/*******************************************************************************
* Method Name  	 : LoadUserSettings
* Description    : Initializes the UserSettings
*
*
* Input          : None
* Output         : None
* Return         : UserSettings 
*
*******************************************************************************/
void SysInit::SaveUserSettings(UserSettings usersettings )
{
     extern CFiles * p_CFiles;
     m_usersettings = usersettings;
     p_CFiles->WriteUserSettings(&usersettings,sizeof(UserSettings));
}


/*******************************************************************************
* Method Name  	 : LoadChuckList
* Description    : Initializes the ChuckList
*
*
* Input          : None
* Output         : None
* Return         : None
*
*******************************************************************************/
void SysInit::LoadChuckList(void)
{
  extern CFiles * p_CFiles;
     
	// Load optional chucklist from filesystem. If present, it is used to render the "System Configuration" window
	//static CChuckList *pChucklist = new CChuckList();
	pChucklist->Init();
}



/*******************************************************************************
* Method Name  	 : InitializeSetupFiles
* Description    : Initializes the Setup files
*
*
* Input          : None
* Output         : None
* Return         : none
*
*******************************************************************************/
void SysInit::InitializeSetupFiles(void )
{
	 extern CFiles * p_CFiles;
	 p_CSetup->WriteDefaultSettings();
}


/*******************************************************************************
* Method Name  	 : CheckForDisplayUpdate
* Description    : Checks existance of Display Update files and triggers update
*
* Input          : None
* Output         : None
* Return         : none
*******************************************************************************/
void SysInit::CheckForDisplayUpdate( void )
{
  extern CFiles * p_CFiles;
	extern char display_update_flag;
	if (p_CFiles->fileExists("DUPDATE.DF") && p_CFiles->fileExists("DUPDATE.MD5")) display_update_flag = 1;
}


/*******************************************************************************
* Method Name  	 : CheckBackup
* Description    : Checks if Backup is valid. If not, a backup will be saved from current filesystem
*
* Input          : None
* Output         : None
* Return         : One of enum values \ref FS_CHECK_STATUS
*******************************************************************************/
BCK_CHECK_STATUS SysInit::CheckBackup( void )
{
	return E_BCK_VALID;
}



/*******************************************************************************
* Method Name  	 : CheckFileSystem
* Description    : Checks if Filesystem is valid. If not, it tries to restore it from backup
*
* Input          : None
* Output         : None
* Return         : One of enum values \ref FS_CHECK_STATUS
*******************************************************************************/
FS_CHECK_STATUS SysInit::CheckFileSystem( void )
{
	return E_FS_VALID;
}



/*******************************************************************************
* Method Name  	 : CheckSystem
* Description    : Makes a system self test
*
* Input          : None
* Output         : None
* Return         : One of enum values \ref SYSTEM_STATUS
*******************************************************************************/


SYSTEM_STATUS SysInit::CheckRepairSystem( void )
{
  extern CFiles * p_CFiles;

	bck_exist_stat bckStat = BCK_EXIST_NONE;
//	_EraseSector(0, 100);
//	return E_SYS_OK;

	// Initialize terminal
	cTerm.Clear();
	cTerm.Printf("System self test, %s", REV);
	
	// Check existance of a filesystem backup
	bckStat = p_CBackup->Exist();

	// Check, if filesystem can be mounted
	E_VOLUME_STATE mounted = p_CFiles->mountFileSystem();
	if (mounted == E_VOLUME_UNKNOWN) 
	{
		 p_CFiles->formatDisk();
     mounted =  p_CFiles->mountFileSystem();     
     if (mounted == E_VOLUME_UNKNOWN)
		 {
			cTerm.Printf("Filesystem could not be mounted! Please contact ERS!");	
			return E_SYS_ERR_FS;
		 }
	}
	
	// Check filesystem. If corrupt:
	if (!p_CBackup->CheckFs()) 
	{
		// a) no backup available
		if ( bckStat == BCK_EXIST_NONE )
		{
			cTerm.Printf("Filesystem error! Please contact ERS!");	
			return E_SYS_ERR_FS;
		}
		// b) backup available
		else
		{
			cTerm.Printf("Filesystem is corrupt and will be restored from backup");
			
			// Only original backup available? Restore this
			if ( bckStat == BCK_EXIST_ORG )
			{ 
				p_CBackup->Restore( BCK_TYPE_ORG );
				cTerm.Printf("Filesystem restored from production backup. Please restart device");
				return E_SYS_FS_RESTORE;
			}
			// Current backup available? Restore this
			else
			{
				p_CBackup->Restore( BCK_TYPE_CUR );
				cTerm.Printf("Filesystem restored from current backup. Please restart device");
				return E_SYS_FS_RESTORE;
			}
		}
	}
	else
	{
		cTerm.Printf("Filesystem check OK");	
		
		// No current backup available yet? Save backup from current configuration
    if ( bckStat == BCK_EXIST_NONE || bckStat == BCK_EXIST_ORG )
		{
			p_CBackup->Save( BCK_TYPE_CUR );	
		}
		// No original backup available yet? Save backup from current configuration
    if ( bckStat == BCK_EXIST_NONE || bckStat == BCK_EXIST_CUR)
		{
			p_CBackup->Save( BCK_TYPE_ORG );	
		}		
	}
	return E_SYS_OK;
}
