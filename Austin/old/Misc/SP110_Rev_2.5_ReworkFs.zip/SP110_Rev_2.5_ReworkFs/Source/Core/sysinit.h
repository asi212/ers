/******************** (C) ERS Electronic GmbH **********************************
* File Name          : sysinit.h
* Author             : Khaukha-Mabinda Paddy
* Date First Issued  : 15.03.2012 : Version 1.0
* Description        : System Initialization Class
**==============================================================================
* Comment:
* This class is used only once during System Inintialization. The Class can not
* be initiated, hence only static methods are defined.
********************************************************************************
* History:
* 15.03.2012 : Version 1.0
*********************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __SYSINIT_H
#define __SYSINIT_H

#define uipIP_ADDR0		172
#define uipIP_ADDR1		30
#define uipIP_ADDR2		240
#define uipIP_ADDR3		199	

//#define uipIP_ADDR0		169
//#define uipIP_ADDR1		254
//#define uipIP_ADDR2		117
//#define uipIP_ADDR3		50	


/* Netmask configuration. */
#define uipNET_MASK0	255
#define uipNET_MASK1	255
#define uipNET_MASK2	0
#define uipNET_MASK3	0

typedef enum
{
	E_SYSINIT_STATE_IDLE,
	E_SYSINIT_STATE_INITIALIZING,
	E_SYSINIT_STATE_INITIALIZED

}E_SYSINIT_STATE;

typedef enum 
{
    E_STANDARD_CONTROL,
    E_PROGRESSIVE_CONTROL,
    E_LOWNOISE_CONTROL
}TEMP_CONTROL_MODE;

typedef enum 
{
    E_OPTION_BUTTON_PLUS_MINUS,
    E_OPTIONS_BUTTON_STATIC_TEMP
}BUTTON_CONFIG_OPTION_MODE;

typedef enum 
{
		E_FS_VALID,
		E_FS_RESTORED,
		E_FS_INVALID,
} FS_CHECK_STATUS;

typedef enum 
{
		E_BCK_VALID,
		E_BCK_ORG_INVALID,
		E_BCK_CUR_INVALID,
		E_BCK_BOTH_INVALID,
} BCK_CHECK_STATUS;

typedef enum 
{
		E_SYS_OK,
		E_SYS_ERR_FS,						/**< The filesystem is corrupt				*/
		E_SYS_FS_RESTORE,		    /**< The filesystem has been restored */
} SYSTEM_STATUS;



typedef struct _UserSettings
{
   int  Version;  // Change Version whenever new fields are added to or removed from the struct. See sysint.cpp 
   TEMP_CONTROL_MODE TemperatureControlMode;
   bool DewpointTrackingActive;
   float DewpointTrackingOffset;
   int ActiveTemperatureOffsetTable;
   BUTTON_CONFIG_OPTION_MODE buttonConfigOption;
   float ButtonOptionPlusMinusValue;
   float ButtonOptionTemp1;
   float ButtonOptionTemp2;
   float ChuckTempMaxLimit;
   float ChuckTempMinLimit;
   bool  SystemEnabled;
   
}UserSettings;

typedef struct _PEER_SYSTEM_STATUS
{
  float SetTemp;
  int   OperationMode;
  int   ControlState;
  int   MacId;
  bool  controller;
  unsigned char   connectionState;
  unsigned char compressorOperation; 
}PeerSystemStatus;


class SysInit
{
	private:
		SysInit(){;}
		~SysInit(){;}

	public:

		static E_SYSINIT_STATE LoadSetup( void );
		static E_SYSINIT_STATE InitializeIPAddress(char p);
		static E_SYSINIT_STATE InitializeItemIPAddress(char *filename, int *ipaddr, int *mask);
 		static E_SYSINIT_STATE InitializeUarts( void );
		static UserSettings LoadUserSettings(void);
		static void SaveUserSettings(UserSettings usersettings );
		inline static UserSettings GetUserSettings(void){return m_usersettings;}
		inline static void SetUserSetting(UserSettings usersettings){m_usersettings = usersettings;}
		static UserSettings m_usersettings;
		static void InitializeSetupFiles(void);
		static E_SYSINIT_STATE LoadDefaultSetup( void );
		static void LoadChuckList(void);
		static void CheckForDisplayUpdate( void );
	  static FS_CHECK_STATUS CheckFileSystem( void );
		static BCK_CHECK_STATUS CheckBackup( void );
		static SYSTEM_STATUS CheckRepairSystem( void );
};

#endif //__SYSINIT_H
