/**
*  \file
*    CDeviceManager.cpp
*   
*  \brief Implementation of the Class CDeviceManager
*  \date 10-Jan-2011 16:15:37
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#include "CSetup.h"
#include "CDeviceManager.h"
#include "IDevice.h"
#include "EAeDIPTFT43A.h"
#include "Devices\CAirPressureSensor.h"
#include "Devices\COverTemperatureSensor.h"


CDeviceManager::CDeviceManager( CEventManager * pEventManager )
{
    
  m_pEventManager = pEventManager;
  devicelist.reserve(3);
  name.reserve(20);
}

CDeviceManager::~CDeviceManager()
{

}

void CDeviceManager::cycCalc()
{
	if (devicelist.size() == 0) return;
        for (int i=0; i<devicelist.size(); i++)
        {
          (*devicelist[i]).cycCalc();
        }
}

void CDeviceManager::Init(const char* devmgr_name)
{  
	extern CSetup * p_CSetup;
	IDevice *p_device;
	
  // ---- Erstellen und Hinzufuegen der Geraete: ---- 
    
  // Messecontroller-Displaydevice: Das Display 1:
  p_device = new EAeDIPTFT43A_Contr;
  p_device->Init( m_pEventManager, "display_1");
  devicelist.push_back(p_device);
	
	// Eingangs-Luftdruckmessung, aber nur bei Chiller 10 
	// d.h. cControllerType = E_CHILLER_MST_SWS_D600 in CONFIG.INI
	if ( p_CSetup->getConConfig() == CSetup::_s_config::E_CHILLER_MST_SWS_D600 		|| 
			 p_CSetup->getConConfig() == CSetup::_s_config::E_CHILLER_MST_SWS_600  		||
			 p_CSetup->getConConfig() == CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600	)
	{
		p_device = new CAirPresssureSensor;
	  p_device->Init( m_pEventManager, "eingangsdruck_sensor");
  	devicelist.push_back(p_device);		
	}

	// Unterst�tzung JUMO-Temperaturw�chter
	p_device = new COverTemperatureSensor;
	p_device->Init( m_pEventManager, "uebertemperatur_sensor");
	devicelist.push_back(p_device);		
	
  //Weitere Hardware..:
  
}

IDevice* CDeviceManager::GetDeviceHandle(const char* dev_name)
{
	string searched_name = dev_name;
	
	for (int i=0; i<devicelist.size(); i++)
	{
		if ( devicelist[i]->m_name.compare(searched_name) == 0 )
		return devicelist[i];
	}
	return NULL;
}
