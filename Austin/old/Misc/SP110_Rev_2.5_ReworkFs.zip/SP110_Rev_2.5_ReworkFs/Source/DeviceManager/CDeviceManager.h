/**
*  \file
*    CDeviceManager.cpp
*   
*  \brief Implementation of the Class CDeviceManager
*  \date 10-Jan-2011 16:15:37
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#if !defined(CDEVICEMANAGER_H__INCLUDED_)
#define CDEVICEMANAGER_H__INCLUDED_

#include "..\system_wide_defs.h"
#include "IDevice.h"
#include "CEventManager.h"
#include <vector>

class CDeviceManager
{

public:
	CDeviceManager( CEventManager * pEventManager );
	virtual ~CDeviceManager();
	/**
	 * Pointer to the responsible mailbox should be set with the constructor. The
	 * mailbox should know the name of this window, an be registered as recipient by
	 * the object that created the window. (see function
	 * add_recipient/remove_recipient in class CMailbox)
	 */

        CEventManager * m_pEventManager;
	void cycCalc();
	void Init(const char* devmgr_name);
	IDevice* GetDeviceHandle( const char* dev_name );

private:
        std::vector<IDevice*> devicelist;
        std::vector<IDevice*>::iterator d_it;
	string name; //res
        IDevice* p_device;
};

void Devicemanager_Task(void *pvParameters);

#endif // !defined(CDEVICEMANAGER_H__INCLUDED_)

