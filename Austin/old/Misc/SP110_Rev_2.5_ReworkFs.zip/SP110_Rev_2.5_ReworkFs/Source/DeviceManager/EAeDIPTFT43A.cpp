/**
*  \file
*    EAeDIPTFT43A.cpp
*   
*  \brief Implementation of the Class EA eDIPTFT43A
*  \date 10-Jan-2011 16:15:54
*  \author
*    Michael Brunner
*    , Lars Possberg
*/
#include "..\system_wide_defs.h"
#include "EAeDIPTFT43A.h"
#include <vector>
#include "FreeRTOS.h"
#include "task.h"
#include <stdio.h>

extern "C"
{
  #include "91x_uart.h"
  #include "91x_lib.h"
  
  /* Scheduler includes. */
  #include "FreeRTOS.h"
  #include "task.h"
  #include "queue.h"
  #include "serial.h"  
    
  //Dateisystem
  //(includes stehen nur hier um in der Main formatieren zu koennen)
  #include "FS.h" //PowerPac File System
  #include "ff.h" //FAT File System
  #include "diskio.h" //FAT File System
}

#include "hl_md5.h" //Lib zur Pruefsummenberechnung

int status1 = -2; //Dateisystem Statusspeicher
int status2 = -2; //Dateisystem Statusspeicher
int status3 = -2; //Dateisystem Statusspeicher
int status4 = -2; //Dateisystem Statusspeicher

unsigned char hashwert1[17] = {0};
unsigned char hashwert2[17] = {0};

HL_MD5_CTX context; // Speicher fuer eine MD5-Checksummenberechnung
MD5 MD5_calculator; // Das Objekt dass MD5-Cheksummen berechnen kann

unsigned char buffer[SIZE_OF_BUFFER]; //Lese-/Schreibpuffer
u16 flash_schreib_buffer=0;
long lasting_bytes; //Wie viele Bytes muessen noch gelesen/geschrieben werden?

vector<char> tx_uartdata(SIZE_OF_BUFFER); //UART2 (display) Send-Buffer
vector<char> rx_uartdata(SIZE_OF_BUFFER); //UART2 (display) commands to send

extern xQueueHandle xUart2RxChars;
extern xQueueHandle xUart2TxChars;

/*
265 Displaybuffergroesse           UART2:
+   1 <DC1>                              8 Datenbits
+   1 len                              + 1 Startbit
+   1 bcc                              + 1 Stopbit
= unter 265 Byte = 2120 bit          -------------
= 10 bit  => faktor 1.2
2120 bit * 1.2 = 2544 bit insgesamt

2544 bit / (115000 bit/s) = 22.1 ms
Nach 22,1 ms hat das Display alle Daten aus seinem Buffer verschickt.
25ms zu warten k�nnte also ausreichen.
1/(25ms) entspr�che maximalen 40 Frames per second f�r die Reaktionszeit
plus der Reaktionszeit des cycCalc des Displaymanagers
=> m�sste schnell genug sein ohne dass der Nutzer
eine Verz�gerung feststellt

F�r unter 11 Datenbyte:
14*8=112 112*1.2=135 135/115000=1.18ms also ca. 2 ms
F�r <ACK> und len:
5*8=40 40*1.2=48 also etwa 1 ms
*/
const portTickType rx_long_delay = 80 / portTICK_RATE_MS; //Maximale Wartezeit
const portTickType task_suspend_delay = 2000 / portTICK_RATE_MS; //2s um dem Scheduler genug Zeit zum Suspenden der Tasks zu geben
const portTickType rx_short_delay  = 2 / portTICK_RATE_MS; //Es sind weniger als 11 Datenbyte zu erwarten
const portTickType rx_supershort_delay = 4 / portTICK_RATE_MS;//K�rzeste Wartezeit, erstmal nur auf <ACK> und len warten

const char get_buffer_cmd[] = "\x53"; //Displaypufferinhalt anfragen //=3
const char get_buffer_info[] = "\x49"; //Pufferinformationen abfragen //=3

EDIPstate state = CALL_FOR_DATA;


EAeDIPTFT43A::EAeDIPTFT43A()
{
    m_event_set_temp_1 = new _event<float>( "ediptft43a", CEventNames::set_temp1_changed, 25.0 );
    m_event_compessor_status = new _event<float>( "ediptft43a", CEventNames::compressor_status, false );

    name.reserve(20);
}

EAeDIPTFT43A::~EAeDIPTFT43A(){}

/**
* Initialisation of the Hardware
*/
void EAeDIPTFT43A::Init( CEventManager * pEventManager, const char *dev_name)
{
	len = 0; //zu erwartende Zeichenzahl
	bcc = 0; //Checksumme
	c = 0;    //Zwischenspeicher
	cmd = 0; //Zwischenspeicher des Befehls
        //MB Event Handler
        m_pEventManager = pEventManager;
        m_pEventManager->AddEventHandler( CEventNames::display_update, EAeDIPTFT43A::display_updateEventWrapper, this );
}

void EAeDIPTFT43A::display_updateEvent( bool b )
{
    update_display("dupdate.DF", "dupdate.MD5", UART2);
    _event<bool> e("EDIPTFT43A", CEventNames::display_update_finished, true );
    m_pEventManager->RaiseEvent(e);
}

unsigned short generate_bcc(vector<char>* data)
{
	unsigned short bcc = 0;
	for (int i=0; i < data->size(); i++)
	{
		bcc += data->at(i);
	}
	return bcc;
}

char ready_to_take=0, bytes_free=0;
bool still_need_to_send_data = true;
void poll_while_displaybuffer_empty_enough(vector<char>* buffer, char needed_free_bytes ,UART_TypeDef* UARTx)
{
  char cTemp;
  still_need_to_send_data = true;
  while (still_need_to_send_data)
  {
    bytes_free=0;
    //while( !buffer->empty() ) buffer->pop_back();
    buffer->clear();
		buffer->push_back('I'); //Command for receiving the buffer-info
    Send_dc2_cmd(buffer, UARTx );
    buffer->clear();
		//while( !buffer->empty() ) buffer->pop_back();
    xQueuePeek(xUart2RxChars, &cTemp,  10 * portTICK_RATE_MS ); //Warte auf erste daten...
    while (xQueueReceive( xUart2RxChars, &cTemp, 1 * portTICK_RATE_MS ) )
    {
        buffer->push_back(cTemp); //Receive Buffer leerraeumen
    }
    bytes_free = buffer->at(3);
    if (bytes_free > needed_free_bytes) still_need_to_send_data = false; //Genug Platz fuer die zu sendenden Daten vorhanden
  }
}

char Send_dc1_cmd(vector<char>* data, UART_TypeDef* UARTx)
{
	char c=0;
	//siehe Datenblatt:
	//data = <DC1> + Byteanzahl + Daten
	data->insert(data->begin(), (unsigned char)data->size());
	//data = <DC1> + Daten
	data->insert(data->begin(), 0x11);
	//data = <DC1> + Byteanzahl + Daten + CRC16
	data->push_back(generate_bcc(data));
     
        //Activate Driver and Deactivate Receiver of 'SN75176':
        GPIO_WriteBit(GPIO6, GPIO_Pin_2, Bit_SET);
        
        
	//Send the Data:
	for (int i=0; i < data->size(); i++)
	{
                //while(RESET == UART_GetFlagStatus(UARTx,UART_FLAG_TxFIFOEmpty)) vTaskDelay(1);//wait active here while data been send
                while( SET == UART_GetFlagStatus(UARTx,UART_FLAG_Busy)) vTaskDelay(1);//wait active here while data been send
		UART_SendData(UARTx, data->at(i));
	}
        while(SET == UART_GetFlagStatus(UARTx,UART_FLAG_Busy) || RESET == UART_GetFlagStatus(UARTx,UART_FLAG_TxFIFOEmpty));//wait active here while data been send        
        //Deactivate Driver and activate Receiver of 'SN75176':
        GPIO_WriteBit(GPIO6, GPIO_Pin_2, Bit_RESET);
        xQueueReceive( xUart2RxChars, &c,  100 * portTICK_RATE_MS );
        data->pop_back();
        data->erase(data->begin());
        data->erase(data->begin());
        return c;
}

char Send_dc2_cmd(vector<char>* data, UART_TypeDef* UARTx, int timeout )
{
  
	char c=0;
	//siehe Datenblatt:
	//data = <DC2> + Byteanzahl + Daten
	//data->insert(data->begin(), (char)data->size());
        data->insert(data->begin(), (unsigned char)data->size());
	//data = <DC2> + Daten
	data->insert(data->begin(), 0x12);
	//data = <DC2> + Byteanzahl + Daten + CRC16
	data->push_back(generate_bcc(data));
        
        //Activate Driver and Deactivate Receiver of 'SN75176':
        GPIO_WriteBit(GPIO6, GPIO_Pin_2, Bit_SET);
        
	//Send the Data:
	for (int i=0; i < data->size(); i++)
	{
          //while( RESET == UART_GetFlagStatus(UARTx,UART_FLAG_TxFIFOEmpty)) vTaskDelay(1);//wait active here while data been send
          while( SET == UART_GetFlagStatus(UARTx,UART_FLAG_Busy)) vTaskDelay(1);//wait active here while data been send
          UART_SendData(UARTx, data->at(i));
        }         
        while(SET == UART_GetFlagStatus(UARTx,UART_FLAG_Busy) || RESET == UART_GetFlagStatus(UARTx,UART_FLAG_TxFIFOEmpty));//wait active here while data been send
        
        //Deactivate Driver and activate Receiver of 'SN75176':
        GPIO_WriteBit(GPIO6, GPIO_Pin_2, Bit_RESET);
        xQueueReceive( xUart2RxChars, &c, timeout * portTICK_RATE_MS  );
        data->pop_back();
        data->erase(data->begin());
        data->erase(data->begin());
        return c;
}


void update_display(string update_filename, string checksum_filename, UART_TypeDef* UARTx)
{ 
  
  //200ms warten, bis der Scheduler die beiden Tasks auch wirklich pausiert hat:
  vTaskDelay(task_suspend_delay);
  
  taskENTER_CRITICAL(); //Sichergehen dass keine Task dazwischenfunkt
 
  bool resend = false;
  char c_update_filename[20] = {0};
  char c_checksum_filename[20] = {0};
  int name_len = 0;
  char c = 0;
  //Kopieren der strings in normale c_strings fuer die Dateisystemfunktionen
  name_len = update_filename.size();
  for (int i=0; i<19; i++) c_update_filename[i] = update_filename[i];
  name_len = checksum_filename.size();
  for (int i=0; i<19; i++) c_checksum_filename[i] = checksum_filename[i];

  FS_Mount("ERS_DSK_1");
  MD5_calculator.MD5Init(&context); //Initialisierung des MD5-Berechners

  // Ueberpruefen, ob gueltiges Dateisystem
  // vorhanden. Sollte das nicht der FAll sein,
  // wird der Vorgang abgebrochen
  status1 = FS_IsLLFormatted ("ERS_DSK_1");
  status4 = FS_IsHLFormatted ("ERS_DSK_1");

  if ((status1 == 1) && (status4 == 1)) //Low-und High-level-formatierung sind vorhanden
  {
    status2 =  FS_GetVolumeStatus("ERS_DSK_1");
    status3 =  FS_IsVolumeMounted("ERS_DSK_1");
    if ((status2 == FS_MEDIA_IS_PRESENT) && (status3 == 1))
    //FlashRom scheint in Ordnung zu sein:
    {
      //---------- #1. Einlesen des hochgeladenen MD5-Hashes. ----------
      FS_FILE *p_FS_FILE = NULL;
      p_FS_FILE = FS_FOpen(c_checksum_filename,"r");
			if (p_FS_FILE != 0)
			{
				int filesize1 = FS_GetFileSize(p_FS_FILE);
				if (filesize1 != -1 && filesize1 == 16) //MD5-Dateigroesse ist schon mal gueltig 
				{
					FS_Read (p_FS_FILE, hashwert1, 16);
					FS_FClose(p_FS_FILE);
					//MD5-Hash erfolgreich gelesen, lesen der Displayupdatebinaerdatei
					// ---- #2. Berechnen eines MD5-Hashes aus den Daten der Updatebinaerdatei. -----
					p_FS_FILE = FS_FOpen(c_update_filename,"r");
					if (p_FS_FILE != NULL)
					{
						int filesize1 = FS_GetFileSize(p_FS_FILE);
						if ((filesize1 != -1) && (filesize1 > 0))
						{
							lasting_bytes = filesize1;
							while (lasting_bytes > 0)		
							{
								if (lasting_bytes < SIZE_OF_BUFFER)
								{
									FS_Read (p_FS_FILE, buffer, lasting_bytes);
									MD5_calculator.MD5Update(&context, buffer, lasting_bytes);
									lasting_bytes = 0;
								}
								else
								{
									FS_Read (p_FS_FILE, buffer, SIZE_OF_BUFFER);
									MD5_calculator.MD5Update(&context, buffer, SIZE_OF_BUFFER);
									lasting_bytes -= SIZE_OF_BUFFER;
								}
							}
							FS_FClose(p_FS_FILE);
							MD5_calculator.MD5Final(hashwert2, &context);
							//------------- #3. Vergleichen beider MD5-Hashes --------------
							int hash_valid = 1;
							for(int i=0; i<16; i++)
							{
								if (hashwert1[i] != hashwert2[i])
								{
									hash_valid = 0;
								}
							}
							if (hash_valid) //Binaerdateihash stimmt mit anderem Hash ueberein
								{
									//---------- #4. Paketweises Senden der Daten ans Display -----------
									p_FS_FILE = FS_FOpen(c_update_filename,"r");
									if (p_FS_FILE != NULL)
									{
										int filesize1 = FS_GetFileSize(p_FS_FILE);
										if ((filesize1 != -1) && (filesize1 > 0))
										{ //Binaerdateigroesse ist gueltig
											lasting_bytes = filesize1;
											while (lasting_bytes > 0)		
											{
												if (lasting_bytes < SIZE_OF_BUFFER)
												{
													FS_Read (p_FS_FILE, buffer, lasting_bytes);
													//Senden der Daten (NICHT komplett voller buffer)
													//<|1|> Vorbereitung des Pakets
													while (!rx_uartdata.empty())rx_uartdata.pop_back();
													for(int i=0; i<lasting_bytes; i++)
													{
														rx_uartdata.push_back(buffer[i]); //copy data
													}
													resend = true;
													while(resend) //Packet so lange neu verschicken bis es erfolgreich angenommen wurde
													{
														//<|2|> Send dc1
														poll_while_displaybuffer_empty_enough(&tx_uartdata, ((char)rx_uartdata.size()+4), UARTx);
														c = Send_dc1_cmd(&rx_uartdata, UARTx);
														if (c == '\x06')
														{
																resend = false;//<ACK> empfangen, alles ok, ggf. das naechste Paket senden
														}
														else //<NACK> oder irgendwas anderes, unerwartetes empfangen, Paket nochmal senden...
														{
															vTaskDelay(rx_long_delay);//vom Protokoll gefordertes timeout...
															resend = true;
														}
													}
													lasting_bytes = 0;
												}
												else
												{
													FS_Read (p_FS_FILE, buffer, SIZE_OF_BUFFER);
													//Senden der Daten (komplett voller buffer)
													//<|1|> Vorbereitung des Pakets
													//while (!rx_uartdata.empty())rx_uartdata.pop_back();
													rx_uartdata.clear();
													for(int i=0; i<SIZE_OF_BUFFER; i++)
													{
														rx_uartdata.push_back(buffer[i]); //copy data
													}
													resend = true;
													while(resend) //Packet so lange neu verschicken bis es erfolgreich angenommen wurde
													{
														//<|2|> Send dc1
														poll_while_displaybuffer_empty_enough(&tx_uartdata, ((char)rx_uartdata.size()+4), UARTx);
														c = Send_dc1_cmd(&rx_uartdata, UARTx);
														if (c == '\x06')
														{
																resend = false;//<ACK> empfangen, alles ok, ggf. das naechste Paket senden
														}
														else //<NACK> oder irgendwas anderes, unerwartetes empfangen, Paket nochmal senden...
														{
															vTaskDelay(rx_long_delay);//vom Protokoll gefordertes timeout...
															resend = true;
														}
													}
													lasting_bytes -= SIZE_OF_BUFFER;
												}
											}
											FS_FClose(p_FS_FILE);
											//------------------- #5. Loeschen der Binaer- und MD5-Dateien. --------------------
										  // NOTE: We only delete update files named DUPDATE.*. Update files named DTELNET.* are not removed
											if (update_filename.compare("DUPDATE.DF") == 0)
											{
												FS_Remove(c_update_filename); 
												FS_Remove(c_checksum_filename); 
											}
										}
									}
								}
						}
					}
				}
    	}
		}
  }
  taskEXIT_CRITICAL();
}




void clean_displaybuffer(UART_TypeDef* UARTx) //gets rid of all data in the displaybuffer
{
    char c;
    tx_uartdata.assign(get_buffer_cmd,get_buffer_cmd+1);
    Send_dc2_cmd(&tx_uartdata, UART2);
    vTaskDelay(rx_long_delay); //Expect huge amount of data...
    while(xQueueReceive( xUart2RxChars, &c, 1 * portTICK_RATE_MS)); //... and send it to nowhere
}

void EAeDIPTFT43A::send_direct_cmd3_dataEvent( void * p)
{    
    vector<char> * pCmd = p;
    while (!rx_uartdata.empty())rx_uartdata.pop_back();
    for(int i=0; i < pCmd->size(); i++)
    {
      rx_uartdata.push_back((char)((*pCmd)[i])); //copy data
    }
    poll_while_displaybuffer_empty_enough(&tx_uartdata, ((char)rx_uartdata.size()+4), UART2);
    c = Send_dc1_cmd(&rx_uartdata, UART2);
}

//const string dest_mainmenu = "mainmenu";

void EAeDIPTFT43A::cycCalc()
{
    msg * p_msg = NULL;
	//1. Check displaybuffer
	while (!tx_uartdata.empty())tx_uartdata.pop_back();
	len = 0;
	bcc = 0;
	tx_uartdata.assign(get_buffer_cmd,get_buffer_cmd+1); //bufferinhalt-befehl holen
	Send_dc2_cmd(&tx_uartdata, UART2); //Befehl senden (Achtung: <DC2> !)
	vTaskDelay(rx_supershort_delay); //uC senden lassen
	vTaskDelay(rx_supershort_delay); //Display senden lassen
	c = UART_ReceiveData(UART2);
	if(c != 0x06)//<ACK> checken
	{ //kein <ACK>! => alles leerr�umen! (Display antwortet nicht auf Befehl!)
		clean_displaybuffer(UART2);
	}
	else
	{
		bcc += 0x06; //Checksumme aktualisieren
		c = UART_ReceiveData(UART2);
		if(c == 0x11)//<DC1> checken
		{
			bcc += 0x11; //<DC1>
			len = UART_ReceiveData(UART2); //len
			bcc += len;

			if(len>0)
			{
				for (int i=0; i<len; i++)
				{
					c = UART_ReceiveData(UART2);
					bcc += c;
					//die drei ueberfluessigen bytes nicht speichern:
					if (i==3)
					{
						cmd = c;
					}
				}
			}
			c = UART_ReceiveData(UART2); //drop bcc
			//Zusaetzliche moegliche Daten verwerfen:
			while(RESET == UART_GetFlagStatus(UART2,UART_FLAG_RxFIFOEmpty)) c = UART_ReceiveData(UART2);
			if (len > 0) //Es gibt estwas zu versenden:
			{
				//state = SEND_MSG;
			}
			else //Naechster Versuch:
			{
				//state = CALL_FOR_DATA;
			}
    }
	}
}
