/**
*  \file
*    EAeDIPTFT43A.cpp
*   
*  \brief Implementation of the Class EA eDIPTFT43A
*  \date 29-Mar-2011 10:51:00
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#if !defined(EAEDIPTFT43A_H__INCLUDED_)
#define EAEDIPTFT43A_H__INCLUDED_

#include "..\system_wide_defs.h"
#include "IDevice.h"
#include "CEventManager.h"
#include "msg.h"
#include <stdio.h>
#include <vector>
#include "FreeRTOS.h"

extern "C"
{
  #include "91x_uart.h"
  #include "91x_lib.h"
  
  /* Scheduler includes. */
  #include "FreeRTOS.h"
  #include "task.h"
  #include "queue.h"
  
  //Dateisystem
  //(includes stehen nur hier um in der Main formatieren zu koennen)
  #include "FS.h" //PowerPac File System
  #include "ff.h" //FAT File System
  #include "diskio.h" //FAT File System
}




#define SIZE_OF_BUFFER 255 // Groesse des Lese-/Schreibpuffers in Byte

//MD5-Pruefsumme aus einem Vektor erstellen:
unsigned short generate_bcc(vector<char>* data);

//void Send_dc1_cmd_old(vector<char> data, UART_TypeDef* UARTx);
char Send_dc1_cmd(vector<char>* data, UART_TypeDef* UARTx);
char Send_dc2_cmd(vector<char>* data, UART_TypeDef* UARTx, int timeout = 100);
char external_display_connect(vector<char>* v_buffer, UART_TypeDef* UARTx, int active_display_num[], CEventManager * pEventManager);

void poll_while_displaybuffer_empty_enough(vector<char>* buffer, char needed_free_bytes, UART_TypeDef* UARTx);

//Ein DIsplayupdate durchfuehren:
void update_display(string update_filename, string checksum_filename, UART_TypeDef* UARTx);

//Den Sendebuffer des Displays leeren:
void clean_displaybuffer(UART_TypeDef* UARTx);

enum EDIPstate {CALL_FOR_DATA, //Daten erbitten
	CATCH_ACK_LEN, //<ACK> und LEN abfangen
	GRAB_CMDS, //Befehle sammeln
	SEND_MSG  //Den entsprechenden Fenstern die Befehle uebermitteln
};


//Chiller-Display-Device
class EAeDIPTFT43A : public IDevice
{

public:
        EAeDIPTFT43A();
	virtual ~EAeDIPTFT43A();

	void cycCalc();
	/**
	 * Initialisation of the Hardware
	 */
	void Init(CEventManager* pEventManager, const char *dev_name);

        string name; //res
          
        char  len, //zu erwartende Zeichenzahl
              bcc, //Checksumme
                c, //Zwischenspeicher
              cmd; //Zwischenspeicher des Befehls
        //MB Event Handler
        CEventManager * m_pEventManager;
        static void display_updateEventWrapper( void * pObject, bool b ){ ((EAeDIPTFT43A*)pObject)->display_updateEvent( b ); };
        void display_updateEvent( bool b );
        static void send_direct_cmd2_dataEventWrapper( void * pObject, void * p ){ ((EAeDIPTFT43A*)pObject)->send_direct_cmd2_dataEvent( p ); };
        void send_direct_cmd2_dataEvent( void * p );
        static void send_direct_cmd3_dataEventWrapper( void * pObject, void * p ){ ((EAeDIPTFT43A*)pObject)->send_direct_cmd3_dataEvent( p ); };
        void send_direct_cmd3_dataEvent( void * p );

private:
	/**
	 * Pointer to the responsible mailbox should be set with the constructor. The
	 * mailbox should know the name of this window, an be registered as recipient by
	 * the object that created the window. (see function
	 * add_recipient/remove_recipient in class CMailbox)
	 */
        void Send(string data);
        unsigned short generate_CRC16( string data );
        
        //Static Messages
        _event<float>* m_event_set_temp_1;
        _event<bool>* m_event_compessor_status;

};


//Messecontroller-Display-Device
class EAeDIPTFT43A_Contr : public IDevice
{
public:
        EAeDIPTFT43A_Contr();
	virtual ~EAeDIPTFT43A_Contr();

	void cycCalc();
	/**
	 * Initialisation of the Hardware
	 */
	void Init(CEventManager* pEventManager, const char *dev_name);

        string name; //res
          
        char  len, //zu erwartende Zeichenzahl
              bcc, //Checksumme
                c, //Zwischenspeicher
              cmd; //Zwischenspeicher des Befehls
        int active_display_num[2]; //Speicher um sich das 'zuletzt un derzeit aktiven' Displays zu merken
        bool touched; //Flag um einen Tastendruck zu vermerken, setzt den Dimmerzaehler zurueck
        //MB Event Handler
        //Static Messages
        CEventManager * m_pEventManager;
        _event<float>* m_event_set_temp_1;
        _event<bool>* m_event_compessor_status;

        static void display_updateEventWrapper( void * pObject, bool b ){ ((EAeDIPTFT43A_Contr*)pObject)->display_updateEvent( b ); };
        void display_updateEvent( bool b );
        static void set_hold_modeEventWrapper( void * pObject, bool b ){ ((EAeDIPTFT43A_Contr*)pObject)->set_hold_modeEvent( b ); };
        void set_hold_modeEvent( bool b );

        static void send_direct_cmd2_dataEventWrapper( void * pObject, void * p ){ ((EAeDIPTFT43A_Contr*)pObject)->send_direct_cmd2_dataEvent( p ); };
        void send_direct_cmd2_dataEvent( void * p );
        static void send_direct_cmd3_dataEventWrapper( void * pObject, void * p ){ ((EAeDIPTFT43A_Contr*)pObject)->send_direct_cmd3_dataEvent( p ); };
        void send_direct_cmd3_dataEvent( void * p );
private:
	/**
	 * Pointer to the responsible mailbox should be set with the constructor. The
	 * mailbox should know the name of this window, an be registered as recipient by
	 * the object that created the window. (see function
	 * add_recipient/remove_recipient in class CMailbox)
	 */
        void Send(string data);
        unsigned short generate_CRC16( string data );
				
				int i_buf[3]; //kleiner Buffer, spart ein wenig code ein...
				bool hold_mode_status; // Flag remembering if hiold mode is currently enabled or not. Required for toggling hold mode via display button
};
#endif // !defined(EAEDIPTFT43A_H__INCLUDED_)
