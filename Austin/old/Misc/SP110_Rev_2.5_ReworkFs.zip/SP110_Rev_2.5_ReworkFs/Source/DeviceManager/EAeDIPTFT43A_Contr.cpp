/**
*  \file
*    EAeDIPTFT43A_Contr.cpp
*   
*  \brief Implementation of the Class EA eDIPTFT43A
*  \date 10-Jan-2011 16:15:54
*  \author
*    Michael Brunner
*    , Lars Possberg
*/
#include "..\system_wide_defs.h"
#include "EAeDIPTFT43A.h"
#include <vector>
#include "FreeRTOS.h"
#include "task.h"
#include <stdio.h>
#include "CFiles.h"
#include "displaymacros.h"


extern "C"
{  
  /* Scheduler includes. */
  #include "FreeRTOS.h"
  #include "task.h"
  #include "queue.h"
  
  //Dateisystem
  //(includes stehen nur hier um in der Main formatieren zu koennen)
  #include "FS.h" //PowerPac File System
  #include "ff.h" //FAT File System
  #include "diskio.h" //FAT File System
}

#include "hl_md5.h" //Lib zur Pruefsummenberechnung


extern int status1; //Dateisystem Statusspeicher
extern int status2; //Dateisystem Statusspeicher
extern int status3; //Dateisystem Statusspeicher
extern int status4; //Dateisystem Statusspeicher

extern unsigned char hashwert1;
extern unsigned char hashwert2;

extern HL_MD5_CTX context; // Speicher fuer eine MD5-Checksummenberechnung
extern MD5 MD5_calculator; // Das Objekt dass MD5-Cheksummen berechnen kann

extern unsigned char buffer[SIZE_OF_BUFFER]; //Lese-/Schreibpuffer
extern u16 flash_schreib_buffer;
extern long lasting_bytes; //Wie viele Bytes muessen noch gelesen/geschrieben werden?

extern vector<char> tx_uartdata; //UART2 (display) Send-Buffer
extern vector<char> rx_uartdata; //UART2 (display) commands to send

extern xQueueHandle xUart2RxChars;
extern xQueueHandle xUart2TxChars;

/*
265 Displaybuffergroesse           UART2:
+   1 <DC1>                              8 Datenbits
+   1 len                              + 1 Startbit
+   1 bcc                              + 1 Stopbit
= unter 265 Byte = 2120 bit          -------------
= 10 bit  => faktor 1.2
2120 bit * 1.2 = 2544 bit insgesamt

2544 bit / (115000 bit/s) = 22.1 ms
Nach 22,1 ms hat das Display alle Daten aus seinem Buffer verschickt.
25ms zu warten k�nnte also ausreichen.
1/(25ms) entspr�che maximalen 40 Frames per second f�r die Reaktionszeit
plus der Reaktionszeit des cycCalc des Displaymanagers
=> m�sste schnell genug sein ohne dass der Nutzer
eine Verz�gerung feststellt

F�r unter 11 Datenbyte:
14*8=112 112*1.2=135 135/115000=1.18ms also ca. 2 ms
F�r <ACK> und len:
5*8=40 40*1.2=48 also etwa 1 ms
*/
const portTickType rx_long_delay = 80 / portTICK_RATE_MS; //Maximale Wartezeit
const portTickType rx_short_delay  = 2 / portTICK_RATE_MS; //Es sind weniger als 11 Datenbyte zu erwarten
const portTickType rx_supershort_delay = 4 / portTICK_RATE_MS;//K�rzeste Wartezeit, erstmal nur auf <ACK> und len warten

const char get_buffer_cmd[] = "\x53"; //Displaypufferinhalt anfragen //=3
const char get_buffer_info[] = "\x49"; //Pufferinformationen abfragen //=3

extern EDIPstate state;


EAeDIPTFT43A_Contr::EAeDIPTFT43A_Contr()
{
  m_event_set_temp_1 = new _event<float>( "ediptft43a", CEventNames::set_temp1_changed, 25.0 );
  m_event_compessor_status = new _event<bool>( "ediptft43a", CEventNames::compressor_status, false );

  name.reserve(20);
}
EAeDIPTFT43A_Contr::~EAeDIPTFT43A_Contr(){}

/**
* Initialisation of the Hardware
*/
void EAeDIPTFT43A_Contr::Init( CEventManager * pEventManager, const char *dev_name)
{
            
    len = 0; //zu erwartende Zeichenzahl
    bcc = 0; //Checksumme
    c = 0;    //Zwischenspeicher
    cmd = 0; //Zwischenspeicher des Befehls
    
    //Initialwerte des 'zuletzt aktiven' Displays:
    active_display_num[0] = 1;
    active_display_num[1] = 1;
  
    clean_displaybuffer(UART2);
    
    while (!tx_uartdata.empty())tx_uartdata.pop_back(); //empty the vector before use
    tx_uartdata.push_back(65);//'A'
    tx_uartdata.push_back('S');//Select
    tx_uartdata.push_back(7);//Adresse des internen Displays (7)
    c = Send_dc2_cmd(&tx_uartdata, UART2);    
    //MB Event Handler
    m_pEventManager = pEventManager;
    m_pEventManager->AddEventHandler( CEventNames::display_update, EAeDIPTFT43A_Contr::display_updateEventWrapper, this );
    m_pEventManager->AddEventHandler( CEventNames::send_direct_cmd2_data, EAeDIPTFT43A_Contr::send_direct_cmd2_dataEventWrapper, this );
    m_pEventManager->AddEventHandler( CEventNames::send_direct_cmd3_data, EAeDIPTFT43A_Contr::send_direct_cmd3_dataEventWrapper, this );
    m_pEventManager->AddEventHandler( CEventNames::set_hold_mode, EAeDIPTFT43A_Contr::set_hold_modeEventWrapper, this );
}

/**
 * This event may be called by different sources triggering a display update
 * Because update files may have different names, we find out here, which file is present
 * Finally, the display-update routine is called wit the found filename
 */
void EAeDIPTFT43A_Contr::display_updateEvent( bool b )
{
		int i;
 	  extern CFiles * p_CFiles;
 	  string names[] = {"DUPDATE", "DTELNET"};
		
		// Get the name of the Display Update file
		for (i = 0; i < sizeof(names) / sizeof (string); i++)
		{ 
			string name_df  = names[i]+".DF";
			string name_md5 = names[i]+".MD5";
			if (p_CFiles->fileExists(name_df.c_str()) && p_CFiles->fileExists(name_md5.c_str()))  
			{
				update_display(name_df, name_md5, UART2);
				break;
			}
		}
		// Give the display enough time to recover after update. Otherwise, the first commands will be ignored by the display
		vTaskDelay(5000);
		// Trigger display of main window
		_event<bool> e("EDIPTFT43A", CEventNames::display_update_finished, true );
		m_pEventManager->RaiseEvent(e);
}

/**
 * Remembers current status of hold mode, set by someone in the system 
 */
void EAeDIPTFT43A_Contr::set_hold_modeEvent( bool b)
{
  if (b) hold_mode_status = true;
  else   hold_mode_status = false;
}


char external_display_connect_new()
{
  return 0;
}


//return values:
// 1 --> everything went fine
// 0 --> you should not communicate to the display right now
char external_display_connect(vector<char>* v_buffer, UART_TypeDef* UARTx, int active_display_num[], CEventManager * pEventManager)
{
  char c;
  while(xQueueReceive( xUart2RxChars, &c, 0)); //... and send it to nowhere  
  //Deselect Display 1 [intern] command senden
  while (!v_buffer->empty())v_buffer->pop_back(); //empty the vector before use
  v_buffer->push_back(65);//'A'
  v_buffer->push_back('D');//Deselect
  v_buffer->push_back(7);//Adresse des internen Displays (7)
  c = Send_dc2_cmd(v_buffer, UARTx );
  if(c == 0x06)
  {
    c = 1;
  }
  else
  {
    c = 2;
  }
  vTaskDelay(rx_supershort_delay);
  
  //Display 2 [extern] Adressieren:
  while(xQueueReceive( xUart2RxChars, &c, 0)); //... and send it to nowhere
  while (!v_buffer->empty())v_buffer->pop_back(); //empty the vector before use
  //MB Tempr�r, das externen Display 3 mal versuchen zu erreichen
  for( int i = 0; i < 3; i++ )
  {
      v_buffer->push_back(65);//'A'
      v_buffer->push_back('S');//Select
      v_buffer->push_back(6);//Adresse des externen Displays (6)
      c = Send_dc2_cmd(v_buffer, UARTx, 5);
      if(c == 0x06)//<ACK> checken
      {//Display 2 [externes] angeschlossen:
        active_display_num[0] = 2;
        break;
      }
      else //Falsche Antwort... ?
      {//Scheinbar nur Display 1 [internes] angeschlossen:
        active_display_num[0] = 1;
      }
  }
  vTaskDelay(rx_supershort_delay);
  
  if ((active_display_num[0] == active_display_num[1]) && (active_display_num[0] == 2))
  {//Es hat sich nichts ge�ndert, display 2 [extern] bleibt aktiv und 1 [intern] inaktiv
    active_display_num[1]=active_display_num[0];//A state just passed...
    return 1;
  }
  else if ((active_display_num[0] == active_display_num[1]) && (active_display_num[0] == 1))
  {  //Kein Displayswitch n�tig, Display 1 [intern] muss trotzdem explizit aktiviert werden und 2 [extern] deaktiviert
    //Display 1 [intern] Adressieren:
    while (!v_buffer->empty())v_buffer->pop_back(); //empty the vector before use
    v_buffer->push_back(65);//'A'
    v_buffer->push_back('S');//Select
    v_buffer->push_back(7);//Adresse des internen Displays (7)
    c = Send_dc2_cmd(v_buffer, UARTx);
    active_display_num[1]=active_display_num[0];//A state just passed...
    return 1;
  }
  else if((active_display_num[0] != active_display_num[1]) && (active_display_num[0] == 2))
  {//Externes Display wurde gerade erst angeschlossen --> Displayswitch von intern auf extern
    //### 1. Display 1 die "externes Display angeschlossen"-Meldung anzeigen lassen:
    //Select Display 1 [intern] command senden
    while (!v_buffer->empty())v_buffer->pop_back(); //empty the vector before use
    v_buffer->push_back(65);//'A'
    v_buffer->push_back('S');//Select
    v_buffer->push_back(7);//Adresse des internen Displays (7)
    c = Send_dc2_cmd(v_buffer, UARTx);
    //MnExternal_Keyboard_Connected = 75 ;'Externes Display Verbunden'_Meldung
    while (!v_buffer->empty())v_buffer->pop_back(); //empty the vector before use
    v_buffer->push_back('#');
    v_buffer->push_back('M');
    v_buffer->push_back('N');
    v_buffer->push_back('7');
    v_buffer->push_back('5');
    v_buffer->push_back(',');
    v_buffer->push_back('#');
    v_buffer->push_back('Y');
    v_buffer->push_back('H');
    v_buffer->push_back('2');
    v_buffer->push_back('5');
    v_buffer->push_back(',');
    c = Send_dc1_cmd(v_buffer, UARTx);
    while (!v_buffer->empty())v_buffer->pop_back(); //empty the vector before use
    v_buffer->push_back(65);//'A'
    v_buffer->push_back('D');//Deselect
    v_buffer->push_back(7);//Adresse des internen Displays (7)
    c = Send_dc2_cmd(v_buffer, UARTx);

    //Abarbeitung des Befehls hier stoppen und abbrechen,
    //denn der Displaymanager muss erstmal ein global-escape 
    //empfangen um das Hauptmenue darzustellen
    active_display_num[1]=active_display_num[0];//A state just passed...
    _event<int> e( "DisplayDetect", CEventNames::external_display_state, 1 );
    pEventManager->RaiseEvent(e);
    return 0;
  }
  else if((active_display_num[0] != active_display_num[1]) && (active_display_num[0] == 1))
  {//Externes Display wurde gerade entfernt --> Displayswitch auf intern
    //Abarbeitung des Befehls hier stoppen und abbrechen,
    //denn der Displaymanager muss erstmal ein global-escape 
    //empfangen um das Hauptmenue darzustellen
    //Display 1 [intern] Adressieren:
    while (!v_buffer->empty())v_buffer->pop_back(); //empty the vector before use
    v_buffer->push_back(65);//'A'
    v_buffer->push_back('S');//Select
    v_buffer->push_back(7);//Adresse des internen Displays (7)
    c = Send_dc2_cmd(v_buffer, UARTx);
    while (!v_buffer->empty())v_buffer->pop_back(); //empty the vector before use
    v_buffer->push_back('#');
    v_buffer->push_back('Y');
    v_buffer->push_back('H');
    v_buffer->push_back('1');
    v_buffer->push_back('0');
    v_buffer->push_back('0');
    v_buffer->push_back(',');
    c = Send_dc1_cmd(v_buffer, UARTx);
    active_display_num[1]=active_display_num[0];//A state just passed...
    _event<int> e( "DisplayDetect", CEventNames::external_display_state, 0 );
    pEventManager->RaiseEvent(e);
    return 0;
  }
  else return 0;
}

void EAeDIPTFT43A_Contr::send_direct_cmd2_dataEvent( void * p )
{
    string * p_s = p;
    while (!rx_uartdata.empty())rx_uartdata.pop_back();
    for(int i=0; i < p_s->size(); i++)
    {
      rx_uartdata.push_back((char)(*p_s)[i]); //copy data
    }
    //Muss noch iregendwie implementiert werden
    /*
    if(p_msg->cmd2 == "textend") //Hinufuegen eines Textendezeichens
    {
      rx_uartdata.push_back('\x0A');
    }
    */
    poll_while_displaybuffer_empty_enough(&tx_uartdata, ((char)rx_uartdata.size()+4), UART2);
    c = Send_dc1_cmd(&rx_uartdata, UART2);
}

void EAeDIPTFT43A_Contr::send_direct_cmd3_dataEvent( void * p )
{
    vector<char> * pCmd = p;
		rx_uartdata.clear();
    for(int i=0; i < pCmd->size(); i++)
    {
      rx_uartdata.push_back((char)((*pCmd)[i])); //copy data
    }
    poll_while_displaybuffer_empty_enough(&tx_uartdata, ((char)rx_uartdata.size()+4), UART2);
    c = Send_dc1_cmd(&rx_uartdata, UART2);
}


void EAeDIPTFT43A_Contr::cycCalc()
{
  _event<bool> event_set_hold_mode("ediptft43a", CEventNames::set_hold_mode, true );
  msg * p_msg = NULL;
  if( external_display_connect(&tx_uartdata, UART2, &active_display_num, m_pEventManager) )
  {
    //for (int b=0;b<8;b++)
    
	//1. Check displaybuffer
	while (!tx_uartdata.empty())tx_uartdata.pop_back();
	len = 0;
	bcc = 0;
	tx_uartdata.assign(get_buffer_cmd,get_buffer_cmd+1); //bufferinhalt-befehl holen
	c = Send_dc2_cmd(&tx_uartdata, UART2); //Befehl senden (Achtung: <DC2> !)
	if(c != 0x06)//<ACK> checken
	{ //kein <ACK>! => alles leerr�umen! (Display antwortet nicht auf Befehl!)
          clean_displaybuffer(UART2);
	}
	else
	{
		bcc += 0x06; //Checksumme aktualisieren

		xQueueReceive( xUart2RxChars, &c,  100 * portTICK_RATE_MS );
		if(c == 0x11)//<DC1> checken
		{
			bcc += 0x11; //<DC1>
			xQueueReceive( xUart2RxChars, &len,  1 * portTICK_RATE_MS );
			bcc += len;

			if(len>0)
			{
				for (int i=0; i<len; i++)
				{
					xQueueReceive( xUart2RxChars, &c,  1 * portTICK_RATE_MS );
					bcc += c;
					//die drei ueberfluessigen bytes nicht speichern:
					if (i==3)
					{
						cmd = c;
					}
				}
			}
			xQueueReceive( xUart2RxChars, &c,  1 * portTICK_RATE_MS ); //drop bcc
			//Zusaetzliche moegliche Daten verwerfen:
			while(xQueueReceive( xUart2RxChars, &c, 0));
			if (len > 0) //Es gibt estwas zu versenden:
			{
				//state = SEND_MSG;
			}
			else //Naechster Versuch:
			{
				//state = CALL_FOR_DATA;
			}
                        touched = false;
                        if( cmd != 0 )
                        {
														touched = true;

                            switch(cmd)
                            {
                                    //Main Menus:
                            case 123: //Config
                                    {
                                        _event<bool> b( "EAeDIPTFT43A", CEventNames::config, true );
                                        m_pEventManager->RaiseEvent(b);
                                        //touched = true;
                                    }
                                    break;
                            case 2:   //+25� B_25_grad_chuck_1 = 2
                                {
                                    _event<float> e( "EAeDIPTFT43A", CEventNames::set_temp1_changed, 25.0 );
                                    m_pEventManager->RaiseEvent(e);
                                    //touched = true;
                                }
                                break;
                            case 4:   //+25� B_25_grad_chuck_2 = 4
                                {
                                    _event<float> e( "EAeDIPTFT43A", CEventNames::set_temp2_changed, 25.0 );
                                    m_pEventManager->RaiseEvent(e);
                                    //touched = true;
                                }
                                break;
                            case 135:   //+25� B_25_grad_chuck_3 = 135
                                {
                                    _event<float> e( "EAeDIPTFT43A", CEventNames::set_temp3_changed, 25.0 );
                                    m_pEventManager->RaiseEvent(e);
                                    //touched = true;
                                }
                                break;
                            case 136:   //+25� B_25_grad_chuck_4 = 136
                                {
                                    _event<float> e( "EAeDIPTFT43A", CEventNames::set_temp4_changed, 25.0 );
                                    m_pEventManager->RaiseEvent(e);
                                    //touched = true;
                                }
                                break;
                            case 222:  //Globaler Escape
                                {
                                    _string s("escape");
                                     _event<bool> e( "EAeDIPTFT43A", CEventNames::exit_button_pressed, true );
                                    m_pEventManager->RaiseEvent(e);
                                   
                                    _event<_string> e2( "EAeDIPTFT43A", CEventNames::forward_to_active_window, s );
                                    m_pEventManager->RaiseEvent(e2);
                                    //touched = true;
                                }
                                break;
    
                            case 21: //B_pin_req_1 = 21
                                {
                                    _event<_string> s( "EAeDIPTFT43A", CEventNames::pin_request_1, "1" );
                                    m_pEventManager->RaiseEvent(s);
                                    //touched = true;
                                }
                                break;
    
                            case 22: //B_pin_req_2 = 22
                                {
                                    _event<_string> s( "EAeDIPTFT43A", CEventNames::pin_request_1, "2" );
                                    m_pEventManager->RaiseEvent(s);
                                    //touched = true;
                                }
                                break;
    
                            case 23: //B_pin_req_3 = 23
                                {
                                    _event<_string> s( "EAeDIPTFT43A", CEventNames::pin_request_1, "3" );
                                    m_pEventManager->RaiseEvent(s);
                                    //touched = true;
                                }
                                break;
    
                            case 24: //B_pin_req_4 = 24
                                 {
                                    _event<_string> s( "EAeDIPTFT43A", CEventNames::pin_request_1, "4" );
                                    m_pEventManager->RaiseEvent(s);
                                    //touched = true;
                                }
                                break;
                                    
                            case 25: //B_pin_req_5 = 25
                                {
                                    _event<_string> s( "EAeDIPTFT43A", CEventNames::pin_request_1, "5" );
                                    m_pEventManager->RaiseEvent(s);
                                    //touched = true;
                                }
                                break;
    
                            case 26: //B_pin_req_6 = 26
                                {
                                    _event<_string> s( "EAeDIPTFT43A", CEventNames::pin_request_1, "6" );
                                    m_pEventManager->RaiseEvent(s);
                                    //touched = true;
                                }
                                break;
    
                            case 121: //B_pin_req_7 = 121
                                {
                                    _event<_string> s( "EAeDIPTFT43A", CEventNames::pin_request_1, "7" );
                                    m_pEventManager->RaiseEvent(s);
                                    //touched = true;
                                }
                                break;
    
                            case 28: //B_pin_req_8 = 28
                                {
                                    _event<_string> s( "EAeDIPTFT43A", CEventNames::pin_request_1, "8" );
                                    m_pEventManager->RaiseEvent(s);
                                    //touched = true;
                                }
                                break;
    
                            case 29: //B_pin_req_9 = 29
                                {
                                    _event<_string> s( "EAeDIPTFT43A", CEventNames::pin_request_1, "9" );
                                    m_pEventManager->RaiseEvent(s);
                                    //touched = true;
                                }
                                break;
    
                            case 30: //B_pin_req_0 = 30
                                 {
                                    _event<_string> s( "EAeDIPTFT43A", CEventNames::pin_request_1, "0" );
                                    m_pEventManager->RaiseEvent(s);
                                    //touched = true;
                                }
                                break;
    
                            case 32: //B_pin_req_clr = 32
                                {
                                    _event<_string> s( "EAeDIPTFT43A", CEventNames::pin_request_1, "clr" );
                                    m_pEventManager->RaiseEvent(s);
                                    //touched = true;
                                }
                                break;
    
                            case 33: //B_pin_req_backspace = 33
                                 {
                                    _event<_string> s( "EAeDIPTFT43A", CEventNames::pin_request_1, "backspace" );
                                    m_pEventManager->RaiseEvent(s);
                                    //touched = true;
                                }
                                break;
                                    
                            case 34: //B_pin_req_enter = 34
                                {
                                    _event<_string> s( "EAeDIPTFT43A", CEventNames::pin_request_1, "enter" );
                                    m_pEventManager->RaiseEvent(s);
                                    //touched = true;
                                }
                                break;
                                
                            case 35: // B_UpperTempLimit = 35
                                {
                                    _event<bool> e( "EAeDIPTFT43A", CEventNames::change_temp_limit, true );
                                    m_pEventManager->RaiseEvent(e);
                                    //touched = true;
                                }
                                break;

                            case 36: // B_LowerTempLimit = 36
                                {
                                    _event<bool> e( "EAeDIPTFT43A", CEventNames::change_temp_limit, false );
                                    m_pEventManager->RaiseEvent(e);
                                    //touched = true;
                                }
                                break;
																
                            case 10: //B_show_file_system = 10
                                    if (p_msg != NULL)
                                    {
                                      p_msg->dest = "config_window";
                                      p_msg->origin = name;
                                      p_msg->cmd1 = "show_file_sys";
                                    }
                                    //touched = true;
                                    break;
                            case 5: //B_display_update = 5
                                    if (p_msg != NULL)
                                    {
                                      p_msg->dest = "config_window";
                                      p_msg->origin = name;
                                      p_msg->cmd1 = "display_update";
                                    }
                                    //touched = true;
                                    break;
                            case 6: //B_controller_overview = 6
                                    if (p_msg != NULL)
                                    {
                                      p_msg->dest = "config_window";
                                      p_msg->origin = name;
                                      p_msg->cmd1 = "controller_overview";
                                    }
                                    //touched = true;
                                    break;
                            case 7: //B_switch_view = 7
                                    if (p_msg != NULL)
                                    {
                                      p_msg->dest = "config_window";
                                      p_msg->origin = name;
                                      p_msg->cmd1 = "switch_view";
                                    }
                                    //touched = true;
                                    break;
                            case 8: //B_temperature_comp = 8
                                    if (p_msg != NULL)
                                    {
                                      p_msg->dest = "config_window";
                                      p_msg->origin = name;
                                      p_msg->cmd1 = "temperature_comp";
                                    }
                                    //touched = true;
                                    break;
                            case 11: //B_show_filesys_back = 11
                                     if (p_msg != NULL)
                                    {
                                      p_msg->dest = "show_file_system";
                                      p_msg->origin = name;
                                      p_msg->cmd1 = "back";
                                    }
                                    //touched = true;
                                    break;    
                            case 13: //B_show_filesys_update = 13
                                {
                                    _event<bool> b("EAeDIPTFT43A_Contr", CEventNames::update_filesys_view, true );
                                    m_pEventManager->RaiseEvent(b);
                                }
                                //touched = true;
                                break;
                            case 61: //B_menue_page_1 = 61
                                {
                                    _event<bool>b("EAeDIPTFT43A_Contr", CEventNames::diag_page_1, true );
                                    m_pEventManager->RaiseEvent(b);
                                }
                                //touched = true;
                                break;
                            case 62: //B_menue_page_2 = 62
                                {
                                    _event<bool>b("EAeDIPTFT43A_Contr", CEventNames::diag_page_2, true );
                                    m_pEventManager->RaiseEvent(b);
                                }
                                //touched = true;
                                break;
                            case 63: //B_menue_page_3 = 63
                                {
                                    _event<bool>b("EAeDIPTFT43A_Contr", CEventNames::diag_page_3, true );
                                    m_pEventManager->RaiseEvent(b);
                                }
                                //touched = true;
                                break;
                            case 64: //B_menue_page_4 = 64
                                {
                                    _event<bool>b("EAeDIPTFT43A_Contr", CEventNames::diag_page_4, true );
                                    m_pEventManager->RaiseEvent(b);
                                }
                                //touched = true;
                                break;
//                            case 66: //B_diag_page_6 = 66
//                                {
//                                    _event<bool>b("EAeDIPTFT43A_Contr", CEventNames::diag_page_6, true );
//                                    m_pEventManager->RaiseEvent(b);
//                                }
//                                //touched = true;
//                                break;
																
														case B_diag_switch_power_relay:  // Toch key 67: Diagnose 2 relay checkbox	
																		{
																			_event<bool>b("EAeDIPTFT43A_Contr", CEventNames::toggle_power_supply_56_relay, true );
																			m_pEventManager->RaiseEvent(b);
																		}
 															break;
																																
                            case 18: //B_switch_v_back = 18
                                    if (p_msg != NULL)
                                    {
                                      p_msg->dest = "switchview_1";
                                      p_msg->origin = name;
                                      p_msg->cmd1 = "back";
                                    }
                                    //touched = true;
                                    break;
                            case 15: //B_contr_over_back = 15
                                    if (p_msg != NULL)
                                    {
                                      p_msg->dest = "controller_overview_1";
                                      p_msg->origin = name;
                                      p_msg->cmd1 = "back";
                                    }
                                    //touched = true;
                                    break;
                            case 120: //B_set_temp_1 = 120
                                {
                                    _event<bool>b("EAeDIPTFT43A_Contr", CEventNames::s_temp_1, true );
                                    m_pEventManager->RaiseEvent(b);
                                }
                                //touched = true;
                                break;
                            case 3: //B_set_temp_2 = 3
                                    if (p_msg != NULL)
                                    {
                                      p_msg->dest = "mainmenu";
                                      p_msg->origin = name;
                                      p_msg->cmd1 = "s_temp_2";
                                    }
                                    //touched = true;
                                    break;
                            case 132: //B_set_temp_3 = 132
                                    if (p_msg != NULL)
                                    {
                                      p_msg->dest = "mainmenu";
                                      p_msg->origin = name;
                                      p_msg->cmd1 = "s_temp_3";
                                    }
                                    //touched = true;
                                    break;                    
                            case 134: //B_set_temp_4 = 134
                                    if (p_msg != NULL)
                                    {
                                      p_msg->dest = "mainmenu";
                                      p_msg->origin = name;
                                      p_msg->cmd1 = "s_temp_4";
                                    }
                                    //touched = true;
                                    break;
                            case 71: //keyb_1 = 71
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("1"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 72: //keyb_2 = 72
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("2"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 73: //keyb_3 = 73
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("3"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 74: //keyb_4 = 74
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("4"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 75: //keyb_5 = 75
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("5"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 76: //keyb_6 = 76
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("6"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 77: //keyb_7 = 77
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("7"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 78: //keyb_8 = 78
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("8"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 79: //keyb_9 = 79
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("9"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 80: //keyb_0 = 80
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("0"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 81: //keyb_esc = 81
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("esc"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 82: //keyb_clr = 82
                                     {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("clr"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 83: //keyb_backspace = 83
                                   {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("backspace"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 84: //keyb_enter = 84
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("enter"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 85: //B_keyb_plus_minus = 85
                                     {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("plus_minus"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 86: //B_keyb_dot = 86
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("dot"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 124: //B_keyb_plus_ten = 124
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("plus_ten"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 125: //B_keyb_plus_one = 125
                                     {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("plus_one"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 126: //B_keyb_plus_zeroone = 126
                                     {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("plus_zeroone"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 127: //B_keyb_plus_zerozeroone = 127
                                     {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("plus_zerozeroone"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 128: //B_keyb_minus_ten = 128
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("minus_ten"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 129: //B_keyb_minus_one = 129
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("minus_one"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 130: //B_keyb_minus_zeroone = 130 
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("minus_zeroone"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 131: //B_keyb_minus_zerozeroone = 131
                                    {
                                        _event<_string> e( "EAeDIPTFT43_Contr", CEventNames::keyboard_float_command, _string("minus_zerozeroone"));
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 140: //B_diag_comp_on = 140
                                m_event_compessor_status->modifyParameter(true);
                                m_pEventManager->RaiseEvent(m_event_compessor_status);
                                //touched = true;
                                break;
                            case 141: //B_diag_comp_off = 141
                                m_event_compessor_status->modifyParameter(false);
                                m_pEventManager->RaiseEvent(m_event_compessor_status);
                                //touched = true;
                                break;
                            case 148: //B_System_Setup_Sys = 148
																{
																	_event<bool> b( "EAeDIPTFT43A", CEventNames::system_config, true );
																	m_pEventManager->RaiseEvent(b);
                                 }
                                //touched = true;
                                break;
                            case 149: //B_System_Setup_Temp = 149
																{
																	_event<bool> b( "EAeDIPTFT43A", CEventNames::temp_limits, true );
																	m_pEventManager->RaiseEvent(b);
                                 }
                                //touched = true;
                                break;
                            case 150: //B_System_Setup_Net = 150
																{
																	_event<bool> b( "EAeDIPTFT43A", CEventNames::network_config, true );
																	m_pEventManager->RaiseEvent(b);
                                 }
                                //touched = true;
                                break;
                            case 151: //keyb_G_1 = 151
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("1"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 152: //keyb_G_2 = 152
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("2"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 153: //keyb_G_3 = 153
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("3"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 154: //keyb_G_4 = 154
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("4"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 155: //keyb_G_5 = 155
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("5"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 156: //keyb_G_6 = 156
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("6"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 157: //keyb_G_7 = 157
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("7"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 158: //keyb_G_8 = 158
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("8"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 159: //keyb_G_9 = 159
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("9"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 160: //keyb_G_0 = 160
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("0"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 162: //keyb_G_esc = 162
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("esc"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
																break;
                            case 163: //keyb_G_clr = 163
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("clr"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 164: //keyb_G_backspace = 164
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("backspace"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 165: //keyb_G_enter = 165
                                 {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("enter"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 161: //B_keyb_G_plus_minus = 161
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("plus_minus"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 166: //B_keyb_G_plus_ten = 166
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("plus_ten"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 168: //B_keyb_G_plus_one = 168
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("plus_one"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 167: //B_keyb_G_minus_ten = 167
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("minus_ten"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 169: //B_keyb_G_minus_one = 169
                                {
                                    _event<_string> e("EAeDIPTFT43_Contr", CEventNames::keyboard_int_command, _string("minus_one"));
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
														case B_diag_bypass_valve_on_off:  // Toch key 144: Diagnose 3 Bypass 1 checkbox	
																		{
																			_event<bool>b("EAeDIPTFT43A_Contr", CEventNames::toggle_bypass_valve, true );
																			m_pEventManager->RaiseEvent(b);
																		}
 																		break;
														case B_diag_main_valve_on_off:  // Toch key 145: Diagnose 3 Bypass 2 checkbox	
																		{
																			_event<bool>b("EAeDIPTFT43A_Contr", CEventNames::toggle_main_valve, true );
																			m_pEventManager->RaiseEvent(b);
																		}
 																		break;
														case B_diag_chiller_on_off:  // Toch key 122: Diagnose 3 chiller checkbox	
																		{
																			_event<bool>b("EAeDIPTFT43A_Contr", CEventNames::toggle_chiller_relay, true );
																			m_pEventManager->RaiseEvent(b);
																		}
 																		break;
                            case 146: //B_diag_set_power_supply_1_v = 146
                                    {
                                        _event<bool> b( "EAeDIPTFT43A", CEventNames::inp_power_suppply_1_set_voltage, true );
                                        m_pEventManager->RaiseEvent(b);
                                        //touched = true;
                                    }
                                    break;
                            case 147: //B_diag_set_power_supply_2_v = 147
                                    {
                                        _event<bool> b( "EAeDIPTFT43A", CEventNames::inp_power_suppply_2_set_voltage, true );
                                        m_pEventManager->RaiseEvent(b);
                                        //touched = true;
                                    }
                                    break;
															
														case B_diag_set_cool_air_value:  // Toch key 142: Diagnose 2 set cool value															
                                    {
                                        _event<bool> b( "EAeDIPTFT43A", CEventNames::inp_cool_air_value, true );
                                        m_pEventManager->RaiseEvent(b);
                                        //touched = true;
                                    }
																		break;

														case B_diag_set_warm_air_value:  // Toch key 143: Diagnose 2 set warm value															
                                    {
                                        _event<bool> b( "EAeDIPTFT43A", CEventNames::inp_warm_air_value, true );
                                        m_pEventManager->RaiseEvent(b);
                                        //touched = true;
                                    }
																		break;
																		
                            case 170: //B_option_1 = 170
                                    {
                                        _event<bool> e( "EAeDIPTFT43_Contr", CEventNames::but_option_1, true );
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 171: //B_option_2 = 171
                                    {
                                        _event<bool> e( "EAeDIPTFT43_Contr", CEventNames::but_option_2, true );
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 137: //B_warning = 137
                                    {
                                        _event<bool> e( "EAeDIPTFT43_Contr", CEventNames::red_ball_pressed, true );
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 172: //B_info_ok = 172
                                    {
                                        _event<bool> e( "EAeDIPTFT43_Contr", CEventNames::error_1_ok, true );
                                        m_pEventManager->RaiseEvent(e);
                                    }
                                    //touched = true;
                                    break;
                            case 173: //B_UserTouchedDisplay = 173
                                    //p_msg = p_deviceControllerMailbox->take_free_msg();
                                    if (p_msg != NULL)
                                    {
                                      p_msg->dest = "dimmer";
                                      p_msg->origin = name;
                                      p_msg->cmd1 = "//touched";
                                    }
                                    //touched = true;
                                    break;
                            case 174: //B_ConfigWindow_1 = 174
                                {
                                    _event<bool> e( "EAeDIPTFT43A", CEventNames::user_config_page_1, true );
                                    m_pEventManager->RaiseEvent(e);
                                    //touched = true;
                                }
                                break;
                            case 175: //B_ConfigWindow_2 = 175                               
                                {
                                    _event<bool> e( "EAeDIPTFT43A", CEventNames::user_config_page_2, true );
                                    m_pEventManager->RaiseEvent(e);
                                    //touched = true;
                                }
                                break;
                            case 176: //B_ConfigWindow_3 = 176
                                {
                                    _event<bool> e( "EAeDIPTFT43A", CEventNames::user_config_page_3, true );
                                    m_pEventManager->RaiseEvent(e);
                                    //touched = true;
                                }
                                break;                                
                            case 177: //B_ConfigWindow_4 = 177
                               {
                                    _event<bool> e( "EAeDIPTFT43A", CEventNames::user_config_page_4, true );
                                    m_pEventManager->RaiseEvent(e);
                                    //touched = true;
                                }
                                break;
                            case 178: //B_ConfigWindow_PowerSense = 178
                                {
                                    _event<bool> e( "EAeDIPTFT43A", CEventNames::user_config_power_sense, true );
                                    m_pEventManager->RaiseEvent(e);
                                    //touched = true;
                                }
                                break;
                            case 179: //B_ConfigWindow_back = 179
                                {
                                    _string s("user_config_back");
                                    _event<_string> e( "EAeDIPTFT43A", CEventNames::forward_to_active_window, s );
                                    m_pEventManager->RaiseEvent(e);
                                    //touched = true;
                                }
                                break;
                            case 180: //B_ConfigWindow_5 = 180
                                {
                                    _event<bool> e( "EAeDIPTFT43A", CEventNames::user_config_page_5, true );
                                    m_pEventManager->RaiseEvent(e);
                                    //touched = true;
                                }
                                break;
                            case 181: //B_Config_up = 181
                                {
                                    _event<bool> e( "EAeDIPTFT43A", CEventNames::up_button_pressed, true );
                                    m_pEventManager->RaiseEvent(e);
//                                    _event<_string> e( "EAeDIPTFT43A_Contr", CEventNames::user_config_5_key, "user_config_table_go_up" );
//                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 182: //B_Config_down = 182
                                {
                                    _event<bool> e( "EAeDIPTFT43A", CEventNames::down_button_pressed, true );
                                    m_pEventManager->RaiseEvent(e);
//                                    _event<_string> e( "EAeDIPTFT43A_Contr", CEventNames::user_config_5_key, "user_config_table_go_down" );
//                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 183: //B_ConfigEditNormTemp = 183
                                {
                                    _event<_string> e( "EAeDIPTFT43A_Contr", CEventNames::user_config_5_key, "user_config_table_edit_norm_temp" );
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 184: //B_ConfigEditCompTemp = 184
                                {
                                    _event<_string> e( "EAeDIPTFT43A_Contr", CEventNames::user_config_5_key, "user_config_table_edit_comp_temp" );
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 185: //B_Config_del_line = 185
                                {
                                    _event<_string> e( "EAeDIPTFT43A_Contr", CEventNames::user_config_5_key, "del_line" );
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 186: //B_Config_ins_line = 186
                                {
                                    _event<_string> e( "EAeDIPTFT43A_Contr", CEventNames::user_config_5_key, "ins_line" );
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 187: //B_Config_clr_table = 187
                                {
                                    _event<_string> e( "EAeDIPTFT43A_Contr", CEventNames::user_config_5_key, "clr_table" );
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 188: //B_Config_table_1 = 188
                                {
                                    _event<_string> e( "EAeDIPTFT43A_Contr", CEventNames::user_config_5_key, "select_table_1" );
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 189: //B_Config_table_2 = 189
                                {
                                    _event<_string> e( "EAeDIPTFT43A_Contr", CEventNames::user_config_5_key, "select_table_2" );
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 190: //B_Config_table_3 = 190
                                {
                                    _event<_string> e( "EAeDIPTFT43A_Contr", CEventNames::user_config_5_key, "select_table_3" );
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 191: //B_Config_table_save = 191
                                {
                                    _event<_string> e( "EAeDIPTFT43A_Contr", CEventNames::user_config_5_key, "save_table" );
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 192: //B_Config_sort_table = 192
                                {
                                    _event<_string> e( "EAeDIPTFT43A_Contr", CEventNames::user_config_5_key, "sort_table" );
                                    m_pEventManager->RaiseEvent(e);
                                }
                                //touched = true;
                                break;
                            case 193: //B_Config_activate_table = 193
                               {
                                    _event<bool> e("EAeDIPTFT43A", CEventNames::activate_comp_table_but, true);
                                    m_pEventManager->RaiseEvent(e);
                                    //touched = true;
                                }
                                break;                                
                            case 194: //B_Config_deactivate_table = 194
                                {
                                    _event<int> e("EAeDIPTFT43A", CEventNames::set_active_comp_table, 0);
                                    m_pEventManager->RaiseEvent(e);
                                    //touched = true;
                                }
                                break;
                            case 195: // B_Config_toggle_holdmode = 195
																// Realize toggle function of hold mode button
																if (!hold_mode_status) m_pEventManager->RaiseEvent(event_set_hold_mode);
																else 
																{
																	event_set_hold_mode.modifyParameter(false);
																	m_pEventManager->RaiseEvent(event_set_hold_mode);
																}
																break;
                            case 196: // not assigned
                                 break;
                            case 197: // B_Config_toggle_standbymode = 197
                                {
                                    _event<bool> b("EAeDIPTFT43A", CEventNames::toggle_standby_mode, true);
                                    m_pEventManager->RaiseEvent(b);
                                    //touched = true;
                                }
                                break;
                            case 198: // B_Config_toggle_enabledmode
                                {
                                    _event<bool> b("EAeDIPTFT43A", CEventNames::toggle_enabled_mode, true);
                                    m_pEventManager->RaiseEvent(b);
                                }
                                 break;
                            case 138: // B_Config_toggle_purgemode = 138
																{
																	_event<bool> b( "EAeDIPTFT43A", CEventNames::toggle_purge_mode, true );
																	m_pEventManager->RaiseEvent(b);
                                 }
                                //touched = true;
                                break;
                            case 139: // not assigned
                                break;
                            case 227: // B_Config_toggle_defrostmode = 227
																{
																	_event<bool> b( "EAeDIPTFT43A", CEventNames::toggle_defrost_mode, true );
																	m_pEventManager->RaiseEvent(b);
                                 }
                                //touched = true;
                                break;
                            case 228: // not assigned
                                break;   
                            case 199: //Standard                        
                               {
                                    _event<bool> b("EAeDIPTFT43A", CEventNames::set_con_mode_standard, true);
                                    m_pEventManager->RaiseEvent(b);
                                    //touched = true;
                                }
                                break;
                            case 200: //Progressive
                                {
                                    _event<bool> b("EAeDIPTFT43A", CEventNames::set_con_mode_progressive, true);
                                    m_pEventManager->RaiseEvent(b);
                                    //touched = true;
                                }
                                break;
                            case 201: //Low Noise
                                {
                                    _event<bool> b("EAeDIPTFT43A", CEventNames::set_con_mode_lnoise, true);
                                    m_pEventManager->RaiseEvent(b);
                                    //touched = true;
                                }
                                break;
                            // 10.07.2012 PM. Activate and deactivate Dewpoint Tracking.
                            // === BEGIN == 
                               
                            case 224: //B_Config_activate_dewpoint = 224
                            {
                                 _event<bool> b("EAeDIPTFT43A", CEventNames::set_active_dewpoint, true);
                                m_pEventManager->RaiseEvent(b);
                                //touched = true;
                            }
                            break;
                            
                            case 225: // B_Config_deactivate_dewpoint = 225
                                                                                                    {
                                 _event<bool> b("EAeDIPTFT43A", CEventNames::set_active_dewpoint,false);
                                m_pEventManager->RaiseEvent(b);
                                //touched = true;
                                                                                                    }
                            break;
                            
                            case 226: //B_Config_Set_dewpoint
														{
                            	_event<bool> b("EAeDIPTFT43A", CEventNames::inp_dewpoint_offsett, true);
                              m_pEventManager->RaiseEvent(b);
                            }
														break;
                            // == END == Dewpoint
														
														case 204:
															i_buf[0] = 0; // 0: IP, 1: Mask
															i_buf[1] = 0; // 0: LSB, ... , 3: MSB
															i_buf[2] = 1; // A flag to allow 'case' without 'break' after each case
                            case 205:  
															if (i_buf[2] == 0) {i_buf[0] = 0; i_buf[1] = 1; i_buf[2] = 1;}
                            case 206:
                              if (i_buf[2] == 0) {i_buf[0] = 0; i_buf[1] = 2; i_buf[2] = 1;}
                            case 207:
                              if (i_buf[2] == 0) {i_buf[0] = 0; i_buf[1] = 3; i_buf[2] = 1;}
                            case 208:
                              if (i_buf[2] == 0) {i_buf[0] = 1; i_buf[1] = 0; i_buf[2] = 1;}
                            case 209:
                              if (i_buf[2] == 0) {i_buf[0] = 1; i_buf[1] = 1; i_buf[2] = 1;}
                            case 210:
                              if (i_buf[2] == 0) {i_buf[0] = 1; i_buf[1] = 2; i_buf[2] = 1;}
                            case 211:
                              if (i_buf[2] == 0) {i_buf[0] = 1; i_buf[1] = 3; i_buf[2] = 1;}
														{
															_two_params<int,int> p;
															p.p1 = i_buf[0];
															p.p2 = i_buf[1];
															i_buf[2] = 0; 
															_event< _two_params<int,int> > e( "EAeDIPTFT43A", CEventNames::input_network_config, p );
															m_pEventManager->RaiseEvent(e);             
														}
														break;

                            case 203: //B_Network_Config_load_default = 203
                                      //Aufforderung an "system", die Defaultwerte der Netzwerkkonfiguration
                                      //an das entsprechende Fenster zu schicken
                              //p_msg = p_deviceControllerMailbox->take_free_msg();
                              if (p_msg != NULL)
                              {
                                p_msg->dest = "system";
                                p_msg->cmd2 = " ";
                                p_msg->origin = name;
                                //p_msg->cmd1 = "request_network_config";
                                p_msg->cmd1 = "request_default_network";
                              }
                              //touched = true;
                              break;
                            case 202: //B_Save = 202
															{
																_event<bool> e( "EAeDIPTFT43A", CEventNames::save_button_pressed, true );
																m_pEventManager->RaiseEvent(e);
															}
                              //touched = true;
                              break;
                            case 216: //B_Exit = 216
															{
																_event<bool> e( "EAeDIPTFT43A", CEventNames::exit_button_pressed, true );
																m_pEventManager->RaiseEvent(e);
															}
                              //touched = true;
                              break;
                            case 217: //B_OptionButtonConfigWindow_1 = 217
                               {
                                    _event<bool> e("EAeDIPTFT43A", CEventNames::option_button_config, true);
                                    m_pEventManager->RaiseEvent(e);
                               }
                               //touched = true;
                               break;
                            case 218: //B_OptionModePlusMinus = 218
                              {
                                   _event<bool> e("EAeDIPTFT43A", CEventNames::set_mode_plusminus, true );
                                   m_pEventManager->RaiseEvent(e);
                              }                          
                              //touched = true;
                              break;
                            case 219: //B_OptionModeStatic = 219
                               {
                                   _event<bool> e("EAeDIPTFT43A", CEventNames::set_mode_static, true );
                                   m_pEventManager->RaiseEvent(e);
                              }                          
                              //touched = true;
                              break;
                            case 220: //B_OptionPlusMinus = 220
                              {
                                  _event<_string> e( "EAeDIPTFT43A_Contr", CEventNames::set_plusminus_value, _string("display_1"));
                                  m_pEventManager->RaiseEvent(e);
                              }
                              //touched = true;
                              break;
                            case 221: //B_OptionStaticB_1 =221
                              {
                                  _event<_string> e( "EAeDIPTFT43A_Contr", CEventNames::set_static_1_value, _string("display_1"));
                                  m_pEventManager->RaiseEvent(e);
                              }
                              //touched = true;
                              break;
                            case 223: //B_OptionStaticB_2 =223
                              {
                                  _event<_string> e( "EAeDIPTFT43A_Contr", CEventNames::set_static_2_value, _string("display_1"));
                                  m_pEventManager->RaiseEvent(e);
                              }
														case B_dim_touched: // Display is dimmed and has been touched
                              // We do nothing, but variable 'touched' will be true
                              break;
                            default:
															touched = false;
                                    break;
                            }
                        }
                        cmd = 0;
                        if (touched)
                        {
                          // Reset Dimm-Counter
                          _event<bool> e( "EAeDIPTFT43A", CEventNames::display_touched, true );
											    m_pEventManager->RaiseEvent(e);
													touched = false;
                        }
                        
		}
		else
		{ //kein <DC1>! => alles leerr�umen!
			clean_displaybuffer(UART2);
		}
        }	
  } //External display connect check
  else
  {
    //Displaymanager needs a global esc:
    _string s("escape");
    _event<_string> e( "EAeDIPTFT43A", CEventNames::forward_to_active_window, s );
    m_pEventManager->RaiseEvent(e);
    
    vTaskDelay(rx_long_delay);
    vTaskDelay(rx_long_delay);
    vTaskDelay(rx_long_delay);
    vTaskDelay(rx_long_delay);
    vTaskDelay(rx_long_delay);
    vTaskDelay(rx_long_delay);
    vTaskDelay(rx_long_delay);
    vTaskDelay(rx_long_delay);
    vTaskDelay(rx_long_delay);
    vTaskDelay(rx_long_delay);
    vTaskDelay(rx_long_delay);
    vTaskDelay(rx_long_delay);
    vTaskDelay(rx_long_delay);
    vTaskDelay(rx_long_delay);
    vTaskDelay(rx_long_delay);
    vTaskDelay(rx_long_delay);
    vTaskDelay(rx_long_delay); 
  }
}