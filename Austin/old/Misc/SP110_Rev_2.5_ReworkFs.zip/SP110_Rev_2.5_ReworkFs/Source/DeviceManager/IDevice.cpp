/**
*  \file
*    IDevice.cpp
*   
*  \brief Implementation of the Class IDevice
*  \date 10-Jan-2011 16:15:45
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#include "IDevice.h"
#include "..\system_wide_defs.h"

IDevice::IDevice()
{
  
}


IDevice::~IDevice()
{
  
}


void IDevice::cycCalc()
{
  
}

void IDevice::Init(CEventManager * pEventManager, const char *dev_name)
{
  
}