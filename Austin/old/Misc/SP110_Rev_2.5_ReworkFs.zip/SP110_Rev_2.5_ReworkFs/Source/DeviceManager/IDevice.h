/**
*  \file
*    IDevice.cpp
*   
*  \brief Implementation of the Class IDevice
*  \date 10-Jan-2011 16:15:45
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#if !defined(IDEVICE_H__INCLUDED_)
#define IDEVICE_H__INCLUDED_

#include "..\system_wide_defs.h"
#include "CEventManager.h"
#include <string>

class IDevice
{

public:
	IDevice();
	virtual ~IDevice();

	virtual void cycCalc();
  virtual void Init(CEventManager* p_dev_Contr_Mailbox, const char *dev_name);
	
	string m_name;
};
#endif // !defined(IDEVICE_H__INCLUDED_)
