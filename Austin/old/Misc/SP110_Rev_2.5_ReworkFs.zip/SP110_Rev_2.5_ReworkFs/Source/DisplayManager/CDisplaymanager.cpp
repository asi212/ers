/**
*  \file
*    CDisplaymanager.cpp
*   
*  \brief Implementation of the Class CDisplaymanager
*  \date 10-Jan-2011 16:21:08
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#include "CDisplaymanager.h"
#include "..\system_wide_defs.h"
#include "windowstate.h"
#include "CView.h"


CDisplaymanager::CDisplaymanager( CEventManager* pEventManager)
{
  m_EventManager = pEventManager;
  namebuffer.reserve(25);
  viewlist.reserve(5);
  windowlist.reserve(30);
}

CView *p_view;

void CDisplaymanager::Init()
{

  v_buffer.reserve(VBUFFER_SIZE);
  //  Create and add viewobjects
  // (The viewobjects create the needed windows during an Init()-call)
  //Demoview 1
//  p_view = new CDemoview();   // View erstellen //Chiller
  p_view = new CController_view_1();  // View erstellen //Controller Horizontal
//  p_view = new CController_view_1_v(); // View erstellen //Controller Vertikal
  
  viewlist.push_back(p_view); //2. In Viewliste eintragen
  vit = viewlist.end();       //3. View anwaehlen
  //(*vit)->Init("Demoview_1", this); //4. View initialisieren <-- Diese Version st�rzt ab?
  p_view->Init("Demoview_1", this); //4. View initialisieren   <-- Diese nicht??? (--> Ist eine haessliche IAR-Compiler Eigenheit...)

}

CDisplaymanager::~CDisplaymanager()
{
  
}

void CDisplaymanager::cycCalc()
{
	//######### A small piece of security: ##################
	//###  Check if only one window exclusive is active.  ###
	//###  If not, activate first switch-view entry.      ###
	int num_active_windows = 0;
	windowstate wstate = MY_ERROR;
	it = windowlist.begin();
	while(it != windowlist.end())
	{ //count active windows
		wstate = (**it).get_state();
		if (( wstate == ACTIVE) || ( wstate == JUST_ACTIVATED)) num_active_windows++;
		it++;
	}
	if(num_active_windows != 1)
	{//There was a failure during activation/deactivation
	 //activate first view in list...
          if (viewlist.size() > 0) //<--Kann tatsaechlich passieren, wenn man gerade neue Menues entwirft :)
          {
            vit = viewlist.begin();
            (**vit).switch_view();
          }
	}
        
        if (windowlist.size() > 0) //<--Sollten wirklich noch keine Eintraege vorhanden sein
        { 
	  //Normaler cycCalc():
          /*
	  it = windowlist.begin();
	  while(it != windowlist.end())
          {
            (**it).cycCalc();
            it++;
          }
          */
          
          for(int i=0; i<windowlist.size(); i++)
          {
            (*windowlist[i]).cycCalc();
          }
        }
}

bool CDisplaymanager::switch_view(string viewname)
{

	return false;
}

windowstate CDisplaymanager::get_state(string windowname)
{
	it = windowlist.begin();
	while(it != windowlist.end())
	{
		if ((**it).get_name() == windowname)
		{
			return (**it).get_state();
		}
		*it++;
	}
	return MY_ERROR; //The specified window was not found
	// (Same return-value when the window is actually
	// really in the ERROR-state)
}


bool CDisplaymanager::set_state(const char* windowname, windowstate newstate)
{
  /*
  bool successflag = false;
	it = windowlist.begin();
	while(it != windowlist.end())
	{
		if ((**it).name == windowname)
//		if ((**it).get_name() == windowname)
		{
		  //return (**it).set_state(state); //<--suizidcode
                  (**it).state = newstate;
                  successflag = true;
		}
		it++;
	}
	return successflag;
  */
  namebuffer.assign(windowname);
  for (int i=0; i<windowlist.size(); i++)
  {
    if (namebuffer == windowlist[i]->name)
    {
      (windowlist[i])->state = newstate;
      break;
    }
  }
  return true;
}

bool CDisplaymanager::set_state(string* windowname, windowstate newstate)
{
  /*
  bool successflag = false;
	it = windowlist.begin();
	while(it != windowlist.end())
	{
		if ((**it).name == windowname)
//		if ((**it).get_name() == windowname)
		{
		  //return (**it).set_state(state); //<--suizidcode
                  (**it).state = newstate;
                  successflag = true;
		}
		it++;
	}
	return successflag;
  */
  for (int i=0; i<windowlist.size(); i++)
  {
    if ((*windowname) == windowlist[i]->name)
    {
      (windowlist[i])->state = newstate;
      break;
    }
  }
  return true;
}

/*
bool CDisplaymanager::set_state(string windowname, windowstate state)
{
  bool successflag = false;
  for (int i=0; i<windowlist.size(); i++)
  {
    if (windowlist[i]->name == windowname)
    {
      windowlist[i]->state = state;
      successflag = true;
    }
  }
  return successflag;
}
*/



//This Pointer is from the file main.cpp
extern CDisplaymanager *pDisplaymanager;

void Displaymanager_Task(void *pvParameters)
{
  while(1)
  {
    pDisplaymanager->cycCalc();
  }
}