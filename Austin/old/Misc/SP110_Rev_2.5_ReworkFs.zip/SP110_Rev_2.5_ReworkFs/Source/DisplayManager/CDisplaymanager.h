/**
*  \file
*    CDisplaymanager.cpp
*   
*  \brief Implementation of the Class CDisplaymanager
*  \date 10-Jan-2011 16:21:08
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#if !defined(CDISPLAYMANAGER_H__INCLUDED_)
#define CDISPLAYMANAGER_H__INCLUDED_

#include "..\system_wide_defs.h"
#include "CWindow.h"
#include "CView.h"
#include "my_demoview.h"
#include "my_demowindows.h"
#include "..\MailboxSystem\CEventManager.h"
#include "windowstate.h"
#include <list>
#include <vector>

#define VBUFFER_SIZE 200

class CWindow; //Vorwaertsdeklaration
class CView; //Vorwaertsdeklaration
class CDemoview; //Vorwaertsdeklaration

class CDisplaymanager
{
public:
	/**
	 * Don't use this standard-constructor.
	 * It's missing the address to the postman.
	 */
	CDisplaymanager( CEventManager* pEventManager);

	~CDisplaymanager();

        CEventManager* m_EventManager;

        void Init();
        
        vector<char> v_buffer;
        
	/**
	 * Saves Objects of the type 'CView'. Those Objects allow to switch between
	 * different window-configurations. For example: Main View with two Temperatures
	 * or with four Temperatures. Or a vertical aligned view can be switched to a 90
	 * degree rotated view for a horizontal aligned display. The Viewobject activates
	 * and deactivates the needed windows in the Displaymanager. The windows are
	 * identified by their name. If a necessary window is missing, the Viewobject
	 * refuses to make the changes.
	 */
        vector<CView*> viewlist; //pre
	/**
	 * Includes the objects of the baseclass "CWindows" of the Display, no matter if
	 * they are active or inactive. Every object in this list is regulary triggered by
	 * the CDisplay-Object with the "cycCalc"-function.
	 */
        vector<CWindow*> windowlist; //pre

	void cycCalc();

	/**
	 * Calls the function for switching between different window-configurations of a
	 * CView-object with the corresponding name.
	 */
	bool switch_view(string viewname);

	/**
	 * Returns the actual state of a window.
	 * If the window does not exist or if the window
	 * actually really is in the ERROR-state,
	 * it returns the ERROR-state.
	 */
	windowstate get_state(string windowname);

	/**
	 * Function for changing the state of a window-object.
	 * Returns true if change was successful, false if
	 * the specific window was not found by the displaymanager.
	 */
	bool set_state(string* windowname, windowstate newstate);
        bool set_state(const char* windowname, windowstate newstate);
        string namebuffer;
	/**
	 * This iterator is not only used by the displaymanager itself.
	 * It is also used by the view- and window-objects.
	 */
        vector<CWindow*>::iterator it;
        vector<CView*>::iterator vit;
};

void Displaymanager_Task(void *pvParameters);


#endif // !defined(CDISPLAYMANAGER_H__INCLUDED_)
