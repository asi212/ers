/**
*  \file
*    CView.cpp
*   
*  \brief Implementation of the Class CView
*  \date 10-Jan-2011 16:21:14
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#include "CView.h"
#include "..\system_wide_defs.h"



CView::CView()
{
  windownames.reserve(25);
  name = "0";
  p_displaymanager = NULL;
}

CView::~CView()
{

}

void CView::Init(string view_name, CDisplaymanager* p_display_manager)
{

}


void CView::create_windows()
{

}


string CView::get_name()
{
	return name;
}

	/**
	 * Calls the function for switching between different window-configurations of a
	 * CView-object with the corresponding name. This function makes windows
	 * wake/sleep. Returns 'true' if everything went well. If it returns 'false'
	 * then you need to call another switch-call of another view that works.
	 * Otherwise, the windows and the display might be caught in a state where
	 * they can not escape by itself.
	 */
bool CView::switch_view()
{
	if ((windownames.size() == 0) ||
		(name == "0") ||
		(p_displaymanager == NULL)) return false; //No initialisation, no windows

	//Step 1: make every window sleep
	p_displaymanager->it = p_displaymanager->windowlist.begin();
	while (p_displaymanager->it != p_displaymanager->windowlist.end())
	{
		(*p_displaymanager->it)->set_state(SLEEPING);
		p_displaymanager->it++;
	}

	//Step 2: Set the first window from windownames to state JUST_ACTIVATED
  p_displaymanager->set_state((windownames[0]), JUST_ACTIVATED);
        
	//Step 3: Set all other windows from windownames to state INACTIVE
	//        Dont forget to skip the first window!
	if (windownames.size() > 1)
	{
          for(int i=1; i<(unsigned)windownames.size();i++)
          {
            p_displaymanager->set_state((windownames[i]), INACTIVE);
          }
        }
        return true;
}



bool CView::check_win_exists(string win_name)
{
  p_displaymanager->it = p_displaymanager->windowlist.begin();
  while (p_displaymanager->it != p_displaymanager->windowlist.end())
  {
    if ((*p_displaymanager->it)->name == win_name) return true;
    p_displaymanager->it++;
  }
  return false;
}
















