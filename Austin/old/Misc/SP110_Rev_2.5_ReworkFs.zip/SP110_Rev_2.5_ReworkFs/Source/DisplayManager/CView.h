/**
*  \file
*    CView.cpp
*   
*  \brief Implementation of the Class CView
*  \date 10-Jan-2011 16:21:14
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#if !defined(CVIEW_H__INCLUDED_)
#define CVIEW_H__INCLUDED_
#include "..\system_wide_defs.h"
#include "CDisplaymanager.h"
#include <vector>
#include <iterator>
#include <algorithm>
#include <string>
#include "s_attributes.h"
#include "orientations.h"
#include "CWindow.h"

class CDisplaymanager; //Vorwaertsdeklaration

/*
// A little template to initialize a vector.
// This is for example for a clearer structure when
// creating a new view-object by adding some windows to it.
// siv := "Simple Init Vector"
template <typename T>
struct siv : public vector<T>
{
	siv(const T& t)
	{
		(*this)(t);
	}
	siv& operator()(const T& t)
	{
		this->push_back(t);
		return *this;
	}
};
*/
class CWindow;

class CView
{
public:
	CView();
	virtual ~CView();

	/**
	 * Names of the windows used by the function switch_view().
	 * The vector is created in the derived class.
	 * The first object is going to be the window in the
	 * JUST_ACTIVATED-state of the windowset. 
	 * The others will be INACTIVE.
	 */
	//vector<string>* p_displaynames;

	virtual void Init(string view_name, CDisplaymanager* p_display_manager);

	/**
	 * This function knows the needed windows. It generates the needed windows and
	 * adds them in the windowlist of the displaymanager. It goes on, even if some
	 * of the windows already exist, and creates the missing ones.
	 * (Because there could be multiple windows used by the same CView-Object)
	 * This is the only function that needs to be defined in a
	 * individual view-class. (public-derived from this class)
	 */
	virtual void create_windows();

	/**
	 * The window-objects can read this "attributes"-struct.
	 * In this struct can be informations such as the orientation
	 * (horizontal/vertical) or maybe some
	 * standard-colors or font-sizes.
	 * (Be careful with this option! Once you added an attribute, you
	 * can not get rid of it anymore. It will stay there forever
	 * to be compatible with other implementations. (Baseclass!))
	 */
	s_attributes attributes;

	string name; //!res
	CDisplaymanager* p_displaymanager;
	string get_name();
	
	vector<string*> windownames; //res
        
        /**
         * Just a pointer for the inherited classes to avoid
         * creating temporary pointers.
         * (Also useful for debugging)
         */
        CWindow *p_window;

	/**
	 * Calls the function for switching between different window-configurations of a
	 * CView-object with the corresponding name. This function makes windows
	 * wake/sleep. Returns 'true' if everything went well. If it returns 'false'
	 * then you need to call another switch-call of another view that works.
	 * Otherwise, the windows and the display might be caught in a state where
	 * they can not escape by itself.
	 */
	bool switch_view();

        
	/**
	 * Checks if a window with the specified name is already existant in the
	 * windowliat of the displaymanager.
	 * Returns 'true' if window already exists, and
	 * returns 'false' if the window needs to be created.
	 * 
	 * 
	 */
     bool check_win_exists(string win_name);
private:
};

//Chiller-Viewobjekt
class CDemoview : public CView
{
public:
  CDemoview();
  ~CDemoview();
  void create_windows();
  void Init(string view_name, CDisplaymanager* p_display_manager);
private:
};

//Controller-Viewobjekt
//(Messegeraet Horizontal)
class CController_view_1 : public CView
{
public:
  CController_view_1();
  ~CController_view_1();
  void create_windows();
  void Init(string view_name, CDisplaymanager* p_display_manager);
private:
};

//Controller-Viewobjekt
//(Messegeraet Vertikal)
class CController_view_1_v : public CView
{
public:
  CController_view_1_v();
  ~CController_view_1_v();
  void create_windows();
  void Init(string view_name, CDisplaymanager* p_display_manager);
private:
};

#endif // !defined(CVIEW_H__INCLUDED_)
