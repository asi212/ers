/**
*  \file
*    CWindow.cpp
*   
*  \brief Implementation of the Class CWindow
*  \date 10-Jan-2011 16:21:01
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#include "CWindow.h"
#include "..\system_wide_defs.h"
#include "CDisplaymanager.h"


CWindow::CWindow()
{
  //actual_pin_input.reserve(16);
  //v_buffer.reserve(VBUFFER_SIZE);
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
}

CWindow::~CWindow()
{

}

void CWindow::Init( CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  
}


void CWindow::cycCalc()
{
	/*
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
	if ((name == "0") || (p_displaymailbox == NULL) || displayname == "0") return;
	switch(state)
	{
	case JUST_ACTIVATED:
		break;
	case ACTIVE:
		break;
	case JUST_DEACTIVATED:
		break;
	case INACTIVE:
		break;
	case SLEEPING:
		break;
	case ERROR:
		break;
	default:
		break;
	}
	*/
}

string CWindow::get_name()
{
	return name;
}

windowstate CWindow::get_state()
{
	return state;
}

bool CWindow::set_state(windowstate window_state)
{
	state = window_state;
	return true;
	// Returns always 'true' at the moment.
	// During development,there was no situation
	// i could think of why this should return a 'false'.
	// But this may change in the future.
	// And because this is one of the rare places where a
	// change in a base-class can do no harm,
	// i leave it like that. :)
}


