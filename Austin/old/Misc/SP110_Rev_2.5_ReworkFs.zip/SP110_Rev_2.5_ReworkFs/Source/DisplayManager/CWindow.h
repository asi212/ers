/**
*  \file
*    CWindow.h
*   
*  \brief Implementation of the Class CWindow
*  \date 10-Jan-2011 16:21:01
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#if !defined(CWINDOW_H__INCLUDED_)
#define CWINDOW_H__INCLUDED_

#include "CDisplaymanager.h"
#include "..\system_wide_defs.h"
#include "windowstate.h"
#include "..\MailboxSystem\CEventManager.h"
#include "msg.h"
#include "CView.h"
#include <string>
#include <vector>
#include "stdio.h"
#include "FS.h"
#include "sysinit.h"
#include "CValve.h"

#define WINDOWSNAMES_SIZE 25 //std:string.reserve(X) beim Konstruktoraufruf der Fenster 

#define SET_TEMP_1 		number_changed[0]
#define SET_TEMP_2 		number_changed[1]
#define SET_TEMP_3 		number_changed[2]
#define SET_TEMP_4 		number_changed[3]
#define CHUCK_TEMP_1 	number_changed[4] 
#define CHUCK_TEMP_2 	number_changed[5]
#define CHUCK_TEMP_3 	number_changed[6]
#define CHUCK_TEMP_4 	number_changed[7]
#define STAT_TEMP1		status_changed[0]
#define STAT_TEMP2		status_changed[1]
#define STAT_TEMP3		status_changed[2]
#define STAT_TEMP4		status_changed[3]
 

/**
 * Possible controller modes
 */
typedef enum {
	CONMODE_STANDARD,
	CONMODE_PROGRESSIVE,
	CONMODE_LOWNOISE,
} con_modes;	


extern CEventManager EventManager;

class CDisplaymanager; //Vorwaertsdeklaration
class CView; //Vorwaertsdeklaration
class CMailbox;

extern CEventManager EventManager;

class CWindow
{
public:
        CWindow();
	CWindow(CView* p_viewobj);
	~CWindow();
        
        vector<char>* v_buffer;
        
	/**
	 * Started die Abfrage nach Fehlerzustaenden in der Komponente. Es wird die Adresse
	 * eines s_error uebergeben um die entsprechenden Informationen zu den
	 * Fehlerzustaenden zu sammeln.
	 * Sollte ein Fehler in der Komponente aufgetreten sein, ist der Rueckgabewert
	 * 'true' andernfalls 'false'
	 */
	string get_name();

	/**
	 * Started die Abfrage nach Fehlerzustaenden inder Komponente. Es wird die Adresse
	 * eines s_error uebergeben um die entsprechenden Informationen zu den
	 * Fehlerzustaenden zu sammeln.
	 * Sollte ein Fehler in der Komponente aufgetreten sein, ist der Rueckgabewert
	 * 'true' andernfalls 'false'
	 */
	virtual void cycCalc();

  virtual void Init(CEventManager* pEventManager, CView* p_viewobj, CDisplaymanager *p_dispmanager, bool b_alignment);
        
	windowstate get_state();

	bool set_state(windowstate window_state);

	/**
	 * Pointer for getting access to the actual dominant CView-object.
	 * So the window can read the "attributes"-struct.
	 * In this struct can be informations such as the orientation
	 * (horizontal/vertical) or maybe some
	 * standard-colors or font-sizes.
	 * (Be careful with this option! Once you added an attribute, you
	 * can not get rid of it anymore. It will stay there forever
	 * to be compatible with other implementations.)
	 */
	CView *p_view;

	/**
	 * Contains the adress to a message. You can use this for
	 * sending and receiving messages without creating temporary
	 * pointers. It is useful if you want to save a message for
	 * a longer period of time. Pointing to NULL can remind your
	 * window that you sent a message, but didn't receive it
	 * back yet. (see the 'trashmark'-function)
	 */
	msg *p_msg;
        
  static vector<char> direct_cmd;
  string s_cmd;


	/**
	 * Pointer to the responsible mailbox should be set with the constructor. The
	 * mailbox should know the name of this window, an be registered as recipient by
	 * the object that created the window. (see function
	 * add_recipient/remove_recipient in class CMailbox)
	 */
        CEventManager* m_pEventManager;
	//CMailbox* p_displaymailbox;
	CDisplaymanager *p_CDisplaymanager;

	/**
	 * Name of the display where the data should be shown.
	 * This name is the identification for the mailbox to
	 * deliver the message.
	 */
	string displayname; //res
        
	string name; //res
        
	/**
	 * If a window is active or inactive is saved in this variable.
	 * active[0] holds the current state, active[1] holds the state during the last
	 * cyCalc()-call. The information about the prior state is useful to run different
	 * code depending an activation- or deactivation- procedure.
	 */
	windowstate state;
		
};

// Das Hauptfenster des Messe-Controllers (horizontal)
// mit einer Temperatur und einer Set-Temperatur
class Main_Window_Fair_Controller_1 : public CWindow
{
public:
  Main_Window_Fair_Controller_1();
  ~Main_Window_Fair_Controller_1();
	void Init( CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //MB Eventhadler ab hier 
  static void set_temp_1EventWrapper( void * pObject, float parameter ){ ((Main_Window_Fair_Controller_1*)pObject)->set_temp_1Event( parameter ); };
  void set_temp_1Event( float f );
  static void temp_1_compEventWrapper( void * pObject, float parameter ){ ((Main_Window_Fair_Controller_1*)pObject)->temp_1_compEvent( parameter ); };
  void temp_1_compEvent( float f );
  static void chuck_tempEventWrapper( void * pObject, float parameter ){ ((Main_Window_Fair_Controller_1*)pObject)->chuck_tempEvent( parameter ); };
  void chuck_tempEvent( float f );
  static void chiller_tempEventWrapper( void * pObject, float parameter ){ ((Main_Window_Fair_Controller_1*)pObject)->chiller_tempEvent( parameter ); };
  void chiller_tempEvent( float f );
  static void base_tempEventWrapper( void * pObject, float parameter ){ ((Main_Window_Fair_Controller_1*)pObject)->base_tempEvent( parameter ); };
  void base_tempEvent( float f );
  static void intern_tempEventWrapper( void * pObject, float parameter ){ ((Main_Window_Fair_Controller_1*)pObject)->intern_tempEvent( parameter ); };
  void intern_tempEvent( float f );
  static void set_limits_1EventWrapper( void * pObject, _set_limits_EventArgument parameter ){ ((Main_Window_Fair_Controller_1*)pObject)->set_limits_1Event( parameter ); };
  void set_limits_1Event( _set_limits_EventArgument p );
  static void controller_statusEventWrapper( void * pObject, _string s ){ ((Main_Window_Fair_Controller_1*)pObject)->controller_statusEvent( s ); };
  void controller_statusEvent( _string s );
  static void status_temp_1EventWrapper( void * pObject, _string s ){ ((Main_Window_Fair_Controller_1*)pObject)->status_temp_1Event( s ); };
  void status_temp_1Event( _string s );
  static void set_version_infoEventWrapper( void * pObject, _string s ){ ((Main_Window_Fair_Controller_1*)pObject)->set_version_infoEvent( s ); };
  void set_version_infoEvent( _string s );
  static void set_ip_infoEventWrapper( void * pObject, bool b ){ ((Main_Window_Fair_Controller_1*)pObject)->set_ip_infoEvent( b ); };
  void set_ip_infoEvent(bool b );
  static void configEventWrapper( void * pObject, bool b ){ ((Main_Window_Fair_Controller_1*)pObject)->configEvent( b ); };
  void configEvent( bool b );
  static void set_active_comp_tableEventWrapper( void * pObject, int i ){ ((Main_Window_Fair_Controller_1*)pObject)->set_active_comp_tableEvent( i ); };
  void set_active_comp_tableEvent( int i );
  static void chiller_comm_symbolEventWrapper( void * pObject, bool b ){ ((Main_Window_Fair_Controller_1*)pObject)->chiller_comm_symbolEvent( b ); };
  void chiller_comm_symbolEvent( bool b );
  static void key_lock_symbolEventWrapper( void * pObject, int i ){ ((Main_Window_Fair_Controller_1*)pObject)->key_lock_symbolEvent( i); };
  void key_lock_symbolEvent( int i );
  static void external_display_stateEventWrapper( void * pObject, int i ){ ((Main_Window_Fair_Controller_1*)pObject)->external_display_stateEvent( i ); };
  void external_display_stateEvent( int i );
  static void advice_symbolEventWrapper( void * pObject, bool b ){ ((Main_Window_Fair_Controller_1*)pObject)->advice_symbolEvent( b ); };
  void advice_symbolEvent( bool b );
  static void s_temp_1EventWrapper( void * pObject, bool b ){ ((Main_Window_Fair_Controller_1*)pObject)->s_temp_1Event( b ); };
  void s_temp_1Event( bool b );
  static void set_plusminus_valueEventWrapper( void * pObject, float f ){ ((Main_Window_Fair_Controller_1*)pObject)->set_plusminus_valueEvent( f ); };
  void set_plusminus_valueEvent( float f );  
  static void set_static_1_valueEventWrapper( void * pObject, float f ){ ((Main_Window_Fair_Controller_1*)pObject)->set_static_1_valueEvent( f ); };
  void set_static_1_valueEvent( float f );
  static void set_static_2_valueEventWrapper( void * pObject, float f ){ ((Main_Window_Fair_Controller_1*)pObject)->set_static_2_valueEvent( f ); };
  void set_static_2_valueEvent( float f );
  static void set_option_modeEventWrapper( void * pObject, int i){ ((Main_Window_Fair_Controller_1*)pObject)->set_option_modeEvent( i ); };
  void set_option_modeEvent( int i );
  static void but_option_1EventWrapper( void * pObject, bool b ){ ((Main_Window_Fair_Controller_1*)pObject)->but_option_1Event( b ); };
  void but_option_1Event( bool b );
  static void but_option_2EventWrapper( void * pObject, bool b ){ ((Main_Window_Fair_Controller_1*)pObject)->but_option_2Event( b ); };
  void but_option_2Event( bool b );
  static void new_dew_pointEventWrapper( void * pObject, float f ){ ((Main_Window_Fair_Controller_1*)pObject)->new_dew_pointEvent( f ); };
  void new_dew_pointEvent( float f );
  static void set_con_mode_standardEventWrapper( void * pObject, bool b ){ ((Main_Window_Fair_Controller_1*)pObject)->set_con_mode_standardEvent( b );};
  void set_con_mode_standardEvent( bool b );
  static void set_con_mode_progressiveEventWrapper( void * pObject, bool b ){ ((Main_Window_Fair_Controller_1*)pObject)->set_con_mode_progressiveEvent( b );};
  void set_con_mode_progressiveEvent( bool b );
  static void set_con_mode_lnoiseEventWrapper( void * pObject, bool b ){ ((Main_Window_Fair_Controller_1*)pObject)->set_con_mode_lnoiseEvent( b );};
  void set_con_mode_lnoiseEvent( bool b );
  static void set_active_dewpointEventWrapper( void * pObject, bool b ){ ((Main_Window_Fair_Controller_1*)pObject)->set_active_dewpointEvent( b );};
  void set_active_dewpointEvent( bool b );
	
  void InitializeUserSettings(void);

private:
  float set_temp_1[3], set_temp_2[3], set_temp_3[3], set_temp_4[3];
  float chuck_temp_1[1], chuck_temp_2[1], chuck_temp_3[1], chuck_temp_4[1];
  
  float chuck_temp_1_comp;
  bool chuck_temp_1_comp_changed;
	
	bool  dew_point_sensor;					/**< Remembers, if a dewpoint sensor is installed or not. Derived from CONFIG.INI */
	float dew_point_value;
  bool  dew_point_changed;

	bool dew_point_status;					/**< Dewpoint can be activated or deactivated */
	bool dew_point_status_changed;	/**< TRUE, if status of dewpoint changed, e.g. deactivated -> activated */
  
  int option_button_mode; //0->plusminus, 1->static
  bool option_button_mode_changed;
	
  float plus_minus;
  float static_1; //(Die Grenzwerte hierfuer werden den Settemp-Daten entnommen)
  float static_2;
  
  
  char buffer[20];
		
	
	/*
	 * number_changed[0] set_temp_1
	 * number_changed[1] set_temp_2
	 * number_changed[2] set_temp_3
	 * number_changed[3] set_temp_4
	 * number_changed[4] chuck_temp_1 (oder Air temp)
	 * number_changed[5] chuck_temp_2 (oder Air temp)
	 * number_changed[6] chuck_temp_3 (oder Air temp)
	 * number_changed[7] chuck_temp_4 (oder Air temp)
   */
	bool number_changed[8];
	
  bool window_just_activated;
  
  bool alignment;
  
  // Temperature_status:
  // 5 Blank
  // 2 Cooling
  // 3 Even
  // 4 heating
  // 1 deltaEven
  char Temperature_status[4];
  /*
  status_changed[0] temp 1 status
  status_changed[1] temp 2 status
  status_changed[2] temp 3 status
  status_changed[3] temp 4 status
  */
  bool status_changed[4];
  char c_buffer[20];

  string controller_status;  //res
  bool controller_status_changed;
  
  string controller_mode; //res
  
  int togglecounter[4]; //For the 'blinking'-animation of the temp-status
  bool chiller_locked;
  bool chiller_locked_old;
  
  bool warning_symbol; //true-> shows the red 'ball' you could push, false-> shows nothing
  bool warning_symbol_changed; //just a flag...
  
  bool chuck_temperature_valid[4]; //Jeweils ein Flag ob die Temperatur gueltig ist

  string version_info; //res
  bool version_info_changed;

  string ip_info;			// Enth�lt den IP-String f�rs Display
  bool ip_info_changed; // TRUE, wenn neue IP-Adresse gesetzt

  bool chiller_comm_symbol; //Symbol zur signalisierung der CHillerkommunikation
  bool chiller_comm_symbol_changed;
  
  int active_table; //Nummer der aktiven Kompensationstabelle
  bool active_table_changed;
	
	TEMP_CONTROL_MODE con_mode;		// Stores the current controller mode (Standard, Progressive, LowNoise)
	bool con_mode_changed;  // Signals a change of controller mode
	
};



// Das Hauptfenster des Chillers (vertikal)
// mit 4 Temperaturen und nur einer Set-Temperatur
class Main_Window_1 : public CWindow
{
public:
  Main_Window_1();
  ~Main_Window_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  static void set_temp_1EventWrapper( void * pObject, float parameter ){ ((Main_Window_1*)pObject)->set_temp_1Event( parameter ); };
  void set_temp_1Event( float f );
  static void chuck_tempEventWrapper( void * pObject, float parameter ){ ((Main_Window_1*)pObject)->chuck_tempEvent( parameter ); };
  void chuck_tempEvent( float f );
  static void advice_symbolEventWrapper( void * pObject, bool b ){ ((Main_Window_1*)pObject)->advice_symbolEvent( b ); };
  void advice_symbolEvent( bool b );
  static void s_temp_1EventWrapper( void * pObject, bool b ){ ((Main_Window_1*)pObject)->s_temp_1Event( b ); };
  void s_temp_1Event( bool b );
  
private:
  float set_temp_1[3], set_temp_2[3], set_temp_3[3], set_temp_4[3];
  float chuck_temp_1[1], chuck_temp_2[1], chuck_temp_3[1], chuck_temp_4[1];
  char buffer[20];
  char c_buffer[20];
  bool set_temp_1_changed;
  bool set_temp_2_changed;
  bool set_temp_3_changed;
  bool set_temp_4_changed;
  bool chuck_temp_1_changed;
  bool chuck_temp_2_changed;
  bool chuck_temp_3_changed;
  bool chuck_temp_4_changed;
  bool alignment;
  
  // Temperature_status:
  // 5 Blank
  // 2 Cooling
  // 3 Even
  // 4 heating
  // 1 deltaEven
  char Temperature_status[4];
  /*
  status_changed[0] temp 1 status
  status_changed[1] temp 2 status
  status_changed[2] temp 3 status
  status_changed[3] temp 4 status
  */
  bool status_changed[4];
  //vector<char>* v_buffer;
  string controller_mode; //res
  bool controller_mode_changed;
  int togglecounter[4]; //For the 'blinking'-animation of the temp-status
  bool chiller_locked;
  
  bool warning_symbol; //true-> shows the red 'ball' you could push, false-> shows nothing
  bool warning_symbol_changed; //just a flag...
  
  bool chuck_temperature_valid[4]; //Jeweils ein Flag ob die Temperatur gueltig ist
  
  string version_info; //res
  bool version_info_changed;
  
  bool chiller_comm_symbol; //Symbol zur signalisierung der CHillerkommunikation
  bool chiller_comm_symbol_changed;
};

/**
* Pin Request window,
* Horizontale und Vertikale Ausrichtung.
* Horizontale ausrichtung wurde fuer die Demonstration
* vom 16.02.2011 verwendet.
* Ueber das Flag 'alignment' kann die Ausrichtung bestimmt werden.
* 
*/
class Pin_Req_1 : public CWindow
{
public:
  Pin_Req_1();
  ~Pin_Req_1();
  void Init(CEventManager* p_EventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //MB EventHandler
  static void pin_request_1EventWrapper( void * pObject, _string s ){ ((Pin_Req_1*)pObject)->pin_request_1Event( s ); };
  void pin_request_1Event( _string s );
  static void option_button_configEventWrapper( void * pObject, bool b ){ ((Pin_Req_1*)pObject)->option_button_configEvent( b ); };
  void option_button_configEvent( bool b );
  
private:
  vector<char> actual_pin_input;
  vector<char> unlock_pin;
  vector<char> diagnose_pin;
  vector<char> network_config_pin;
  //vector<char> buffer;
  bool pin_changed;
  bool alignment; //false = horizontal, true = vertical
};


class Assist_1 : public CWindow
{
public:
  Assist_1();
  ~Assist_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //MB EventHandler
  static void display_update_finishedEventWrapper( void * pObject, bool b ){ ((Assist_1*)pObject)->display_update_finishedEvent( b ); };
  void display_update_finishedEvent(bool b);
  static void forward_to_active_windowEventWrapper( void * pObject, _string s ){ ((Assist_1*)pObject)->forward_to_active_windowEvent( s ); };
  void forward_to_active_windowEvent( _string s );
private:
  bool found_active_window;
  windowstate former_windowstate; //windowsstatus des vom Assistenten deaktivierten Fensters
                                  //(Wird bei einem Displayupdate zwischengespeichert)
  bool display_update_in_progress;
  string former_active_window; //res
                               //Name des vom Assistenten deaktivierten Fensters
                               //(Wird bei einem Displayupdate zwischengespeichert)
  
};

class Config_Window_1 : public CWindow
{
public:
  Config_Window_1();
  ~Config_Window_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  
private:
};

class Diagnose_1 : public CWindow
{
public:
  Diagnose_1();
  ~Diagnose_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  string compressor_status; //res
  bool compressor_status_changed;
  string controller_mode; //res
  bool controller_mode_changed;
  bool temp_changed[4];
  float chuck_temp_1[1], chuck_temp_2[1], chuck_temp_3[1], chuck_temp_4[1];

private:
  bool chiller_locked;
  bool status_changed[4];
  char Temperature_status[4];
  //vector<char>* v_buffer;
  char c_buffer[20];
  float chiller_temp;
  bool chiller_temp_changed;
};

class Diagnose_2 : public CWindow
{
public:
  Diagnose_2();
  ~Diagnose_2();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  
  //vector<char>* v_buffer;

  // cool_air_set_value[0] -> actual value
  // cool_air_set_value[1] -> upper limit
  // cool_air_set_value[2] -> lower limit
  int cool_air_set_value[3];
  bool cool_air_set_value_changed; //Just a flag...
  int cool_air_actual_flow;//The current flow through the valve
  bool cool_air_actual_flow_changed; //Just a flag...

  // warm_air_set_value[0] -> actual value
  // warm_air_set_value[1] -> upper limit
  // warm_air_set_value[2] -> lower limit
  int warm_air_set_value[3];
  bool warm_air_set_value_changed;
  int warm_air_actual_flow;//The current flow through the valve
  bool warm_air_actual_flow_changed;//Just a flag...

  int bypass_valve_actual_flow; //The current flow through the valve
  int bypass_valve_actual_flow_changed; //Just a flag...
  bool bypass_valve_on_off; //The state of the valve true->ON, false->OFF
  bool bypass_valve_on_off_changed; //Just a flag...

  int main_valve_actual_flow; //The current flow through the valve
  bool main_valve_actual_flow_changed; //Just a flag...
  bool main_valve_on_off; //The state of the valve true->ON, false->OFF
  bool main_valve_on_off_changed; //Just a flag...

private:
};

class Diagnose_3 : public CWindow
{
public:
  Diagnose_3();
  ~Diagnose_3();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //MB EventHandler
  static void set_power_suppply_5_set_voltageEventWrapper( void * pObject, float f ){ ((Diagnose_3*)pObject)->set_power_suppply_5_set_voltageEvent( f ); };
  void set_power_suppply_5_set_voltageEvent( float f );
  static void set_power_suppply_6_set_voltageEventWrapper( void * pObject, float f ){ ((Diagnose_3*)pObject)->set_power_suppply_6_set_voltageEvent( f ); };
  void set_power_suppply_6_set_voltageEvent( float f );

private:
  char buffer[20];
  //vector<char>* v_buffer;
  int power_suppply_1_set_voltage[3];
  // power_suppply_1_set_voltage[0] -> actual value
  // power_suppply_1_set_voltage[1] -> upper limit
  // power_suppply_1_set_voltage[2] -> lower limit
  int power_suppply_1_voltage;
  bool power_suppply_1_voltage_changed;
  
  int power_suppply_2_set_voltage[3];
  // power_suppply_2_set_v[0] -> actual value
  // power_suppply_2_set_v[1] -> upper limit
  // power_suppply_2_set_v[2] -> lower limit
  int power_suppply_2_voltage;
  bool power_suppply_2_voltage_changed;
  
  float power_suppply_1_current;
  float power_suppply_2_current;
  float power_suppply_3_current;
  float power_suppply_4_current;
  bool power_suppply_1_set_v_changed;
  bool power_suppply_2_set_v_changed;
  bool power_suppply_1_current_changed;
  bool power_suppply_2_current_changed;
  bool power_suppply_3_current_changed;
  bool power_suppply_4_current_changed;
};

class Diagnose_4 : public CWindow
{
public:
  Diagnose_4();
  ~Diagnose_4();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
private:
  char c_buffer[20];
  //vector<char>* v_buffer;
  float temp[8];
  bool temp_changed[8];
};

class Diagnose_5 : public CWindow
{
public:
  Diagnose_5();
  ~Diagnose_5();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
private:
  char c_buffer[20];
  //vector<char>* v_buffer;
  float temp[8];
  bool temp_changed[8];
};

class Diagnose_6 : public CWindow
{
public:
  Diagnose_6();
  ~Diagnose_6();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
private:
  int data_read;
  int filesize;
  int entrysize;
  FS_DIR    *pDir;
  FS_DIRENT *pDirEnt;
  char _acBuffer[50];
  char acName[20];
  char space[10];
  U8 Attr;
  //PowerPac FS:
  FS_FIND_DATA *p_finddata;
  FS_FILE *p_FS_FILE;
};



class Show_File_System_1 : public CWindow
{
public:
  Show_File_System_1();
  ~Show_File_System_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
private:
  int data_read;
  int filesize;
  int entrysize;
  FS_DIR    *pDir;
  FS_DIRENT *pDirEnt;
  char _acBuffer[50];
  char acName[20];
  char space[10];
  U8 Attr;
  //PowerPac FS:
  FS_FIND_DATA *p_finddata;
  FS_FILE *p_FS_FILE;
};

class Switchview_1 : public CWindow
{
public:
  Switchview_1();
  ~Switchview_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
private:
};

class Controller_Overview_1 : public CWindow
{
public:
  Controller_Overview_1();
  ~Controller_Overview_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
private:
};


class Set_Temp_1 : public CWindow
{
public:
  Set_Temp_1();
  ~Set_Temp_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
private:
  int set_temp_1;
  char buffer[20];
  bool set_temp_1_changed;
};


/*
Keyboard fuer Gleitkommazahlen,
im Moment fuer zwei Nachkommastellen,
es ist aber dafuer ausgelegt mit
mehr oder weniger zu arbeiten, ohne grossen Aufwand.
*/
class Keyboard_1 : public CWindow
{
public:
  Keyboard_1();
  ~Keyboard_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //MB Event Handler
  static void init_float_inputEventWrapper( void * pObject, _input_float_EventArgument a ){ ((Keyboard_1*)pObject)->init_float_inputEvent( a ); };
  void init_float_inputEvent( _input_float_EventArgument a );
  static void keyboard_float_commandEventWrapper( void * pObject, _string s ){ ((Keyboard_1*)pObject)->keyboard_float_commandEvent( s ); };
  void keyboard_float_commandEvent( _string s );
  
private:
  vector<char> actual_pin_input;
  //vector<char> config_pin;
  //vector<char> diagnose_pin;
  
  bool  limit_reached;
  
  //vector<char> buffer;
  char c_buffer[20];
  bool number_changed;
//  bool init_number_arrived;
  float f_numberbuffer;
  int i_numberbuffer;
  float f_number[3]; //startwert, upper limit, lower limit
  CEventNames::_event_name e_dst; //Ereigniss das ausgel�st werden soll nach der Eingabe
  string called_window; //res - name des Fensters dem nach Betaetigen des 'Enter'-Buttons der neue Wert zugesendet werden soll
  bool first_button;
  bool alignment; //false = horizontal, true = vertical
  int nachkommastellen;
};

/*
Keyboard fuer Ganzzahlen
*/
class Keyboard_2 : public CWindow
{
public:
  Keyboard_2();
  ~Keyboard_2();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //MB EventHandler
  static void init_int_inputEventWrapper( void * pObject, _input_int_EventArgument a ){ ((Keyboard_2*)pObject)->init_int_inputEvent( a ); };
  void init_int_inputEvent( _input_int_EventArgument a );
  static void keyboard_int_commandEventWrapper( void * pObject, _string s ){ ((Keyboard_2*)pObject)->keyboard_int_commandEvent( s ); };
  void keyboard_int_commandEvent( _string s );
    
private:
  vector<char> actual_pin_input;
  //vector<char> config_pin;
  //vector<char> diagnose_pin;
  
  bool  limit_reached;
  
  //vector<char> buffer;
  char c_buffer[20];
  bool number_changed;
//  bool init_number_arrived;
  int i_numberbuffer;
  int i_number[3]; //startwert, upper limit, lower limit
  string parametername; //res - name des Parameters zur Identifikation (beim Zuruecksenden des neuen Wertes benoetigt)
  CEventNames::_event_name e_return;  //Ereigniss das bei Eingabe ausgel�st werden soll
  string called_window; //res - name des Fensters dem nach Betaetigen des 'Enter'-Buttons der neue Wert zugesendet werden soll
  bool first_button;
  bool alignment; //false = horizontal, true = vertical
};

class Diagnose_1_Fair_Controller_1 : public CWindow
{
public:
  Diagnose_1_Fair_Controller_1();
  ~Diagnose_1_Fair_Controller_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  string controller_mode; //res
  string controller_status; //res
  bool controller_mode_changed;
  bool controller_status_changed;
  bool temp_changed;
  float chuck_temp, chiller_temp, base_temp, intern_temp, dewpoint_temp;
	bool over_temp, over_temp_status_changed;
	
  // Event Handler
  static void diag_page_1EventWrapper( void * pObject, bool p ){ ((Diagnose_1_Fair_Controller_1*)pObject)->diag_page_1Event(p);};
  void diag_page_1Event( bool p );
  static void chuck_tempEventWrapper( void * pObject, float parameter ){ ((Diagnose_1_Fair_Controller_1*)pObject)->chuck_tempEvent( parameter ); };
  void chuck_tempEvent( float f );
  static void chiller_tempEventWrapper( void * pObject, float parameter ){ ((Diagnose_1_Fair_Controller_1*)pObject)->chiller_tempEvent( parameter ); };
  void chiller_tempEvent( float f );
  static void base_tempEventWrapper( void * pObject, float parameter ){ ((Diagnose_1_Fair_Controller_1*)pObject)->base_tempEvent( parameter ); };
  void base_tempEvent( float f );
  static void intern_tempEventWrapper( void * pObject, float parameter ){ ((Diagnose_1_Fair_Controller_1*)pObject)->intern_tempEvent( parameter ); };
  void intern_tempEvent( float f );
  static void new_dew_pointEventWrapper( void * pObject, float f ){ ((Diagnose_1_Fair_Controller_1*)pObject)->new_dew_pointEvent( f ); };
  void new_dew_pointEvent( float f );
  static void controller_statusEventWrapper( void * pObject, _string s ){ ((Diagnose_1_Fair_Controller_1*)pObject)->controller_statusEvent( s ); };
  void controller_statusEvent( _string s );
  static void set_errorEventWrapper( void * pObject, int i ){ ((Diagnose_1_Fair_Controller_1*)pObject)->set_errorEvent( i ); };
  void set_errorEvent( int i );
  static void reset_errorEventWrapper( void * pObject, int i ){ ((Diagnose_1_Fair_Controller_1*)pObject)->reset_errorEvent( i ); };
  void reset_errorEvent( int i );

private:
  bool chiller_locked;
  bool status_changed[4];
  char Temperature_status[4];
  //vector<char>* v_buffer;
  char c_buffer[20];
  bool alignment; //false = horizontal, true = vertical
  bool window_just_activated;
};

class Diagnose_2_Fair_Controller_1 : public CWindow
{
public:
  Diagnose_2_Fair_Controller_1();
  ~Diagnose_2_Fair_Controller_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();

	float power_suppply_1_set_value;
	float power_suppply_2_set_value;
	
  float power_suppply_1_voltage;
  float power_suppply_2_voltage;
  float power_suppply_1_current;
  float power_suppply_2_current;

	bool over_current;
	bool under_current;
	
	bool relay_status;
	
  bool power_suppply_1_set_v_changed;
  bool power_suppply_2_set_v_changed;
	
	bool value_changed;   // measured current or voltage value has changed
	bool error_changed;	  // under- or over-current error status has changed
  bool alignment; 			// false = horizontal, true = vertical
  
    //MB EventHandler
  static void diag_page_2EventWrapper( void * pObject, bool p ){ ((Diagnose_2_Fair_Controller_1*)pObject)->diag_page_2Event(p);};
  void diag_page_2Event( bool p );
  static void set_power_supply_1_voltage_limitsEventWrapper( void * pObject, _set_limits_EventArgument p ){ ((Diagnose_2_Fair_Controller_1*)pObject)->set_power_supply_1_voltage_limitsEvent(p);};
  void set_power_supply_1_voltage_limitsEvent( _set_limits_EventArgument p );
  static void set_power_supply_2_voltage_limitsEventWrapper( void * pObject, _set_limits_EventArgument p ){ ((Diagnose_2_Fair_Controller_1*)pObject)->set_power_supply_2_voltage_limitsEvent(p);};
  void set_power_supply_2_voltage_limitsEvent( _set_limits_EventArgument p );
  static void set_power_supply_5_set_voltageEventWrapper( void * pObject, float p ){ ((Diagnose_2_Fair_Controller_1*)pObject)->set_power_supply_5_set_voltageEvent(p);};
  void set_power_supply_5_set_voltageEvent( float p );
  static void set_power_supply_6_set_voltageEventWrapper( void * pObject, float p ){ ((Diagnose_2_Fair_Controller_1*)pObject)->set_power_supply_6_set_voltageEvent(p);};
  void set_power_supply_6_set_voltageEvent( float p );
  static void power_suppply_1_currentEventWrapper( void * pObject, float p ){ ((Diagnose_2_Fair_Controller_1*)pObject)->power_suppply_1_currentEvent(p);};
  void power_suppply_1_currentEvent( float p );
  static void power_suppply_2_currentEventWrapper( void * pObject, float p ){ ((Diagnose_2_Fair_Controller_1*)pObject)->power_suppply_2_currentEvent(p);};
  void power_suppply_2_currentEvent( float p );
  static void power_suppply_1_voltageEventWrapper( void * pObject, float f ){ ((Diagnose_2_Fair_Controller_1*)pObject)->power_suppply_1_voltageEvent(f);};
  void power_suppply_1_voltageEvent( float f );
  static void power_suppply_2_voltageEventWrapper( void * pObject, float f ){ ((Diagnose_2_Fair_Controller_1*)pObject)->power_suppply_2_voltageEvent(f);};
  void power_suppply_2_voltageEvent( float  );
  static void inp_power_suppply_1_set_voltageEventWrapper( void * pObject, bool b ){ ((Diagnose_2_Fair_Controller_1*)pObject)->inp_power_suppply_1_set_voltageEvent(b);};
  void inp_power_suppply_1_set_voltageEvent( bool b );
  static void inp_power_suppply_2_set_voltageEventWrapper( void * pObject, bool b ){ ((Diagnose_2_Fair_Controller_1*)pObject)->inp_power_suppply_2_set_voltageEvent(b);};
  void inp_power_suppply_2_set_voltageEvent( bool b );
  static void set_power_supply_56_relayEventWrapper( void * pObject, bool b ){ ((Diagnose_2_Fair_Controller_1*)pObject)->set_power_supply_56_relayEvent(b);};
  void set_power_supply_56_relayEvent( bool b );
  static void toggle_power_supply_56_relayEventWrapper( void * pObject, bool b ){ ((Diagnose_2_Fair_Controller_1*)pObject)->toggle_power_supply_56_relayEvent(b);};
  void toggle_power_supply_56_relayEvent( bool b );
  static void forward_to_active_windowEventWrapper( void * pObject, _string s ){ ((Diagnose_2_Fair_Controller_1*)pObject)->forward_to_active_windowEvent( s ); };
  void forward_to_active_windowEvent( _string s );
	static void set_errorEventWrapper( void * pObject, int i ){ ((Diagnose_2_Fair_Controller_1*)pObject)->set_errorEvent( i ); };
  void set_errorEvent( int i );
	static void reset_errorEventWrapper( void * pObject, int i ){ ((Diagnose_2_Fair_Controller_1*)pObject)->reset_errorEvent( i ); };
  void reset_errorEvent( int i );
  
private:
};

class Diagnose_3_Fair_Controller_1 : public CWindow {
	
public:

	// Public functions
  Diagnose_3_Fair_Controller_1();
  ~Diagnose_3_Fair_Controller_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
	
  // Event Handlers
	static void diag_page_3EventWrapper( void * pObject, bool p ){ ((Diagnose_3_Fair_Controller_1*)pObject)->diag_page_3Event(p);};
  void diag_page_3Event( bool p );
 	static void inp_cool_air_valueEventWrapper( void * pObject, bool b ){ ((Diagnose_3_Fair_Controller_1*)pObject)->inp_cool_air_valueEvent(b);};
  void inp_cool_air_valueEvent( bool b );
 	static void inp_warm_air_valueEventWrapper( void * pObject, bool b ){ ((Diagnose_3_Fair_Controller_1*)pObject)->inp_warm_air_valueEvent(b);};
  void inp_warm_air_valueEvent( bool b );
	static void valve_1_setEventWrapper( void * pObject, float f ){ ((Diagnose_3_Fair_Controller_1*)pObject)->valve_1_setEvent(f);};
  void valve_1_setEvent( float f );
	static void valve_2_setEventWrapper( void * pObject, float f ){ ((Diagnose_3_Fair_Controller_1*)pObject)->valve_2_setEvent(f);};
  void valve_2_setEvent( float f );
	static void air_pressure_new_valEventWrapper( void * pObject, float f ){ ((Diagnose_3_Fair_Controller_1*)pObject)->air_pressure_new_valEvent(f);};
  void air_pressure_new_valEvent( float f );
	static void toggle_bypass_valveEventWrapper( void * pObject, bool b ){ ((Diagnose_3_Fair_Controller_1*)pObject)->toggle_bypass_valveEvent(b);};
  void toggle_bypass_valveEvent( bool b );
	static void switch_bypass_valveEventWrapper( void * pObject, bool b ){ ((Diagnose_3_Fair_Controller_1*)pObject)->switch_bypass_valveEvent(b);};
  void switch_bypass_valveEvent( bool b );
	static void toggle_main_valveEventWrapper( void * pObject, bool b ){ ((Diagnose_3_Fair_Controller_1*)pObject)->toggle_main_valveEvent(b);};
  void toggle_main_valveEvent( bool b );
	static void switch_main_valveEventWrapper( void * pObject, bool b ){ ((Diagnose_3_Fair_Controller_1*)pObject)->switch_main_valveEvent(b);};
  void switch_main_valveEvent( bool b );
	static void toggle_chiller_relayEventWrapper( void * pObject, bool b ){ ((Diagnose_3_Fair_Controller_1*)pObject)->toggle_chiller_relayEvent(b);};
  void toggle_chiller_relayEvent( bool b );
	static void switch_chiller_relayEventWrapper( void * pObject, bool b ){ ((Diagnose_3_Fair_Controller_1*)pObject)->switch_chiller_relayEvent(b);};
  void switch_chiller_relayEvent( bool b );
	
private:
  
	bool display_new_valve_val( void );
	portTickType disp_valv_count;
	
	bool int_chiller;							// Flag telling us, if an internal chiller (=true) or external chiller (=false) is used	
	bool value_changed;						// Flag telling us, if any of displayed values has changed
	
  float cool_air_set_value;    	// The set value for cold air flow in %
  int cool_air_actual_flow;			// The current flow through the cold air valve in l/min

  float warm_air_set_value;   	// The set value for warm air flow in %
  int warm_air_actual_flow;			// The current flow through the warm air valve in l/min

	float input_pressure;					// Input pressure in bar

  bool bypass_valve_status; 		// The state of the valve true->ON, false->OFF
  bool main_valve_status; 			// The state of the valve true->ON, false->OFF
	bool chiller_relay_status; 		// The state of the chiller relay, true->ON, false->OFF

  bool alignment; 							// false = horizontal, true = vertical	
};

class Diagnose_4_Fair_Controller_1 : public CWindow
{
public:
  Diagnose_4_Fair_Controller_1();
  ~Diagnose_4_Fair_Controller_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //MB Event Handler
  static void forward_to_active_windowEventWrapper( void * pObject, _string s ){ ((Diagnose_4_Fair_Controller_1*)pObject)->forward_to_active_windowEvent( s ); };
  void forward_to_active_windowEvent( _string s );
  static void diag_page_4EventWrapper( void * pObject, bool p ){ ((Diagnose_4_Fair_Controller_1*)pObject)->diag_page_4Event(p);};
  void diag_page_4Event( bool p );
  static void update_filesys_viewEventWrapper( void * pObject, bool p ){ ((Diagnose_4_Fair_Controller_1*)pObject)->update_filesys_viewEvent(p);};
  void update_filesys_viewEvent( bool p );

  
private:
  int data_read;
  int filesize;
  int entrysize;
  FS_DIR    *pDir;
  FS_DIRENT *pDirEnt;
  char _acBuffer[50];
  char acName[20];
  char space[10];
  U8 Attr;
  //PowerPac FS:
  FS_FIND_DATA *p_finddata;
  FS_FILE *p_FS_FILE;
  bool alignment; //false = horizontal, true = vertical
  bool m_update_filesys_view;
};

class Menue_v : public CWindow
{
public:
  Menue_v();
  ~Menue_v();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  
	// Event Handler
  static void init_menue_vEventWrapper( void * pObject, _two_params<int,int> p){ ((Menue_v*)pObject)->init_menue_vEvent( p ); };
  void init_menue_vEvent( _two_params<int,int> p );
  static void forward_to_active_windowEventWrapper( void * pObject, _string s ){ ((Menue_v*)pObject)->forward_to_active_windowEvent( s ); };
  void forward_to_active_windowEvent( _string s );
  
private:
	int number_pages;
	int active_page;
	bool menue_changed;
	bool page_changed;
};


class Error_1 : public CWindow
{
public:
  Error_1();
  ~Error_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //vector<char>* v_buffer;
  char _acBuffer[50];
//int timeshift_calls; //Kuenstliche Zeitversetzung bis die n�chste Infobenachrichtung ans Mainmenu geschickt wird. (nach verlassen einer Info)
  string former_active_window; //res - Name des vom Errorhandler deaktivierten Fensters
  string messagebox_text; //res - Anzuzeigende Nachricht
  /*
  active_error == 0 --> Kein Fehler aktiv, oder er wird gerade angezeigt
  active_error == 1 --> Infomessage aktiv, Fenster wird im folgenden angezeigt
  active_error == 2 --> Normaler Fehler aktiv, Fenster wird im folgenden angezeigt
  active_error == 3 --> Schwerer Fehler aktiv, Fenster wird im folgenden angezeigt
  */
  int active_error;
  
  bool found_active_window;
  windowstate former_windowstate; //windowsstatus des vom Errorhandler deaktivierten Fensters
                                  //Wird anschliessend wieder hergestellt
  bool alignment;
  
  // Event Handler
  static void drop_errormessageEventWrapper( void * pObject, _string s ){ ((Error_1*)pObject)->drop_errormessageEvent( s );};
  void drop_errormessageEvent( _string s );
  static void remove_errormessageEventWrapper( void * pObject, bool b ){ ((Error_1*)pObject)->remove_errormessageEvent( b );};
  void remove_errormessageEvent( bool b );
  static void drop_infomessageEventWrapper( void * pObject, _string s ){ ((Error_1*)pObject)->drop_infomessageEvent( s );};
  void drop_infomessageEvent( _string s );
  static void red_ball_pressedEventWrapper( void * pObject, bool b ){ ((Error_1*)pObject)->red_ball_pressedEvent( b );};
  void red_ball_pressedEvent( bool b );
  static void error_1_okEventWrapper( void * pObject, bool b ){ ((Error_1*)pObject)->error_1_okEvent( b );};
  void error_1_okEvent( bool b );
  static void drop_fatalerrormessageEventWrapper( void * pObject, bool b ){ ((Error_1*)pObject)->drop_fatalerrormessageEvent( b );};
  void drop_fatalerrormessageEvent( bool b );
  
private:
};

class Dimmer_1 : public CWindow
{
public:
  Dimmer_1();
  ~Dimmer_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
	
	// Event Handler
	static void display_touchedEventWrapper( void * pObject, bool b ){ ((Dimmer_1*)pObject)->display_touchedEvent( b );};
  void display_touchedEvent( bool b );
	
private:
  bool alignment; //false = horizontal, true = vertical
  int callcount;
  bool is_dimmed;
};


class User_Config_1 : public CWindow
{
public:
  User_Config_1();
  ~User_Config_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //MB EventHandler
  static void user_config_page_1EventWrapper( void * pObject, bool b ){ ((User_Config_1*)pObject)->user_config_page_1Event( b ); };
  void user_config_page_1Event( bool b );
  static void config_window_activationEventWrapper( void * pObject,  _two_params<int,int> p ){ ((User_Config_1*)pObject)->config_window_activationEvent( p);};
  void config_window_activationEvent(  _two_params<int,int> p );
//  static void set_standby_modeEventWrapper( void * pObject,  bool b ){ ((User_Config_1*)pObject)->set_standby_modeEvent( b );};
//  void set_standby_modeEvent( bool b );
  static void set_hold_modeEventWrapper( void * pObject,  bool b ){ ((User_Config_1*)pObject)->set_hold_modeEvent( b );};
  void set_hold_modeEvent( bool b );
  static void controller_modeEventWrapper( void * pObject, _string s ){ ((User_Config_1*)pObject)->controller_modeEvent( s ); };
  void controller_modeEvent( _string s );
  static void controller_statusEventWrapper( void * pObject, _string s ){ ((User_Config_1*)pObject)->controller_statusEvent( s ); };
  void controller_statusEvent( _string s );
  
private:
  bool alignment; //false = horizontal, true = vertical

  bool hold_mode;
  bool standby_mode;
	bool enabled_mode;
	bool purge_mode;
	bool defrost_mode;
  bool mode_changed;

  char menu[5][7]; //user_config_menu Buttonleistenkonfiguration
  bool menu_changed;
  int xpos, ypos;
};


class System_Setup_1 : public CWindow
{
public:
  System_Setup_1();
  ~System_Setup_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();

  // Event Handler
  static void system_configEventWrapper(  void * pObject,  bool b ){ ((System_Setup_1*)pObject)->system_configEvent( b );};
  void system_configEvent( bool b );
  static void temp_limitsEventWrapper(  void * pObject,  bool b ){ ((System_Setup_1*)pObject)->temp_limitsEvent( b );};
  void temp_limitsEvent( bool b );
  static void network_configEventWrapper(  void * pObject,  bool b ){ ((System_Setup_1*)pObject)->network_configEvent( b );};
  void network_configEvent( bool b );
  
private:
  bool alignment; // false = horizontal, true = vertical
};


class System_Config_1 : public CWindow
{
public:
  System_Config_1();
  ~System_Config_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();

  // Event Handler
  static void save_button_pressedEventWrapper( void * pObject,  bool b ){ ((System_Config_1*)pObject)->save_button_pressedEvent( b );};
  void save_button_pressedEvent( bool b );
  static void exit_button_pressedEventWrapper( void * pObject,  bool b ){ ((System_Config_1*)pObject)->exit_button_pressedEvent( b );};
  void exit_button_pressedEvent( bool b );
  static void up_button_pressedEventWrapper( void * pObject,  bool b ){ ((System_Config_1*)pObject)->up_button_pressedEvent( b );};
  void up_button_pressedEvent( bool b );
  static void down_button_pressedEventWrapper( void * pObject,  bool b ){ ((System_Config_1*)pObject)->down_button_pressedEvent( b );};
  void down_button_pressedEvent( bool b );
  
private:
  bool alignment; 					// false = horizontal, true = vertical
	bool chuck_list_changed;  // true, if displayed chuck list has changed
	char selected_chuck;			// index of chuck list entry to be shown in selected chuck line (white frame)
};


class Temp_Limits_1 : public CWindow
{
public:
  Temp_Limits_1();
  ~Temp_Limits_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();

  // Event Handler
  static void save_button_pressedEventWrapper( void * pObject,  bool b ){ ((Temp_Limits_1*)pObject)->save_button_pressedEvent( b );};
  void save_button_pressedEvent( bool b );
  static void exit_button_pressedEventWrapper( void * pObject,  bool b ){ ((Temp_Limits_1*)pObject)->exit_button_pressedEvent( b );};
  void exit_button_pressedEvent( bool b );
  static void change_temp_limitEventWrapper( void * pObject,  bool b ){ ((Temp_Limits_1*)pObject)->change_temp_limitEvent( b );};
  void change_temp_limitEvent( bool b );
  static void reset_user_limitsEventWrapper( void * pObject, bool b){ ((Temp_Limits_1*)pObject)->reset_user_limitsEvent( b ); };
  void reset_user_limitsEvent( bool b );
  static void temp_limit_changedEventWrapper( void * pObject,  float f ){ ((Temp_Limits_1*)pObject)->temp_limit_changedEvent( f );};
  void temp_limit_changedEvent( float f );
  
private:
  bool alignment; // false = horizontal, true = vertical
	bool temp_limit_changed;
	bool upper_limit; // false = lower limit is handled, true = upper limit is handled
	float limits[2];
};


class Network_Config_1 : public CWindow
{
public:
  Network_Config_1();
  ~Network_Config_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //MB EventHandler
  static void set_network_macEventWrapper( void * pObject,  _string s ){ ((Network_Config_1*)pObject)->set_network_macEvent( s );};
  void set_network_macEvent( _string s );
  static void input_network_configEventWrapper( void * pObject,  _two_params<int,int> p ){ ((Network_Config_1*)pObject)->input_network_configEvent( p);};
  void input_network_configEvent(  _two_params<int,int> p );
  static void network_config_changedEventWrapper( void * pObject, int i ){ ((Network_Config_1*)pObject)->network_config_changedEvent( i); };
  void network_config_changedEvent( int i );
  static void save_button_pressedEventWrapper( void * pObject,  bool b ){ ((Network_Config_1*)pObject)->save_button_pressedEvent( b );};
  void save_button_pressedEvent( bool b );
  static void exit_button_pressedEventWrapper( void * pObject,  bool b ){ ((Network_Config_1*)pObject)->exit_button_pressedEvent( b );};
  void exit_button_pressedEvent( bool b );

	
private:
  bool alignment; //false = horizontal, true = vertical
  
  //    0     1        2        3     2    1    0
  // [ IP / Mask / Gateway ] [ 192 / 168 / 1 / 183]
  unsigned char network[3][4];
  unsigned char* p_ext_network[3]; //Zum casten auf eine empfangene Netzwerkkonfiguration (z.B. beim Booten des Systems)
  int i_buf[2]; //Buffer zum zwischenspeichern des zu Aendernden Adresswertes fuer die Bearbeitung vom Keyboardfenster
  string mac;
  bool net_adresses_changed;
  bool waiting_for_keyboard;
};

class Option_Button_Config : public CWindow
{
public:
  Option_Button_Config();
  ~Option_Button_Config();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //EventHandler
  static void set_limits_1EventWrapper( void * pObject, _set_limits_EventArgument parameter ){ ((Option_Button_Config*)pObject)->set_limits_1Event( parameter ); };
  void set_limits_1Event( _set_limits_EventArgument p );
  static void set_plusminus_valuesEventWrapper( void * pObject, _string s ){ ((Option_Button_Config*)pObject)->set_plusminus_valueEvent( s ); };
  void set_plusminus_valueEvent( _string s );
  static void set_plusminus_valuefEventWrapper( void * pObject, float f ){ ((Option_Button_Config*)pObject)->set_plusminus_valueEvent( f ); };
  void set_plusminus_valueEvent( float f );
  static void set_static_1_valuesEventWrapper( void * pObject, _string s ){ ((Option_Button_Config*)pObject)->set_static_1_valueEvent( s ); };
  void set_static_1_valueEvent( _string s );
  static void set_static_1_valuefEventWrapper( void * pObject, float f ){ ((Option_Button_Config*)pObject)->set_static_1_valueEvent( f ); };
  void set_static_1_valueEvent( float f );
  static void set_static_2_valuesEventWrapper( void * pObject, _string s ){ ((Option_Button_Config*)pObject)->set_static_2_valueEvent( s ); };
  void set_static_2_valueEvent( _string s );
  static void set_static_2_valuefEventWrapper( void * pObject, float f ){ ((Option_Button_Config*)pObject)->set_static_2_valueEvent( f ); };
  void set_static_2_valueEvent( float f );
  static void set_mode_plusminusEventWrapper( void * pObject, bool b ){ ((Option_Button_Config*)pObject)->set_mode_plusminusEvent( b ); };
  void set_mode_plusminusEvent( bool b );
  static void set_mode_staticEventWrapper( void * pObject, bool b ){ ((Option_Button_Config*)pObject)->set_mode_staticEvent( b ); };
  void set_mode_staticEvent( bool b );
  // 13.07.2012 PM added Usersettings support
  void SetOptionButtonMode(BUTTON_CONFIG_OPTION_MODE mode);
  void SaveUserOptionButtonMode(void);
  
private:
  bool alignment; //false = horizontal, true = vertical

  int option_button_mode; //0->plusminus, 1->static
  bool option_button_mode_changed;
  float plus_minus[3]; //[1]->upper limit,[2]-> lower limit
  float static_1[3]; //[1]->upper limit,[2]-> lower limit
  float static_2[3]; //[1]->upper limit,[2]-> lower limit
  
  bool plus_minus_value_changed;
  bool static_1_changed;
  bool static_2_changed;
  
  char buffer[20];
  
};


class User_Config_2 : public CWindow
{
public:
  User_Config_2();
  ~User_Config_2();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //MB EventHandler
  static void user_config_page_2EventWrapper( void * pObject, bool b ){ ((User_Config_2*)pObject)->user_config_page_2Event( b ); };
  void user_config_page_2Event( bool b );
  static void config_window_activationEventWrapper( void * pObject,  _two_params<int,int> p ){ ((User_Config_2*)pObject)->config_window_activationEvent( p);};
  void config_window_activationEvent(  _two_params<int,int> p );
  static void new_dewpoint_offsettEventWrapper( void * pObject, float f ){ ((User_Config_2*)pObject)->new_dewpoint_offsettEvent( f );};
  void new_dewpoint_offsettEvent(float f);
// 10.02.2012 PM. Added an event for dewpoint activation and di-activation
  static void set_active_dewpointEventWrapper( void * pObject, bool b ){ ((User_Config_2*)pObject)->set_active_dewpointEvent( b );};
  void set_active_dewpointEvent(bool b);
// 19.2.2013 KM. Added event for input of new dewpoint offset via display
  static void inp_dewpoint_offsettEventWrapper( void * pObject, bool b ){ ((User_Config_2*)pObject)->inp_dewpoint_offsettEvent( b );};
  void inp_dewpoint_offsettEvent(bool b);
  
private:
  bool alignment; //false = horizontal, true = vertical
  char menu[5][7]; //user_config_menu Buttonleistenkonfiguration
  bool menu_changed;
  int xpos, ypos;
  bool m_newDewPointOffsett;   //Taupunktabstand hat sich ge�ndert
  float m_DewPointOffsett;     //Wert des Taupunktesabstands
  bool m_dewpointStatusChanged;
  bool m_dewpointStatus;
      
};

class User_Config_3 : public CWindow
{
public:
  User_Config_3();
  ~User_Config_3();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //MB EventHandler
  static void user_config_page_3EventWrapper( void * pObject, bool b ){ ((User_Config_3*)pObject)->user_config_page_3Event( b ); };
  void user_config_page_3Event( bool b );
  static void config_window_activationEventWrapper( void * pObject,  _two_params<int,int> p ){ ((User_Config_3*)pObject)->config_window_activationEvent( p);};
  void config_window_activationEvent(  _two_params<int,int> p );
  static void set_con_mode_standardEventWrapper( void * pObject, bool b ){ ((User_Config_3*)pObject)->set_con_mode_standardEvent( b );};
  void set_con_mode_standardEvent( bool b );
  static void set_con_mode_progressiveEventWrapper( void * pObject, bool b ){ ((User_Config_3*)pObject)->set_con_mode_progressiveEvent( b );};
  void set_con_mode_progressiveEvent( bool b );
  static void set_con_mode_lnoiseEventWrapper( void * pObject, bool b ){ ((User_Config_3*)pObject)->set_con_mode_lnoiseEvent( b );};
  void set_con_mode_lnoiseEvent( bool b );
  
private:
  bool alignment; //false = horizontal, true = vertical
  char menu[5][7]; //user_config_menu Buttonleistenkonfiguration
  bool menu_changed;
  int xpos, ypos;
  int TDC_mode;
  bool TDC_mode_changed;
};

class User_Config_4 : public CWindow
{
public:
  User_Config_4();
  ~User_Config_4();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //MB EventHandler
  static void user_config_page_4EventWrapper( void * pObject, bool b ){ ((User_Config_4*)pObject)->user_config_page_4Event( b ); };
  void user_config_page_4Event( bool b );
  static void config_window_activationEventWrapper( void * pObject,  _two_params<int,int> p ){ ((User_Config_4*)pObject)->config_window_activationEvent( p);};
  void config_window_activationEvent(  _two_params<int,int> p );
private:
  bool alignment; //false = horizontal, true = vertical
  char menu[5][7]; //user_config_menu Buttonleistenkonfiguration
  bool menu_changed;
  int xpos, ypos;
};

class User_Config_5 : public CWindow
{
public:
  User_Config_5();
  ~User_Config_5();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //MB EventHandler
  static void user_config_page_5EventWrapper( void * pObject, bool b ){ ((User_Config_5*)pObject)->user_config_page_5Event( b ); };
  void user_config_page_5Event( bool b );
  static void config_window_activationEventWrapper( void * pObject, _two_params<int,int> p ){ ((User_Config_5*)pObject)->config_window_activationEvent( p);};
  void config_window_activationEvent(  _two_params<int,int> p );
  static void receive_table1EventWrapper( void * pObject, void* p ){ ((User_Config_5*)pObject)->receive_table1Event( p);};
  void receive_table1Event( void* p );
  static void receive_table2EventWrapper( void * pObject, void* p ){ ((User_Config_5*)pObject)->receive_table2Event( p);};
  void receive_table2Event( void* p );
  static void receive_table3EventWrapper( void * pObject, void* p ){ ((User_Config_5*)pObject)->receive_table3Event( p);};
  void receive_table3Event( void* p );
  static void set_active_comp_tableEventWrapper( void * pObject, int i ){ ((User_Config_5*)pObject)->set_active_comp_tableEvent( i );};
  void set_active_comp_tableEvent( int i );
  static void activate_comp_table_butEventWrapper( void * pObject, bool b ){ ((User_Config_5*)pObject)->activate_comp_table_butEvent( b );};
  void activate_comp_table_butEvent( bool b );
  static void set_comp_temp_limitsEventWrapper( void * pObject, _set_limits_EventArgument l ){ ((User_Config_5*)pObject)->set_comp_temp_limitsEvent( l );};
  void set_comp_temp_limitsEvent( _set_limits_EventArgument l );
  static void set_norm_temp_limitsEventWrapper( void * pObject, _set_limits_EventArgument l ){ ((User_Config_5*)pObject)->set_norm_temp_limitsEvent( l );};
  void set_norm_temp_limitsEvent( _set_limits_EventArgument l );
  static void user_config_5_keyEventWrapper( void * pObject, _string s ){ ((User_Config_5*)pObject)->user_config_5_keyEvent( s );};
  static void up_button_pressedEventWrapper( void * pObject, bool b ){ ((User_Config_5*)pObject)->user_config_5_keyEvent( "user_config_table_go_up" );};  	 // Forward 'up'-button event to user_config_5_key
  static void down_button_pressedEventWrapper( void * pObject, bool b ){ ((User_Config_5*)pObject)->user_config_5_keyEvent( "user_config_table_go_down" );}; // Forward 'down'-button event to user_config_5_key
  void user_config_5_keyEvent( _string s );
  static void set_norm_tempEventWrapper( void * pObject, float f ){ ((User_Config_5*)pObject)->set_norm_tempEvent( f );};
  void set_norm_tempEvent( float f );
  static void set_comp_tempEventWrapper( void * pObject, float f ){ ((User_Config_5*)pObject)->set_comp_tempEvent( f );};
  void set_comp_tempEvent( float f );
  
  static void exit_button_pressedEventWrapper( void * pObject,  bool b ){ ((User_Config_5*)pObject)->exit_button_pressedEvent( b );};
  void exit_button_pressedEvent( bool b );


  
private:
  bool alignment; //false = horizontal, true = vertical
//  double T[2][3] = { {1,3,4},{7,8,9}};
  bool menu_changed;
  float table_1[2][20];
  float table_2[2][20];
  float table_3[2][20];
  int selected_line;
  int selected_table;
  bool table_changed;
  bool table_selection_changed;
  bool dirty_table;
  //vector<char>* v_buffer;
  char c_buffer[20];
  bool just_woke_up; //Zur kleinen Entlastung des Displays nach einem Switch.
  //Die darauf folgenden Tabellenwerte direkt nach dem Switch ueberlasten das Display,
  //manche Nachrichten werden verworfen
  
  float temp_lower_limit;
  float temp_upper_limit;
  
  float norm_temp_lower_limit;
  float norm_temp_upper_limit;
  
  char delete_lines[6];
  //Funktionen zur Tabellenmanipulation:
  int count_valid_lines(float table_1[]);
  void delete_line(float array_1[] ,float array_2[], int line_number);
  bool insert_line(float array_1[] ,float array_2[], int line_number);
  void clear_table(float array_1[] ,float array_2[], int line_number);
  int check_for_duplicate(float array_1[], float array_2[]);
  
  bool window_just_activated;
  
  int active_table;
  bool active_table_changed;
  
  bool duplicate;
  bool duplicate_changed;
  int line_of_duplicate;
  char menu[5][7]; //user_config_menu Buttonleistenkonfiguration
  int xpos, ypos;
};

class User_Config_PowerSense_1 : public CWindow
{
public:
  User_Config_PowerSense_1();
  ~User_Config_PowerSense_1();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //MB Event Handler
  static void user_config_power_senseEventWrapper( void * pObject, bool b ){ ((User_Config_PowerSense_1*)pObject)->user_config_power_senseEvent( b ); };
  void user_config_power_senseEvent( bool b );

private:
  bool alignment; //false = horizontal, true = vertical
};


//Eingangspunkt in die User Config,
//Hier wird kurz entschieden wohin der User weitergeleitet wird.
//Dies ist abh�ngig von der Kombination an aktiven Fenstern, da dass
//im Unteren Bereich angezeigte user-config-menu in seinem aufbau
//dynamisch ist. Sollte kein Fenster zugaenglich sein wird der User auf ein
//Fenster mit einer entsprechenden Meldung weitergeleitet.
class User_Config_entry : public CWindow
{
public:
  User_Config_entry();
  ~User_Config_entry();
  void Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment);
  void cycCalc();
  //MB EventHandler
  static void config_window_activationEventWrapper( void * pObject,  _two_params<int,int> p ){ ((User_Config_entry*)pObject)->config_window_activationEvent( p);};
  void config_window_activationEvent(  _two_params<int,int> p );
private:
  char menu[5][7]; //user_config_menu Buttonleistenkonfiguration
  bool at_least_one_active_window_exists;
  bool hold_mode;
//  bool menu_changed;
  int first_available_window;
  bool menu_changed;
};


#endif // !defined(CWINDOW_H__INCLUDED_)