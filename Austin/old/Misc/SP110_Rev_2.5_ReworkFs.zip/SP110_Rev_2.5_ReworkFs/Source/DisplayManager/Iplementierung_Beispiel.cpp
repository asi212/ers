

//Includes:
#include "..\system_wide_defs.h"
#include "..\MailboxSystem\CPostman.h"
#include "..\MailboxSystem\CMailbox.h"


//Anzulegende Objekte:
  CMailbox systemmailbox;
  CMailbox* p_systemmailbox;
  string name;
  
//Vorzunehmende Initialisierungen:
  
  
  postman.addMailbox(&systemmailbox);
  systemmailbox.set_name("system_mbox");
  systemmailbox.Init(16);
  name = "system";
  p_systemmailbox = &systemmailbox;
  //Beispiele fuer die Nutzung:
  //Senden von Nachrichten:

//--------------------------------------------------------------
// Optionbuttons
//--------------------------------------------------------------  
// Nach einem Reset sollte der gew�nschte Modus und die entsprechenden
// Werte dem Optionbuttonfenster gesendet werden.
// (ggf. gespeicherte Werte aus einer Setupdatei?)
// Beim setzen neuer Werte und Modi werden diese dem system zum
// ggf. speichern mitgeteilt.

  //Setzen des Modi der Optionbuttons:
  p2_msg = p_systemmailbox->take_free_msg();
  if(p2_msg != NULL)
  {
    p2_msg->cmd1 = "set_mode_plusminus"; //inkrement-dekrement-Modus aktivieren
    //p2_msg->cmd1 = "set_mode_static"; //Feste-Werte-Modus aktivieren
    p2_msg->origin = name;
    p2_msg->dest = "opt_button_conf";
  }
  
  //Setzen des Modi der Optionbuttons:
  p2_msg = p_systemmailbox->take_free_msg();
  if(p2_msg != NULL)
  {
    p2_msg->cmd1 = "set_plusminus_value"; //inkrement-dekrement-Wert
    //p2_msg->cmd1 = "set_static_1_value"; //Wert des Ersten Buttons (links) bei Festwert-Modus
    //p2_msg->cmd1 = "set_static_2_value"; //Wert des Ersten Buttons (links) bei Festwert-Modus
    p2_msg->origin = name;
    p2_msg->dest = "opt_button_conf";
    p2_msg->f_number[0] = ???;
  }
//--------------------------------------------------------------  

  
//--------------------------------------------------------------
// Netzwerkkonfigurationsfenster
//--------------------------------------------------------------
  //Vorzubereitende Daten:
  unsigned char network[3][4]; //derzeitige aktive Konfiguration
  unsigned char default_network[3][4]; //Konfiguration im Auslieferungszustand (Defaultwerte)
  
  //Beispielbelegung von 'network':
  //    0     1        2        3     2    1    0
  // [ IP / Mask / Gateway ] [ 192 / 168 / 1 / 183]
  // IP
  network[0][3] = 192;
  network[0][2] = 168;
  network[0][1] = 1;
  network[0][0] = 183;

  // Mask
  network[1][3] = 255;
  network[1][2] = 255;
  network[1][1] = 255;
  network[1][0] = 0;
  
  // Gateway
  network[2][3] = 192;
  network[2][2] = 168;
  network[2][1] = 1;
  network[2][0] = 99;
  
  //Nach dem Booten des Ger�tes soll dem Netzwerkonfigurationsfenster
  //die aktuelle Konfiguration zugesendet werden damit diese auch
  //gleich angezeigt werden kann.
  
  
  
  
  
  
//--------------------------------------------------------------
  //Setzen des Aktuellen Modi der Temeprature Dynamic Control in der User Config:
  p2_msg = p_systemmailbox->take_free_msg();
  if(p2_msg != NULL)
  {
    p2_msg->cmd1 = "set_con_mode_standard";
  //p2_msg->cmd1 = "set_con_mode_progressive";
  //p2_msg->cmd1 = "set_con_mode_lnoise";
    p2_msg->origin = name;
    p2_msg->dest = "user_config_3";
  }
//--------------------------------------------------------------
  //Anpassung des User-Config-Menues durch Ein- und Ausblenden von Menuebuttons:
  p2_msg = p_systemmailbox->take_free_msg();
  if(p2_msg != NULL)
  {
    p2_msg->cmd1 = "config_window_activation";
    p2_msg->origin = name;
    p2_msg->dest = "user_config_entry";
    //Auswahl des zu aktivieren/deaktivierenden Menueintrags:
    p2_msg->i_number[0] = 0; //User-Config 1: Hold/Standby
    p2_msg->i_number[0] = 1; //User-Config 2: Close Loop Dew Point Control System
  //p2_msg->i_number[0] = 2; //User-Config 3: Temperature Dynamic Control
  //p2_msg->i_number[0] = 3; //User-Config 4: System Check Control
  //p2_msg->i_number[0] = 4; //User-Config 5: Temperature Compensation Table
    
    p2_msg->i_number[1] = 1; //Aktivieren des Menueeintrages
  //p2_msg->i_number[1] = 0; //Deaktivieren des Menueeintrages
  }
//--------------------------------------------------------------
  //Am Display im user-Config-Hold-Standby-Fenster den den Hold mode als aktiv/inaktiv anzeigen lassen:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "set_hold_mode";
  p2_msg->cmd2 == "ON"
//p2_msg->cmd2 == "OFF"
  p2_msg->origin = name;
  p2_msg->dest = "user_config_1";
}
//--------------------------------------------------------------
  //Am Display im user-Config-Hold-Standby-Fenster den den Standby mode als aktiv/inaktiv anzeigen lassen:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "set_standby_mode";
  p2_msg->cmd2 == "ON"
//p2_msg->cmd2 == "OFF"
  p2_msg->origin = name;
  p2_msg->dest = "user_config_1";
}
//--------------------------------------------------------------
  //�ndern des Kompensationslimits f�r die Kompensationstabelle (default ist: +-20.00)
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "set_comp_temp_limits";
  p2_msg->f_number[0] = ???; //upper limit (default +20.00)
  p2_msg->f_number[1] = ???; //lower limit (default -20.00)
  p2_msg->origin = name;
  p2_msg->dest = "user_config_5";
}
//--------------------------------------------------------------
  //�ndern der aktuellen Kompensierten Temperatur 1,2,3 oder 4
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "temp_1_comp";
//p2_msg->cmd1 = "temp_2_comp";
//p2_msg->cmd1 = "temp_3_comp";
//p2_msg->cmd1 = "temp_4_comp";
  p2_msg->f_number[0] = 101.44; //aktuelle kompensierte Temperatur, 'float' wird erwartet
  p2_msg->origin = name;
  p2_msg->dest = "mainmenu";
}
//--------------------------------------------------------------
  // Einen neuen Temperatursensor Wert (der 16 Sensoren) Uebertragen:
  p2_msg = p_systemmailbox->take_free_msg();
  if(p2_msg != NULL)
  {
    p2_msg->cmd1 = "temp_sensor";
    p2_msg->i_number[0] = 5; //Nummer des Temperatursensors 0 bis 7 !!!
    p2_msg->f_number[0] = 180.45; //Temperaturwert
    p2_msg->origin = name;
    p2_msg->dest = "diagnose_4"; //Temperatursensoren Nummer 1 bis 8
    p2_msg->dest = "diagnose_5"; //Temperatursensoren Nummer 9 bis 16
  }
  
//--------------------------------------------------------------
// In der User Configuration Seite 5 die derzeit aktive
// Temperaturkompensationstabelle festlegen.
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "set_active_comp_table";
  p2_msg->i_number[0] = 0; //Derzeit keine Kompensation aktiv (Default-Wert nach Reboot)
//p2_msg->i_number[0] = 1; //Kompensationstabelle 1 aktiv 
//p2_msg->i_number[0] = 2; //Kompensationstabelle 2 aktiv
//p2_msg->i_number[0] = 3; //Kompensationstabelle 3 aktiv
  p2_msg->origin = name;
  p2_msg->dest = "user_config_5";
}
//--------------------------------------------------------------
  // Dem Diagnose 3 Fenster eine neue Chillertemperatur uebertragen:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "set_chiller_temp";
  p2_msg->f_number[0] = float ???; 
//p2_msg->f_number[0] = 22222.0; ->  es wird ein "X" angezeigt.
  p2_msg->origin = name;
  p2_msg->dest = "diagnose_3";
}
//--------------------------------------------------------------
// Versenden einer Temperatur-Kompensationstabelle an das Display
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "receive_table";
  p2_msg->origin = name;
  p2_msg->dest = "user_config_5";
  p2_msg->i_number[0] = 1; //Number of the table (1,2 or 3)
//  p2_msg->i_number[0] = 2; //Number of the table (1,2 or 3)
//  p2_msg->i_number[0] = 3; //Number of the table (1,2 or 3)
  p2_msg->data = &table_1;
//  p2_msg->data = &table_2;
//  p2_msg->data = &table_3;
}
//--------------------------------------------------------------
// Eine neue Set-Spannung der Stromversorgungen anzeigen:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "set_power_suppply_1_set_voltage";
  p2_msg->i_number[0] = int ???; 
//p2_msg->i_number[0] = 22222; ->  es wird ein "-" angezeigt.
//(steht f�r 'ungueltiger Wert'. set-Werte k�nnen bei einer
// solchen Markierung nicht vom User �ber
// das Display per Keyboard ge�ndert werden.)
  p2_msg->origin = name;
  p2_msg->dest = "diagnose_3";
}

//--------------------------------------------------------------
// Eine neue gemessene Spannung der Stromversorgungen anzeigen:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "power_suppply_1_voltage";
  p2_msg->i_number[0] = int ???; 
//p2_msg->i_number[0] = 22222; ->  es wird ein "-" angezeigt.
//(steht f�r 'ungueltiger Wert'. set-Werte k�nnen bei einer
// solchen Markierung nicht vom User �ber
// das Display per Keyboard ge�ndert werden.)
  p2_msg->origin = name;
  p2_msg->dest = "diagnose_3";
}

//--------------------------------------------------------------
// Einen neuen Stromwert der Stromversorgungen anzeigen:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "power_suppply_1_current";
//p2_msg->cmd1 = "power_suppply_2_current";
//p2_msg->cmd1 = "power_suppply_3_current";
//p2_msg->cmd1 = "power_suppply_4_current";
  p2_msg->f_number[0] = int ???; 
//p2_msg->f_number[0] = 22222.0; ->  es wird ein "-" angezeigt.
//(steht f�r 'ungueltiger Wert'. set-Werte k�nnen bei einer
// solchen Markierung nicht vom User �ber
// das Display per Keyboard ge�ndert werden.)
  p2_msg->origin = name;
  p2_msg->dest = "diagnose_3";
}

//--------------------------------------------------------------
//Setzen der Set-Temperature 1,2,3 oder 4:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "set_temp_1";
//p2_msg->cmd1 = "set_temp_2";
//p2_msg->cmd1 = "set_temp_3";
//p2_msg->cmd1 = "set_temp_4";
  p2_msg->f_number[0] = 16.10; //Statt der 16.10 hier den gewuenschten set-Wert eintragen
                               // (Es wird double erwartet)
  p2_msg->origin = name;
  p2_msg->dest = "mainmenu";
}

//--------------------------------------------------------------
//Setzen des oberen und des unteren Limits der Set-Temperature 1,2,3 oder 4:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "set_limits_1";
//p2_msg->cmd1 = "set_limits_2";
//p2_msg->cmd1 = "set_limits_3";
//p2_msg->cmd1 = "set_limits_4";
  p2_msg->f_number[0] = 350.00; //upper limit, 'double' wird erwartet
  p2_msg->f_number[1] = -45.00; //lower limit, 'double' wird erwartet
  p2_msg->origin = name;
  p2_msg->dest = "mainmenu";
}

//--------------------------------------------------------------
//�ndern des "Chiller-Status"
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "chiller_status";
  p2_msg->cmd2 = "Controlling"; //<-- Hier beliebigen Text eintragen,
                                //wird direkt so angezeigt
  p2_msg->origin = name;
  p2_msg->dest = "mainmenu";
}

//--------------------------------------------------------------
//�ndern der aktuellen Temperatur 1,2,3 oder 4
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "temp_1";
//p2_msg->cmd1 = "temp_2";
//p2_msg->cmd1 = "temp_3";
//p2_msg->cmd1 = "temp_4";
  p2_msg->f_number[0] = 101.44; //aktuelle Temperatur, 'double' wird erwartet
  p2_msg->origin = name;
  p2_msg->dest = "mainmenu";
}
//--------------------------------------------------------------
// �ndern der Statussymbole (pfeil nach oben, unten gleich) fuer
// Temperatur 1,2,3 oder 4
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "status_temp_1";
//p2_msg->cmd1 = "status_temp_2";
//p2_msg->cmd1 = "status_temp_3";
//p2_msg->cmd1 = "status_temp_4";
  
  p2_msg->cmd2 = "heating"; //Pfeil nach oben
//p2_msg->cmd2 = "cooling"; //Pfeil nach unten
//p2_msg->cmd2 = "even"; //Gleichheitszeichen
//p2_msg->cmd2 = "blank"; //leerer Kasten

  p2_msg->origin = name;
  p2_msg->dest = "mainmenu";
}

//--------------------------------------------------------------
// �ndern des Ciller-Statussymbols (rotes, geschlossenes Schloss (locked)
//                             oder gruenes, offenes Schloss (open))
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "chiller_status_symbol";
  p2_msg->cmd2 = "locked";
//p2_msg->cmd2 = "open";
  p2_msg->origin = name;
  p2_msg->dest = "mainmenu";
}

//--------------------------------------------------------------
// Bypass-valve-status-Anzeige beim diagnose-2 Fenster Aendern:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "bypass_valve_on"; //ON anzeigen
  //p2_msg->cmd1 = "bypass_valve_off"; //OFF anzeigen
  p2_msg->origin = name;
  p2_msg->dest = "diagnose_2";
}
//==============================================================================
// Set flow value (Diagnose page 2):
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "set_cool_air_actual_flow";
  //p2_msg->cmd1 = "set_warm_air_actual_flow";
  //p2_msg->cmd1 = "set_bypass_valve_actual_flow";
  //p2_msg->cmd1 = "set_main_valve_actual_flow";
  p2_msg->i_number[0] = 113; //New Value
  p2_msg->origin = name;
  p2_msg->dest = "diagnose_2";
}
//--------------------------------------------------------------
// Eine Hinweismeldung im Hauptmenu droppen
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "drop_infomessage";
  p2_msg->cmd2 = "   No chucks found!##Please go to the next#supermarket an buy#some!";
  p2_msg->origin = name;
  p2_msg->dest = "error_handler";
}
//--------------------------------------------------------------
// Eine einfache Fehlermeldung droppen
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "drop_errormessage";
  p2_msg->cmd2 = "  There is a rabidly# beaver in the casing.##      Please remove#            beaver!";
  p2_msg->origin = name;
  p2_msg->dest = "error_handler";
}
//--------------------------------------------------------------
// Eine einfache Fehlermeldung aufheben (Fehlerursache wurde beseitigt)
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "remove_errormessage";
  p2_msg->origin = name;
  p2_msg->dest = "error_handler";
}
//--------------------------------------------------------------
// Eine schwere Fehlermeldung droppen
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "drop_fatalerrormessage"; //ON anzeigen
  p2_msg->cmd2 = "The system became#self-aware and wants#to get rid of mankind.##   Please reboot the#     whole system!";
  p2_msg->origin = name;
  p2_msg->dest = "error_handler";
}
//==============================================================================
// Eine Temperatur im Mainmenu fuer ungueltig erklaeren:
// (Es wird "--.--" in den jeweiligen Feldern angezeigt)
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "invalid_temp";
  p2_msg->i_number[0] = 1; //Temp. 1 ungeultig
//p2_msg->i_number[0] = 2; //Temp. 2 ungeultig
//p2_msg->i_number[0] = 3; //Temp. 3 ungeultig
//p2_msg->i_number[0] = 4; //Temp. 4 ungeultig
  p2_msg->origin = name;
  p2_msg->dest = "mainmenu";
}


//==============================================================================
// Die Versionsnummer usw. auf dem Hauptmenue setzen (Darstellung erfolgt dann automatisch):
//(Sollte noch keine Version gesendet sein befindet sich an der betreffenden Stelle nichts)
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "set_version_info";
  p2_msg->cmd2 = "Chiller version 1.027 23.02.2011    "; //(<-- ca. 30 Zeichen, je nach Anzahl schmaler Zeichen wie Punkte und 1er)
  p2_msg->origin = name;                                 //(Zusaetzliche Leerzeichen am Ende einfuegen, falls mehrfach ueberschrieben wird!)
  p2_msg->dest = "mainmenu";
}
//==============================================================================

// Eine neue Chiller Temperatur �bertragen:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "set_chiller_temperature";
  p2_msg->f_number[0] = double ???;
  p2_msg->origin = name;
  p2_msg->dest = "diagnose_1";
}
//==============================================================================
// Chiller-Kommunikations-symbol an/aus
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "chiller_comm_symbol";
  p2_msg->cmd2 = "ON";
//  p2_msg->cmd2 = "OFF";
  p2_msg->origin = name;
  p2_msg->dest = "mainmenu";
}
//==============================================================================

//Empfangen von Nachrichten:

p_msg = p_displaymailbox->grab_msg(name);
if (p_msg != NULL)
{
  if (p_msg->cmd1 == "trash") //zurueckerhaltene Nachricht recyceln
  {
    p_msg->dest = p_displaymailbox->name;
  }
  else if(p_msg->cmd1 == "set_temp_1_changed")
  {
    ????? = p2_msg->f_number[0]; //Neue set-Temp 1 irgendwo speichern
  }
  else if(p_msg->cmd1 == "set_temp_2_changed")
  {
    ????? = p2_msg->f_number[0]; //Neue set-Temp 2 irgendwo speichern
  }
  else if(p_msg->cmd1 == "set_temp_3_changed")
  {
    ????? = p2_msg->f_number[0]; //Neue set-Temp 3 irgendwo speichern
  }
  else if(p_msg->cmd1 == "set_temp_4_changed")
  {
    ????? = p2_msg->f_number[0]; //Neue set-Temp 4 irgendwo speichern
  }
  else if(p_msg->cmd1 == "compressor_status") //Es wurde eine Anfrage fuer einen neuen Kompressor-status gesendet
  {
    ???? = p_msg->cmd2; //Derzeit "ON" oder "OFF"
  }
  else if(p_msg->cmd1 == "bypass_valve_on_off") //Der Bypass-Valve-Status moechte vom User getoggelt werden
  {

  }
  else if (p_msg->cmd1 == "receive_table")
  { //Empfange neue Tabellenwerte
    //float table_1[2][20];
    //float table_2[2][20];
    //float table_3[2][20];
    float *p_table[2];
    p_table[0] = p_msg->data;
    p_table[1] = ((float*)p_msg->data)+20;
    if (p_msg->i_number[0] == 1) for (int i=0; i<2;i++) for (int k=0; k<20; k++) table_1[i][k] = *(p_table[i] + k); //Tabelle 1
    else if (p_msg->i_number[0] == 2) for (int i=0; i<2;i++) for (int k=0; k<20; k++) table_2[i][k] = *(p_table[i] + k); //Tabelle 2
    else for (int i=0; i<2;i++) for (int k=0; k<20; k++) table_3[i][k] = *(p_table[i] + k); //Tabelle 3
  }
  else if (p_msg->cmd1 == "set_active_comp_table")
  { //Der User fordert ein Wechseln der aktiven Kompensationstabelle an
    ???? = p_msg->i_number[0]; //0=keine aktiv, 1,2,3= jeweilige Tabelle aktiv
  }
  else if (p_msg->cmd1 == "get_comp_table")
  { //Das Display moechte eine Tabelle zugeschickt bekommen
    ???? = p_msg->i_number[0]; //Die Nummer der angeforderten Tabelle. Kann 1,2 oder 3 sein
  }
  else if (p_msg->cmd1 == "get_all_comp_tables")
  { //Das Display moechte jeweils alle tabellen zugeschickt bekommen
    
  }
  else if (p_msg->cmd1 == "set_hold_mode")
  {
    if (p_msg->cmd2 == "ON") ????; //Der User moechte den Hold-Mode aktivieren
    else if (p_msg->cmd2 == "OFF") ????; //Der User moechte den Hold-Mode deaktivieren
  }
  else if (p_msg->cmd1 == "set_standby_mode")
  {
    if (p_msg->cmd2 == "ON") ????;//Der User moechte den Standby-Mode aktivieren
    else if (p_msg->cmd2 == "OFF") standby_mode = ????;//Der User moechte den Standby-Mode deaktivieren
  }
  else if(p_msg->cmd1 == "request_network_config")
  { //Aufforderung des Netzwerkkonfigurationsfensters, ihm
    // die derzeitige Netzwerkkonfiguration zu schicken
    p2_msg = p_systemmailbox->take_free_msg();
    if(p2_msg != NULL)
    {
      p2_msg->cmd1 = "set_network_config";
      p2_msg->origin = name;
      p2_msg->dest = "network_config_1";
      p2_msg->data = &network;
    }
        
    p2_msg = p_systemmailbox->take_free_msg();
    if(p2_msg != NULL)
    {
      p2_msg->cmd1 = "set_network_mac";
      p2_msg->origin = name;
      p2_msg->dest = "network_config_1";
      p2_msg->cmd2 = "F0:4D:A2:9B:E5:8A"; //Die anzuzeigende Netzwerkadresse, es kann ein beliebiger string sein,
                                          //denn er wird direkt angezeigt und nicht weiter verarbeitet.
    }
  }
  else if(p_msg->cmd1 == "request_default_network")
  { //Aufforderung des Netzwerkkonfigurationsfensters, ihm
    //die Standard-Netzwerkinformation zuzuschicken.
    //(Die Netzwerkeinstellungen eines neu augelieferten Ger�tes)
    p2_msg = p_systemmailbox->take_free_msg();
    if(p2_msg != NULL)
    {
      p2_msg->cmd1 = "set_network_config";
      p2_msg->origin = name;
      p2_msg->dest = "network_config_1";
      p2_msg->data = &default_network;
    }
        
    p2_msg = p_systemmailbox->take_free_msg();
    if(p2_msg != NULL)
    {
      p2_msg->cmd1 = "set_network_mac";
      p2_msg->origin = name;
      p2_msg->dest = "network_config_1";
      p2_msg->cmd2 = "F0:4D:A2:9B:E5:8A";
    }
  }
  else if(p_msg->cmd1 == "save_network_config") //Es wird eine aktuellere, vom Benutzer erstellte, Netzwerkadressenkonfiguration empfangen
  {
    unsigned char* p_ext_network[3];
    p_ext_network[0] = (unsigned char*)p_msg->data;
    p_ext_network[1] = ((unsigned char*)p_msg->data)+4;
    p_ext_network[2] = ((unsigned char*)p_msg->data)+8;
    //IP
    network[0][0] = *(p_ext_network[0]+0);
    network[0][1] = *(p_ext_network[0]+1);
    network[0][2] = *(p_ext_network[0]+2);
    network[0][3] = *(p_ext_network[0]+3);
    //MAC
    network[1][0] = *(p_ext_network[1]+0);
    network[1][1] = *(p_ext_network[1]+1);
    network[1][2] = *(p_ext_network[1]+2);
    network[1][3] = *(p_ext_network[1]+3);
    //Gateway
    network[2][0] = *(p_ext_network[2]+0);
    network[2][1] = *(p_ext_network[2]+1);
    network[2][2] = *(p_ext_network[2]+2);
    network[2][3] = *(p_ext_network[2]+3);
  }
  else if (p_msg->cmd1 == "set_option_mode") //Optionbuttons, ein Modus wurde durch Nutzer eingestellt.
  {
    // 0 entspricht inkrement-dekrement-Modus
    // 1 entspricht Festwertemodus
    ??? = p_msg->i_number[0];
  }
  else if (p_msg->cmd1 == "set_plusminus_value") //Neuer Inkrement-Dekrementwert des Optionbuttons durch Nutzer eingestellt
  {
    ??? = p_msg->f_number[0];
  }
  else if (p_msg->cmd1 == "set_static_1_value") //Neuer set-Wert des Optionbuttons Nr. 1 durch Nutzer eingestellt
  {
    ??? = p_msg->f_number[0];
  }
  else if (p_msg->cmd1 == "set_static_2_value") //Neuer set-Wert des Optionbuttons Nr. 1 durch Nutzer eingestellt
  {
    ??? = p_msg->f_number[0];
  }
    p_displaymailbox->trashmark(p_msg); //Unbekannte Nachricht als empfangen zurueckschicken...
}



