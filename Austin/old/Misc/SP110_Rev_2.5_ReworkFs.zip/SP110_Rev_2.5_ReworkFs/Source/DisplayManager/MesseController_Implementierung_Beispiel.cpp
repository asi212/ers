
//#############################################################################
//#############################################################################
// Folgende Befehle haben sich gegen�ber dem Chiller-Befehlssatz ge�ndert
// oder sind hinzugekommen. �nderungen sind an der entsprechenden Stelle
// mit #changed# markiert, neue Befehle mit #new#
//#############################################################################
//#############################################################################



// #new# Neue Grenzwerte f�r die Spannungsversorgungen �bertragen:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "set_power_supply_1_voltage_limits";
//p2_msg->cmd1 = "set_power_supply_2_voltage_limits";
  p2_msg->i_number[1] = int ???; //upper limit
  p2_msg->i_number[2] = int ???; //lower limit
  p2_msg->origin = name;
  p2_msg->dest = "diagnose_2";
}

//--------------------------------------------------------------
// #new# Eine neue Set-Spannung der Stromversorgungen anzeigen:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "set_power_suppply_1_set_voltage";
//p2_msg->cmd1 = "set_power_suppply_2_set_voltage";
  p2_msg->i_number[0] = int ???; 
//p2_msg->i_number[0] = 22222; ->  es wird ein "-" angezeigt.
//(steht f�r 'ungueltiger Wert'. set-Werte k�nnen bei einer
// solchen Markierung nicht vom User �ber
// das Display per Keyboard ge�ndert werden.)
  p2_msg->origin = name;
  p2_msg->dest = "diagnose_2";
}

//--------------------------------------------------------------
// #new# Eine neue gemessene Spannung der Stromversorgungen anzeigen:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "power_suppply_1_voltage";
//p2_msg->cmd1 = "power_suppply_2_voltage";
  p2_msg->i_number[0] = int ???; 
//p2_msg->i_number[0] = 22222; ->  es wird ein "-" angezeigt.
//(steht f�r 'ungueltiger Wert'. set-Werte k�nnen bei einer
// solchen Markierung nicht vom User �ber
// das Display per Keyboard ge�ndert werden.)
  p2_msg->origin = name;
  p2_msg->dest = "diagnose_2";
}

//--------------------------------------------------------------
// #new# Einen neuen Stromwert der Stromversorgungen anzeigen:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "power_suppply_1_current";
//p2_msg->cmd1 = "power_suppply_2_current";
  p2_msg->f_number[0] = int ???; 
//p2_msg->f_number[0] = 22222.0; ->  es wird ein "-" angezeigt.
//(steht f�r 'ungueltiger Wert'. set-Werte k�nnen bei einer
// solchen Markierung nicht vom User �ber
// das Display per Keyboard ge�ndert werden.)
  p2_msg->origin = name;
  p2_msg->dest = "diagnose_2";
}



//--------------------------------------------------------------
// Bypass-valve-status-Anzeige beim diagnose-3 Fenster Aendern:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "bypass_valve_on"; //ON anzeigen
  //p2_msg->cmd1 = "bypass_valve_off"; //OFF anzeigen
  p2_msg->origin = name;
  p2_msg->dest = "diagnose_3"; //#changed# _3 statt _2
}

//--------------------------------------------------------------
// #new# (Dieser Befehl war noch nicht dokumentiert)
// Main-valve-status-Anzeige beim diagnose-3 Fenster Aendern:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "main_valve_on"; //ON anzeigen
  //p2_msg->cmd1 = "main_valve_off"; //OFF anzeigen
  p2_msg->origin = name;
  p2_msg->dest = "diagnose_3"; //#changed# _3 statt _2
}
//==============================================================================
// Set flow value (Diagnose page 3):
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "set_cool_air_actual_flow";
  //p2_msg->cmd1 = "set_warm_air_actual_flow";
  //p2_msg->cmd1 = "set_bypass_valve_actual_flow";
  //p2_msg->cmd1 = "set_main_valve_actual_flow";
  p2_msg->i_number[0] = 113; //New Value
//p2_msg->i_number[0] = 22222; ->  es wird ein "-" angezeigt.
//(steht f�r 'ungueltiger Wert'. set-Werte k�nnen bei einer
// solchen Markierung nicht vom User �ber
// das Display per Keyboard ge�ndert werden.)
  p2_msg->origin = name;
  p2_msg->dest = "diagnose_3"; //#changed# _3 statt _2
}
//==============================================================================
// #new# (Dieser Befehl war noch nicht dokumentiert)
// Compressor-Status-Anzeigetext �ndern
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "compressor_status";
  p2_msg->cmd2 = "ON";
//  p2_msg->cmd2 = "OFF"; //Es ist z.B. auch "--" m�glich
  p2_msg->origin = name;
  p2_msg->dest = "diagnose_3"; //#changed# _3 statt _2
}

//#############################################################################
//#############################################################################
//Folgende Befehle haben sich gegen�ber dem Chiller-Befehlssatz nicht ge�ndert:
//#############################################################################
//#############################################################################
//--------------------------------------------------------------
//Setzen der Set-Temperature 1,2,3 oder 4:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "set_temp_1";
//p2_msg->cmd1 = "set_temp_2";
//p2_msg->cmd1 = "set_temp_3";
//p2_msg->cmd1 = "set_temp_4";
  p2_msg->f_number[0] = 16.10; //Statt der 16.10 hier den gewuenschten set-Wert eintragen
                               // (Es wird double erwartet)
  p2_msg->origin = name;
  p2_msg->dest = "mainmenu";
}

//--------------------------------------------------------------
//Setzen des oberen und des unteren Limits der Set-Temperature 1,2,3 oder 4:
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "set_limits_1";
//p2_msg->cmd1 = "set_limits_2";
//p2_msg->cmd1 = "set_limits_3";
//p2_msg->cmd1 = "set_limits_4";
  p2_msg->f_number[0] = 350.00; //upper limit, 'double' wird erwartet
  p2_msg->f_number[1] = -45.00; //lower limit, 'double' wird erwartet
  p2_msg->origin = name;
  p2_msg->dest = "mainmenu";
}

//--------------------------------------------------------------
//�ndern des "Chiller-Status"
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "chiller_status";
  p2_msg->cmd2 = "Controlling"; //<-- Hier beliebigen Text eintragen,
                                //wird direkt so angezeigt
  p2_msg->origin = name;
  p2_msg->dest = "mainmenu";
}

//--------------------------------------------------------------
//�ndern der aktuellen Temperatur 1,2,3 oder 4
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "temp_1";
//p2_msg->cmd1 = "temp_2";
//p2_msg->cmd1 = "temp_3";
//p2_msg->cmd1 = "temp_4";
  p2_msg->f_number[0] = 101.44; //aktuelle Temperatur, 'double' wird erwartet
  p2_msg->origin = name;
  p2_msg->dest = "mainmenu";
}

//--------------------------------------------------------------
// �ndern der Statussymbole (pfeil nach oben, unten gleich) fuer
// Temperatur 1,2,3 oder 4
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "status_temp_1";
//p2_msg->cmd1 = "status_temp_2";
//p2_msg->cmd1 = "status_temp_3";
//p2_msg->cmd1 = "status_temp_4";
  
  p2_msg->cmd1 = "heating"; //Pfeil nach oben
//p2_msg->cmd1 = "cooling"; //Pfeil nach unten
//p2_msg->cmd1 = "even"; //Gleichheitszeichen
//p2_msg->cmd1 = "blank"; //leerer Kasten
//p2_msg->cmd1 = "delta"; //Blinkendes Gleichheitszeichen

  p2_msg->origin = name;
  p2_msg->dest = "mainmenu";
}

//==============================================================================
// Eine Temperatur im Mainmenu fuer ungueltig erklaeren:
// (Es wird "--.--" in den jeweiligen Feldern angezeigt)
p2_msg = p_systemmailbox->take_free_msg();
if(p2_msg != NULL)
{
  p2_msg->cmd1 = "invalid_temp";
  p2_msg->i_number[0] = 1; //Temp. 1 ungeultig
//p2_msg->i_number[0] = 2; //Temp. 2 ungeultig
//p2_msg->i_number[0] = 3; //Temp. 3 ungeultig
//p2_msg->i_number[0] = 4; //Temp. 4 ungeultig
  p2_msg->origin = name;
  p2_msg->dest = "mainmenu";
}


//##############################################################################
//Neue Nachrichten die system erreichen k�nnen:
      else if(p_msg->cmd1 == "set_power_suppply_1_set_voltage")
      {
        //????? = p_msg->i_number[0]; //Neue Spannung irgendwo speichern
      }
      else if(p_msg->cmd1 == "set_power_suppply_2_set_voltage")
      {
        //????? = p_msg->i_number[0]; //Neue Spannung irgendwo speichern
      }
      else if(p_msg->cmd1 == "user_entered_diag")
      {//Benutzer ist in die Diagnoser-Fenster eingetreten
        
      }
      else if(p_msg->cmd1 == "user_left_diag")
      {//Benutzer hat die Diagnoser-Fenster verlassen
        
      }
