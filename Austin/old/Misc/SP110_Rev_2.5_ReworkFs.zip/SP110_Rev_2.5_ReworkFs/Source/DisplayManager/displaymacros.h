//******************
// Display Macros
//
// DESCRIPTION:
//  Lists the Macros defined in the constants_Controller.kmi file of the display macro programming language
//
//  To update this file, just:
//    1) Copy Macros from kmi-File to this file
//    2) Search replace 'Mn' by '#define Mn' 
//    3) Search replace '=' by ' '
//    4) Search replace ';' by '//'
//
// Use only these defines within the code, not any explicit Macro numbers!
//
// CREATED: 26.09.2012, by KM
//
// FILE: displaymacros.h
//


// The STR macro calls the STR_EXPAND macro with its argument. The parameter is checked for macro expansions 
// and evaluated by the preprocessor before being passed to STR_EXPAND which quotes it
// e.g. STR(MnAutoStart) results in a quoted 0: "0"
#define STR_EXPAND(tok) #tok
#define STR(tok) STR_EXPAND(tok)

// This Macro can be used to compose the command to be forwared to display
// cmd  : any string variable to store the command
// macro: one of the below defines
// e.g. MACRO_TO_CMD(s_cmd, MnAutoStart) corresponds to s_cmd = "#MN0,"
#define MACRO_TO_CMD(cmd,macro) 			\
		cmd  = "#MN"; 		 			          \
		cmd += STR(macro);	    					\
		cmd += ",";


////////////////////////////////////////////////////////////////////////
// The Macro List
///////////////////////////////////////////////////////////////////////


#define MnAutoStart     		        0
#define MnInitWindow    		        1
#define MnInitMainFrame 		        2
#define MnInitLogo      		        3
#define MnInitKeyboard		          4
#define MnInitInnerFrame						5
#define MnInitTouchFrame						6
#define MnMainMenueins		          11
#define MnMainMenuzwei		          12
#define MnMainMenudrei		          13
#define MnMainMenuvier		          14
#define MnKeyboardNumeric		        21
#define MnkeyboardAlphaNumeric	    22
#define MnDiagnostics			          23
#define MnStatusTemperatures		    24
#define MnDiagnoseView		          25
#define MnConfigView			          26
#define MnShowFileSystem 		        27
#define MnConfigWindow 		          28
#define MnSwitchView 			          29
#define MnPinRequest 			          30
#define MnClearPinInputField 	      32
#define MnControllerOverview 	      31
#define MnClearWrongCode 		        33
#define MnShowWrongCode 		        34
#define MnEraseFilesList					  35
#define MnDiagnose_1			          36
#define MnDiagnose_2 			          37
#define MnDiagnose_3 			          38
#define MnDiagnose_3_PropValve 			39
#define MnDiagnose_4 			          40
//#define MnDiagnose_6 			        41
#define MnClearTempEndReached  	    42
#define MnUpperEndReached 		      43
#define MnLowerEndReached 		      44
#define MnChangeTemp 			          45
#define MnClearSetTempInputField 	  46
//#define MnClearDiagnoseGreybox_vertical 47
#define MnClearAirTemperatureArea	  48
#define MnClearChillerStatusArea	  49
#define MnKeyboardFloat		          50		//Keyboard zur Eingabe von Gleitkommazahlen
#define MnKeyboardInt 		          51		//Keyboard zur Eingabe von Festkommazahlen
#define MnShowInvalidValue 		      52		//Keyboard, ungueltiger Wert eingegeben
#define MnClearInvalidValue  	      53		//Keyboard, ungueltiger Wert eingegeben, Warnung wieder loeschen
#define MnKeyBoardClearInputField 	54
#define MnClearAirTemperatureArea_1 55
#define MnClearAirTemperatureArea_2 56
#define MnClearAirTemperatureArea_3 57
#define MnClearAirTemperatureArea_4 58
#define MnClearShowSetTemp_1 	      59
#define MnClearShowSetTemp_2		    60
#define MnClearShowSetTemp_3 	      61
#define MnClearShowSetTemp_4 	      62
#define MnClearDiag3ValueAreas 	    63
#define MnShowLimitReached 		      64
#define MnClearLimitReached 		    65
#define MnMenueButton_v_1 				  67    // Rendering of vertical menue button 1
#define MnMenueButton_v_2 				  68    // Rendering of vertical menue button 2
#define MnMenueButton_v_3					  69    // Rendering of vertical menue button 3
#define MnMenueButton_v_4					  70    // Rendering of vertical menue button 4
#define MnMenueButton_v_5					  71    // Rendering of vertical menue button 5
//#define MnPrintDiag1Vals					72
#define MnKeyboardFloat_short 	    74		// Keyboard zur Eingabe von Gleitkommazahlen aber mit nur einer Nachkommastelle
#define MnExternal_Keyboard_Connected 75  // 'Externes Display Verbunden'_Meldung
#define MnInfoWindow			          76
#define MnFatalErrorWindow 		      77
#define MnErrorWindow 		          78
#define MnConfigWindow_1 		        79
#define MnConfigWindow_2 		        80
#define MnConfigWindow_3 		        81
#define MnConfigWindow_4 		        82
#define MnTDC_PS_ConfigWindow 	 	  83
#define MnConfigWindow_5 		        84
#define MnConfigClearCompensationTable  85
#define MnConfigTable_1_active 	    86
#define MnConfigTable_2_active      87
#define MnConfigTable_3_active      88

#define MnMain_h_cooling		   89		// Display cooling symbol for horizontal displays
#define MnMain_h_even 		     90		// Display even symbol for horizontal displays
#define MnMain_h_heating 		   91		// Display heating symbol for horizontal displays
#define MnMain_h_blank 		     92		// Display blank (grey only) symbol for horizontal displays
//#define MnMain_h_deltaeven 	 93		// Function unknow

#define MnMain_v_cooling 		   94
#define MnMain_v_even 		     95
#define MnMain_v_heating 		   96
#define MnMain_v_blank 		     97
#define MnMain_v_deltaeven 		 98
#define MnConfigWindow_blank 	 99
#define MnOptionButtonConfigWindow_1    101
#define MnOptionButton1 		  102		// Rendering of option button 1
#define MnOptionButton2 		  103		// Rendering of option button 2
#define MnSetTemp 			      104		// Rendering of touch area displaying set temperarture
#define MnChuckTemp			      105		// Rendering of chuck temperarture value
#define MnChuckComp 			    106		// Rendering of chuck compensated temperarture value
#define MnChuckStat			      107		// Rendering of chuck status text
#define MnDewTempVal			    108		// Rendering of depoint value
#define MnDewTempFrame	     	109		// Rendering of depoint frame and title

#define MnComAct_Off			    110		// Communication activity icon, off
#define MnComAct_On			      111		// Communication activity icon, on
#define MnTDC_Std			        112		// Icon, signalling TDC mode "Standard"
#define MnTDC_Prg			        113		// Icon, signalling TDC mode "Progressive"
#define MnTDC_Low			        114		// Icon, signalling TDC mode "LowNoise"
#define MnCDCS_Off			      115		// Icon signalling deactivated dew point
#define MnCDCS_On			        116		// Icon signalling activated dew point
#define MnWarn_On			        117		// Warning symbol on
#define MnWarn_Off			      118		// Warning symbol off
#define MnLock_Off			      119		// Lock off
#define MnLock_On			        120		// Lock on
#define MnVersionInfo		      121		// Prints version string
#define MnIpInfo			        122		// Prints IP info string

#define MnSystem_Setup_1			125		// Renders System Setup Window, the menue for the following three windows
#define MnSystem_Config_1			126		// Renders Chuck Configuration Window
#define MnTemp_Limits_1				127		// Renders Temperature Limits Window
#define MnNetwork_Config_1 		128		// Renders Network Configuration Window
#define MnSysConfButton				129		// Renders the SYS-Button in System Setup Window

#define MnPrintNetInfo		    130		// Prints IP, Mask, Gate, and MAC-Address in to Network-Config-Window
#define MnPrintChuckList		  113		// Prints Chuck-List into System Configuration Window
#define MnPrintTempLimits			132		// Prints current user ser temperature limits
#define MnConfig1CheckBoxes		133		// Renders checkmarks in Config Window 1 check boxes

#define MnMenue_v							134		// Renders vertical menue in rigth column
#define MnPrintDiag1Vals			135		// Prints current diagnose 1 values (temperatures and status) 
#define MnPrintDiag2Vals			136		// Prints current diagnose 2 values (voltage, current, relay position and errors) 
#define MnPrintDiag2Errs			137		// Prints over/under current errors in diagnose 2 window
#define MnPrintDiag3Vals			138		// Prints current diagnose 3 values (flows, pressure and relay position) 
#define MnPrintDiag3PropValveVals	139		// Print values for diagnose 3 for prop valve values
#define MnPrintDiag4LeftPage	140		// Prints to left page of file system view
#define MnPrintDiag4RightPage	141		// Prints to right page of file system view

#define MnDimDisplay		      220		// Dims display
#define MnUndimDisplay				221   // Undims display

#define MnDummyName			      255		// Used during development, not an existing macro


////////////////////////////////////////////////////////////////////////
// The Button List
///////////////////////////////////////////////////////////////////////

#define B_no_touch	    255 				//  keycode for toch button just used for rendering. This code does not trigger any action
#define B_global_escape   222 			// globale ESCapesequenz: ersetzt in den meisten Faellen die einzelnen

//  --- Mainmenu ---
#define B_ers_logo   42 						// (Eintritt zur Eingabe der Codes fuer Diagnose und Config)
#define B_25_grad_chuck_1   2
#define B_25_grad_chuck_2   4
#define B_25_grad_chuck_3   135
#define B_25_grad_chuck_4   136
#define B_set_temp_1   120
#define B_set_temp_2   3
#define B_set_temp_3   132
#define B_set_temp_4   134
#define B_main_config   123
#define B_option_1   170
#define B_option_2   171
#define B_warning   137

//  --- Config Window --- old
#define B_show_file_system   10
#define B_display_update   5
#define B_controller_overview   6
#define B_switch_view   7
#define B_temperature_comp   8
#define B_config_exit   9

//  --- Switch View ---
#define B_switch   19
#define B_save_as_std   20
#define B_switch_v_back   18
#define B_switch_v_exit   17
#define B_switch_v_1   91
#define B_switch_v_2   92
#define B_switch_v_3   93
#define B_switch_v_4   94
#define B_switch_v_5   95
#define B_switch_v_6   96
#define B_switch_v_7   97
#define B_switch_v_8   98
#define B_switch_v_9   99
#define B_switch_v_10   100
#define B_switch_v_11   101
#define B_switch_v_12   102
#define B_switch_v_13   102
#define B_switch_v_14   104
#define B_switch_v_15   105
#define B_switch_v_16   106
#define B_switch_v_17   107
#define B_switch_v_18   108
#define B_switch_v_19   109
#define B_switch_v_20   110

//  --- Pin Request / Keyboard ---
#define B_pin_req_1   21
#define B_pin_req_2   22
#define B_pin_req_3   23
#define B_pin_req_4   24
#define B_pin_req_5   25
#define B_pin_req_6   26
#define B_pin_req_7   121
#define B_pin_req_8   28
#define B_pin_req_9   29
#define B_pin_req_0   30
#define B_pin_req_esc   31
#define B_pin_req_clr   32
#define B_pin_req_backspace   33
#define B_pin_req_enter   34

//  --- Keyboard ---
// Float:
#define keyb_1   71
#define keyb_2   72
#define keyb_3   73
#define keyb_4   74
#define keyb_5   75
#define keyb_6   76
#define keyb_7   77
#define keyb_8   78
#define keyb_9   79
#define keyb_0   80
#define keyb_esc   81
#define keyb_clr   82
#define keyb_backspace   83
#define keyb_enter   84
#define B_keyb_plus_minus   85
#define B_keyb_dot   86

#define B_keyb_plus_ten   124
#define B_keyb_plus_one   125
#define B_keyb_plus_zeroone   126
#define B_keyb_plus_zerozeroone   127

#define B_keyb_minus_ten   128
#define B_keyb_minus_one   129
#define B_keyb_minus_zeroone   130 
#define B_keyb_minus_zerozeroone   131

// Ganzzahl:
#define keyb_G_1   151
#define keyb_G_2   152
#define keyb_G_3   153
#define keyb_G_4   154
#define keyb_G_5   155
#define keyb_G_6   156
#define keyb_G_7   157
#define keyb_G_8   158
#define keyb_G_9   159
#define keyb_G_0   160
#define keyb_G_esc   162
#define keyb_G_clr   163
#define keyb_G_backspace   164
#define keyb_G_enter   165
#define B_keyb_G_plus_minus   161

#define B_keyb_G_plus_ten   166
#define B_keyb_G_plus_one   168

#define B_keyb_G_minus_ten   167
#define B_keyb_G_minus_one   169

//  --- Menue pages ---
#define B_menue_page_1   61
#define B_menue_page_2   62
#define B_menue_page_3   63
#define B_menue_page_4   64
#define B_menue_page_5   66

//  --- Diagnose ---
// #define B_menue_page_5   122
#define B_diag_comp_on   						140
#define B_diag_comp_off  						141
#define B_diag_set_cool_air_value   142
#define B_diag_set_warm_air_value   143
#define B_diag_bypass_valve_on_off  144
#define B_diag_main_valve_on_off    145
#define B_diag_set_power_supply_1   146
#define B_diag_set_power_supply_2   147
#define B_diag_switch_power_relay    67
#define B_diag_chiller_on_off				122

//  --- Show File System ---
#define B_show_filesys_back   11
#define B_show_filesys_exit   12
#define B_show_filesys_update   13

//  --- Controller Overview ---
#define B_contr_over_edit   14
#define B_contr_over_back   15
#define B_contr_over_exit   16
#define B_contr_over_1   111
#define B_contr_over_2   112
#define B_contr_over_3   113
#define B_contr_over_4   114
#define B_contr_over_5   115
#define B_contr_over_6   116
#define B_contr_over_7   117
#define B_contr_over_8   118
#define B_contr_over_9   119

//  --- Error ---
#define B_info_ok   172

// --------------
#define B_UserTouchedDisplay   173

//  --- Config Windows ---
#define B_ConfigWindow_1   174
#define B_ConfigWindow_2   175
#define B_ConfigWindow_3   176
#define B_ConfigWindow_4   177
#define B_ConfigWindow_PowerSense   178
#define B_ConfigWindow_back   179
#define B_ConfigWindow_5   180
#define B_ConfigEditNormTemp   183
#define B_ConfigEditCompTemp   184
#define B_Config_del_line   185
#define B_Config_ins_line   186
#define B_Config_clr_table   187

#define B_Config_table_1   188
#define B_Config_table_2   189
#define B_Config_table_3   190
#define B_Config_table_save   191

#define B_Config_sort_table   192

#define B_Config_activate_table   193
#define B_Config_deactivate_table   194

#define B_Config_toggle_holdmode   195
//#define B_Config_deactivate_holdmode   196

#define B_Config_toggle_standbymode   197
#define B_Config_toggle_enabledmode   198

#define B_Config_toggle_purgemode     138
//#define B_Config_deactivate_purgemode   139

#define B_Config_toggle_defrostmode   227
//#define B_Config_deactivate_defrostmode   228

#define B_ConfigWindow_activate_standard   199
#define B_ConfigWindow_activate_progressive   200
#define B_ConfigWindow_activate_low_noise   201

//  --- System Setup Fenster ---
#define B_System_Setup_Sys	  148 
#define B_System_Setup_Temp	  149 
#define B_System_Setup_Net	  150 

//  --- Temperature Limits Fenster ---
#define B_UpperTempLimit 	  35
#define B_LowerTempLimit 	  36

//  --- General action buttons ---
#define B_Save   202
#define B_Exit   216
#define B_Up	  181
#define B_Down   182

//  --- Netzwerkkonfiguration ---
#define B_Network_Config_load_default   203
#define B_Network_Config_IP_0   204
#define B_Network_Config_IP_1   205
#define B_Network_Config_IP_2   206
#define B_Network_Config_IP_3   207
#define B_Network_Config_Mask_0   208
#define B_Network_Config_Mask_1   209
#define B_Network_Config_Mask_2   210
#define B_Network_Config_Mask_3   211
#define B_Network_Config_Gateway_0   212
#define B_Network_Config_Gateway_1   213
#define B_Network_Config_Gateway_2   214
#define B_Network_Config_Gateway_3   215

//  --- Optionsbuttonkonfigurationsfenster ---
#define B_OptionButtonConfigWindow_1   217
#define B_OptionModePlusMinus   218
#define B_OptionModeStatic   219
#define B_OptionPlusMinus   220
#define B_OptionStaticB_1   221
#define B_OptionStaticB_2   223

//  --- CDCS Window ---
#define B_Config_activate_dewpoint 224
#define B_Config_deactivate_dewpoint 225
#define B_Config_Set_dewpoint 226

//  --- Dimming ---
#define B_dim_touched   					 254	 	// Touch button during display is dimmed


////////////////////////////////////////////////////////////////////////
// The Color List
///////////////////////////////////////////////////////////////////////

#define MAIN_FRAME_BG_COLOR      		22		// Background of main frame
#define MAIN_FRAME_TEXT_COLOR    		23		// Color of static texts within main frame, e.g. "Chuck Temperature"
#define INNER_FRAME_BORDER_COLOR 		24		// Border color of inner frames (text and status frames within main frame)
#define STATUS_COLOR_OK							25		// Color for OK status fields
#define STATUS_COLOR_NOK						26		// Color for NOT OK status fields
