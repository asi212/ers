/**
*  \file
*    
*   
*  \brief Implementation of the Class orientations
*  \date 19-Jan-2011 10:45:00
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#if !defined(ORIENTATIONS_H__INCLUDED_)
#define ORIENTATIONS_H__INCLUDED_

enum orientations
{
	HORIZONTAL,
	VERTICAL
};

#endif // !defined(ORIENTATIONS_H__INCLUDED_)
