/**
*  \file
*    s_attributes.cpp
*   
*  \brief Implementation of the Class s_attributes
*  \date 19-Jan-2011 10:45:08
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#include "s_attributes.h"
