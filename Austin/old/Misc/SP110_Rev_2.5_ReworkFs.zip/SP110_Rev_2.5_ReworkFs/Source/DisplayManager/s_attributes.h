/**
*  \file
*    s_attributes.cpp
*   
*  \brief Implementation of the Class s_attributes
*  \date 19-Jan-2011 10:45:08
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#if !defined(S_ATTRIBUTES_H__INCLUDED_)
#define S_ATTRIBUTES_H__INCLUDED_

#include "orientations.h"

struct s_attributes
{

public:
	orientations orientation;
        int num_chucktemps;

};
#endif // !defined(S_ATTRIBUTES_H__INCLUDED_)
