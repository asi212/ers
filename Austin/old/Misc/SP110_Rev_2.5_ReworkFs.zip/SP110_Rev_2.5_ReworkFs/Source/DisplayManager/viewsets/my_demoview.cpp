

#include "my_demoview.h"
#include "my_demowindows.h"

CDemoview::CDemoview()
{

}

CDemoview::~CDemoview()
{

}

void CDemoview::Init(string view_name, CDisplaymanager* p_display_manager)
{
  name = view_name;
  p_displaymanager = p_display_manager;
  create_windows();
  attributes.orientation = HORIZONTAL; //Horizontales Fenster
  attributes.num_chucktemps = 1; //Anzahl der Chucktemperaturen;
                                   //Legt insbesondere die Anzahl der angezeigten
                                   //Temperaturen im Hauptfenster fest
}

void CDemoview::create_windows()
{
  attributes.orientation = HORIZONTAL; //Horizontales Fenster
  attributes.num_chucktemps = 1; //Anzahl der Chucktemperaturen;
  
  // - Create window-objects with the following names, and add them as recipients: -
  //if (!check_win_exists("mainmenu")) //Pruefen of dieses Fenster mit dem Namen nicht vielleicht schon vorher von einem anderen Viewobjekt erstellt wurde
  //{
  
    p_window =  new Main_Window_1(); //Fenster erzeugen
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true); //Fenster initialisieren
    p_window->name.assign("mainmenu");
    p_displaymanager->windowlist.push_back(p_window); //Fenster im Displaymanager hinzufuegen
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new Assist_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("assist");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
  //}
  //if (!check_win_exists("assist"))
  //{

  //}
  //if (!check_win_exists("pin_request_1"))
  //{
    p_window =  new Pin_Req_1();
    p_window->Init( p_displaymanager->m_EventManager, this,  p_displaymanager, true);
    p_window->name.assign("pin_request_1");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
  //}
  //if (!check_win_exists("config_window"))
  //{
    p_window =  new Config_Window_1();
    p_window->Init( p_displaymanager->m_EventManager, this,  p_displaymanager, true);
    p_window->name.assign("config_window");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
  //}
  //if (!check_win_exists("show_file_system"))
  //{
    p_window =  new Show_File_System_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("show_file_system");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
  //}
    p_window =  new Diagnose_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("diagnose_1");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
    
    p_window =  new Diagnose_2();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("diagnose_2");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
    
    p_window =  new Diagnose_3();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("diagnose_3");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
    
    p_window =  new Diagnose_4();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("diagnose_4");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
    
    p_window =  new Diagnose_5();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("diagnose_5");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
    
    p_window =  new Diagnose_6();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("diagnose_6");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
    
    p_window =  new Switchview_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("switchview_1");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 

    p_window =  new Controller_Overview_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("controller_overview_1");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new Keyboard_1(); //Keyboard fuer Gleitkommazahlen
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("keyboard");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new Keyboard_2();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("keyboard_int");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new Error_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true); //true->vertikal
    p_window->name.assign("error_handler");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
}


CController_view_1::CController_view_1()
{

}

CController_view_1::~CController_view_1()
{

}

void CController_view_1::Init(string view_name, CDisplaymanager* p_display_manager)
{
  name = view_name;
  p_displaymanager = p_display_manager;
  create_windows();
  attributes.orientation = HORIZONTAL; //Horizontales Fenster
  attributes.num_chucktemps = 1; //Anzahl der Chucktemperaturen;
                                   //Legt insbesondere die Anzahl der angezeigten
                                   //Temperaturen im Hauptfenster fest
}

void CController_view_1::create_windows()
{
  attributes.orientation = HORIZONTAL; //Horizontales Fenster
  attributes.num_chucktemps = 1; //Anzahl der Chucktemperaturen;
  
  // - Create window-objects with the following names, and add them as recipients: -
  //if (!check_win_exists("mainmenu")) //Pruefen of dieses Fenster mit dem Namen nicht vielleicht schon vorher von einem anderen Viewobjekt erstellt wurde
  //{
  
    p_window =  new Main_Window_Fair_Controller_1(); //Fenster erzeugen
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false); //Fenster initialisieren
    p_window->name.assign("mainmenu");
    p_displaymanager->windowlist.push_back(p_window); //Fenster im Displaymanager hinzufuegen
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); //Windowname in Viewobjekt speichern

    p_window =  new Assist_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("assist");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
  //}
  //if (!check_win_exists("assist"))
  //{

  //}
  //if (!check_win_exists("pin_request_1"))
  //{

  //}
  //if (!check_win_exists("config_window"))
  //{
    p_window =  new Config_Window_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("config_window");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
  //}
  //if (!check_win_exists("show_file_system"))
  //{
    p_window =  new Show_File_System_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("show_file_system");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
  //}
    p_window =  new Diagnose_1_Fair_Controller_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("diagnose_1");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
    
    p_window =  new Pin_Req_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("pin_request_1");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);     
    
    p_window =  new Diagnose_2_Fair_Controller_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("diagnose_2");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
    
    p_window =  new Diagnose_3_Fair_Controller_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("diagnose_3");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
    
    p_window =  new Diagnose_4_Fair_Controller_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("diagnose_4");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
    
    p_window =  new Diagnose_5();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("diagnose_5");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
    
    p_window =  new Diagnose_6();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("diagnose_6");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
    
    p_window =  new Switchview_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("switchview_1");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 

    p_window =  new Keyboard_1(); //Keyboard fuer Gleitkommazahlen
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("keyboard");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new Keyboard_2();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("keyboard_int");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new Error_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("error_handler");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new Dimmer_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("dimmer");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new System_Setup_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("system_setup_1");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);

    p_window =  new System_Config_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("system_config_1");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);

    p_window =  new Temp_Limits_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("temp_limits_1");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);

    p_window =  new Network_Config_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("network_config_1");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);

    p_window =  new Option_Button_Config();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("opt_button_conf");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new User_Config_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("user_config_1");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new User_Config_2();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("user_config_2");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new User_Config_3();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("user_config_3");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new User_Config_4();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("user_config_4");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new User_Config_5();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("user_config_5");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new User_Config_PowerSense_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("user_config_power_sense");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new User_Config_entry();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("user_config_entry");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);

    p_window =  new Menue_v();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("menue_v");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
}

CController_view_1_v::CController_view_1_v()
{
  
}

CController_view_1_v::~CController_view_1_v()
{
  
}

void CController_view_1_v::Init(string view_name, CDisplaymanager* p_display_manager)
{
  name = view_name;
  p_displaymanager = p_display_manager;
  create_windows();
  attributes.orientation = HORIZONTAL; //Horizontales Fenster
  attributes.num_chucktemps = 1; //Anzahl der Chucktemperaturen;
                                   //Legt insbesondere die Anzahl der angezeigten
                                   //Temperaturen im Hauptfenster fest
}

void CController_view_1_v::create_windows()
{
  attributes.orientation = HORIZONTAL; //Horizontales Fenster
  attributes.num_chucktemps = 1; //Anzahl der Chucktemperaturen;
  
  // - Create window-objects with the following names, and add them as recipients: -
  //if (!check_win_exists("mainmenu")) //Pruefen of dieses Fenster mit dem Namen nicht vielleicht schon vorher von einem anderen Viewobjekt erstellt wurde
  //{
  
    p_window =  new Main_Window_Fair_Controller_1(); //Fenster erzeugen
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true); //Fenster initialisieren
    p_window->name.assign("mainmenu");
    p_displaymanager->windowlist.push_back(p_window); //Fenster im Displaymanager hinzufuegen
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); //Windowname in Viewobjekt speichern
    
    p_window =  new Assist_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("assist");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);

    p_window =  new Pin_Req_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("pin_request_1");
    p_displaymanager->windowlist.push_back(p_window); 
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 

    p_window =  new Config_Window_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("config_window");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
  //}
  //if (!check_win_exists("show_file_system"))
  //{
  //}
    p_window =  new Diagnose_1_Fair_Controller_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("diagnose_1");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
    
    p_window =  new Diagnose_2_Fair_Controller_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("diagnose_2");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
    
    p_window =  new Diagnose_3_Fair_Controller_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("diagnose_3");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
    
    p_window =  new Diagnose_4_Fair_Controller_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("diagnose_4");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer); 
    
    p_window =  new Keyboard_1(); //Keyboard fuer Gleitkommazahlen
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("keyboard");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new Keyboard_2();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("keyboard_int");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new Error_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, false);
    p_window->name.assign("error_handler");
    p_displaymanager->windowlist.push_back(p_window);
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
    
    p_window =  new Dimmer_1();
    p_window->Init( p_displaymanager->m_EventManager, this, p_displaymanager, true);
    p_window->name.assign("dimmer");
    p_displaymanager->windowlist.push_back(p_window); 
    windownames.push_back(&(p_window->name)); p_window->v_buffer = &(p_displaymanager->v_buffer);
}

