
/**
*  \file
*    my_demowindows.cpp
*   
*  \brief Implementation of some window classes for demonstration
*  \date 13-Jan-2011 13:00:00
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#if !defined(MY_DEMOVIEW_H__INCLUDED_)
#define MY_DEMOVIEW_H__INCLUDED_
#include "..\..\system_wide_defs.h"
#include "..\CDisplaymanager.h"
#include "..\CWindow.h"
#include "..\CView.h"
#include <vector>
#include <iterator>
#include <algorithm>
#include <string>

//class CView;
/**
* A simple View-Object.
* Nothing special yet.
* 
* 
* 
*/



#endif // !defined(MY_DEMOVIEW_H__INCLUDED_)
