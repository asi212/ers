/**
*  \file
*    IControllerController.cpp
*   
*  \brief Implementations of the Demonstrationwindows
*  \date 20-Jan-2011 09:30:00
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#include "my_demowindows.h"
#include "windowstate.h"
#include "CWindow.h"
#include "toolbox.h"
#include "../../MailboxSystem/CEventManager.h"

#include <stdlib.h>
#define PRECISION 2

msg *p2_msg;
extern bool error_button_clicked;

bool no_dot_in_vector(vector<char>* data)
{
  bool dot = true;
  for(int i=0; i<data->size();i++)
  {
    if (data->at(i) == '.') dot = false;
  }
  return dot;
}



Main_Window_1::Main_Window_1()
{ //Sicherheitsinit
  
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
  
  controller_mode.reserve(25);
  version_info.reserve(60);
}

// Das Hauptfenster des Chillers (vertikal)
// mit 4 Temperaturen und nur einer Set-Temperatur
void Main_Window_1::Init( CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  
  m_pEventManager = pEventManager;
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
  alignment = b_alignment;
  set_temp_1[0] = 31.00;  // Initial value
  set_temp_1[1] = 350.00; // Upper limit
  set_temp_1[2] = -45.00; // Lower limit
  
  set_temp_2[0] = 144.10;  // Initial value
  set_temp_2[1] = 350.00; // Upper limit
  set_temp_2[2] = -45.00; // Lower limit
  
  set_temp_3[0] = -15.00;  // Initial value
  set_temp_3[1] = 350.00; // Upper limit
  set_temp_3[2] = -45.00; // Lower limit
  
  set_temp_4[0] = 24.00;  // Initial value
  set_temp_4[1] = 25.00; // Upper limit
  set_temp_4[2] = -45.00; // Lower limit
  
  chuck_temp_1[0] = 25.00;  // Initial value
  chuck_temp_2[0] = -13.00;  // Initial value
  chuck_temp_3[0] = 0.0;  // Initial value
  chuck_temp_4[0] = 103.00;  // Initial value
  
  set_temp_1_changed = true;
  set_temp_2_changed = true;
  set_temp_3_changed = true;
  set_temp_4_changed = true;
  chuck_temp_1_changed = true;
  chuck_temp_2_changed = true;
  chuck_temp_3_changed = true;
  chuck_temp_4_changed = true;
  
  
//  for (int i=0;i<8;i++) number_changed[i] = true;
  controller_mode = "-----";
//  controller_mode = "Controlling";
  controller_mode_changed = true;
  for (int i=0;i<4;i++) status_changed[i] = true;
  chiller_locked = false;
  // Temperature_status:
  // 5 Blank
  // 2 Cooling
  // 3 Even
  // 4 heating
  // 1 deltaEven
  Temperature_status[0] = 5;
  Temperature_status[1] = 5;
  Temperature_status[2] = 5;
  Temperature_status[3] = 5;
  
  for (int i=0;i<4;i++) togglecounter[i] = 0;
  
  warning_symbol = false; //#LP#
  warning_symbol_changed = false; //#LP#
  
  for (int i=0;i<4;i++) chuck_temperature_valid[i] = false; //#LP#
  
  version_info = " ";
  
  chiller_comm_symbol = false;
  chiller_comm_symbol_changed = true;
  
  //Rgistrieren der Ereignis- handler
  m_pEventManager->AddEventHandler( CEventNames::set_temp1_changed, Main_Window_1::set_temp_1EventWrapper, this );
  m_pEventManager->AddEventHandler( CEventNames::chuck_temp, Main_Window_1::chuck_tempEventWrapper, this );
  m_pEventManager->AddEventHandler( CEventNames::advice_symbol, Main_Window_1::advice_symbolEventWrapper, this );
  m_pEventManager->AddEventHandler( CEventNames::s_temp_1, Main_Window_1::s_temp_1EventWrapper, this );
  
}

void Main_Window_1::set_temp_1Event( float f )
{
    //if ((!chiller_locked) && (p_msg->origin != "display_1"))
    if (!chiller_locked) //MB, Quelle nicht mehr eitscheidend, aktion ist auch f�r ACTIVE und INACTIVE gleich
    {
        if(!float_equal(set_temp_1[0], f, 1))
        {
          set_temp_1[0] = f;
          set_temp_1_changed = true;
        }
    }
    switch( state )
    {
        case INACTIVE:
            break;
    }            
}

void Main_Window_1::chuck_tempEvent( float f )
{
    //if ((!chiller_locked) && (p_msg->origin != "display_1"))
  if(!float_equal(chuck_temp_1[0], f, 2))
  {
    chuck_temp_1[0] = f;
    chuck_temp_1_changed = true;
    chuck_temperature_valid[0] = true;
  }
}

void Main_Window_1::advice_symbolEvent( bool b )
{ // Das rote, runde Warnsimbol soll angezeigt werden
  if( b && (warning_symbol == false))
  {
    warning_symbol = true;
    warning_symbol_changed = true;
  }
  else if ( !b && (warning_symbol == true))
  {
    warning_symbol = false;
    warning_symbol_changed = true;
  }
}

void Main_Window_1::s_temp_1Event( bool b )
{ // Der User moechte die Set-Temperatur Nr. 1 aendern
  //Temperatur zum editieren ans Keyboard schicken:
  //Die Fenster aktivieren/deaktivieren:
  if (!chiller_locked)
  {
    p_CDisplaymanager->set_state(&name, INACTIVE);
    p_CDisplaymanager->set_state("keyboard", JUST_ACTIVATED);
    //Keyboard die gewuenschten Parameter zukommen lassen:
    p2_msg = NULL;//p_displaymailbox->take_free_msg();
    if(p2_msg != NULL)
    {
      p2_msg->cmd1 = "F1"; //Float, signed, zwei Nachkommastellen
      p2_msg->cmd2 = "set_temp_1"; //Parametername
      p2_msg->f_number[0] = set_temp_1[0]; //aktueller Wert
      p2_msg->f_number[1] = set_temp_1[1]; //upper limit
      p2_msg->f_number[2] = set_temp_1[2]; //lower limit
      p2_msg->origin = "mainmenu";
      p2_msg->dest = "keyboard";
    }
  }
}

void Main_Window_1::cycCalc()
{
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
        msg * p_msg = NULL;
	switch(state)
	{
	case INACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//NULL;//p_displaymailbox->name;
            }
            else if (   p_msg->cmd1 == "set_temp_2")
            { // Es wurde eine neue Setz-Temperatur von irgendwo her uebertragen
              if ((!chiller_locked) && (p_msg->origin != "display_1"))
              {
               if(!float_equal(set_temp_2[0], p_msg->f_number[0], 1))
                //if (set_temp_2[0] != p_msg->f_number[0])
                {
                  set_temp_2[0] = p_msg->f_number[0];
                  set_temp_2_changed = true;
  		  //Die neue Setz-Temperatur kurz dem "system" mitteilen:
		  p2_msg = NULL;//p_displaymailbox->take_free_msg();
  		  if(p2_msg != NULL)
    		  {
                    p2_msg->cmd1 = "set_temp_2_changed";
                    p2_msg->f_number[0] = set_temp_2[0];
                    p2_msg->origin = name;
                    p2_msg->dest = "system";
                  }
                }
              }
            }
            else if (   p_msg->cmd1 == "set_temp_3")
            { // Es wurde eine neue Setz-Temperatur von irgendwo her uebertragen
              if ((!chiller_locked) && (p_msg->origin != "display_1"))
              {
                if(!float_equal(set_temp_3[0], p_msg->f_number[0], 1))
                //if(set_temp_3[0] != p_msg->f_number[0])
                {
                  set_temp_3[0] = p_msg->f_number[0];
                  set_temp_3_changed = true;
                  //Die neue Setz-Temperatur kurz dem "system" mitteilen:
                  p2_msg = NULL;//p_displaymailbox->take_free_msg();
		  if(p2_msg != NULL)
		  {
                    p2_msg->cmd1 = "set_temp_3_changed";
                    p2_msg->f_number[0] = set_temp_3[0];
                    p2_msg->origin = name;
                    p2_msg->dest = "system";
                  }
                }
              }
            }
            else if (   p_msg->cmd1 == "set_temp_4")
            { // Es wurde eine neue Setz-Temperatur von irgendwo her uebertragen
              if ((!chiller_locked) && (p_msg->origin != "display_1"))
              {
                if(!float_equal(set_temp_4[0], p_msg->f_number[0], 1))
                //if (set_temp_4[0] != p_msg->f_number[0])
                {
                  set_temp_4[0] = p_msg->f_number[0];
                  set_temp_4_changed = true;
                  //Die neue Setz-Temperatur kurz dem "system" mitteilen:
                  p2_msg = NULL;//p_displaymailbox->take_free_msg();
                  if(p2_msg != NULL)
                  {
                    p2_msg->cmd1 = "set_temp_4_changed";
                    p2_msg->f_number[0] = set_temp_4[0];
                    p2_msg->origin = name;
                    p2_msg->dest = "system";
                  }
                }
              }
            }
            else if (   p_msg->cmd1 == "set_version_info")
            { // Es wurde eine neue Versionsinfo irgendwo her uebertragen
              version_info = p_msg->cmd2;
              version_info_changed = true;
            }
            else if (   p_msg->cmd1 == "controller_mode")
            { // Es wurde ein neuer Chiller-status von irgendwo her uebertragen
              if(controller_mode != p_msg->cmd2)
              {
                controller_mode = p_msg->cmd2;
                controller_mode_changed = true;
                /*
                //"diagnose_1" interessiert sich ebenfalls fuer den Chillerstatus:
                p2_msg = p_displaymailbox->take_free_msg();
                if(p2_msg != NULL)
                {
                    p2_msg->cmd1 = p_msg->cmd1;
                  p2_msg->cmd2 = p_msg->cmd2;
                  p2_msg->origin = "mainmenu";
                  p2_msg->dest = "diagnose_1";
                }
                */
              }
            }
            else if (   p_msg->cmd1 == "set_limits_1")
            { // Es wurden neue Limits von irgendwo her uebertragen
			set_temp_1[1] = p_msg->f_number[0]; //upper limit
			set_temp_1[2] = p_msg->f_number[1]; //lower limit
            }
            else if (   p_msg->cmd1 == "set_limits_2")
            { // Es wurden neue Limits von irgendwo her uebertragen
			set_temp_2[1] = p_msg->f_number[0]; //upper limit
			set_temp_2[2] = p_msg->f_number[1]; //lower limit
            }
            else if (   p_msg->cmd1 == "set_limits_3")
            { // Es wurden neue Limits von irgendwo her uebertragen
			set_temp_3[1] = p_msg->f_number[0]; //upper limit
			set_temp_3[2] = p_msg->f_number[1]; //lower limit
            }
            else if (   p_msg->cmd1 == "set_limits_4")
            { // Es wurden neue Limits von irgendwo her uebertragen
			set_temp_4[1] = p_msg->f_number[0]; //upper limit
			set_temp_4[2] = p_msg->f_number[1]; //lower limit
            }
            else if (   p_msg->cmd1 == "invalid_temp")
            { 
              if((p2_msg->f_number[0] < 5) && (p2_msg->f_number[0] >= 1))
              {
                chuck_temperature_valid[p2_msg->i_number[0]-1] = false;
                //number_changed[p2_msg->i_number[0]-1+4] = true;
                if (p2_msg->i_number[0] == 1) chuck_temp_1_changed = true;
                else if (p2_msg->i_number[0] == 2) chuck_temp_2_changed = true;
                else if (p2_msg->i_number[0] == 3) chuck_temp_3_changed = true;
                else chuck_temp_4_changed = true;
                
                
              }
            }
             else if (   p_msg->cmd1 == "temp_2")
            { // Es wurde eine neue Chuck/Air-Temperatur von irgendwo her uebertragen
              //if(chuck_temp_2[0] != p_msg->f_number[0])
              if(!float_equal(chuck_temp_2[0], p_msg->f_number[0], 2))
              {
                chuck_temp_2[0] = p_msg->f_number[0];
                chuck_temp_2_changed = true;
                //"diagnose_1" interessiert sich ebenfalls fuer eine neue Temperatur 1:
                
                p2_msg = NULL;//p_displaymailbox->take_free_msg();
                if(p2_msg != NULL)
                {
                  p2_msg->cmd1 = p_msg->cmd1;
                  p2_msg->cmd2 = p_msg->cmd2;
                  p2_msg->origin = name;
                  p2_msg->f_number[0] = p_msg->f_number[0];
                  p2_msg->dest = "diagnose_1";
                }
                chuck_temperature_valid[1] = true;
              }
            }
            else if (   p_msg->cmd1 == "temp_3")
            { // Es wurde eine neue Chuck/Air-Temperatur von irgendwo her uebertragen
              //if (chuck_temp_3[0] != p_msg->f_number[0])
              if(!float_equal(chuck_temp_3[0], p_msg->f_number[0], 2))
              {
                chuck_temp_3[0] = p_msg->f_number[0];
                chuck_temp_3_changed = true;
                //"diagnose_1" interessiert sich ebenfalls fuer eine neue Temperatur 1:
              
               p2_msg = NULL;//p_displaymailbox->take_free_msg();
                if(p2_msg != NULL)
                {
                  p2_msg->cmd1 = p_msg->cmd1;
                  p2_msg->cmd2 = p_msg->cmd2;
                  p2_msg->origin = name;
                  p2_msg->f_number[0] = p_msg->f_number[0];
                  p2_msg->dest = "diagnose_1";
                }
                chuck_temperature_valid[2] = true;
              }
            }
            else if (   p_msg->cmd1 == "temp_4")
            { // Es wurde eine neue Chuck/Air-Temperatur von irgendwo her uebertragen
              //if(chuck_temp_4[0] != p_msg->f_number[0])
              if(!float_equal(chuck_temp_4[0], p_msg->f_number[0], 2))
              {
                chuck_temp_4[0] = p_msg->f_number[0];
                chuck_temp_4_changed = true;
                //"diagnose_1" interessiert sich ebenfalls fuer eine neue Temperatur 1:
                
                p2_msg = NULL;//p_displaymailbox->take_free_msg();
                if(p2_msg != NULL)
                {
                  p2_msg->cmd1 = p_msg->cmd1;
                  p2_msg->cmd2 = p_msg->cmd2;
                  p2_msg->origin = name;
                  p2_msg->f_number[0] = p_msg->f_number[0];
                  p2_msg->dest = "diagnose_1";
                }
                chuck_temperature_valid[3] = true;
              }
            }
            else if (   p_msg->cmd1 == "status_temp_1")
            { // Es wurde eine �nderung des Chuck/Air-Temperatur-Symbols von irgendwo her uebertragen
              if(p_msg->cmd2 == "heating") Temperature_status[0] = 4;
              else if(p_msg->cmd2 == "cooling") Temperature_status[0] = 2;
              else if(p_msg->cmd2 == "even") Temperature_status[0] = 3;
              else if(p_msg->cmd2 == "blank") Temperature_status[0] = 5;
              status_changed[0] = true;
            }
            else if (   p_msg->cmd1 == "status_temp_2")
            { // Es wurde eine �nderung des Chuck/Air-Temperatur-Symbols von irgendwo her uebertragen
              if(p_msg->cmd2 == "heating") Temperature_status[1] = 4;
              else if(p_msg->cmd2 == "cooling") Temperature_status[1] = 2;
              else if(p_msg->cmd2 == "even") Temperature_status[1] = 3;
              else if(p_msg->cmd2 == "blank") Temperature_status[1] = 5;
              status_changed[1] = true;
            }
            else if (   p_msg->cmd1 == "status_temp_3")
            { // Es wurde eine �nderung des Chuck/Air-Temperatur-Symbols von irgendwo her uebertragen
              if(p_msg->cmd2 == "heating") Temperature_status[2] = 4;
              else if(p_msg->cmd2 == "cooling") Temperature_status[2] = 2;
              else if(p_msg->cmd2 == "even") Temperature_status[2] = 3;
              else if(p_msg->cmd2 == "blank") Temperature_status[2] = 5;
              status_changed[2] = true;
            }
            else if (   p_msg->cmd1 == "status_temp_4")
            { // Es wurde eine �nderung des Chuck/Air-Temperatur-Symbols von irgendwo her uebertragen
              if(p_msg->cmd2 == "heating") Temperature_status[3] = 4;
              else if(p_msg->cmd2 == "cooling") Temperature_status[3] = 2;
              else if(p_msg->cmd2 == "even") Temperature_status[3] = 3;
              else if(p_msg->cmd2 == "blank") Temperature_status[3] = 5;
              status_changed[3] = true;
            }
            else if (   p_msg->cmd1 == "key_lock_symbol")
            { // Es wurde eine neue Setz-Temperatur von irgendwo her uebertragen
              if((p_msg->cmd2 == "locked") && (chiller_locked == false))
              { //Der Chiller sperrt die Bedienung des Displays,
                //Der Benutzer wird nun ins Manmenu "gezwungen" um ihn dort auszuschliessen:
                chiller_locked = true;
                p_CDisplaymanager->set_state(&name, INACTIVE);
                p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
              }
              else if((p_msg->cmd2 == "open") && (chiller_locked == true)) chiller_locked = false;
              controller_mode_changed = true;
            }
            else if (p_msg->cmd1 == "chiller_comm_symbol")
            { // Das rote, runde Warnsimbol soll angezeigt werden
              if((p_msg->cmd2 == "ON") && (chiller_comm_symbol == false))
              {
                chiller_comm_symbol = true;
                chiller_comm_symbol_changed = true;
              }
              else if ((p_msg->cmd2 == "OFF") && (chiller_comm_symbol == true))
              {
                chiller_comm_symbol = false;
                chiller_comm_symbol_changed = true;
              }
            }
            if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Unbekannte Nachricht als empfangen zurueckschicken...
          }
          break;
	case JUST_ACTIVATED:
          //"Ansicht wechseln" ans Display schicken...
          controller_mode_changed = true;
//          for(int i=0; i<8;i++)number_changed[i] = true;
          set_temp_1_changed = true;
          set_temp_2_changed = false;
          set_temp_3_changed = false;
          set_temp_4_changed = false;
          chuck_temp_1_changed = true;
          chuck_temp_2_changed = true;
          chuck_temp_3_changed = true;
          chuck_temp_4_changed = true;
          
          chiller_comm_symbol_changed = true;
          
          controller_mode_changed = true;
          for (int i=0;i<4;i++) status_changed[i] = true;
//          number_changed[0] = true;
//          for(int i=4; i<8;i++)number_changed[i] = true;
          for(int i=0; i<4;i++)status_changed[i] = true;
          
          p2_msg = NULL;//p_displaymailbox->take_free_msg();
          if (p2_msg != NULL)
          {
            p2_msg->dest = "display_1";  
            p2_msg->origin = name;
            
            if(   (p_view->attributes.orientation == HORIZONTAL)
               && (p_view->attributes.num_chucktemps == 1))
            {
              p2_msg->cmd1 = "#DL#MN11,"; //MnMainMenueins 11 //#DL ;clear Display
            }
          }
          warning_symbol_changed = true;
          version_info_changed = true;
          state = ACTIVE;
          break;
	case ACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name; //msg wieder einlagern
            }
            else if (p_msg->cmd1 == "config")
            { //configbutton wurde gedr�ckt
              //Die Fenster aktivieren/deaktivieren:
              if (!chiller_locked)
              {
                p_CDisplaymanager->set_state(&name, INACTIVE);
                p_CDisplaymanager->set_state("pin_request_1", JUST_ACTIVATED);
              }
            }
            else if (p_msg->cmd1 == "escape")
            { //escapebutton wurde gedr�ckt
              //Die Fenster aktivieren/deaktivieren:
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "chiller_comm_symbol")
            { // Das rote, runde Warnsimbol soll angezeigt werden
              if((p_msg->cmd2 == "ON") && (chiller_comm_symbol == false))
              {
                chiller_comm_symbol = true;
                chiller_comm_symbol_changed = true;
              }
              else if ((p_msg->cmd2 == "OFF") && (chiller_comm_symbol == true))
              {
                chiller_comm_symbol = false;
                chiller_comm_symbol_changed = true;
              }
            }
            else if (p_msg->cmd1 == "change_set_temperature")
            { //configbutton wurde gedr�ckt
              //Die Fenster aktivieren/deaktivieren:
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("change_temp_1", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "s_temp_2")
            { // Der User moechte die Set-Temperatur Nr. 1 aendern
              //Temperatur zum editieren ans Keyboard schicken:
              //Die Fenster aktivieren/deaktivieren:
              if ((!chiller_locked) && (p_msg->origin != "display_1"))
              {
                p_CDisplaymanager->set_state(&name, INACTIVE);
                p_CDisplaymanager->set_state("keyboard", JUST_ACTIVATED);
                //Keyboard die gewuenschten Parameter zukommen lassen:
                p2_msg = NULL;//p_displaymailbox->take_free_msg();
                if(p2_msg != NULL)
                {
                  p2_msg->cmd1 = "F2"; //Float, signed, zwei Nachkommastellen
                  p2_msg->cmd2 = "set_temp_2"; //Parametername
                  p2_msg->f_number[0] = set_temp_2[0]; //aktueller Wert
                  p2_msg->f_number[1] = set_temp_2[1]; //upper limit
                  p2_msg->f_number[2] = set_temp_2[2]; //lower limit
                  p2_msg->origin = "mainmenu";
                  p2_msg->dest = "keyboard";
                }
              }
            }
            else if (p_msg->cmd1 == "s_temp_3")
            { // Der User moechte die Set-Temperatur Nr. 1 aendern
              //Temperatur zum editieren ans Keyboard schicken:
              //Die Fenster aktivieren/deaktivieren:
              if (!chiller_locked)
              {
                p_CDisplaymanager->set_state(&name, INACTIVE);
                p_CDisplaymanager->set_state("keyboard", JUST_ACTIVATED);
                //Keyboard die gewuenschten Parameter zukommen lassen:
                p2_msg = NULL;//p_displaymailbox->take_free_msg();
                if(p2_msg != NULL)
                {
                  p2_msg->cmd1 = "F2"; //Float, signed, zwei Nachkommastellen
                  p2_msg->cmd2 = "set_temp_3"; //Parametername
                  p2_msg->f_number[0] = set_temp_3[0]; //aktueller Wert
                  p2_msg->f_number[1] = set_temp_3[1]; //upper limit
                  p2_msg->f_number[2] = set_temp_3[2]; //lower limit
                  p2_msg->origin = "mainmenu";
                  p2_msg->dest = "keyboard";
                }
              }
            }
            else if (p_msg->cmd1 == "s_temp_4")
            { // Der User moechte die Set-Temperatur Nr. 1 aendern
              //Temperatur zum editieren ans Keyboard schicken:
              //Die Fenster aktivieren/deaktivieren:
              if (!chiller_locked)
              {
                p_CDisplaymanager->set_state(&name, INACTIVE);
                p_CDisplaymanager->set_state("keyboard", JUST_ACTIVATED);
                //Keyboard die gewuenschten Parameter zukommen lassen:
                p2_msg = NULL;//p_displaymailbox->take_free_msg();
                if(p2_msg != NULL)
                {
                  p2_msg->cmd1 = "F2"; //Float, signed, zwei Nachkommastellen
                  p2_msg->cmd2 = "set_temp_4"; //Parametername
                  p2_msg->f_number[0] = set_temp_4[0]; //aktueller Wert
                  p2_msg->f_number[1] = set_temp_4[1]; //upper limit
                  p2_msg->f_number[2] = set_temp_4[2]; //lower limit
                  p2_msg->origin = "mainmenu";
                  p2_msg->dest = "keyboard";
                }
              }
            }
            else if (   p_msg->cmd1 == "set_temp_2")
            { // Es wurde eine neue Setz-Temperatur von irgendwo her uebertragen
              //if(set_temp_2[0] != p_msg->f_number[0])
              if ((!chiller_locked) && (p_msg->origin != "display_1"))
              {
                if(!float_equal(set_temp_2[0], p_msg->f_number[0], 1))
                {
                  set_temp_2[0] = p_msg->f_number[0];
                  set_temp_2_changed = true;
                  //Die neue Setz-Temperatur kurz dem "system" mitteilen:
                  p2_msg = NULL;//p_displaymailbox->take_free_msg();
                  if(p2_msg != NULL)
                  {
                    p2_msg->cmd1 = "set_temp_2_changed";
                    p2_msg->f_number[0] = set_temp_2[0];
                    p2_msg->origin = name;
                    p2_msg->dest = "system";
                  }
                }
              }
            }
            else if (   p_msg->cmd1 == "set_temp_3")
            { // Es wurde eine neue Setz-Temperatur von irgendwo her uebertragen
              //if (set_temp_3[0] != p_msg->f_number[0])
              if ((!chiller_locked) && (p_msg->origin != "display_1"))
              {
                if(!float_equal(set_temp_3[0], p_msg->f_number[0], 1))
                {
                  set_temp_3[0] = p_msg->f_number[0];
                  set_temp_3_changed = true;
                  //Die neue Setz-Temperatur kurz dem "system" mitteilen:
                  p2_msg = NULL;//p_displaymailbox->take_free_msg();
                  if(p2_msg != NULL)
                  {
                    p2_msg->cmd1 = "set_temp_3_changed";
                    p2_msg->f_number[0] = set_temp_3[0];
                    p2_msg->origin = name;
                    p2_msg->dest = "system";
                  }
                }
              }
            }
            else if (p_msg->cmd1 == "set_temp_4")
            { // Es wurde eine neue Setz-Temperatur von irgendwo her uebertragen
              //if (set_temp_4[0] != p_msg->f_number[0])
              if ((!chiller_locked) && (p_msg->origin != "display_1"))
              {
                if(!float_equal(set_temp_4[0], p_msg->f_number[0], 1))
                {
                  set_temp_4[0] = p_msg->f_number[0];
                  set_temp_4_changed = true;
                  //Die neue Setz-Temperatur kurz dem "system" mitteilen:
                  p2_msg = NULL;//p_displaymailbox->take_free_msg();
                  if(p2_msg != NULL)
                  {
                    p2_msg->cmd1 = "set_temp_4_changed";
                    p2_msg->f_number[0] = set_temp_4[0];
                    p2_msg->origin = name;
                    p2_msg->dest = "system";
                  }
                }
              }
            }
            else if (   p_msg->cmd1 == "set_version_info")
            { // Es wurde eine neue Setz-Temperatur von irgendwo her uebertragen
              version_info = p_msg->cmd2;
              version_info_changed = true;
            }
            else if (   p_msg->cmd1 == "controller_mode")
            { // Es wurde ein neuer Chiller-status von irgendwo her uebertragen
              if (controller_mode != p_msg->cmd2)
              {
                controller_mode = p_msg->cmd2;
                controller_mode_changed = true;
              }
              /*
              //"diagnose_1" interessiert sich ebenfalls fuer den Chillerstatus:
              p2_msg = p_displaymailbox->take_free_msg();
              if(p2_msg != NULL)
              {
                p2_msg->cmd1 = p_msg->cmd1;
                p2_msg->cmd2 = p_msg->cmd2;
                p2_msg->origin = "mainmenu";
                p2_msg->dest = "diagnose_1";
              }
              */
            }
            else if (   p_msg->cmd1 == "set_limits_1")
            { // Es wurden Set-Temp-Grenzen irgendwo her uebertragen
			set_temp_1[1] = p_msg->f_number[0]; //upper limit
			set_temp_1[2] = p_msg->f_number[1]; //lower limit
            }
            else if (   p_msg->cmd1 == "set_limits_2")
            { // Es wurden Set-Temp-Grenzen irgendwo her uebertragen
			set_temp_2[1] = p_msg->f_number[0]; //upper limit
			set_temp_2[2] = p_msg->f_number[1]; //lower limit
            }
            else if (   p_msg->cmd1 == "set_limits_3")
            { // Es wurden Set-Temp-Grenzen irgendwo her uebertragen
			set_temp_3[1] = p_msg->f_number[0]; //upper limit
			set_temp_3[2] = p_msg->f_number[1]; //lower limit
            }
            else if (   p_msg->cmd1 == "set_limits_4")
            { // Es wurden Set-Temp-Grenzen irgendwo her uebertragen
			set_temp_4[1] = p_msg->f_number[0]; //upper limit
			set_temp_4[2] = p_msg->f_number[1]; //lower limit
            }
            else if (   p_msg->cmd1 == "invalid_temp")
            { // Es wurden Set-Temp-Grenzen irgendwo her uebertragen
              if((p2_msg->f_number[0] < 5) && (p2_msg->f_number[0] >= 1))
              {
                chuck_temperature_valid[p2_msg->i_number[0]-1] = false;
                //number_changed[p2_msg->i_number[0]-1+4] = true;
                if (p2_msg->i_number[0] == 1) chuck_temp_1_changed = true;
                else if (p2_msg->i_number[0] == 2) chuck_temp_2_changed = true;
                else if (p2_msg->i_number[0] == 3) chuck_temp_3_changed = true;
                else chuck_temp_4_changed = true;
              }
            }
            else if (   p_msg->cmd1 == "temp_2")
            { // Es wurde eine neue Chuck/Air-Temperatur von  irgendwo her uebertragen
              //if (chuck_temp_2[0] != p_msg->f_number[0])
              if(!float_equal(chuck_temp_2[0], p_msg->f_number[0], 2))
              {
                chuck_temp_2[0] = p_msg->f_number[0];
                chuck_temp_2_changed = true;
                //"diagnose_1" interessiert sich ebenfalls fuer eine neue Temperatur 1:
                p2_msg = NULL;//p_displaymailbox->take_free_msg();
                if(p2_msg != NULL)
                {
                  p2_msg->cmd1 = p_msg->cmd1;
                  p2_msg->f_number[0] = p_msg->f_number[0];
                  p2_msg->origin = name;
                  p2_msg->dest = "diagnose_1";
                }
                chuck_temperature_valid[1] = true;
              }
            }
            else if (   p_msg->cmd1 == "temp_3")
            { // Es wurde eine neue Chuck/Air-Temperatur von irgendwo her uebertragen
              //if (chuck_temp_3[0] != p_msg->f_number[0])
              if(!float_equal(chuck_temp_3[0], p_msg->f_number[0], 2))
              {
                chuck_temp_3[0] = p_msg->f_number[0];
                chuck_temp_3_changed = true;
                //"diagnose_1" interessiert sich ebenfalls fuer eine neue Temperatur 1:
                p2_msg = NULL;//p_displaymailbox->take_free_msg();
                if(p2_msg != NULL)
                {
                  p2_msg->cmd1 = p_msg->cmd1;
                  p2_msg->f_number[0] = p_msg->f_number[0];
                  p2_msg->origin = name;
                  p2_msg->dest = "diagnose_1";
                }
                chuck_temperature_valid[2] = true;
              }
            }
            else if (   p_msg->cmd1 == "temp_4")
            { // Es wurde eine neue Chuck/Air-Temperatur von irgendwo her uebertragen
              //if (chuck_temp_4[0] != p_msg->f_number[0])
              if(!float_equal(chuck_temp_4[0], p_msg->f_number[0], 2))
              {
                chuck_temp_4[0] = p_msg->f_number[0];
                chuck_temp_4_changed = true;
                //"diagnose_1" interessiert sich ebenfalls fuer eine neue Temperatur 1:
                p2_msg = NULL;//p_displaymailbox->take_free_msg();
                if(p2_msg != NULL)
                {
                  p2_msg->cmd1 = p_msg->cmd1;
                  p2_msg->f_number[0] = p_msg->f_number[0];
                  p2_msg->origin = name;
                  p2_msg->dest = "diagnose_1";
                }
                chuck_temperature_valid[3] = true;
              }
            }
            else if (   p_msg->cmd1 == "status_temp_1")
            { // 
              if(p_msg->cmd2 == "heating") Temperature_status[0] = 4;
              else if(p_msg->cmd2 == "cooling") Temperature_status[0] = 2;
              else if(p_msg->cmd2 == "even") Temperature_status[0] = 3;
              else if(p_msg->cmd2 == "blank") Temperature_status[0] = 5;
              status_changed[0] = true;
            }
            else if (   p_msg->cmd1 == "status_temp_2")
            { // 
              if(p_msg->cmd2 == "heating") Temperature_status[1] = 4;
              else if(p_msg->cmd2 == "cooling") Temperature_status[1] = 2;
              else if(p_msg->cmd2 == "even") Temperature_status[1] = 3;
              else if(p_msg->cmd2 == "blank") Temperature_status[1] = 5;
              status_changed[1] = true;
            }
            else if (   p_msg->cmd1 == "status_temp_3")
            { // 
              if(p_msg->cmd2 == "heating") Temperature_status[2] = 4;
              else if(p_msg->cmd2 == "cooling") Temperature_status[2] = 2;
              else if(p_msg->cmd2 == "even") Temperature_status[2] = 3;
              else if(p_msg->cmd2 == "blank") Temperature_status[2] = 5;
              status_changed[2] = true;
            }
            else if (   p_msg->cmd1 == "status_temp_4")
            { // 
              if(p_msg->cmd2 == "heating") Temperature_status[3] = 4;
              else if(p_msg->cmd2 == "cooling") Temperature_status[3] = 2;
              else if(p_msg->cmd2 == "even") Temperature_status[3] = 3;
              else if(p_msg->cmd2 == "blank") Temperature_status[3] = 5;
              status_changed[3] = true;
            }
            else if (   p_msg->cmd1 == "key_lock_symbol")
            { // Es wurde eine neue Setz-Temperatur von irgendwo her uebertragen
              if((p_msg->cmd2 == "locked") && (chiller_locked == false)) chiller_locked = true;
              else if((p_msg->cmd2 == "open") && (chiller_locked == true)) chiller_locked = false;
              controller_mode_changed = true;
            }
            if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Unbekannte Nachricht als empfangen zurueckschicken...
            //Messwerte usw. Darstellen:
                /*
                p2_msg->cmd2 = "#MN53,"; //MnClearInvalidValue  = 53 ;Keyboard, ungueltiger Wert eingegeben, Warnung wieder loeschen
                for(int i=0; i<p2_msg->cmd2.size(); i++)
                {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data

                p2_msg->cmd2 = "#MN54,"; //MnKeyBoardClearInputField = 54
                for(int i=0; i<p2_msg->cmd2.size(); i++)
                {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data    
                */
          }


		 if (   set_temp_1_changed
                     || set_temp_2_changed
                     || set_temp_3_changed
                     || set_temp_4_changed )
                {
                  p2_msg = NULL;//p_displaymailbox->take_free_msg();
                  if (p2_msg != NULL)
                  {
                    p2_msg->dest = "display_1";  
                    p2_msg->origin = name;
                    p2_msg->cmd1 = "send_direct_cmd3_data";
                    while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use
                    
                    p2_msg->cmd2 = "#ZF22,#FZ24,22,";
                    //#ZR260,10,";
                    for(int i=0; i<p2_msg->cmd2.size(); i++)
                    {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                    
                    if (set_temp_1_changed)
                    {
                      while (!v_buffer->empty())v_buffer->pop_back();
                      p2_msg->cmd2 = "#MN59,"; //Clear Area:
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                     {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      p2_msg->cmd3.push_back('\x0A');
                        
                      p2_msg->cmd2 = "#ZR212,35,Set: "; //Set 1 Koordianten
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      
                      // doubleToVector(set_temp_1[0], v_buffer, 2, true);
                      floatToVector2((float)set_temp_1[0], v_buffer, 1, true, &buffer);
                      
                      for(int i=0; i<v_buffer->size(); i++)
                      {p2_msg->cmd3.push_back((char)v_buffer->at(i));}//copy data
                      p2_msg->cmd3.push_back('\x0A');
                    }
                    if (set_temp_2_changed)
                    {
                      while (!v_buffer->empty())v_buffer->pop_back();
                      p2_msg->cmd2 = "#MN60,"; //Clear Area:
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      p2_msg->cmd3.push_back('\x0A');
                    
                      p2_msg->cmd2 = "#ZR212,107,Set: "; //Set 2 Koordianten
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      doubleToVector(set_temp_2[0], v_buffer, 2, true);
                      for(int i=0; i<v_buffer->size(); i++)
                      {p2_msg->cmd3.push_back((char)v_buffer->at(i));}//copy data
                      p2_msg->cmd3.push_back('\x0A');
                    }
                    if (set_temp_3_changed)
                    {
                      while (!v_buffer->empty())v_buffer->pop_back();
                      p2_msg->cmd2 = "#MN61,"; //Clear Area:
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      p2_msg->cmd3.push_back('\x0A');
                    
                      p2_msg->cmd2 = "#ZR212,180,Set: "; //Set 3 Koordianten
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      doubleToVector(set_temp_3[0], v_buffer, 2, true);
                      for(int i=0; i<v_buffer->size(); i++)
                      {p2_msg->cmd3.push_back((char)v_buffer->at(i));}//copy data
                      p2_msg->cmd3.push_back('\x0A');
                    }
                    if (set_temp_4_changed)
                    {
                      while (!v_buffer->empty())v_buffer->pop_back();
                      p2_msg->cmd2 = "#MN62,"; //Clear Area:
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      p2_msg->cmd3.push_back('\x0A');
                    
                      p2_msg->cmd2 = "#ZR212,253,Set: "; //Set 4 Koordianten
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      doubleToVector(set_temp_4[0], v_buffer, 2, true);
                      for(int i=0; i<v_buffer->size(); i++)
                      {p2_msg->cmd3.push_back((char)v_buffer->at(i));}//copy data
                      p2_msg->cmd3.push_back('\x0A');
                    }
                  }
                  set_temp_1_changed = false;
                  set_temp_2_changed = false;
                  set_temp_3_changed = false;
                  set_temp_4_changed = false;
                  //for(int i=0;i<4;i++)number_changed[i]=false;
                }


          
          
            if (   chuck_temp_1_changed
                || chuck_temp_2_changed
                || chuck_temp_3_changed
                || chuck_temp_4_changed
                  )
            {
                  p2_msg = NULL;//p_displaymailbox->take_free_msg();
                  if (p2_msg != NULL)
                  {
                    p2_msg->dest = "display_1";  
                    p2_msg->origin = name;
                    p2_msg->cmd1 = "send_direct_cmd3_data";
                    while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use
                    
                    p2_msg->cmd2 = "#ZF19,";
                    //#ZR260,10,";
                    for(int i=0; i<p2_msg->cmd2.size(); i++)
                    {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                    
                    if (chuck_temp_1_changed)
                    {
                      while (!v_buffer->empty())v_buffer->pop_back();
                      /*
                      p2_msg->cmd2 = "#AL120,0,#MN55,"; //Clear Area:
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                     {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                     */
                       p2_msg->cmd2 = "#FZ1,8,"; //Black
                       for(int i=0; i<p2_msg->cmd2.size(); i++)
                       {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                       
                      if (chuck_temperature_valid[0])
                      {
                      p2_msg->cmd2 = "#ZR160,61,"; //Set 1 Koordianten
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      //doubleToVector(chuck_temp_1[0], v_buffer, 2, true);
                      floatToVector3((float)chuck_temp_1[0], v_buffer, 2, 7, true, &c_buffer);
                      for(int i=0; i<v_buffer->size(); i++)
                      {p2_msg->cmd3.push_back((char)v_buffer->at(i));}//copy data
                      }
                      else
                      {
                      p2_msg->cmd2 = "#ZR160,61,--.--"; //Set 1 Koordianten
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      }
                      p2_msg->cmd3.push_back('\x0A');
                      chuck_temp_1_changed = false;
                    }
                  }

                  //p2_msg = p_displaymailbox->take_free_msg();
                  //if (p2_msg != NULL)
                  {
                    //p2_msg->dest = "display_1";  
                    //p2_msg->origin = name;
                    //p2_msg->cmd1 = "send_direct_cmd3_data";
                    //while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use 
                    if (chuck_temp_2_changed)
                    {
                      while (!v_buffer->empty())v_buffer->pop_back();
                      /*
                      p2_msg->cmd2 = "#AL3,0,#MN56,"; //
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      */
                      p2_msg->cmd2 = "#FZ1,8,"; //Black
                       for(int i=0; i<p2_msg->cmd2.size(); i++)
                       {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                       
                     if (chuck_temperature_valid[1])
                      {
                        p2_msg->cmd2 = "#ZR160,134,"; //Set 2 Koordianten
                        for(int i=0; i<p2_msg->cmd2.size(); i++)
                        {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                        //doubleToVector(chuck_temp_2[0], v_buffer, 2, true);
                        floatToVector3((float)chuck_temp_2[0], v_buffer, 2, 7, true, &c_buffer);
                        for(int i=0; i<v_buffer->size(); i++)
                        {p2_msg->cmd3.push_back((char)v_buffer->at(i));}//copy data
                      }
                      else
                      {
                        p2_msg->cmd2 = "#ZR160,134,--.--"; //Set 1 Koordianten
                        for(int i=0; i<p2_msg->cmd2.size(); i++)
                        {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      }
                      p2_msg->cmd3.push_back('\x0A');
                      chuck_temp_2_changed = false;
                    }
                  }
                  
                  p2_msg = NULL;//p_displaymailbox->take_free_msg();
                  if (p2_msg != NULL)
                  {
                    p2_msg->dest = "display_1";  
                    p2_msg->origin = name;
                    p2_msg->cmd1 = "send_direct_cmd3_data";
                    while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use 
                    if (chuck_temp_3_changed)
                    {
                      while (!v_buffer->empty())v_buffer->pop_back();
                      /*
                      p2_msg->cmd2 = "#AL132,0,#MN57,"; //
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      */
                       p2_msg->cmd2 = "#FZ1,8,"; //Black
                       for(int i=0; i<p2_msg->cmd2.size(); i++)
                       {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                       
                     if (chuck_temperature_valid[2])
                      {
                      p2_msg->cmd2 = "#ZR160,207,"; //Set 3 Koordianten
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      //doubleToVector(chuck_temp_3[0], v_buffer, 2, true);
                      floatToVector3((float)chuck_temp_3[0], v_buffer, 2, 7, true, &c_buffer);
                      for(int i=0; i<v_buffer->size(); i++)
                      {p2_msg->cmd3.push_back((char)v_buffer->at(i));}//copy data
                      }
                      else
                      {
                      p2_msg->cmd2 = "#ZR160,207,--.--"; //Set 1 Koordianten
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      }
                      p2_msg->cmd3.push_back('\x0A');
                      chuck_temp_3_changed=false;
                    }
                  }
                  
                  //p2_msg = p_displaymailbox->take_free_msg();
                  //if (p2_msg != NULL)
                  {
                    //p2_msg->dest = "display_1";  
                    //p2_msg->origin = name;
                    //p2_msg->cmd1 = "send_direct_cmd3_data";
                    //while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use
                    if (chuck_temp_4_changed)
                    {
                      while (!v_buffer->empty())v_buffer->pop_back();
                      /*
                      p2_msg->cmd2 = "#AL134,0,#MN58,"; //
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      */
                      p2_msg->cmd2 = "#FZ1,8,"; //Black
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      
                     if (chuck_temperature_valid[3])
                      {
                      p2_msg->cmd2 = "#ZR160,280,"; //Set 4 Koordianten
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      //doubleToVector(chuck_temp_4[0], v_buffer, 2, true);
                      floatToVector3((float)chuck_temp_4[0], v_buffer, 2, 7, true, &c_buffer);
                      for(int i=0; i<v_buffer->size(); i++)
                      {p2_msg->cmd3.push_back((char)v_buffer->at(i));}//copy data
                      }
                      else
                      {
                      p2_msg->cmd2 = "#ZR160,280,--.--"; //Set 1 Koordianten
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                      }
                      p2_msg->cmd3.push_back('\x0A');
                      chuck_temp_4_changed=false;                     
                    }
                  }
                  //for(int i=4;i<8;i++)number_changed[i]=false;
            }

            //Abarbeiten der normalen Symbole:
            //(Even, Heating, Cooling, [Das blinkende Symbol ausgeschlossen!])
            if (   status_changed[0]
                || status_changed[1]
                || status_changed[2]
                || status_changed[3]
                || controller_mode_changed
                || warning_symbol_changed )
            {
              p2_msg = NULL;//p_displaymailbox->take_free_msg();
              if (p2_msg != NULL)
              {
                p2_msg->dest = "display_1";  
                p2_msg->origin = name;
                p2_msg->cmd1 = "send_direct_cmd3_data";
                while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use
                
                if(controller_mode_changed)
                  {
                    while (!v_buffer->empty())v_buffer->pop_back();
                    pushing_back(&(p2_msg->cmd3), "#MN49,#ZF19,#FZ1,0,#ZC110,360,", sizeof("#MN49,#ZF19,#FZ1,0,#ZC110,360,")-1);//MnClearChillerStatusArea = 49
                
                    for(int i=0; i<controller_mode.size(); i++)
                    {p2_msg->cmd3.push_back((char)controller_mode[i]);}//copy data
                    p2_msg->cmd3.push_back('\x0A');
                    controller_mode_changed = false;
                    
                    if(chiller_locked)
                    {
                      p2_msg->cmd2 = "#UI214,354,6,";
                    }
                    else
                    {
                      p2_msg->cmd2 = "#UI214,354,7,";
                    }
                    for(int k=0; k<p2_msg->cmd2.size(); k++)
                    {p2_msg->cmd3.push_back((char)p2_msg->cmd2[k]);}//copy data
                  }
                
                if (warning_symbol_changed)
                { 
                  pushing_back(&(p2_msg->cmd3), "#UT0,#FE0,0,0,0,0,0,", sizeof("#UT0,#FE0,0,0,0,0,0,")-1); //B_warning = 137
                  
                  if (warning_symbol)
                  {//roten 'ball' anzeigen und Touchbereich definieren
                    if (alignment)
                    {//Vertikal)
                      pushing_back(&(p2_msg->cmd3), "#UI133,414,8,#AT133,414,183,464,137,0,", sizeof("#UI133,414,8,#AT133,414,183,464,137,0,")-1);//B_warning = 137 #Original#
                    }
                    else
                    {//Horizontal
                      pushing_back(&(p2_msg->cmd3), "#UI130,205,8,#AT130,205,180,255,137,0,", sizeof("#UI130,205,8,#AT130,205,180,255,137,0,")-1);
                      //#UI 130,205,8
                    }
                  }
                  else
                  {//roten 'ball' ueberschreiben und Touchbereich loeschen
                    if (alignment)
                    {
                      pushing_back(&(p2_msg->cmd3), "#AL137,0,#UI133,414,9,", sizeof("#AL137,0,#UI133,414,9,")-1);
                    }
                    else
                    {//Horizontal
                      pushing_back(&(p2_msg->cmd3), "#AL137,0,#UI130,205,9,", sizeof("#AL137,0,#UI130,205,9,")-1);
                    }
                  }

                  if (warning_symbol) p2_msg->cmd3.push_back('\x0A');
                  warning_symbol_changed = false;
                }
                
                for (char i=0;i<4;i++)
                {
                  if(status_changed[i] == true)
                  {
                    if (i == 0) p2_msg->cmd2 = "#UI166,54,"; //Prepare Temp-Status-Symbol-Coordinates
                    else if (i == 1) p2_msg->cmd2 = "#UI166,127,";
                    else if (i == 2) p2_msg->cmd2 = "#UI166,200,";
                    else if (i == 3) p2_msg->cmd2 = "#UI166,273,";
                    for(int k=0; k<p2_msg->cmd2.size(); k++)
                    {p2_msg->cmd3.push_back((char)p2_msg->cmd2[k]);}//copy data
                    
                    if(Temperature_status[i] == 2) p2_msg->cmd3.push_back('2');// 2 Cooling
                    else if(Temperature_status[i] == 3) p2_msg->cmd3.push_back('3');// 3 Even
                    else if(Temperature_status[i] == 4) p2_msg->cmd3.push_back('4');// 4 heating
                    else if(Temperature_status[i] == 5) p2_msg->cmd3.push_back('5');// 5 blank
                    else p2_msg->cmd3.push_back('5'); //Sollte nicht eintreten, kann aber, und Falls doch schmiert zumindest nichts ab...
                    p2_msg->cmd3.push_back(',');
                    status_changed[(int)i] = false;
                  }
                }
              }
            }
          
            if (   version_info_changed
                || chiller_comm_symbol_changed)
            {
              p2_msg = NULL;//p_displaymailbox->take_free_msg();
              if (p2_msg != NULL)
              {
                p2_msg->dest = "display_1";  
                p2_msg->origin = name;
                p2_msg->cmd1 = "send_direct_cmd3_data";
                while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use
                
                if (version_info_changed)
                {
                  pushing_back(&(p2_msg->cmd3), "#FZ9,0,#ZF5,#ZL0,469,", sizeof("#FZ9,0,#ZF5,#ZL0,469,")-1);
                  
                  for(int k=0; k<version_info.size(); k++)
                  {p2_msg->cmd3.push_back(version_info[k]);}//copy data
                  p2_msg->cmd3.push_back('\x0A');
                  version_info_changed = false;
                }
                if (chiller_comm_symbol_changed)
                {
                  if (chiller_comm_symbol) pushing_back(&(p2_msg->cmd3), "#UT1,#UI224,277,11,", sizeof("#UT1,#UI224,277,11,")-1);//ON
                  else pushing_back(&(p2_msg->cmd3), "#UT1,#UI224,277,10,", sizeof("#UT1,#UI224,277,10,")-1);//OFF
                  chiller_comm_symbol_changed = false;
                }
              }
            }
              
          
          break;
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
        /*
        if (p_msg != NULL)
        {
          if (p_msg->cmd1 == "config")
          {
            p_CDisplaymanager->set_state(&name, INACTIVE);
            p_CDisplaymanager->set_state("pin_request_1", JUST_ACTIVATED);
            p_displaymailbox->trashmark(p_msg); //Trash zurueckschicken
          }
        }
        */
}

Pin_Req_1::Pin_Req_1()
{
  actual_pin_input.reserve(4);
  unlock_pin.reserve(4);
  diagnose_pin.reserve(4);
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
  unlock_pin.assign("1234","1234"+4);
  diagnose_pin.assign("5678","5678"+4);
  network_config_pin.assign("4152","4152"+4);
  bool pin_changed = false;
  alignment = false; //false = horizontal, true = vertical
  s_cmd.reserve(32);
  direct_cmd.reserve(64);
//  diagnose_pin
}

void Pin_Req_1::Init( CEventManager * p_EventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  m_pEventManager = p_EventManager;
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
  alignment = b_alignment;
  //EventHandler
  m_pEventManager->AddEventHandler( CEventNames::pin_request_1, Pin_Req_1::pin_request_1EventWrapper, this);
  m_pEventManager->AddEventHandler( CEventNames::option_button_config, Pin_Req_1::option_button_configEventWrapper, this);  

}

void Pin_Req_1::pin_request_1Event( _string s )
{
    if (s == "clr")
    {
        while (!actual_pin_input.empty())actual_pin_input.pop_back();
        pin_changed= true;
    }
    else if (s == "backspace")
    {
        actual_pin_input.pop_back();
        pin_changed= true;
    }
    else if (s == "enter")
    {
      if(actual_pin_input == diagnose_pin) //Es wurde der richtige Pin fuers Diagnosefenster eingegeben
      {
        p_CDisplaymanager->set_state(&name, INACTIVE);
        p_CDisplaymanager->set_state("diagnose_1", JUST_ACTIVATED);
        //_event<bool> b( "Pin_Req_1", CEventNames::user_entered_diag, true );
        //m_pEventManager->RaiseEvent(b);
      }
      else if(actual_pin_input == network_config_pin) //Es wurde der richtige Pin fuers Diagnosefenster eingegeben
      {
        p_CDisplaymanager->set_state(&name, INACTIVE);
        p_CDisplaymanager->set_state("system_setup_1", JUST_ACTIVATED);
      }
      else if(actual_pin_input == unlock_pin) //Es wurde der richtige Pin fuer Display-Unlock eingegeben
      {
        p_CDisplaymanager->set_state(&name, INACTIVE);
        p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
        _event<bool> b( "Pin_Req_1", CEventNames::display_unlocked, true );
        m_pEventManager->RaiseEvent(b);
      }
      else
      { //Show the red 'WRONG CODE'-Warning (Falsche Pin eingegeben)
        while (!direct_cmd.empty())direct_cmd.pop_back();          
        s_cmd = "#MN34,"; //MnShowWrongCode = 34
        for(int i=0; i<s_cmd.size(); i++)
        {direct_cmd.push_back((char)s_cmd[i]);}//copy data
        _event<void*> e("Pin_Req_1", CEventNames::send_direct_cmd3_data, &direct_cmd );
        m_pEventManager->RaiseEventSync(e);
      }
    }
    //Wenn es eine Ziffer aus der Tastatur ist
    else
    {
        char c = s.getBuffer()[0];
        if(actual_pin_input.size() < 4)
        {
            actual_pin_input.push_back(c);
            pin_changed= true;
        }
    }  
}
 
void Pin_Req_1::option_button_configEvent( bool b )

{ //configbutton wurde gedr�ckt
  //Die Fenster aktivieren/deaktivieren:
  p_CDisplaymanager->set_state(&name, INACTIVE);
  p_CDisplaymanager->set_state("opt_button_conf", JUST_ACTIVATED);
}

void Pin_Req_1::cycCalc()
{
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
	switch(state)
	{
	case INACTIVE:
            break;
	case JUST_ACTIVATED:
          //Bisher eingegebene Pin zuruecksetzen:
          while (!actual_pin_input.empty())actual_pin_input.pop_back();
          //"Ansicht wechseln" ans Display schicken...
          {
            s_cmd = "#MN30,";
            _event<void*> e( "Pin_Req_1", CEventNames::send_direct_cmd2_data, &s_cmd );
            m_pEventManager->RaiseEventSync(e);
          }
          state = ACTIVE;
          break;
          
	case ACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//NULL;//p_displaymailbox->name; //msg wieder einlagern
            }
            else if (p_msg->cmd1 == "escape")
            { //configbutton wurde gedr�ckt
              //Die Fenster aktivieren/deaktivieren:
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "user_config_page_1")
            { //configbutton wurde gedr�ckt
              //Die Fenster aktivieren/deaktivieren:
              p_CDisplaymanager->set_state(&name, INACTIVE);
              //p_CDisplaymanager->set_state("user_config_1", JUST_ACTIVATED);
              p_CDisplaymanager->set_state("user_config_entry", JUST_ACTIVATED);
            }
            
            if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Als Trash zurueckschicken
          }
        if (pin_changed)
        {
            while (!direct_cmd.empty())direct_cmd.pop_back();          
            s_cmd = "#MN33,"; //MnClearWrongCode = 33
            for(int i=0; i < s_cmd.size(); i++)
            {direct_cmd.push_back((char)s_cmd[i]);}//copy data

            s_cmd = "#MN32,"; //MnClearPinInputField = 32
            for(int i=0; i < s_cmd.size(); i++)
            {direct_cmd.push_back((char)s_cmd[i]);}//copy data                
            if (actual_pin_input.size() > 0)
            {
              if (alignment)
              { //vertical
                pushing_back(&direct_cmd, "#ZF100,#FZ8,0,#ZL61,29,", sizeof("#ZF100,#FZ8,0,#ZL61,29,")-1);
              }
              else
              { //horizontal
                pushing_back(&direct_cmd, "#ZF100,#FZ8,0,#ZL40,13,", sizeof("#ZF100,#FZ8,0,#ZL40,13,")-1);
              }
              
              for(int i=0; i<actual_pin_input.size();i++) //Text
              {
                direct_cmd.push_back(actual_pin_input[i]);
              }
            }
            direct_cmd.push_back('\x0A');
            _event<void*> e( "Pin_Req_1", CEventNames::send_direct_cmd3_data, &direct_cmd );
            m_pEventManager->RaiseEvent(e);
            pin_changed = false;                               
          }
        break;
          
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}

Assist_1::Assist_1()
{
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
  former_active_window.reserve(WINDOWSNAMES_SIZE);
}

void Assist_1::Init( CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
  found_active_window = false;
  display_update_in_progress = false;

    //MB ab hier EventHandler
    m_pEventManager = pEventManager;
    m_pEventManager->AddEventHandler( CEventNames::forward_to_active_window, Assist_1::forward_to_active_windowEventWrapper,this );
    m_pEventManager->AddEventHandler( CEventNames::display_update_finished, Assist_1::display_update_finishedEventWrapper,this );
  
}

//veraltet, assist wird langfristik rausfliegen
void Assist_1::forward_to_active_windowEvent( _string window )
{
  //Namen des aktiven Fensters ermitteln und zustellen:
  p_CDisplaymanager->it = p_CDisplaymanager->windowlist.begin();
  while (p_CDisplaymanager->it != p_CDisplaymanager->windowlist.end() //listenende erreicht
         && !((*p_CDisplaymanager->it)->state == ACTIVE) //aktives Fenster noch nicht gefunden
         && !((*p_CDisplaymanager->it)->state == JUST_ACTIVATED)) //gerade aktiviertes noch nicht Fenster gefunden
  {
    p_CDisplaymanager->it++;
  }
  //MB, wenn escape dann auf den fall neuezeichnen
  if( window == "escape" )
  {
    (*p_CDisplaymanager->it)->set_state( INACTIVE );
    if( (*p_CDisplaymanager->it)->name == "diagnose_1" || 
        (*p_CDisplaymanager->it)->name == "diagnose_2" || 
        (*p_CDisplaymanager->it)->name == "diagnose_3" || 
        (*p_CDisplaymanager->it)->name == "diagnose_4" || 
        (*p_CDisplaymanager->it)->name == "diagnose_5" 
//				(*p_CDisplaymanager->it)->name == "network_config_1"
        )
    {
        _event<bool> b( "Assist", CEventNames::user_left_diag, true);
        m_pEventManager->RaiseEvent(b);
    }
  }
  //p_msg->dest = (*p_CDisplaymanager->it)->name;
}

void Assist_1::display_update_finishedEvent( bool b )
{
    //Alten Zustand wieder herstellen:
    state = INACTIVE;
    display_update_in_progress = false;
    p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
}

void Assist_1::cycCalc()
{
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
	switch(state)
	{
	case INACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name;
            }
            else if (p_msg->cmd2 == "forward_to_active_window") //Nachricht soll an das aktuelle aktive Fenster weitergeleitet werden
            {
              //Namen des aktiven Fensters ermitteln und zustellen:
              p_CDisplaymanager->it = p_CDisplaymanager->windowlist.begin();
              while (p_CDisplaymanager->it != p_CDisplaymanager->windowlist.end() //listenende erreicht
                     && !((*p_CDisplaymanager->it)->state == ACTIVE) //aktives Fenster noch nicht gefunden
                     && !((*p_CDisplaymanager->it)->state == JUST_ACTIVATED)) //gerade aktiviertes noch nicht Fenster gefunden
              {
                p_CDisplaymanager->it++;
              }
              p_msg->dest = (*p_CDisplaymanager->it)->name;
            }
            else if (p_msg->cmd1 == "display_update")
            {
              //Namen des aktiven Fensters ermitteln und zwischenspeichern:
              p_CDisplaymanager->it = p_CDisplaymanager->windowlist.begin();
              while (p_CDisplaymanager->it != p_CDisplaymanager->windowlist.end() //listenende erreicht
                     && !((*p_CDisplaymanager->it)->state == ACTIVE) //aktives Fenster noch nicht gefunden
                     && !((*p_CDisplaymanager->it)->state == JUST_ACTIVATED)) //gerade aktiviertes Fenster noch nicht gefunden
              {
                p_CDisplaymanager->it++;
              }
              //<|1|> Sichern des Fenster -status und -namens
              former_active_window = (*p_CDisplaymanager->it)->name;
              former_windowstate =  (*p_CDisplaymanager->it)->state;
              display_update_in_progress = true; //Dieses Flag ist ggf. zukuenftig ueberhaupt nicht noetig. Wenn nicht verwendet, bitte loeschen, danke! :)
              //Aktives Fenster deaktivieren und Assistenten in den aktiven Modus schalten.
              //Wenn das Displayupdate abgeschlossen (oder nicht gestartet wegen fehlender Dateien) ist
              //kehrt der Assistent in den Inaktiven Modus zur�ck und aktiviert das vorher deaktivierte Fenster,
              //bzw. stellt den vorher gesichtern Fensterstatus weder her.
              //Der Abschluss des Updates wird dem Assistenten mit einer Nachricht vom Displaytreiber mitgeteilt.
              //<|2|> Uebergang zum warten auf den Displayabschluss einleiten:
              state = ACTIVE;
              p_CDisplaymanager->set_state(&name, INACTIVE);
              
              //Update beim Treiber einleiten:
              p2_msg = NULL;//p_displaymailbox->take_free_msg();
              if(p2_msg != NULL)
              {
                p2_msg->cmd1 = "display_update";
                p2_msg->origin = name;
                p2_msg->dest = "display_1";
              }
            }
            if ((p_msg->cmd1 != "trash") && (p_msg->cmd2 != "forward_to_active_window")) ;//p_displaymailbox->trashmark(p_msg); //Unbekannte Nachricht als empfangen zurueckschicken...
          }
          break;
	case JUST_ACTIVATED: // Dieser Fensterstatus wird derzeit nicht verwendet,
                             // und wird es wohl auch nie, da nicht zweckmaessig.
                             // Sollte dieser MOdus trotzdem verwendet werden MUSS GGF.
                             // der entsprechende Part des Displayupdates angepasst werden!
          break;
	case ACTIVE:
          //Das Assist-Window ist nahezu niemals Aktiv,
          //dies ist eine Ausnahme um den Displaymanager so lange
          //zu blockieren bis der Displaytreiber mit dem Update fertig ist.
          //(oder auch nicht, falls die entsprechenden Dateien nicht vorhanden sind)
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name;
            }
            else if (p_msg->cmd2 == "forward_to_active_window") //Nachricht soll an das aktuelle aktive Fenster weitergeleitet werden
            { // Dieser Part wird trotz eines laufenden Displayupdates auch
              // im aktiven Status ausgefuehrt, um die Kommunikation der
              // inaktiven Fenster Nicht zu beeinflussen.
              
              //Namen des aktiven Fensters ermitteln und zustellen:
              p_CDisplaymanager->it = p_CDisplaymanager->windowlist.begin();
              while (p_CDisplaymanager->it != p_CDisplaymanager->windowlist.end() //listenende erreicht
                     && !((*p_CDisplaymanager->it)->state == ACTIVE) //aktives Fenster noch nicht gefunden
                     && !((*p_CDisplaymanager->it)->state == JUST_ACTIVATED)) //gerade aktiviertes noch nicht Fenster gefunden
              {
                p_CDisplaymanager->it++;
              }
              p_msg->dest = (*p_CDisplaymanager->it)->name;
            }
            if ((p_msg->cmd1 != "trash") && (p_msg->cmd2 != "forward_to_active_window"));// p_displaymailbox->trashmark(p_msg); //Unbekannte Nachricht als empfangen zurueckschicken...
          }
          
          
          
          break;
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}


Config_Window_1::Config_Window_1()
{ //Sicherheitsinit
  //
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
}

void Config_Window_1::Init( CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
  //Registrieren der EventHandler
  m_pEventManager = pEventManager;
}

void Config_Window_1::cycCalc()
{
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
	switch(state)
	{
	case INACTIVE:
        break;
	case JUST_ACTIVATED:
          //"Ansicht wechseln" ans Display schicken...
          {
              s_cmd = "#MN28,"; //MnConfigWindow = 28
              _event<void*> e("Config_Window_1", CEventNames::send_direct_cmd2_data, &s_cmd );
              m_pEventManager->RaiseEventSync(e);
          }
          state = ACTIVE;
          break;
	case ACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name; //msg wieder einlagern
            }
            else if (p_msg->cmd1 == "escape")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "show_file_sys")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("show_file_system", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "display_update")
            {
              /*
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("pin_request_1", JUST_ACTIVATED);
              */
            }
            else if (p_msg->cmd1 == "controller_overview")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("controller_overview_1", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "switch_view")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("switchview_1", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "temperature_comp")
            {
              /*
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("pin_request_1", JUST_ACTIVATED);
              */
            }
          if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Als Trash zurueckschicken
          }
          break;
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}

Show_File_System_1::Show_File_System_1()
{ //Sicherheitsinit
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
}

void Show_File_System_1::Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  
  m_pEventManager = pEventManager;
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
  
  data_read = 0;
  filesize = 0;
  entrysize = 0;
}


void Show_File_System_1::cycCalc()
{
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
	switch(state)
	{
	case INACTIVE:
        break;
	case JUST_ACTIVATED:
          //"Ansicht wechseln" ans Display schicken...
          p2_msg = NULL;//p_displaymailbox->take_free_msg();
          if (p2_msg != NULL)
          {
            p2_msg->dest = "display_1";  
            p2_msg->origin = name;
            
            p2_msg->cmd1 = "#MN27,"; //MnShowFileSystem = 27
            
          }
          state = ACTIVE;
          break;
	case ACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name; //msg wieder einlagern
            }
            else if (p_msg->cmd1 == "escape")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "back")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("config_window", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "update_filesys_view")
            { 
              //-------- grab file ---------
                 //Clear Display, Read Filesystem and show the Files and Folders
                int Zeile = 0;
                int y_space = 12;
                int y_start = 16;
                
                //Clear Text areas and set Font-Config:
                p2_msg = NULL;//p_displaymailbox->take_free_msg();
                if (p2_msg != NULL)
                {
                  p2_msg->dest = "display_1";
                  p2_msg->origin = name;
                  p2_msg->cmd1 = "send_direct_cmd3_data";
                  while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use
                  p2_msg->cmd2 = "#MN35,"; //MnEraseBlackBoxesShowFilesys = 35 (Schwarze Felder loeschen)
                  for(int i=0; i<p2_msg->cmd2.size(); i++)
                  {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                  
                  p2_msg->cmd2 = "#ZL10,";
                  for(int i=0; i<p2_msg->cmd2.size(); i++)
                  {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                  sprintf(_acBuffer,"%d,",(y_start-6+y_space*Zeile)); //y ermitteln                  
                  for(int i=0; _acBuffer[i]!=0;i++) //Text in den vector kopieren
                  {p2_msg->cmd3.push_back(_acBuffer[i]);}
                  
                  pushing_back(&(p2_msg->cmd3), "type size     name", sizeof("type size     name")-1);
                  
                  p2_msg->cmd3.push_back('\x0A');// Textendezeichen
                  Zeile++;
                  
                  p2_msg->cmd2 = "#ZL10,";
                  for(int i=0; i<p2_msg->cmd2.size(); i++)
                  {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                  sprintf(_acBuffer,"%d,",(y_start+y_space*Zeile)); //y ermitteln                  
                  for(int i=0; _acBuffer[i]!=0;i++) //Text in den vector kopieren
                  {p2_msg->cmd3.push_back(_acBuffer[i]);}
                  p2_msg->cmd2 = "--------------------------";
                  pushing_back(&(p2_msg->cmd3), "--------------------------", sizeof("--------------------------")-1);
                  
                  p2_msg->cmd3.push_back('\x0A');// Textendezeichen
                  Zeile++;                
                }
                
                //Open Files:
                pDir = FS_OpenDir("");      // Open root directory of default device 
                if (pDir)
                {
                  do
                  {
                    pDirEnt = FS_ReadDir(pDir);
                    FS_DirEnt2Name(pDirEnt, acName);
                    FS_DirEnt2Attr(pDirEnt, &Attr);
                    entrysize = FS_DirEnt2Size(pDirEnt);
                    if ((void*)pDirEnt == NULL) break; // No more files
                  
                    p2_msg = NULL;//p_displaymailbox->take_free_msg();
                    if (p2_msg != NULL)
                    {
                      p2_msg->dest = "display_1";
                      p2_msg->origin = name;
                      p2_msg->cmd1 = "send_direct_cmd3_data";
                      while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use
                      p2_msg->cmd2 = "#ZL10,";
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                  
                      sprintf(_acBuffer,"%d,",(y_start+y_space*Zeile)); //y ermitteln                  
                      for(int i=0; _acBuffer[i]!=0;i++) //Text in den vector kopieren
                      {p2_msg->cmd3.push_back(_acBuffer[i]);}
                  
                      for(int i=0; i<9;i++) space[i] = ' '; space[9] = 0;
                      
                      if (entrysize<10) space[6] = 0;
                      else if (entrysize<100) space[5] = 0;
                      else if (entrysize<1000) space[4] = 0;
                      else if (entrysize<10000) space[3] = 0;
                      else if (entrysize<100000) space[2] = 0;
                      else if (entrysize<1000000) space[1] = 0;
                      
                      sprintf(_acBuffer,"%s  %d %s %s", 
                              (Attr & FS_ATTR_DIRECTORY) ? "Dir " : "File",
                              entrysize,
                              space,
                              acName);
                      for(int i=0; _acBuffer[i]!=0;i++) //Text in den vector kopieren
                      {p2_msg->cmd3.push_back(_acBuffer[i]);}                   
                      p2_msg->cmd3.push_back('\x0A');// Textendezeichen
                      Zeile++;
                    }
                  }while (1);
                  FS_CloseDir(pDir);
                }// diropen possible
              }// /msg
          if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Als Trash zurueckschicken
          }
          break;
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}

Diagnose_1::Diagnose_1()
{ //Sicherheitsinit
  
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
  compressor_status.reserve(25);
  controller_mode.reserve(25);
}

void Diagnose_1::Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  
  m_pEventManager = pEventManager;
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
  
  controller_mode = "-----";
  
  controller_mode_changed = true;
  /*
  chuck_temp_1[0] = 22222.0; //#LP#
  chuck_temp_2[0] = 22222.0;
  chuck_temp_3[0] = 22222.0;
  chuck_temp_4[0] = 22222.0;

  chiller_temp = 22222.0;
  */
  chuck_temp_1[0] = 22222.0;
  chuck_temp_2[0] = 22222.0;
  chuck_temp_3[0] = 22222.0;
  chuck_temp_4[0] = 22222.0;

  chiller_temp = 22222.0;
  
  chiller_temp_changed = true;
    
  compressor_status = "ON";
  compressor_status_changed = true;
}

void Diagnose_1::cycCalc()
{
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
	switch(state)
	{
	case INACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//NULL;//p_displaymailbox->name;
            }
            else if (   p_msg->cmd1 == "controller_mode")
            { // Es wurde eine Anfrage fuer die Aenderung des Chillerstatus von
              //irgendwo her uebertragen
                  controller_mode = p_msg->cmd2;
                  controller_mode_changed = true;
            }
            else if (p_msg->cmd1 == "new_controller_mode")
            { // Es wurde eine Anfrage fuer die Aenderung des Chillerstatus von
              //irgendwo her uebertragen
                // Die Anfrage fuer einen neuen Chillerstatus kurz
                // dem "system" mitteilen, sofern die Nachricht nicht
                // vom "system" selbst kam (z.B. vom Display oder Ethernet):
                  p2_msg = NULL;// p_displaymailbox->take_free_msg();
                  if(p2_msg != NULL)
                  {
                    p2_msg->cmd1 = "new_controller_mode";
                    p2_msg->cmd2 = p_msg->cmd2;
                    p2_msg->origin = name;
                    p2_msg->dest = "system";
                  }
            }
            else if (p_msg->cmd1 == "temp_1")
            { // Es wurde eine neue Chuck/Air-Temperatur von irgendwo her uebertragen
              chuck_temp_1[0] = p_msg->f_number[0];
            }
            else if (p_msg->cmd1 == "temp_2")
            { // Es wurde eine neue Chuck/Air-Temperatur von irgendwo her uebertragen
              chuck_temp_2[0] = p_msg->f_number[0];
            }
            else if (p_msg->cmd1 == "temp_3")
            { // Es wurde eine neue Chuck/Air-Temperatur von irgendwo her uebertragen
              chuck_temp_3[0] = p_msg->f_number[0];
            }
            else if (p_msg->cmd1 == "temp_4")
            { // Es wurde eine neue Chuck/Air-Temperatur von irgendwo her uebertragen
              chuck_temp_4[0] = p_msg->f_number[0];
            }
            else if (p_msg->cmd1 == "set_chiller_temperature")
            { // Es wurde eine neue Chiller-Temperatur von irgendwo her uebertragen
              chiller_temp = p_msg->f_number[0];
              chiller_temp_changed = true;
            }
            else if (p_msg->cmd1 == "compressor_status")
            { // Es wurde eine Anfrage fuer die Aenderung des Kompressorstatus von
              //irgendwo her uebertragen
              if(p_msg->cmd2 != compressor_status)
              {//Nur bei einem neuen Zustand taetig werden:
                if (p_msg->origin != "system")
                {
                // Die Anfrage fuer einen neuen Kompressorstatus kurz
                // dem "system" mitteilen, sofern die Nachricht nicht
                // vom "system" selbst kam (z.B. vom Display oder Ethernet):
                  p2_msg = NULL;//p_displaymailbox->take_free_msg();
                  if(p2_msg != NULL)
                  {
                    p2_msg->cmd1 = "compressor_status";
                    p2_msg->cmd2 = p_msg->cmd2;
                    p2_msg->origin = name;
                    p2_msg->dest = "system";
                  }
                }
                else
                {//Neuer Kompressorstatus wird gespeichert
                  compressor_status = p_msg->cmd2;
                  compressor_status_changed = true;
                }
              }
            }
          if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Unbekannte Nachricht als empfangen zurueckschicken...
          }
          break;
	case JUST_ACTIVATED:
          //"Ansicht wechseln" ans Display schicken...
          p2_msg = NULL;//p_displaymailbox->take_free_msg();
          if (p2_msg != NULL)
          {
            p2_msg->dest = "display_1";  
            p2_msg->origin = name;
            p2_msg->cmd1 = "#MN36,"; //MnDiagnose_1 = 36
          }
          for (int i=0;i<4;i++) temp_changed[i]=true;
          controller_mode_changed = true;
          compressor_status_changed = true;
          chiller_temp_changed = true;
          state = ACTIVE;
          break;
case ACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name; //msg wieder einlagern
            }
            else if (p_msg->cmd1 == "escape")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_1")
            {

            }
            else if (p_msg->cmd1 == "diag_page_2")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_2", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_3")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_3", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_4")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_4", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_5")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_5", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_6")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_6", JUST_ACTIVATED);
            }
            else if (   p_msg->cmd1 == "controller_mode")
            { // Es wurde eine Anfrage fuer die Aenderung des Controller-Mode von
              //irgendwo her uebertragen
                  controller_mode = p_msg->cmd2;
                  controller_mode_changed = true;
            }
            else if (p_msg->cmd1 == "new_controller_mode")
            { // Es wurde eine Anfrage fuer die Aenderung des Controller-Mode von
              //irgendwo her uebertragen
                // Die Anfrage fuer einen neuen Controller-Mode kurz
                // dem "system" mitteilen, sofern die Nachricht nicht
                // vom "system" selbst kam (z.B. vom Display oder Ethernet):
                  p2_msg = NULL;//p_displaymailbox->take_free_msg();
                  if(p2_msg != NULL)
                  {
                    p2_msg->cmd1 = "new_controller_mode";
                    p2_msg->cmd2 = p_msg->cmd2;
                    p2_msg->origin = name;
                    p2_msg->dest = "system";
                  }
            }
            else if (p_msg->cmd1 == "set_chiller_temperature")
            { // Es wurde eine neue Chiller-Temperatur von irgendwo her uebertragen
              chiller_temp = p_msg->f_number[0];
              chiller_temp_changed = true;
            }
            else if (p_msg->cmd1 == "temp_1")
            { // Es wurde eine neue Chuck/Air-Temperatur von irgendwo her uebertragen
              if (chuck_temp_1[0] != p_msg->f_number[0])
              {
                chuck_temp_1[0] = p_msg->f_number[0];
                temp_changed[0] = true;
              }
            }
            else if (p_msg->cmd1 == "temp_2")
            { // Es wurde eine neue Chuck/Air-Temperatur von irgendwo her uebertragen
              if (chuck_temp_2[0] != p_msg->f_number[0])
              {
                chuck_temp_2[0] = p_msg->f_number[0];
                temp_changed[1] = true;
              }
            }
            else if (p_msg->cmd1 == "temp_3")
            { // Es wurde eine neue Chuck/Air-Temperatur von irgendwo her uebertragen
              if (chuck_temp_3[0] != p_msg->f_number[0])
              {
                chuck_temp_3[0] = p_msg->f_number[0];
                temp_changed[2] = true;
              }
            }
            else if (p_msg->cmd1 == "temp_4")
            { // Es wurde eine neue Chuck/Air-Temperatur von irgendwo her uebertragen
              if (chuck_temp_4[0] != p_msg->f_number[0])
              {
                chuck_temp_4[0] = p_msg->f_number[0];
                temp_changed[3] = true;
              }
            }
            else if (p_msg->cmd1 == "compressor_status")
            { // Es wurde eine Anfrage fuer die Aenderung des Kompressorstatus von
              //irgendwo her uebertragen
              if(p_msg->cmd2 != compressor_status)
              {//Nur bei einem neuen Zustand taetig werden:
                if (p_msg->origin != "system")
                {
                // Die Anfrage fuer einen neuen Kompressorstatus kurz
                // dem "system" mitteilen, sofern die Nachricht nicht
                // vom "system" selbst kam (z.B. vom Display oder Ethernet):
                  p2_msg = NULL;//p_displaymailbox->take_free_msg();
                  if(p2_msg != NULL)
                  {
                    p2_msg->cmd1 = "compressor_status";
                    p2_msg->cmd2 = p_msg->cmd2;
                    p2_msg->origin = name;
                    p2_msg->dest = "system";
                  }
                }
                else
                {//Neuer Kompressorstatus wird gespeichert
                  compressor_status = p_msg->cmd2;
                  compressor_status_changed = true;
                }
              }
            }
            else if (p_msg->cmd1 == "controller_mode")
            { // Es wurde eine Anfrage fuer die Aenderung des Chillerstatus von
              //irgendwo her uebertragen
                  controller_mode = p_msg->cmd2;
                  controller_mode_changed = true;
            }
          if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Unbekannte Nachricht als empfangen zurueckschicken...
            
          
          }
          
          if(controller_mode_changed || compressor_status_changed || chiller_temp_changed)
            {
              p2_msg = NULL;//p_displaymailbox->take_free_msg();
              if (p2_msg != NULL)
              {
                p2_msg->dest = "display_1";  
                p2_msg->origin = name;
                p2_msg->cmd1 = "send_direct_cmd3_data";
                while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use
                
                p2_msg->cmd2 = "#MN67,"; //MnClearDiag_1ChillerStatus = 67
                for(int i=0; i<p2_msg->cmd2.size(); i++)
                {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                
                    p2_msg->cmd2 = "#ZC206,12,"; 
                    for(int i=0; i<p2_msg->cmd2.size(); i++)
                    {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                
                    for(int i=0; i<controller_mode.size(); i++)
                    {p2_msg->cmd3.push_back((char)controller_mode[i]);}//copy data
                    p2_msg->cmd3.push_back('\x0A');
                    controller_mode_changed = false;
                

                    p2_msg->cmd2 = "#ZC184,115,";
                    for(int i=0; i<p2_msg->cmd2.size(); i++)
                    {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                
                    for(int i=0; i<compressor_status.size(); i++)
                    {p2_msg->cmd3.push_back((char)compressor_status[i]);}//copy data
                    p2_msg->cmd3.push_back('\x0A');
                    compressor_status_changed = false;
                
                //---
                
                //if(chiller_temp_changed)
                //{
                  
                  //p_msg = p_displaymailbox->take_free_msg();
                  //if (p_msg != NULL)
                  //{
                    while (!v_buffer->empty())v_buffer->pop_back(); //empty the vector before use
                    
                    p2_msg->cmd2 = "#ZC206,73,"; //MnClearChillerStatusArea = 49
                    for(int i=0; i<p2_msg->cmd2.size(); i++)
                    {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                
                    if (chiller_temp != 22222.0)
                    {
                      doubleToVector(chiller_temp, v_buffer, 2, true);
                    }
                    else
                    {
                      v_buffer->push_back('X');
                    }
                    for(int k=0; k<v_buffer->size(); k++)
                    {p2_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                    
                    p2_msg->cmd3.push_back('\x0A');
                  
                    chiller_temp_changed = false;  
               // }
              }
            }

          if(temp_changed[0]
             || temp_changed[1]
             || temp_changed[2]
             || temp_changed[3])
            {
              //Aktueller Nachrichtenrahmen koennte in Zukunft die Display-Buffergroesse sprengen,
              //deswegen wird hier eine weitere Nachricht erstellt:
              p_msg = NULL;//p_displaymailbox->take_free_msg();
              if (p_msg != NULL)
              {
                p_msg->dest = "display_1";  
                p_msg->origin = name;
                p_msg->cmd1 = "send_direct_cmd3_data";
                while (!p_msg->cmd3.empty())p_msg->cmd3.pop_back();
                
                p_msg->cmd2 = "#ZF21,#FZ1,0,";
                for(int k=0; k<p_msg->cmd2.size(); k++)
                {p_msg->cmd3.push_back((char)p_msg->cmd2[k]);}//copy data
                
                for (char i=0;i<4;i++)
                {
                  //if(temp_changed[i] == true)
                  {
                    while (!v_buffer->empty())v_buffer->pop_back();
                    if (i == 0) p_msg->cmd2 = "#RR128,210,248,241,#ZR242,217,";
                    else if (i == 1) p_msg->cmd2 = "#RR128,241,248,272,#ZR242,248,";
                    else if (i == 2) p_msg->cmd2 = "#RR128,272,248,303,#ZR242,279,";
                    else if (i == 3) p_msg->cmd2 = "#RR128,303,248,334,#ZR242,310,";
                    for(int k=0; k<p_msg->cmd2.size(); k++)
                    {p_msg->cmd3.push_back((char)p_msg->cmd2[k]);}//copy data
                    
                    if (i == 0) 
                    {
                      if (chuck_temp_1[0] != 22222.0)
                      {
                        doubleToVector(chuck_temp_1[0], v_buffer, 2, true);
                      }
                      else
                      {
                        v_buffer->push_back('X');
                      }
                    }
                    else if (i == 1) 
                    {
                      if (chuck_temp_2[0] != 22222.0)
                      {
                        doubleToVector(chuck_temp_2[0], v_buffer, 2, true);
                      }
                      else
                      {
                        v_buffer->push_back('X');
                      }
                    }
                    else if (i == 2) 
                    {
                      if (chuck_temp_3[0] != 22222.0)
                      {
                        doubleToVector(chuck_temp_3[0], v_buffer, 2, true);
                      }
                      else
                      {
                        v_buffer->push_back('X');
                      }
                    }
                    else if (i == 3) 
                    {
                      if (chuck_temp_4[0] != 22222.0)
                      {
                        doubleToVector(chuck_temp_4[0], v_buffer, 2, true);
                      }
                      else
                      {
                        v_buffer->push_back('X');
                      }
                    }
                    for(int k=0; k<v_buffer->size(); k++)
                    {p_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                    p_msg->cmd3.push_back('\x0A');
                    
                    temp_changed[(int)i] = false;
                  }
                }
              }
            }
          break;
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}

Diagnose_2::Diagnose_2()
{ //Sicherheitsinit
  
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
}

void Diagnose_2::Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  
  m_pEventManager = pEventManager;
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
 
  cool_air_set_value[0] = 22222; //-> actual value
  cool_air_set_value[1] = 233;//-> upper limit
  cool_air_set_value[2] = 0;//-> lower limit
  cool_air_actual_flow = 22222;//The current flow through the valve
  cool_air_set_value_changed = false;

  warm_air_set_value[0] = 22222; //-> actual value
  warm_air_set_value[1] = 370; //-> upper limit
  warm_air_set_value[2] = 0; //-> lower limit
  warm_air_actual_flow = 22222;//The current flow through the valve
  bool warm_air_set_value_changed = false;

  bypass_valve_actual_flow = 22222; //The current flow through the valve
  bypass_valve_on_off = false; //The state of the valve true->ON, false->OFF
  bypass_valve_on_off_changed = false; //Just a flag...

  main_valve_actual_flow = 22222; //The current flow through the valve
  main_valve_on_off = true; //The state of the valve true->ON, false->OFF
  main_valve_on_off_changed = false; //Just a flag...
  
}

void Diagnose_2::cycCalc()
{
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
	switch(state)
	{
	case INACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name;
            }
            else if (p_msg->cmd1 == "s_cool_air_value")
            { // Der User moechte den Kalte-Luft-Durchsatz aendern
              //Wert zum editieren ans Keyboard schicken:
              //Die Fenster aktivieren/deaktivieren:
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("keyboard_int", JUST_ACTIVATED); //Ganzzahl!
              //Keyboard die gewuenschten Parameter zukommen lassen:
              p2_msg = NULL;//p_displaymailbox->take_free_msg();
              if(p2_msg != NULL)
              {
                p2_msg->cmd1 = "I"; //Float, signed, zwei Nachkommastellen
                p2_msg->cmd2 = "set_cool_air_set_value"; //Parametername
//              p2_msg->i_number[0] = cool_air_set_value; //aktueller Wert
                p2_msg->i_number[0] = cool_air_set_value[0];
                p2_msg->i_number[1] = cool_air_set_value[1];
                p2_msg->i_number[2] = cool_air_set_value[2];
                
                p2_msg->origin = name;
                p2_msg->dest = "keyboard_int";
              }
            }
            else if (p_msg->cmd1 == "set_cool_air_set_value")
            { // Es wurde ein neuer Wertt fuer das Kaltluftventil empfangen (z.B. vom Display)
              // Sollte die Meldung nicht vom System kommen wird diesem entsprechend eine
              // Nachricht hinterlassen
              cool_air_set_value[0] = p2_msg->i_number[0];
              cool_air_set_value_changed = true;
              if (p_msg->origin != "system")
              {
                p2_msg = NULL;//p_displaymailbox->take_free_msg();
                if(p2_msg != NULL)
                { 
                  p2_msg->cmd1 = "set_cool_air_set_value"; //Float, signed, zwei Nachkommastellen
                  p2_msg->i_number[0] = p_msg->i_number[0]; //aktueller Wert
                  p2_msg->origin = name;
                  p2_msg->dest = "system";
                }
              }
            }
            else if (p_msg->cmd1 == "main_valve_on_off")
            {
              p2_msg = NULL;//p_displaymailbox->take_free_msg();
              if(p2_msg != NULL)
              { //Nachricht kopieren und an "system" weiterleiten
                p2_msg->cmd1 = "main_valve_on_off";
                p2_msg->origin = name;
                p2_msg->dest = "system";
              }
            }
            else if (p_msg->cmd1 == "main_valve_on")
            {
              main_valve_on_off = true;
              main_valve_on_off_changed = true;
            }
            else if (p_msg->cmd1 == "main_valve_off")
            {
              main_valve_on_off = false;
              main_valve_on_off_changed = true;
            }
            else if (p_msg->cmd1 == "set_warm_air_set_value")
            { // Es wurde ein neuer Wertt fuer das Kaltluftventil empfangen (z.B. vom Display)
              // Sollte die Meldung nicht vom System kommen wird diesem entsprechend eine
              // Nachricht hinterlassen
              warm_air_set_value[0] = p_msg->i_number[0];
              warm_air_set_value_changed = true;
              if (p_msg->origin != "system")
              {
                p2_msg = NULL;//p_displaymailbox->take_free_msg();
                if(p2_msg != NULL)
                { 
                  p2_msg->cmd1 = "set_warm_air_set_value"; //Float, signed, zwei Nachkommastellen
                  p2_msg->i_number[0] = p_msg->i_number[0]; //aktueller Wert
                  p2_msg->origin = name;
                  p2_msg->dest = "system";
                }
              }
            }
            else if (p_msg->cmd1 == "set_cool_air_actual_flow")
            { // Es wurde ein neuer Wertt fuer das Kaltluftventil empfangen (z.B. vom Display)
              // Sollte die Meldung nicht vom System kommen wird diesem entsprechend eine
              // Nachricht hinterlassen
              cool_air_actual_flow = p_msg->i_number[0];
              cool_air_actual_flow_changed = true;
            }
            else if (p_msg->cmd1 == "set_warm_air_actual_flow")
            { // Es wurde ein neuer Wertt fuer das Kaltluftventil empfangen (z.B. vom Display)
              // Sollte die Meldung nicht vom System kommen wird diesem entsprechend eine
              // Nachricht hinterlassen
              warm_air_actual_flow = p_msg->i_number[0];
              warm_air_actual_flow_changed = true;
            }
            else if (p_msg->cmd1 == "set_bypass_valve_actual_flow")
            { // Es wurde ein neuer Wertt fuer das Kaltluftventil empfangen (z.B. vom Display)
              // Sollte die Meldung nicht vom System kommen wird diesem entsprechend eine
              // Nachricht hinterlassen
              bypass_valve_actual_flow = p_msg->i_number[0];
              bypass_valve_actual_flow_changed = true;
            }
            else if (p_msg->cmd1 == "set_main_valve_actual_flow")
            { // Es wurde ein neuer Wertt fuer das Kaltluftventil empfangen (z.B. vom Display)
              // Sollte die Meldung nicht vom System kommen wird diesem entsprechend eine
              // Nachricht hinterlassen
              main_valve_actual_flow = p_msg->i_number[0];
              main_valve_actual_flow_changed = true;
            }
            if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Unbekannte Nachricht als empfangen zurueckschicken...
          }
          break;
	case JUST_ACTIVATED:
          //"Ansicht wechseln" ans Display schicken...
          p2_msg = NULL;//p_displaymailbox->take_free_msg();
          if (p2_msg != NULL)
          {
            p2_msg->dest = "display_1";  
            p2_msg->origin = name;
            p2_msg->cmd1 = "#MN37,"; //MnDiagnose_2 = 37
          }
          state = ACTIVE;
          
          cool_air_set_value_changed = true;
          cool_air_actual_flow_changed = true;
          
          warm_air_set_value_changed = true;
          warm_air_actual_flow_changed = true;
          
          bypass_valve_actual_flow_changed = true;
          bypass_valve_on_off_changed = true;
          
          main_valve_actual_flow_changed = true;
          main_valve_on_off_changed = true;
          
          break;
	case ACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name; //msg wieder einlagern
            }
            else if (p_msg->cmd1 == "escape")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_1")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_1", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_2")
            {

            }
            else if (p_msg->cmd1 == "diag_page_3")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_3", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_4")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_4", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_5")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_5", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_6")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_6", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "s_cool_air_value")
            { // Der User moechte den Kalte-Luft-Durchsatz aendern
              //Wert zum editieren ans Keyboard schicken:
              //Die Fenster aktivieren/deaktivieren:
              if (cool_air_set_value[0] != 22222)
              {
                p_CDisplaymanager->set_state(&name, INACTIVE);
                p_CDisplaymanager->set_state("keyboard_int", JUST_ACTIVATED); //Ganzzahl!
                //Keyboard die gewuenschten Parameter zukommen lassen:
                p2_msg = NULL;//p_displaymailbox->take_free_msg();
                if(p2_msg != NULL)
                {
                  p2_msg->cmd1 = "I"; //Float, signed, zwei Nachkommastellen
                  p2_msg->cmd2 = "set_cool_air_set_value"; //Parametername
  //              p2_msg->i_number[0] = cool_air_set_value; //aktueller Wert
                  p2_msg->i_number[0] = cool_air_set_value[0];
                  p2_msg->i_number[1] = cool_air_set_value[1];
                  p2_msg->i_number[2] = cool_air_set_value[2];
                  
                  p2_msg->origin = name;
                  p2_msg->dest = "keyboard_int";
                }
              }
            }
              else if (p_msg->cmd1 == "set_cool_air_set_value")
              { // Es wurde ein neuer Wertt fuer das Kaltluftventil empfangen (z.B. vom Display)
              // Sollte die Meldung nicht vom System kommen wird diesem entsprechend eine
              // Nachricht hinterlassen
              if (cool_air_set_value[0] != p_msg->i_number[0])
              {
                cool_air_set_value[0] = p_msg->i_number[0];
                cool_air_set_value_changed = true;
                if (p_msg->origin != "system")
                {
                  p2_msg = NULL;//p_displaymailbox->take_free_msg();
                  if(p2_msg != NULL)
                  { 
                    p2_msg->cmd1 = "set_cool_air_set_value"; //Float, signed, zwei Nachkommastellen
                    p2_msg->i_number[0] = p_msg->i_number[0]; //aktueller Wert
                    p2_msg->origin = name;
                    p2_msg->dest = "system";
                  }
                }
              }
            }
            else if (p_msg->cmd1 == "s_warm_air_value")
            { // Der User moechte den Kalte-Luft-Durchsatz aendern
              //Wert zum editieren ans Keyboard schicken:
              //Die Fenster aktivieren/deaktivieren:
              if (warm_air_set_value[0] != 22222)
              {
                p_CDisplaymanager->set_state(&name, INACTIVE);
                p_CDisplaymanager->set_state("keyboard_int", JUST_ACTIVATED); //Ganzzahl!
                //Keyboard die gewuenschten Parameter zukommen lassen:
                p2_msg = NULL;//p_displaymailbox->take_free_msg();
                  if(p2_msg != NULL)
                {
                  p2_msg->cmd1 = "I"; //Float, signed, zwei Nachkommastellen
                  p2_msg->cmd2 = "set_warm_air_set_value"; //Parametername
                  p2_msg->i_number[0] = warm_air_set_value[0];
                  p2_msg->i_number[1] = warm_air_set_value[1];
                  p2_msg->i_number[2] = warm_air_set_value[2];
                
                  p2_msg->origin = name;
                  p2_msg->dest = "keyboard_int";
                }
              }
            }
            else if (p_msg->cmd1 == "set_warm_air_set_value")
            { // Es wurde ein neuer Wertt fuer das Kaltluftventil empfangen (z.B. vom Display)
              // Sollte die Meldung nicht vom System kommen wird diesem entsprechend eine
              // Nachricht hinterlassen
              if (warm_air_set_value[0] != p_msg->i_number[0])
              {
                warm_air_set_value[0] = p_msg->i_number[0];
                warm_air_set_value_changed = true;
                if (p_msg->origin != "system")
                {
                  p2_msg = NULL;//p_displaymailbox->take_free_msg();
                  if(p2_msg != NULL)
                  { 
                    p2_msg->cmd1 = "set_warm_air_set_value"; //Float, signed, zwei Nachkommastellen
                    p2_msg->i_number[0] = p_msg->i_number[0]; //aktueller Wert
                    p2_msg->origin = name;
                    p2_msg->dest = "system";
                  }
                }
              }
            }
            else if (p_msg->cmd1 == "bypass_valve_on_off")
            {
              p2_msg = NULL;//p_displaymailbox->take_free_msg();
              if(p2_msg != NULL)
              { //Nachricht kopieren und an "system" weiterleiten
                p2_msg->cmd1 = "bypass_valve_on_off";
                p2_msg->origin = name;
                p2_msg->dest = "system";
              }
            }
            else if (p_msg->cmd1 == "bypass_valve_on")
            {
              bypass_valve_on_off = true;
              bypass_valve_on_off_changed = true;
            }
            else if (p_msg->cmd1 == "bypass_valve_off")
            {
              bypass_valve_on_off = false;
              bypass_valve_on_off_changed = true;
            }
            else if (p_msg->cmd1 == "main_valve_on_off")
            {
              p2_msg = NULL;//p_displaymailbox->take_free_msg();
              if(p2_msg != NULL)
              { //Nachricht kopieren und an "system" weiterleiten
                p2_msg->cmd1 = "main_valve_on_off";
                p2_msg->origin = name;
                p2_msg->dest = "system";
              }
            }
            else if (p_msg->cmd1 == "main_valve_on")
            {
              main_valve_on_off = true;
              main_valve_on_off_changed = true;
            }
            else if (p_msg->cmd1 == "main_valve_off")
            {
              main_valve_on_off = false;
              main_valve_on_off_changed = true;
            }
            else if (p_msg->cmd1 == "set_cool_air_actual_flow")
            { // Es wurde ein neuer Wertt fuer das Kaltluftventil empfangen (z.B. vom Display)
              // Sollte die Meldung nicht vom System kommen wird diesem entsprechend eine
              // Nachricht hinterlassen
              if (cool_air_actual_flow != p_msg->i_number[0])
              {
                cool_air_actual_flow = p_msg->i_number[0];
                cool_air_actual_flow_changed = true;
              }
            }
            else if (p_msg->cmd1 == "set_warm_air_actual_flow")
            { // Es wurde ein neuer Wertt fuer das Kaltluftventil empfangen (z.B. vom Display)
              // Sollte die Meldung nicht vom System kommen wird diesem entsprechend eine
              // Nachricht hinterlassen
              if (warm_air_actual_flow != p_msg->i_number[0])
              {
                warm_air_actual_flow = p_msg->i_number[0];
                warm_air_actual_flow_changed = true;
              }
            }
            else if (p_msg->cmd1 == "set_bypass_valve_actual_flow")
            { // Es wurde ein neuer Wertt fuer das Kaltluftventil empfangen (z.B. vom Display)
              // Sollte die Meldung nicht vom System kommen wird diesem entsprechend eine
              // Nachricht hinterlassen
              if (bypass_valve_actual_flow != p_msg->i_number[0])
              {
                bypass_valve_actual_flow = p_msg->i_number[0];
                bypass_valve_actual_flow_changed = true;
              }
            }
            else if (p_msg->cmd1 == "set_main_valve_actual_flow")
            { // Es wurde ein neuer Wertt fuer das Kaltluftventil empfangen (z.B. vom Display)
              // Sollte die Meldung nicht vom System kommen wird diesem entsprechend eine
              // Nachricht hinterlassen
              if (main_valve_actual_flow != p_msg->i_number[0])
              {
                main_valve_actual_flow = p_msg->i_number[0];
                main_valve_actual_flow_changed = true;
              }
            }
          if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Als Trash zurueckschicken
          }
          

          if(   cool_air_actual_flow_changed
             || warm_air_actual_flow_changed
             || main_valve_actual_flow_changed
             || bypass_valve_actual_flow_changed)
            {
              //Aktueller Nachrichtenrahmen koennte in Zukunft die Display-Buffergroesse sprengen,
              //deswegen wird hier eine weitere Nachricht erstellt:
              p_msg = NULL;//p_displaymailbox->take_free_msg();
              if (p_msg != NULL)
              {
                p_msg->dest = "display_1";  
                p_msg->origin = name;
                p_msg->cmd1 = "send_direct_cmd3_data";
                while (!p_msg->cmd3.empty())p_msg->cmd3.pop_back();
                
                p_msg->cmd2 = "#MN63,#FZ1,0,"; //MnClearDiag2ValueAreas = 63, clear area and set text color white
                for(int k=0; k<p_msg->cmd2.size(); k++)
                {p_msg->cmd3.push_back((char)p_msg->cmd2[k]);}//copy data
                
//                  p_msg->cmd2 = "#ZR233,67,"; //write text
                  p_msg->cmd2 = "#ZC222,67,"; //write text
                  for(int k=0; k<p_msg->cmd2.size(); k++)
                  {p_msg->cmd3.push_back((char)p_msg->cmd2[k]);}//copy data
                  
                  while (!v_buffer->empty())v_buffer->pop_back();
                  //intToVector(cool_air_actual_flow, v_buffer, true);
                  
                  if(cool_air_actual_flow != 22222)
                  {
                    intToVector(cool_air_actual_flow, v_buffer, true);
                    if ((v_buffer->at(0) == '+') || (v_buffer->at(0) == '-'))
                    {
                      for(int k=1; k<v_buffer->size(); k++)
                      {p_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                    }
                    else
                    {
                      for(int k=0; k<v_buffer->size(); k++)
                      {p_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                    }
                  }
                  else
                  {
                    p_msg->cmd3.push_back('X');
                  }
                  p_msg->cmd3.push_back('\x0A');
                
                  p_msg->cmd2 = "#ZC222,98,"; //write text
                  for(int k=0; k<p_msg->cmd2.size(); k++)
                  {p_msg->cmd3.push_back((char)p_msg->cmd2[k]);}//copy data
                  
                  while (!v_buffer->empty())v_buffer->pop_back();
                  //intToVector(warm_air_actual_flow, v_buffer, true);
                  if(warm_air_actual_flow != 22222)
                  {
                    intToVector(warm_air_actual_flow, v_buffer, true);
                    if ((v_buffer->at(0) == '+') || (v_buffer->at(0) == '-'))
                    {
                      for(int k=1; k<v_buffer->size(); k++)
                      {p_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                    }
                    else
                    {
                      for(int k=0; k<v_buffer->size(); k++)
                      {p_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                    }
                  }
                  else
                  {
                    p_msg->cmd3.push_back('X');
                  }
                  p_msg->cmd3.push_back('\x0A');

                  p_msg->cmd2 = "#ZC222,160,"; //write text
                  for(int k=0; k<p_msg->cmd2.size(); k++)
                  {p_msg->cmd3.push_back((char)p_msg->cmd2[k]);}//copy data
                  
                  while (!v_buffer->empty())v_buffer->pop_back();
                  //intToVector(main_valve_actual_flow, v_buffer, true);
                  if(main_valve_actual_flow != 22222)
                  {
                    intToVector(main_valve_actual_flow, v_buffer, true);
                    if ((v_buffer->at(0) == '+') || (v_buffer->at(0) == '-'))
                    {
                      for(int k=1; k<v_buffer->size(); k++)
                      {p_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                    }
                    else
                    {
                      for(int k=0; k<v_buffer->size(); k++)
                      {p_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                    }
                  }
                  else
                  {
                    p_msg->cmd3.push_back('X');
                  }
                  p_msg->cmd3.push_back('\x0A');

                  p_msg->cmd2 = "#ZC222,129,"; //write text
                  for(int k=0; k<p_msg->cmd2.size(); k++)
                  {p_msg->cmd3.push_back((char)p_msg->cmd2[k]);}//copy data
                  
                  while (!v_buffer->empty())v_buffer->pop_back();
                  //intToVector(bypass_valve_actual_flow, v_buffer, true);
                  if(bypass_valve_actual_flow != 22222)
                  {
                    intToVector(bypass_valve_actual_flow, v_buffer, true);
                    if ((v_buffer->at(0) == '+') || (v_buffer->at(0) == '-'))
                    {
                      for(int k=1; k<v_buffer->size(); k++)
                      {p_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                    }
                    else
                    {
                      for(int k=0; k<v_buffer->size(); k++)
                      {p_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                    }
                  }
                  else
                  {
                    p_msg->cmd3.push_back('X');
                  }
                  p_msg->cmd3.push_back('\x0A');

              }
              cool_air_actual_flow_changed = false;
              warm_air_actual_flow_changed = false;
              main_valve_actual_flow_changed = false;
              bypass_valve_actual_flow_changed = false;
            }
            
            
          if(   cool_air_set_value_changed
             || warm_air_set_value_changed
             || bypass_valve_on_off_changed
             || main_valve_on_off_changed )
            {
              //Aktueller Nachrichtenrahmen koennte in Zukunft die Display-Buffergroesse sprengen,
              //deswegen wird hier eine weitere Nachricht erstellt:
              p_msg = NULL;//p_displaymailbox->take_free_msg();
              if (p_msg != NULL)
              {
                p_msg->dest = "display_1";  
                p_msg->origin = name;
                p_msg->cmd1 = "send_direct_cmd3_data";
                while (!p_msg->cmd3.empty())p_msg->cmd3.pop_back();
                
                if(bypass_valve_on_off_changed)
                {
                  p_msg->cmd2 = "#AL144,0,#AT95,121,182,152,144,0,"; //B_diag_bypass_valve_on_off = 144
                  for(int k=0; k<p_msg->cmd2.size(); k++)
                  {p_msg->cmd3.push_back((char)p_msg->cmd2[k]);}//copy data
                  if(bypass_valve_on_off) p_msg->cmd2 = "ON";
                  else p_msg->cmd2 = "OFF";
                  for(int k=0; k<p_msg->cmd2.size(); k++)
                  {p_msg->cmd3.push_back((char)p_msg->cmd2[k]);}//copy data
                  p_msg->cmd3.push_back('\x0A');
                }// *37*
                
                if(main_valve_on_off_changed)
                {
                  p_msg->cmd2 = "#AL145,0,#AT95,152,182,183,145,0,"; //B_diag_main_valve_on_off = 145
                  for(int k=0; k<p_msg->cmd2.size(); k++)
                  {p_msg->cmd3.push_back((char)p_msg->cmd2[k]);}//copy data
                  if(main_valve_on_off) p_msg->cmd2 = "ON";
                  else p_msg->cmd2 = "OFF";
                  for(int k=0; k<p_msg->cmd2.size(); k++)
                  {p_msg->cmd3.push_back((char)p_msg->cmd2[k]);}//copy data
                  p_msg->cmd3.push_back('\x0A');
                }// *37*
                
                if(cool_air_set_value_changed)
                {
                  p_msg->cmd2 = "#AL142,0,#AT95,59,182,90,142,0,"; //B_diag_set_cool_air_value = 142
                  for(int k=0; k<p_msg->cmd2.size(); k++)
                  {p_msg->cmd3.push_back((char)p_msg->cmd2[k]);}//copy data
                  
                  while (!v_buffer->empty())v_buffer->pop_back();
                  //intToVector(cool_air_set_value[0], v_buffer, true);
                  if(cool_air_set_value[0] != 22222)
                  {
                    intToVector(cool_air_set_value[0], v_buffer, true);
                    if ((v_buffer->at(0) == '+') || (v_buffer->at(0) == '-'))
                    {
                      for(int k=1; k<v_buffer->size(); k++)
                      {p_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                    }
                    else
                    {
                      for(int k=0; k<v_buffer->size(); k++)
                      {p_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                    }
                  }
                  else
                  {
                    p_msg->cmd3.push_back('X');
                  }
                  p_msg->cmd3.push_back('\x0A');
                }// *41*
                
                if(warm_air_set_value_changed)
                {
                  p_msg->cmd2 = "#AL143,0,#AT95,90,182,121,143,0,"; //B_diag_set_warm_air_value = 143
                  for(int k=0; k<p_msg->cmd2.size(); k++)
                  {p_msg->cmd3.push_back((char)p_msg->cmd2[k]);}//copy data
                  
                  while (!v_buffer->empty())v_buffer->pop_back();
                  //intToVector(warm_air_set_value[0], v_buffer, true);
                  if(warm_air_set_value[0] != 22222)
                  {
                    intToVector(warm_air_set_value[0], v_buffer, true);
                    if ((v_buffer->at(0) == '+') || (v_buffer->at(0) == '-'))
                    {
                      for(int k=1; k<v_buffer->size(); k++)
                      {p_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                    }
                    else
                    {
                      for(int k=0; k<v_buffer->size(); k++)
                      {p_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                    }
                  }
                  else
                  {
                    p_msg->cmd3.push_back('X');
                  }
                  p_msg->cmd3.push_back('\x0A');
                }// *41*

                /*
                for (char i=0;i<4;i++)
                {
                  //if(temp_changed[i] == true)
                  {
                    while (!v_buffer->empty())v_buffer->pop_back();
                    if (i == 0) p_msg->cmd2 = "#RR128,203,248,234,#ZR242,210,";
                    else if (i == 1) p_msg->cmd2 = "#RR128,234,248,265,#ZR242,241,";
                    else if (i == 2) p_msg->cmd2 = "#RR128,265,248,296,#ZR242,272,";
                    else if (i == 3) p_msg->cmd2 = "#RR128,296,248,327,#ZR242,303,";
                    for(int k=0; k<p_msg->cmd2.size(); k++)
                    {p_msg->cmd3.push_back((char)p_msg->cmd2[k]);}//copy data
                    
                    if (i == 0) doubleToVector(chuck_temp_1[0], v_buffer, 2, true);
                    else if (i == 1) doubleToVector(chuck_temp_2[0], v_buffer, 2, true);
                    else if (i == 2) doubleToVector(chuck_temp_3[0], v_buffer, 2, true);
                    else if (i == 3) doubleToVector(chuck_temp_4[0], v_buffer, 2, true);
                    for(int k=0; k<v_buffer->size(); k++)
                    {p_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                    p_msg->cmd3.push_back('\x0A');
                    
                    temp_changed[(int)i] = false;
                  }
                }
                */
              }
              cool_air_set_value_changed = false;
              warm_air_set_value_changed = false;
              bypass_valve_on_off_changed = false;
              main_valve_on_off_changed = false;
            }
          break;
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}

Diagnose_3::Diagnose_3()
{ //Sicherheitsinit
  
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
}

void Diagnose_3::Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  
  m_pEventManager = pEventManager;
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
  
  
  power_suppply_1_set_voltage[0] = 22222;
  power_suppply_1_set_voltage[1] = 14; 
  power_suppply_1_set_voltage[2] = 0;

  power_suppply_2_set_voltage[0] = 14;
  power_suppply_2_set_voltage[1] = 10;
  power_suppply_2_set_voltage[2] = 0;
  
  
  power_suppply_1_current = 22222.0;
  power_suppply_2_current = 22222.0;
  power_suppply_3_current = 22222.0;
  power_suppply_4_current = 22222.0;
  
  power_suppply_1_set_v_changed = true;
  power_suppply_2_set_v_changed = true;
  power_suppply_1_current_changed = true;
  power_suppply_2_current_changed = true;
  power_suppply_3_current_changed = true;
  power_suppply_4_current_changed = true;
  
  power_suppply_1_voltage  = 22222;
  power_suppply_1_voltage_changed = true;
  
  power_suppply_2_voltage  = 22222;
  power_suppply_2_voltage_changed = true;

  m_pEventManager->AddEventHandler( CEventNames::set_power_suppply_5_set_voltage, Diagnose_3::set_power_suppply_5_set_voltageEventWrapper, this );

}

void Diagnose_3::set_power_suppply_5_set_voltageEvent( float f )
{ 
    // Es wurde ein neuer Wert fuer die Ausgangsspannung der Spannungsversorgung empfangen
    power_suppply_1_set_voltage[0] = (int)f;
    power_suppply_1_set_v_changed = true;
}


void Diagnose_3::cycCalc()
{
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
	switch(state)
	{
	case INACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name;
            }
             else if (p_msg->cmd1 == "power_suppply_1_current")
            { // Es wurde ein neuer Wert fuer den Ausgangsstrom der Stromversorgung 1 empfangen
              power_suppply_1_current = p_msg->f_number[0];
              power_suppply_1_current_changed = true;
            }
            else if (p_msg->cmd1 == "power_suppply_2_current")
            { // Es wurde ein neuer Wert fuer den Ausgangsstrom der Stromversorgung 2 empfangen
              power_suppply_2_current = p_msg->f_number[0];
              power_suppply_2_current_changed = true;
            }
            else if (p_msg->cmd1 == "power_suppply_3_current")
            { // Es wurde ein neuer Wert fuer den Ausgangsstrom der Stromversorgung 3 empfangen
              power_suppply_3_current = p_msg->f_number[0];
              power_suppply_3_current_changed = true;
            }
            else if (p_msg->cmd1 == "power_suppply_4_current")
            { // Es wurde ein neuer Wert fuer den Ausgangsstrom der Stromversorgung 4 empfangen
              power_suppply_4_current = p_msg->f_number[0];
              power_suppply_4_current_changed = true;
            }
            else if (   p_msg->cmd1 == "set_power_supply_1_voltage_limits")
            { // Es wurden neue Limits von irgendwo her uebertragen
			power_suppply_1_set_voltage[1] = p_msg->i_number[1]; //upper limit
			power_suppply_1_set_voltage[2] = p_msg->i_number[2]; //lower limit
            }
            if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Unbekannte Nachricht als empfangen zurueckschicken...
          }
          break;
	case JUST_ACTIVATED:
          //"Ansicht wechseln" ans Display schicken...
          p2_msg = NULL;//p_displaymailbox->take_free_msg();
          if (p2_msg != NULL)
          {
            p2_msg->dest = "display_1";  
            p2_msg->origin = name;
            p2_msg->cmd1 = "#MN38,"; //MnDiagnose_3 = 38
          }
          
          power_suppply_1_set_v_changed = true;
          power_suppply_1_current_changed = true;
          power_suppply_2_current_changed = true;
          power_suppply_3_current_changed = true;
          power_suppply_4_current_changed = true;
          
          state = ACTIVE;
          break;
	case ACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name; //msg wieder einlagern
            }
            else if (p_msg->cmd1 == "escape")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_1")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_1", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_2")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_2", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_3")
            {

            }
            else if (p_msg->cmd1 == "diag_page_4")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_4", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_5")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_5", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_6")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_6", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "power_suppply_1_voltage")
            { // Es wurde ein neuer Wert fuer die Ausgangsspannung der Spannungsversorgung empfangen
              if (power_suppply_1_voltage != p_msg->i_number[0])
              {
                power_suppply_1_voltage = p_msg->i_number[0];
                power_suppply_1_voltage_changed = true;
              }
            }
            else if (p_msg->cmd1 == "power_suppply_2_voltage")
            { // Es wurde ein neuer Wert fuer die Ausgangsspannung der Spannungsversorgung empfangen
              if (power_suppply_2_voltage != p_msg->i_number[0])
              {
                power_suppply_2_voltage = p_msg->i_number[0];
                power_suppply_2_voltage_changed = true;
              }
            }
            else if (p_msg->cmd1 == "s_power_suppply_1_set_voltage")
            { // Der User moechte den Setzwert der Spannugsversorgung aendern
              //Wert zum editieren ans Keyboard schicken:
              //Die Fenster aktivieren/deaktivieren:
              if (power_suppply_1_set_voltage[0] != 22222)
              {
                p_CDisplaymanager->set_state(&name, INACTIVE);
                p_CDisplaymanager->set_state("keyboard_int", JUST_ACTIVATED); //Ganzzahl!
                //Keyboard die gewuenschten Parameter zukommen lassen:
                  p2_msg = NULL;//p_displaymailbox->take_free_msg();
                if(p2_msg != NULL)
                {
                  p2_msg->cmd1 = "I"; //Integer, signed, zwei Nachkommastellen
                  p2_msg->cmd2 = "set_power_suppply_1_set_voltage"; //Parametername
                  p2_msg->i_number[0] = power_suppply_1_set_voltage[0];
                  p2_msg->i_number[1] = power_suppply_1_set_voltage[1];
                  p2_msg->i_number[2] = power_suppply_1_set_voltage[2];
                    
                  p2_msg->origin = name;
                    p2_msg->dest = "keyboard_int";
                }
              }
            }
            else if (p_msg->cmd1 == "set_power_suppply_1_set_voltage")
            { // Es wurde ein neuer Wert fuer die Ausgangsspannung der Spannungsversorgung empfangen
              if(power_suppply_1_set_voltage[0] != p_msg->i_number[0])
              {
                power_suppply_1_set_voltage[0] = p_msg->i_number[0];
                power_suppply_1_set_v_changed = true;
                if (p_msg->origin != "system")
                {
                  p2_msg = NULL;//p_displaymailbox->take_free_msg();
                  if(p2_msg != NULL)
                  { 
                    p2_msg->cmd1 = "set_power_suppply_1_set_voltage"; //Float, signed, zwei Nachkommastellen
                    p2_msg->i_number[0] = p_msg->i_number[0]; //aktueller Wert
                    p2_msg->origin = name;
                    p2_msg->dest = "system";
                  }
                }
              }
            }
            else if (   p_msg->cmd1 == "set_power_supply_1_voltage_limits")
            { // Es wurden neue Limits von irgendwo her uebertragen
			power_suppply_1_set_voltage[1] = p_msg->i_number[1]; //upper limit
			power_suppply_1_set_voltage[2] = p_msg->i_number[2]; //lower limit
            }
            else if (p_msg->cmd1 == "power_suppply_1_current")
            { // Es wurde ein neuer Wert fuer den Ausgangsstrom der Stromversorgung 1 empfangen
              if (power_suppply_1_current != p_msg->f_number[0])
              {
                power_suppply_1_current = p_msg->f_number[0];
                power_suppply_1_current_changed = true;
              }
            }
            else if (p_msg->cmd1 == "power_suppply_2_current")
            { // Es wurde ein neuer Wert fuer den Ausgangsstrom der Stromversorgung 2 empfangen
              if (power_suppply_2_current != p_msg->f_number[0])
              {
                power_suppply_2_current = p_msg->f_number[0];
                power_suppply_2_current_changed = true;
              }
            }
            else if (p_msg->cmd1 == "power_suppply_3_current")
            { // Es wurde ein neuer Wert fuer den Ausgangsstrom der Stromversorgung 3 empfangen
              if (power_suppply_3_current != p_msg->f_number[0])
              {
                power_suppply_3_current = p_msg->f_number[0];
                power_suppply_3_current_changed = true;
              }
            }
            else if (p_msg->cmd1 == "power_suppply_4_current")
            { // Es wurde ein neuer Wert fuer den Ausgangsstrom der Stromversorgung 4 empfangen
              if (power_suppply_4_current != p_msg->f_number[0])
              {
                power_suppply_4_current = p_msg->f_number[0];
                power_suppply_4_current_changed = true;
              }
            }
            else if (   p_msg->cmd1 == "set_power_supply_1_voltage_limits")
            { // Es wurden neue Limits von irgendwo her uebertragen
			power_suppply_1_set_voltage[1] = p_msg->i_number[1]; //upper limit
			power_suppply_1_set_voltage[2] = p_msg->i_number[2]; //lower limit
            }
          if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Als Trash zurueckschicken
          }
          
          if(   power_suppply_1_set_v_changed
             || power_suppply_1_current_changed
             || power_suppply_2_current_changed
             || power_suppply_3_current_changed
             || power_suppply_4_current_changed )
            {
              p2_msg = NULL;//p_displaymailbox->take_free_msg();
              if (p2_msg != NULL)
              {
                p2_msg->dest = "display_1";  
                p2_msg->origin = name;
                p2_msg->cmd1 = "send_direct_cmd3_data";
                while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use

                    p2_msg->cmd2 = "#MN68,#FZ1,0,"; //MnClearDiag_3All = 68
                    for(int i=0; i<p2_msg->cmd2.size(); i++)
                    {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                    
                //if(power_suppply_1_set_v_changed)
                    p2_msg->cmd2 = "#ZC198,80,"; //MnDiagnose_clr_chill_status = 68
                    for(int i=0; i<p2_msg->cmd2.size(); i++)
                    {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                    
                    while (!v_buffer->empty())v_buffer->pop_back();
                    if(power_suppply_1_set_voltage[0] != 22222)
                    {
                      intToVector(power_suppply_1_set_voltage[0], v_buffer, true);
                      if ((v_buffer->at(0) == '+') || (v_buffer->at(0) == '-'))
                      {
                        for(int k=1; k<v_buffer->size(); k++)
                        {p2_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                      }
                      else
                      {
                        for(int k=0; k<v_buffer->size(); k++)
                        {p2_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                      }
                    }
                    else
                    {
                      p2_msg->cmd3.push_back('X');
                    }
                    p2_msg->cmd3.push_back('\x0A');
                    power_suppply_1_set_v_changed = false;
                  
                  
               //if(power_suppply_1_current_changed)
                    p2_msg->cmd2 = "#ZC198,152,"; //MnDiagnose_clr_chill_status = 68
                    for(int i=0; i<p2_msg->cmd2.size(); i++)
                    {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                    
                    while (!v_buffer->empty())v_buffer->pop_back();
                    
                    if(power_suppply_1_current != 22222.0)
                    {
                    //floatToVector(power_suppply_1_current, v_buffer, 3, true);
                    floatToVector2((float)power_suppply_1_current, v_buffer, 3, true, &buffer);
                      if ((v_buffer->at(0) == '+') || (v_buffer->at(0) == '-'))
                      {
                        for(int k=1; k<v_buffer->size(); k++)
                        {p2_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                      }
                      else
                      {
                       for(int k=0; k<v_buffer->size(); k++)
                       {p2_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                      }
                    }
                    else
                    {
                      p2_msg->cmd3.push_back('X');
                    }
                      p2_msg->cmd3.push_back('\x0A');
                      power_suppply_1_current_changed = false;
                  
                  
                //if(power_suppply_2_current_changed)
                    p2_msg->cmd2 = "#ZC198,183,"; //MnDiagnose_clr_chill_status = 68
                    for(int i=0; i<p2_msg->cmd2.size(); i++)
                    {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                    
                    while (!v_buffer->empty())v_buffer->pop_back();
                    if(power_suppply_2_current != 22222.0)
                    {
                      //floatToVector(power_suppply_2_current, v_buffer, 3, true);
                      floatToVector2((float)power_suppply_2_current, v_buffer, 3, true, &buffer);
                      if ((v_buffer->at(0) == '+') || (v_buffer->at(0) == '-'))
                      {
                        for(int k=1; k<v_buffer->size(); k++)
                        {p2_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                      }
                      else
                      {
                        for(int k=0; k<v_buffer->size(); k++)
                      {p2_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                      }
                    }
                    else
                    {
                      p2_msg->cmd3.push_back('X');
                    }
                    p2_msg->cmd3.push_back('\x0A');
                    power_suppply_2_current_changed = false;
                  
                //if(power_suppply_3_current_changed)
                    p2_msg->cmd2 = "#ZC198,214,"; //MnDiagnose_clr_chill_status = 68
                    for(int i=0; i<p2_msg->cmd2.size(); i++)
                    {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                    
                    while (!v_buffer->empty())v_buffer->pop_back();
                    if(power_suppply_3_current != 22222.0)
                    {
                      //floatToVector(power_suppply_3_current, v_buffer, 3, true);
                      floatToVector2((float)power_suppply_3_current, v_buffer, 3, true, &buffer);
                      if ((v_buffer->at(0) == '+') || (v_buffer->at(0) == '-'))
                      {
                        for(int k=1; k<v_buffer->size(); k++)
                        {p2_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                      }
                      else
                      {
                        for(int k=0; k<v_buffer->size(); k++)
                      {p2_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                      }
                    }
                    else
                    {
                      p2_msg->cmd3.push_back('X');
                    }
                    p2_msg->cmd3.push_back('\x0A');
                    power_suppply_3_current_changed = false;
                    
                //if(power_suppply_4_current_changed)
                    p2_msg->cmd2 = "#ZC198,245,"; //MnDiagnose_clr_chill_status = 68
                    for(int i=0; i<p2_msg->cmd2.size(); i++)
                    {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                    
                    while (!v_buffer->empty())v_buffer->pop_back();
                    if(power_suppply_4_current != 22222.0)
                    {
                      //floatToVector(power_suppply_4_current, v_buffer, 3, true);
                      floatToVector2((float)power_suppply_4_current, v_buffer, 3, true, &buffer);
                      if ((v_buffer->at(0) == '+') || (v_buffer->at(0) == '-'))
                      {
                        for(int k=1; k<v_buffer->size(); k++)
                        {p2_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                      }
                      else
                      {
                        for(int k=0; k<v_buffer->size(); k++)
                      {p2_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                      }
                    }
                    else
                    {
                      p2_msg->cmd3.push_back('X');
                    }
                    p2_msg->cmd3.push_back('\x0A');
                    power_suppply_4_current_changed = false;
              }
            }
          break;
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}

Diagnose_4::Diagnose_4()
{ //Sicherheitsinit
  
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
}

void Diagnose_4::Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  
  m_pEventManager = pEventManager;
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
  for (int i=0; i<8; i++) temp[i] = 22222.0;
  for (int i=0; i<8; i++) temp_changed[i] = true;
}

void Diagnose_4::cycCalc()
{
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
	switch(state)
	{
	case INACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name;
            }
            else if (p_msg->cmd1 == "temp_sensor")
            { // Es wurde eine neue Temperatur fuer einen Temperatursensor �bertragen
                temp[p_msg->i_number[0]] = (float)p_msg->f_number[0];
                temp_changed[p_msg->i_number[0]] = true;
            }
            if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Unbekannte Nachricht als empfangen zurueckschicken...
          }
          break;
	case JUST_ACTIVATED:
          //"Ansicht wechseln" ans Display schicken...
          p2_msg = NULL;//p_displaymailbox->take_free_msg();
          if (p2_msg != NULL)
          {
            p2_msg->dest = "display_1";  
            p2_msg->origin = name;
            p2_msg->cmd1 = "#MN39,"; //MnDiagnose_4 = 39
          }
          state = ACTIVE;
          for (int i=0; i<8; i++) temp_changed[i] = true;
          break;
	case ACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name; //msg wieder einlagern
            }
            else if (p_msg->cmd1 == "escape")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_1")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_1", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_2")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_2", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_3")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_3", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_4")
            {
              
            }
            else if (p_msg->cmd1 == "diag_page_5")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_5", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_6")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_6", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "temp_sensor")
            { // Es wurde eine neue Temperatur fuer einen Temperatursensor �bertragen
                temp[p_msg->i_number[0]] = (float)p_msg->f_number[0];
                temp_changed[p_msg->i_number[0]] = true;
            }
          if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Als Trash zurueckschicken
          }
          
          if(   temp_changed[0]
             || temp_changed[1]
             || temp_changed[2]
             || temp_changed[3]
             || temp_changed[4]
             || temp_changed[5]
             || temp_changed[6]
             || temp_changed[7])
          {
            p2_msg = NULL;//p_displaymailbox->take_free_msg();
            if (p2_msg != NULL)
            {
              p2_msg->dest = "display_1";  
              p2_msg->origin = name;
              p2_msg->cmd1 = "send_direct_cmd3_data";
              while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use

              p2_msg->cmd2 = "#MN69,#FZ1,0,"; //MnClearDiag_4All = 69
              for(int i=0; i<p2_msg->cmd2.size(); i++)
              {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
               
              for (int m=0; m<8;m++)
              {
                p2_msg->cmd2 = "#ZC184,";
                for(int i=0; i<p2_msg->cmd2.size(); i++)
                {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                   
                intToVector(82+31*m, v_buffer, false); //Y-Koordinaten
                for(int k=0; k<v_buffer->size(); k++)
                {p2_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                p2_msg->cmd3.push_back(',');
                   
                while (!v_buffer->empty())v_buffer->pop_back();
                if(temp[m] != 22222)
                {
                  //intToVector(temp[m], v_buffer, true);
                  floatToVector2(temp[m], v_buffer, 2, true, &c_buffer);
                  for(int k=0; k<v_buffer->size(); k++)
                  {p2_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                }
                else
                {
                  p2_msg->cmd3.push_back('X');
                }
                p2_msg->cmd3.push_back('\x0A');
                temp_changed[m] = false;
              }
            }
          }

          break;
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}

Diagnose_5::Diagnose_5()
{ //Sicherheitsinit
  
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
}

void Diagnose_5::Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  
  m_pEventManager = pEventManager;
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
  for (int i=0; i<8; i++) temp[i] = 22222.0;
  for (int i=0; i<8; i++) temp_changed[i] = true;
  
}

void Diagnose_5::cycCalc()
{
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
	switch(state)
	{
	case INACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name;
            }
            else if (p_msg->cmd1 == "temp_sensor")
            { // Es wurde eine neue Temperatur fuer einen Temperatursensor �bertragen
                temp[p_msg->i_number[0]] = (float)p_msg->f_number[0];
                temp_changed[p_msg->i_number[0]] = true;
            }
            if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Unbekannte Nachricht als empfangen zurueckschicken...
          }
          break;
	case JUST_ACTIVATED:
          //"Ansicht wechseln" ans Display schicken...
          p2_msg = NULL;//p_displaymailbox->take_free_msg();
          if (p2_msg != NULL)
          {
            p2_msg->dest = "display_1";  
            p2_msg->origin = name;
            p2_msg->cmd1 = "#MN40,"; //MnDiagnose_5 = 40
          }
          for (int i=0; i<8; i++) temp_changed[i] = true;
          state = ACTIVE;
          break;
	case ACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name; //msg wieder einlagern
            }
            else if (p_msg->cmd1 == "escape")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_1")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_1", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_2")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_2", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_3")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_3", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_4")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_4", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_5")
            {

            }
            else if (p_msg->cmd1 == "diag_page_6")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_6", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "temp_sensor")
            { // Es wurde eine neue Temperatur fuer einen Temperatursensor �bertragen
                temp[p_msg->i_number[0]] = (float)p_msg->f_number[0];
                temp_changed[p_msg->i_number[0]] = true;
            }
          if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Als Trash zurueckschicken
          }
          
          if(   temp_changed[0]
             || temp_changed[1]
             || temp_changed[2]
             || temp_changed[3]
             || temp_changed[4]
             || temp_changed[5]
             || temp_changed[6]
             || temp_changed[7])
          {
            p2_msg = NULL;//p_displaymailbox->take_free_msg();
            if (p2_msg != NULL)
            {
              p2_msg->dest = "display_1";  
              p2_msg->origin = name;
              p2_msg->cmd1 = "send_direct_cmd3_data";
              while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use

              p2_msg->cmd2 = "#MN69,#FZ1,0,"; //MnClearDiag_4All = 69
              for(int i=0; i<p2_msg->cmd2.size(); i++)
              {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
               
              for (int m=0; m<8;m++)
              {
                p2_msg->cmd2 = "#ZC184,";
                for(int i=0; i<p2_msg->cmd2.size(); i++)
                {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                   
                intToVector(82+31*m, v_buffer, false); //Y-Koordinaten
                for(int k=0; k<v_buffer->size(); k++)
                {p2_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                p2_msg->cmd3.push_back(',');
                   
                while (!v_buffer->empty())v_buffer->pop_back();
                if(temp[m] != 22222)
                {
                  //intToVector(temp[m], v_buffer, true);
                  floatToVector2(temp[m], v_buffer, 2, true, &c_buffer);
                  for(int k=0; k<v_buffer->size(); k++)
                  {p2_msg->cmd3.push_back((char)v_buffer->at(k));}//copy data
                }
                else
                {
                  p2_msg->cmd3.push_back('X');
                }
                p2_msg->cmd3.push_back('\x0A');
                temp_changed[m] = false;
              }
            }
          }
          
          break;
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}

Diagnose_6::Diagnose_6()
{ //Sicherheitsinit
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
}

void Diagnose_6::Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  
  m_pEventManager = pEventManager;
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
  
  data_read = 0;
  filesize = 0;
  entrysize = 0;
}

void Diagnose_6::cycCalc()
{
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
	switch(state)
	{
	case INACTIVE:
          break;
	case JUST_ACTIVATED:
          //"Ansicht wechseln" ans Display schicken...
          p2_msg = NULL;//p_displaymailbox->take_free_msg();
          if (p2_msg != NULL)
          {
            p2_msg->dest = "display_1";  
            p2_msg->origin = name;
            p2_msg->cmd1 = "#MN41,"; //MnDiagnose_6 = 41
          }
          state = ACTIVE;
          break;
	case ACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name; //msg wieder einlagern
            }
            else if (p_msg->cmd1 == "escape")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_1")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_1", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_2")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_2", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_3")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_3", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_4")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_4", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_5")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("diagnose_5", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "diag_page_6")
            {

            }
            else if (p_msg->cmd1 == "update_filesys_view")
            { 
              //-------- grab file ---------
                 //Clear Display, Read Filesystem and show the Files and Folders
                int Zeile = 0;
                int y_space = 12;
                int y_start = 40;
                
                //Clear Text areas and set Font-Config:
                p2_msg = NULL;//p_displaymailbox->take_free_msg();
                if (p2_msg != NULL)
                {
                  p2_msg->dest = "display_1";
                  p2_msg->origin = name;
                  p2_msg->cmd1 = "send_direct_cmd3_data";
                  while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use
                  pushing_back(&(p2_msg->cmd3), "#MN35,#FZ1,0,#ZF3,", sizeof("#MN35,#FZ1,0,#ZF3,")-1); //MnEraseBlackBoxesShowFilesys = 35 (Schwarze Felder loeschen)
                  
                  /*
                  p2_msg->cmd2 = "#ZL10,";
                  for(int i=0; i<p2_msg->cmd2.size(); i++)
                  {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                  sprintf(_acBuffer,"%d,",(y_start-6+y_space*Zeile)); //y ermitteln                  
                  for(int i=0; _acBuffer[i]!=0;i++) //Text in den vector kopieren
                  {p2_msg->cmd3.push_back(_acBuffer[i]);}
                  p2_msg->cmd2 = "type size     name";
                  for(int i=0; i<p2_msg->cmd2.size(); i++)
                  {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                  p2_msg->cmd3.push_back('\x0A');// Textendezeichen
                  Zeile++;
                  
                  p2_msg->cmd2 = "#ZL10,";
                  for(int i=0; i<p2_msg->cmd2.size(); i++)
                  {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                  sprintf(_acBuffer,"%d,",(y_start+y_space*Zeile)); //y ermitteln                  
                  for(int i=0; _acBuffer[i]!=0;i++) //Text in den vector kopieren
                  {p2_msg->cmd3.push_back(_acBuffer[i]);}
                  p2_msg->cmd2 = "--------------------------";
                  for(int i=0; i<p2_msg->cmd2.size(); i++)
                  {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                  p2_msg->cmd3.push_back('\x0A');// Textendezeichen
                  Zeile++;     
                  */
                }
                
                //Open Files:
                pDir = FS_OpenDir("");      // Open root directory of default device 
                if (pDir)
                {
                  do
                  {
                    //---------
                    /*
                    pDirEnt = FS_ReadDir(pDir);
                    FS_DirEnt2Name(pDirEnt, acName);
                    FS_DirEnt2Attr(pDirEnt, &Attr);
                    entrysize = FS_DirEnt2Size(pDirEnt);
                    if ((void*)pDirEnt == NULL) break; // No more files
                    */
                    //---------
                    p2_msg = NULL;//p_displaymailbox->take_free_msg();
                    if (p2_msg != NULL)
                    {
                      //---------
                      pDirEnt = FS_ReadDir(pDir);
                      FS_DirEnt2Name(pDirEnt, acName);
                      FS_DirEnt2Attr(pDirEnt, &Attr);
                      entrysize = FS_DirEnt2Size(pDirEnt);
                      if ((void*)pDirEnt == NULL) break; // No more files
                      //---------
                      
                      p2_msg->dest = "display_1";
                      p2_msg->origin = name;
                      p2_msg->cmd1 = "send_direct_cmd3_data";
                      while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use
                      //-xxxxx-
                      p2_msg->cmd2 = "#ZL20,";
                      for(int i=0; i<p2_msg->cmd2.size(); i++)
                      {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                  
                      sprintf(_acBuffer,"%d,",(y_start+y_space*Zeile)); //y ermitteln                  
                      for(int i=0; _acBuffer[i]!=0;i++) //Text in den vector kopieren
                      {p2_msg->cmd3.push_back(_acBuffer[i]);}
                  
                      for(int i=0; i<9;i++) space[i] = ' '; space[9] = 0;
                      
                      if (entrysize<10) space[6] = 0;
                      else if (entrysize<100) space[5] = 0;
                      else if (entrysize<1000) space[4] = 0;
                      else if (entrysize<10000) space[3] = 0;
                      else if (entrysize<100000) space[2] = 0;
                      else if (entrysize<1000000) space[1] = 0;
                      
                      sprintf(_acBuffer,"%s %d %s %s", 
                              (Attr & FS_ATTR_DIRECTORY) ? "Dir " : "File",
                              entrysize,
                              space,
                              acName);
                      for(int i=0; _acBuffer[i]!=0;i++) //Text in den vector kopieren
                      {p2_msg->cmd3.push_back(_acBuffer[i]);}                   
                      p2_msg->cmd3.push_back('\x0A');// Textendezeichen
                      Zeile++;
                      
                      for (int t=0; t<6;t++)
                      {
                        //---------
                        pDirEnt = FS_ReadDir(pDir);
                        FS_DirEnt2Name(pDirEnt, acName);
                        FS_DirEnt2Attr(pDirEnt, &Attr);
                        entrysize = FS_DirEnt2Size(pDirEnt);
                        if ((void*)pDirEnt == NULL) break; // No more files
                        //---------
                        //-xxxxx-
                        p2_msg->cmd2 = "#ZL20,";
                        for(int i=0; i<p2_msg->cmd2.size(); i++)
                        {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                  
                        sprintf(_acBuffer,"%d,",(y_start+y_space*Zeile)); //y ermitteln                  
                        for(int i=0; _acBuffer[i]!=0;i++) //Text in den vector kopieren
                        {p2_msg->cmd3.push_back(_acBuffer[i]);}
                    
                        for(int i=0; i<9;i++) space[i] = ' '; space[9] = 0;
                      
                        if (entrysize<10) space[6] = 0;
                        else if (entrysize<100) space[5] = 0;
                        else if (entrysize<1000) space[4] = 0;
                        else if (entrysize<10000) space[3] = 0;
                        else if (entrysize<100000) space[2] = 0;
                        else if (entrysize<1000000) space[1] = 0;
                      
                        sprintf(_acBuffer,"%s %d %s %s", 
                              (Attr & FS_ATTR_DIRECTORY) ? "Dir " : "File",
                              entrysize,
                              space,
                              acName);
                        for(int i=0; _acBuffer[i]!=0;i++) //Text in den vector kopieren
                        {p2_msg->cmd3.push_back(_acBuffer[i]);}                   
                        p2_msg->cmd3.push_back('\x0A');// Textendezeichen
                        Zeile++;
                      }
                    }
                  }while (1);
                  FS_CloseDir(pDir);
                }// diropen possible
              }// /msg
          if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Als Trash zurueckschicken
          }
          break;
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}

Switchview_1::Switchview_1()
{ //Sicherheitsinit
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
}

void Switchview_1::Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  
  m_pEventManager = pEventManager;
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
}

void Switchview_1::cycCalc()
{
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
	switch(state)
	{
	case INACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name;
            }
            if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Unbekannte Nachricht als empfangen zurueckschicken...
          }
          break;
	case JUST_ACTIVATED:
          //"Ansicht wechseln" ans Display schicken...
          p2_msg = NULL;//p_displaymailbox->take_free_msg();
          if (p2_msg != NULL)
          {
            p2_msg->dest = "display_1";  
            p2_msg->origin = name;
            p2_msg->cmd1 = "#MN29,"; //MnSwitchView = 29
          }
          state = ACTIVE;
          break;
	case ACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name; //msg wieder einlagern
            }
            else if (p_msg->cmd1 == "escape")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "back")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("config_window", JUST_ACTIVATED);
            }

          if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Als Trash zurueckschicken
          }
          break;
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}

Controller_Overview_1::Controller_Overview_1()
{ //Sicherheitsinit
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
}

void Controller_Overview_1::Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  
  m_pEventManager = pEventManager;
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
}

void Controller_Overview_1::cycCalc()
{
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
	switch(state)
	{
	case INACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name;
            }
            if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Unbekannte Nachricht als empfangen zurueckschicken...
          }
          break;
	case JUST_ACTIVATED:
          //"Ansicht wechseln" ans Display schicken...
          p2_msg = NULL;//p_displaymailbox->take_free_msg();
          if (p2_msg != NULL)
          {
            p2_msg->dest = "display_1";  
            p2_msg->origin = name;
            p2_msg->cmd1 = "#MN31,"; //MnControllerOverview = 31
          }
          state = ACTIVE;
          break;
	case ACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name; //msg wieder einlagern
            }
            else if (p_msg->cmd1 == "escape")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
            }
            else if (p_msg->cmd1 == "back")
            {
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("config_window", JUST_ACTIVATED);
            }

          if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Als Trash zurueckschicken
          }
          break;
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}

Set_Temp_1::Set_Temp_1()
{
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
  set_temp_1 = 25;
  bool set_temp_1_changed = false;
//  diagnose_pin
}

void Set_Temp_1::Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  
  m_pEventManager = pEventManager;
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
}

void Set_Temp_1::cycCalc()
{
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
	switch(state)
	{
	case INACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name;
            }
            if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Unbekannte Nachricht als empfangen zurueckschicken...
          }
          break;
	case JUST_ACTIVATED:
          //Bisher eingegebene Pin zuruecksetzen:
          //while (!actual_pin_input.empty())actual_pin_input.pop_back();
          //"Ansicht wechseln" ans Display schicken...
          p2_msg = NULL;//p_displaymailbox->take_free_msg();
          if (p2_msg != NULL)
          {
            p2_msg->dest = "display_1";  
            p2_msg->origin = name;
            p2_msg->cmd1 = "#MN45,"; //MnChangeTemp = 45
          }
          state = ACTIVE;
          break;
          
	case ACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name; //msg wieder einlagern
            }
            else if (p_msg->cmd1 == "escape")
            { //configbutton wurde gedr�ckt
              //Die Fenster aktivieren/deaktivieren:
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
            }
            /*
            else if (p_msg->cmd1 == "1")
            {if(actual_pin_input.size() < 4) {actual_pin_input.push_back('1'); set_temp_1_changed= true;}}
            else if (p_msg->cmd1 == "2")
            {if(actual_pin_input.size() < 4) {actual_pin_input.push_back('2'); set_temp_1_changed= true;}}
            else if (p_msg->cmd1 == "3")
            {if(actual_pin_input.size() < 4) {actual_pin_input.push_back('3'); set_temp_1_changed= true;}}
            else if (p_msg->cmd1 == "4")
            {if(actual_pin_input.size() < 4) {actual_pin_input.push_back('4'); set_temp_1_changed= true;}}
            else if (p_msg->cmd1 == "5")
            {if(actual_pin_input.size() < 4) {actual_pin_input.push_back('5'); set_temp_1_changed= true;}}
            else if (p_msg->cmd1 == "6")
            {if(actual_pin_input.size() < 4) {actual_pin_input.push_back('6'); set_temp_1_changed= true;}}
            else if (p_msg->cmd1 == "7")
            {if(actual_pin_input.size() < 4) {actual_pin_input.push_back('7'); set_temp_1_changed= true;}}
            else if (p_msg->cmd1 == "8")
            {if(actual_pin_input.size() < 4) {actual_pin_input.push_back('8'); set_temp_1_changed= true;}}
            else if (p_msg->cmd1 == "9")
            {if(actual_pin_input.size() < 4) {actual_pin_input.push_back('9'); set_temp_1_changed= true;}}
            else if (p_msg->cmd1 == "0")
            {if(actual_pin_input.size() < 4) {actual_pin_input.push_back('0'); set_temp_1_changed= true;}}
            else if (p_msg->cmd1 == "clr")
            {while (!actual_pin_input.empty())actual_pin_input.pop_back(); set_temp_1_changed= true;}
            else if (p_msg->cmd1 == "backspace")
            {actual_pin_input.pop_back(); pin_changed= true;}
            */

            
            if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Als Trash zurueckschicken
            if (set_temp_1_changed)
            {
              p2_msg = NULL;//p_displaymailbox->take_free_msg();
              if (p2_msg != NULL)
              {              
                p2_msg->dest = "display_1";  
                p2_msg->origin = name;
                p2_msg->cmd1 = "send_direct_cmd3_data";
                while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use
                
                //MnClearPinInputField = 32
                //p2_msg->cmd3 = "#MN32,"; 
                //p2_msg->cmd3("#MN32,", "#MN32," + 100); 

                p2_msg->cmd2 = "#MN33,"; //MnClearWrongCode = 33
                for(int i=0; i<p2_msg->cmd2.size(); i++)
                {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data

                p2_msg->cmd2 = "#MN32,"; //MnClearPinInputField = 32
                for(int i=0; i<p2_msg->cmd2.size(); i++)
                {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                /*
                if (actual_pin_input.size() > 0)
                {
                  p2_msg->cmd2 = "#ZF15,#FZ8,0,#ZL33,5,";
                  for(int i=0; i<p2_msg->cmd2.size(); i++)
                  {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                  
                  for(int i=0; i<actual_pin_input.size();i++) //Text
                  {
                    p2_msg->cmd3.push_back(actual_pin_input[i]);
                  }
                }
                */
                p2_msg->cmd3.push_back('\x0A');
                set_temp_1_changed = false;
                
                
                /* //Old code, used string instead the vector. (cmd3 didnt exist before)
                p2_msg->cmd1 = "#MN32,"; //MnClearPinInputField = 32
                // #ZF16, ; set font no.
	        // #FZ WHITE,0 ; Set Text Color WHITE = 8
                // #ZL10,10," Set Temp. " ; set text
                if (actual_pin_input.size() > 0)
                {
                  p2_msg->cmd2 = "#ZF15,#FZ8,0,"; //Set Font, Set Color
                  p2_msg->cmd1.insert(p2_msg->cmd1.end(), p2_msg->cmd2.begin(), p2_msg->cmd2.end());             
                  p2_msg->cmd2 = "#ZL33,5,"; //Set Text Koordinaten
                  p2_msg->cmd1.insert(p2_msg->cmd1.end(), p2_msg->cmd2.begin(), p2_msg->cmd2.end());              
                  for(int i=0; i<actual_pin_input.size();i++) //Text
                  {
                    p2_msg->cmd1.push_back(actual_pin_input[i]);
                  }
                   p2_msg->cmd2 = "textend";
                  //'\x0A' <--Textende
                }
                */
              }
              //pin_changed = false;
            }
          }
          break;
          
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}

//-----------------------------------------------------------------------------

//------------------------------------------------------------------------------
//Keyboard fuer Gleitkommazahlen
Keyboard_1::Keyboard_1()
{
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  p_view = NULL;
  p_CDisplaymanager = NULL;
  //config_pin.assign("1234","1234"+4);
  //diagnose_pin.assign("5678","5678"+4);
  bool pin_changed = false;
  alignment = true; //false = horizontal, true = vertical
  limit_reached = false;
  called_window.reserve(WINDOWSNAMES_SIZE);
  actual_pin_input.reserve(10);
  
  direct_cmd.reserve(64);
  s_cmd.reserve(16);
}

void Keyboard_1::Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  
  m_pEventManager = pEventManager;
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
  alignment = b_alignment;
  nachkommastellen = 2;
    //EventHandler
    m_pEventManager->AddEventHandler( CEventNames::init_float_input, Keyboard_1::init_float_inputEventWrapper, this );
    m_pEventManager->AddEventHandler( CEventNames::keyboard_float_command, Keyboard_1::keyboard_float_commandEventWrapper, this );

}

void Keyboard_1::init_float_inputEvent(_input_float_EventArgument a )
{
    f_number[0] = a.actValue; //actual value
    f_number[1] = a.limitMax; //upper limit
    f_number[2] = a.limitMin; //lower limit
    e_dst = a.e_dst;
    called_window = a.origin.getBuffer();
    if ( a.mode == "F2") // 2 Nachkommastellen
    {
      nachkommastellen = 2;
      floatToVector2((float)f_number[0], &actual_pin_input, (char)nachkommastellen, true, &c_buffer);
      number_changed = true; //Erste Ausgabe des neuen Wertes erzwingen
      first_button = true;
      s_cmd = "#MN50,"; //MnKeyboardFloat = 50 ;Keyboard zur Eingabe von Gleitkommazahlen
      _event<void*> e("Keyboard_1", CEventNames::send_direct_cmd2_data, &s_cmd );
      m_pEventManager->RaiseEventSync(e);
    }
    else if ( a.mode == "F1") // 1 Nachkommastelle
    {
      nachkommastellen = 1;
      floatToVector2((float)f_number[0], &actual_pin_input, (char)nachkommastellen, true, &c_buffer);
      number_changed = true; //Erste Ausgabe des neuen Wertes erzwingen
      first_button = true;
      s_cmd = "#MN74,"; //MnKeyboardFloat_short = 74 ;Keyboard zur Eingabe von Gleitkommazahlen
      _event<void*> e("Keyboard_1", CEventNames::send_direct_cmd2_data, &s_cmd );
      m_pEventManager->RaiseEventSync(e);
    }

}

void Keyboard_1::keyboard_float_commandEvent( _string cmd )
{
    if (   cmd == "1"
             || cmd == "2"
             || cmd == "3"
             || cmd == "4"
             || cmd == "5"
             || cmd == "6"
             || cmd == "7"
             || cmd == "8"
             || cmd == "9")
    {
      if(first_button)
      {
        while (!actual_pin_input.empty())actual_pin_input.pop_back();
        actual_pin_input.push_back('+');
        first_button=false;
      }
      if((actual_pin_input.size() < 7))
      {
    //                if (!((actual_pin_input.size() > 3)
        if (!((actual_pin_input.size() > (nachkommastellen+1))
              && (actual_pin_input[actual_pin_input.size()-(nachkommastellen+1)] == '.'))
            )
        {
          if (!(no_dot_in_vector(&actual_pin_input) && (actual_pin_input.size() > (nachkommastellen+2))))
          {
            actual_pin_input.push_back(cmd.getBuffer()[0]);
            number_changed= true;
          }
        }
      }
    }
    else if (cmd == "0")
    {
      if(first_button && cmd == "0")
      {
        while (!actual_pin_input.empty())actual_pin_input.pop_back();
        actual_pin_input.push_back('+');
        
      }
      if(actual_pin_input.size() == 1)
      {//Bisher noch keine Zahl eingegeben
        actual_pin_input.push_back('0');
        actual_pin_input.push_back('.');
        number_changed= true;
      }
      else if((actual_pin_input.size() < (nachkommastellen+5)))
      {                
        if (!(actual_pin_input[actual_pin_input.size()-(nachkommastellen+1)] == '.'))
        {
          if (!(no_dot_in_vector(&actual_pin_input) && (actual_pin_input.size() > (nachkommastellen+2))))
          {
            actual_pin_input.push_back('0');
            number_changed= true;
          }
        }
      }
      first_button=false;
    }
    else if (cmd == "clr")
    {
      while (!actual_pin_input.empty())actual_pin_input.pop_back();
      actual_pin_input.push_back('+'); //Vorzeichen hinzufuegen
      number_changed= true;    
      first_button=false;
    }
    else if (cmd == "dot")
    {
      if(first_button)
      {
        while (!actual_pin_input.empty())actual_pin_input.pop_back();
        actual_pin_input.push_back('+');
        first_button=false;
      }
      if(actual_pin_input.size() < 7)
      {
        if(no_dot_in_vector(&actual_pin_input)
           && (actual_pin_input.size() > 1)) //Vorzeichen Ueberspringen
        {//Bisher kein Punkt in der eingegebenen Zahl
          actual_pin_input.push_back('.');
          number_changed= true;
        }
        else if(actual_pin_input.size() == 1)
        {//Bisher noch keine Zahl eingegeben
          actual_pin_input.push_back('0');
          actual_pin_input.push_back('.');
          number_changed= true;
        }
      }
    }
    else if (cmd == "backspace")
    {
      if (actual_pin_input.size() != 1)//Nicht bloss das Vorzeichen vorhanden
      {
        while((actual_pin_input[actual_pin_input.size()-1] == 0) && (actual_pin_input.size() > 0))actual_pin_input.pop_back();
        
        actual_pin_input.pop_back();
        number_changed= true;
      }
      first_button=false;
    }
    else if (cmd == "plus_minus")
    {
      if(first_button)
      {
        while (!actual_pin_input.empty())actual_pin_input.pop_back();
        actual_pin_input.push_back('-'); //Vorzeichen hinzufuegen
        number_changed= true;
        first_button = false;
      }
      else
      {
        if (actual_pin_input[0] == '+') actual_pin_input[0] = '-';
        else if (actual_pin_input[0] == '-') actual_pin_input[0] = '+';
        else actual_pin_input[0] = '+';
      
        if (actual_pin_input.size() > 1)
        { //Falls eine der Grenzen erreicht: Zahl zuschneiden:
          //Vom Vektor in ein normales Array kopieren
          for (int i=0; i<20; i++) c_buffer[i] = 0;
          copy(actual_pin_input.begin(), actual_pin_input.end(), c_buffer);
          c_buffer[actual_pin_input.size()] = 0; //c-String ende einfuegen
          //In eine float Zahl wandeln lassen:
          f_numberbuffer = atof(c_buffer);
          if(!f_Rangecheck(&f_numberbuffer, f_number[1], f_number[2])) //Zahl ggf. begrenzen lassen
          {
            limit_reached = true;
          }
    //                doubleToVector(f_numberbuffer, &actual_pin_input, 2, true); //Und zurueck in den Ausgabevektor schreiben
          floatToVector2((float)f_numberbuffer, &actual_pin_input, (char)nachkommastellen, true, &c_buffer);
        }
        number_changed= true;
      }
    }
    else if (   cmd == "plus_ten"
             || cmd == "plus_one"
             || cmd == "plus_zeroone"
             || cmd == "plus_zerozeroone"
             || cmd == "minus_ten"
             || cmd == "minus_one"
             || cmd == "minus_zeroone"
             || cmd == "minus_zerozeroone"
             )
    {
      //Vom Vektor in ein normales Array kopieren
      copy(actual_pin_input.begin(), actual_pin_input.end(), c_buffer);
      c_buffer[actual_pin_input.size()] = 0; //c-String ende einfuegen
      
      //i_numberbuffer = atoi(c_buffer);
       
      //In eine float Zahl wandeln lassen:
      f_numberbuffer = atof(c_buffer);
    
      if (cmd == "plus_ten")             f_numberbuffer += 10.00;
      else if (cmd == "plus_one")          f_numberbuffer += 1.000;
      else if (cmd == "plus_zeroone")      f_numberbuffer += 0.100;
      else if (cmd == "plus_zerozeroone")  f_numberbuffer += 0.010;
      else if (cmd == "minus_ten")         f_numberbuffer -= 10.00;
      else if (cmd == "minus_one")         f_numberbuffer -= 1.000;
      else if (cmd == "minus_zeroone")     f_numberbuffer -= 0.100;
      else if (cmd == "minus_zerozeroone") f_numberbuffer -= 0.010;
    
    if(!f_Rangecheck(&f_numberbuffer, f_number[1], f_number[2])) //Zahl ggf. begrenzen lassen
      {
        limit_reached = true;
      }
      
      ftoa(c_buffer, f_numberbuffer, (char)nachkommastellen, 4, 1);
    
      while (!actual_pin_input.empty())actual_pin_input.pop_back(); //empty the vector before use
      for(int i=0; i<7; i++)
      {
        if (c_buffer[i] != ' ') actual_pin_input.push_back(c_buffer[i]);
      }
      
    
      copy(actual_pin_input.begin(), actual_pin_input.end(), c_buffer);
    
      //doubleToVector(f_numberbuffer, &actual_pin_input, 4, true); //Und zurueck in den Ausgabevektor schreiben
      number_changed= true;
    }
     else if ( cmd == "enter")
    {
      //if( called_window == "mainmenu" )
      //{
        copy(actual_pin_input.begin(), actual_pin_input.end(), c_buffer);
        c_buffer[actual_pin_input.size()] = 0; //c-String ende einfuegen
        //In eine float Zahl wandeln lassen:
        f_numberbuffer = atof(c_buffer);
        //Zahl ggf. begrenzen lassen
				if (f_Rangecheck(&f_numberbuffer, f_number[1], f_number[2])) {
					p_CDisplaymanager->set_state(&name, INACTIVE);
					p_CDisplaymanager->set_state(&called_window, JUST_ACTIVATED);
					_event<float> e( "Keyboard", e_dst, f_numberbuffer );
					EventManager.RaiseEvent(e);
				} 
				else {
					limit_reached = true; // Signals too high or low number
		      number_changed= true; // Required, to trigger display of limit error
					first_button = true;  // Next button press will be handled as first button
				}
      /*
			}
      else
      {
        copy(actual_pin_input.begin(), actual_pin_input.end(), c_buffer);
        c_buffer[actual_pin_input.size()] = 0; //c-String ende einfuegen
        //In eine float Zahl wandeln lassen:
        f_numberbuffer = atof(c_buffer);
        f_Rangecheck(&f_numberbuffer, f_number[1], f_number[2]); //Zahl ggf. begrenzen lassen
        
        p_CDisplaymanager->set_state(&name, INACTIVE);
        p_CDisplaymanager->set_state(&called_window, JUST_ACTIVATED);

        _event<float> e( "Keyboard", e_dst, f_numberbuffer );
        EventManager.RaiseEvent(e);
        
			}
			*/
    }
    else if ( cmd == "esc")
    {
      //Nutzer moechte die Eingabe ueber ESC komplett abbrechen,
      //Es wird kein neuer Wert uebertragen.
      // (Der alte Wert wurde trotzdem zwischengespeichert)              
        p_CDisplaymanager->set_state(&name, INACTIVE);
        p_CDisplaymanager->set_state(&called_window, JUST_ACTIVATED);
    }
    
}

void Keyboard_1::cycCalc()
{
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
	switch(state)
	{
	case INACTIVE:
        break;
	case JUST_ACTIVATED:
          //Bisher eingegebene Pin zuruecksetzen:
          //while (!actual_pin_input.empty())actual_pin_input.pop_back();          
          number_changed = true; //Erste Ausgabe des neuen Wertes erzwingen
          first_button = true;
          //while (!actual_pin_input.empty())actual_pin_input.pop_back();
          state = ACTIVE;
          break;
          
	case ACTIVE:          
          if (number_changed)
          {
            while (!direct_cmd.empty())direct_cmd.pop_back(); //empty the vector before use
            
            //MnClearPinInputField = 32
            //p2_msg->cmd3 = "#MN32,"; 
            //p2_msg->cmd3("#MN32,", "#MN32," + 100); 

            if (limit_reached)
            {//Die Zahl wurde bei der Eingabe auf 
              s_cmd = "#MN64,"; //MnShowLimitReached = 64
              for(int i=0; i<s_cmd.size(); i++)
              {direct_cmd.push_back((char)s_cmd[i]);}//copy data
              // Show minimal allowed 
              pushing_back(&direct_cmd, "#ZR160,100,", sizeof("#ZR160,100,")-1);
							ftoa(c_buffer, f_number[2], 1, 4, 1);
							pushing_back(&direct_cmd, c_buffer, 6);							
              direct_cmd.push_back('\x0A');
              // Show maximal allowed value
              pushing_back(&direct_cmd, "#ZR160,127,", sizeof("#ZR160,127,")-1);
							ftoa(c_buffer, f_number[1], 1, 4, 1);
							pushing_back(&direct_cmd, c_buffer, 6);							
              direct_cmd.push_back('\x0A');
              limit_reached = false;
            }
            else
            {
              s_cmd = "#MN65,"; //MnClearLimitReached = 65 ;Keyboard, ungueltiger Wert eingegeben, Warnung wieder loeschen
              for(int i=0; i<s_cmd.size(); i++)
              {direct_cmd.push_back((char)s_cmd[i]);}//copy data
            }
            
            s_cmd = "#MN54,"; //MnKeyBoardClearInputField = 54
            for(int i=0; i<s_cmd.size(); i++)
            {direct_cmd.push_back((char)s_cmd[i]);}//copy data                
            if (actual_pin_input.size() > 0)
            {
              if (alignment)
              { //vertical
                //p2_msg->cmd2 = "#ZF15,#FZ8,0,#ZL61,29,";
                pushing_back(&direct_cmd, "#ZF24,#FZ8,0,#ZR260,10,", sizeof("#ZF24,#FZ8,0,#ZR260,10,")-1);
              }
              else
              { //horizontal
                pushing_back(&direct_cmd, "#ZF25,#FZ8,0,#ZR207,15,", sizeof("#ZF25,#FZ8,0,#ZR207,15,")-1);
              }
              
              for(int i=0; i<actual_pin_input.size();i++) //Text
              {
                direct_cmd.push_back(actual_pin_input[i]);
              }
              direct_cmd.push_back('\x0A');
              _event<void*> e("Keyboard_1", CEventNames::send_direct_cmd3_data, &direct_cmd );
              m_pEventManager->RaiseEventSync(e);
              number_changed = false;
          	}
          //pin_changed = false;
          }
          break;
          
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}

//Keyboard fuer Ganzzahlen
Keyboard_2::Keyboard_2()
{
  actual_pin_input.reserve(30);
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
  //config_pin.assign("1234","1234"+4);
  //diagnose_pin.assign("5678","5678"+4);
  bool pin_changed = false;
  alignment = true; //false = horizontal, true = vertical
  limit_reached = false;
  parametername.reserve(30);
  called_window.reserve(WINDOWSNAMES_SIZE);
  
  direct_cmd.reserve(64);
  s_cmd.reserve(16);
}

void Keyboard_2::Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  
  m_pEventManager = pEventManager;
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
  alignment = b_alignment;
//  just_activated_ = false;
  //MB EventHandler
  m_pEventManager->AddEventHandler( CEventNames::init_int_input, Keyboard_2::init_int_inputEventWrapper, this );
  m_pEventManager->AddEventHandler( CEventNames::keyboard_int_command, Keyboard_2::keyboard_int_commandEventWrapper, this );
  
}

void Keyboard_2::init_int_inputEvent( _input_int_EventArgument a )
{
  i_number[0] = a.i1; //actual value
  i_number[1] = a.i2; //upper limit
  i_number[2] = a.i3; //lower limit
  e_return = a.e_dst;
  called_window = a.origin.getBuffer();
  intToVector(i_number[0], &actual_pin_input, false);
}

void Keyboard_2::keyboard_int_commandEvent( _string s )
{	
	// A number key was pressed
	if (  s == "1"
		 || s == "2"
		 || s == "3"
		 || s == "4"
		 || s == "5"
		 || s == "6"
		 || s == "7"
		 || s == "8"
		 || s == "9"
		 || s == "0")
	{
		// In case of first digit is a number, we clear current input value string
		if(first_button)
		{
			while (!actual_pin_input.empty())actual_pin_input.pop_back();
			first_button=false;
		}

		// We can not enter more then 6 digits
		if((actual_pin_input.size() < 7))
		{
			// We do not display trailing zeros for numbers > 0
			if (actual_pin_input.size()==1 && actual_pin_input[0] == '0') actual_pin_input.pop_back();

			// Append input to current input string and display it
			actual_pin_input.push_back(s.getBuffer()[0]); 
			number_changed= true;
		}
	}
	// The "Clear" key was pressed
	else if ( s == "clr")
	{
		// Empty current input string
		while (!actual_pin_input.empty())actual_pin_input.pop_back();
		number_changed= true;
	}
	// The "Back" key was pressed
	else if ( s == "backspace")
	{
		// Remove last digit of current input string, if not already empty
		if (actual_pin_input.size() != 0)
		{
			actual_pin_input.pop_back(); 
			// I we have removed the last digit, we display a zero
			if (actual_pin_input.size() == 0) actual_pin_input.push_back('0');
			first_button=false;
			number_changed= true;
		}
	}
	// The "Enter" key was pressed
	else if ( s == "enter")
	{
		// Convert input string to integer 
		copy(actual_pin_input.begin(), actual_pin_input.end(), c_buffer);
		c_buffer[actual_pin_input.size()] = 0; // c-String ende einfuegen
		i_numberbuffer = atoi(c_buffer);

		// Check the range.
		if (i_Rangecheck(&i_numberbuffer, i_number[1], i_number[2])) 
		{
			// Range not exceeded: return number to calling display and reactivate this display
			_event<int> e( "Keyboard2", e_return, i_numberbuffer );
			m_pEventManager->RaiseEvent(e);
			p_CDisplaymanager->set_state(&name, INACTIVE);
			p_CDisplaymanager->set_state(&called_window, JUST_ACTIVATED);
		} 
		else 
		{
			// Range exceeded: display an error message
			limit_reached = true; // Signals too high or low number
			number_changed= true; // Required, to trigger display of limit error
			first_button = true;  // Next button press will be handled as first button
		}
	}
	// The "Escape" key was pressed
	else if ( s == "esc")
	{
		// Return to calling window without doing anything
		p_CDisplaymanager->set_state(&name, INACTIVE);
		p_CDisplaymanager->set_state(&called_window, JUST_ACTIVATED);
	}
}

void Keyboard_2::cycCalc()
{
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
	switch(state)
	{
	case INACTIVE:
        break;
	case JUST_ACTIVATED:
          //Bisher eingegebene Pin zuruecksetzen:
          while (!actual_pin_input.empty())actual_pin_input.pop_back();
          //"Ansicht wechseln" ans Display schicken...
          {
            s_cmd = "#MN51,"; //MnKeyboardInt = 51 ;Keyboard zur Eingabe von Festkommazahlen
            _event<void*> e("Keyboard_2", CEventNames::send_direct_cmd2_data, &s_cmd );
            m_pEventManager->RaiseEventSync(e);
          }
          number_changed = true; //Erste Ausgabe des neuen Wertes erzwingen
          while (!actual_pin_input.empty())actual_pin_input.pop_back();
//          just_activated_ = true;
          state = ACTIVE;
//          number_changed = true;
          first_button = true;
          break;
          
	case ACTIVE:          
            if (number_changed)
            {
                while (!direct_cmd.empty())direct_cmd.pop_back(); //empty the vector before use
                
                //MnClearPinInputField = 32
                //p2_msg->cmd3 = "#MN32,"; 
                //p2_msg->cmd3("#MN32,", "#MN32," + 100); 
                
                if (limit_reached)
                {//Die Zahl wurde bei der Eingabe auf 
                  s_cmd = "#MN64,"; //MnShowLimitReached = 64
                  for(int i=0; i<s_cmd.size(); i++)
                  	{direct_cmd.push_back((char)s_cmd[i]);}//copy data
									// Show minimal allowed 
									pushing_back(&direct_cmd, "#ZR160,100,", sizeof("#ZR160,100,")-1);
									//ftoa(c_buffer, i_number[2], 1, 4, 1);
									ltoa(c_buffer, (long)i_number[2], 1, 6, 0);
									pushing_back(&direct_cmd, c_buffer, 6);							
									direct_cmd.push_back('\x0A');
									// Show maximal allowed value
									pushing_back(&direct_cmd, "#ZR160,127,", sizeof("#ZR160,127,")-1);
//									ftoa(c_buffer, i_number[1], 1, 4, 1);
									ltoa(c_buffer, (long)i_number[1], 1, 6, 0);
									pushing_back(&direct_cmd, c_buffer, 6);							
									direct_cmd.push_back('\x0A');
									limit_reached = false;
                }
                else
                {
                  s_cmd = "#MN65,"; //MnClearLimitReached = 65 ;Keyboard, ungueltiger Wert eingegeben, Warnung wieder loeschen
                  for(int i=0; i<s_cmd.size(); i++)
                  {direct_cmd.push_back((char)s_cmd[i]);}//copy data
                }
                
                s_cmd = "#MN54,"; //MnKeyBoardClearInputField = 54
                for(int i=0; i<s_cmd.size(); i++)
                {direct_cmd.push_back((char)s_cmd[i]);}//copy data                
                if (actual_pin_input.size() > 0)
                {
                  if (alignment)
                  { //vertical
                    //p2_msg->cmd2 = "#ZF15,#FZ8,0,#ZL61,29,";
                    pushing_back(&direct_cmd, "#ZF24,#FZ8,0,#ZR260,10,", sizeof("#ZF24,#FZ8,0,#ZR260,10,")-1);
                  }
                  else
                  { //horizontal
                    pushing_back(&direct_cmd, "#ZF25,#FZ8,0,#ZR207,15,", sizeof("#ZF25,#FZ8,0,#ZR207,15,")-1);
                  }
                  
                  for(int i=0; i<actual_pin_input.size();i++) //Text
                  {
                    direct_cmd.push_back(actual_pin_input[i]);
                  }
                }
                direct_cmd.push_back('\x0A');
                _event<void*> e("", CEventNames::send_direct_cmd3_data, &direct_cmd );
                m_pEventManager->RaiseEventSync(e);
                number_changed = false;
          }
          break;
          
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}


Error_1::Error_1()
{ //Sicherheitsinit
  
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = SLEEPING;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
  former_active_window.reserve(WINDOWSNAMES_SIZE);
  messagebox_text.reserve(100);
  
  direct_cmd.reserve(128);
  s_cmd.reserve(16);
  
}

void Error_1::Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = SLEEPING;
  
  m_pEventManager = pEventManager;
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
  active_error = 0;
  error_button_clicked = false;
  alignment = b_alignment;
  //timeshift_calls = 0;
  //MB EventHandler
  m_pEventManager->AddEventHandler( CEventNames::drop_errormessage, Error_1::drop_errormessageEventWrapper, this );
  m_pEventManager->AddEventHandler( CEventNames::remove_errormessage, Error_1::remove_errormessageEventWrapper, this );
  m_pEventManager->AddEventHandler( CEventNames::drop_infomessage, Error_1::drop_infomessageEventWrapper, this ); 
  m_pEventManager->AddEventHandler( CEventNames::red_ball_pressed, Error_1::red_ball_pressedEventWrapper, this ); 
  m_pEventManager->AddEventHandler( CEventNames::error_1_ok, Error_1::error_1_okEventWrapper, this ); 
  m_pEventManager->AddEventHandler( CEventNames::drop_fatalerrormessage, Error_1::drop_fatalerrormessageEventWrapper, this ); 
  
}

void Error_1::drop_errormessageEvent( _string s )
{ //Eine einfache Fehlermeldung soll angezeigt werden:
  if(active_error != 3)
  {//Eine schwere Fehlermeldung kann von dieser nicht ueberschrieben werden
    messagebox_text = s.getBuffer();    
    active_error = 2; //Einfache Fehlermeldung
    //Namen des aktiven Fensters ermitteln und zwischenspeichern:
    p_CDisplaymanager->it = p_CDisplaymanager->windowlist.begin();
    while (p_CDisplaymanager->it != p_CDisplaymanager->windowlist.end() //listenende erreicht
           && !((*p_CDisplaymanager->it)->state == ACTIVE) //aktives Fenster noch nicht gefunden
           && !((*p_CDisplaymanager->it)->state == JUST_ACTIVATED)) //gerade aktiviertes Fenster noch nicht gefunden
    {
      p_CDisplaymanager->it++;
    }
    // Sichern des Fenster -status und -namens
    if ((*p_CDisplaymanager->it)->name != name)
    { //Niederpriore Meldungen ausschliessen:
      former_active_window = (*p_CDisplaymanager->it)->name;
    }
    else former_active_window = "mainmenu";
    former_windowstate =  (*p_CDisplaymanager->it)->state;
    // errorhandler aktiv schalten:
    state = JUST_ACTIVATED;
    p_CDisplaymanager->set_state(&former_active_window, INACTIVE);
    active_error = 2; //Einfache Fehlermeldung
    //Warnungssymbol im Mainmenu (roter Ball) falls vorhanden ausblenden:
    _event<bool> e("Error_1", CEventNames::advice_symbol, false );
    m_pEventManager->RaiseEvent(e);
  }
}


void Error_1::remove_errormessageEvent( bool b )
{//Fehlerursache wurde anscheinend beseitigt und die Blockade durch die Fehlermeldung wird aufgehoben...
  if (active_error == 2)
  {
    state = INACTIVE;
    p_CDisplaymanager->set_state(&former_active_window, JUST_ACTIVATED);
  }
  active_error = 0;
	messagebox_text.clear();
}

void Error_1::drop_infomessageEvent( _string s )
{ //Eine Infomessage soll signalisiert werden:
  if ( s != messagebox_text.data() )
  {
    if(active_error == 0)
    {//Infomessage hat die niedrigste Prioritaet unter den Meldungen
      messagebox_text = s.getBuffer(); //Nachricht Speichern          
      
      //Mainmenu eine Benachrichtigung zum Anzeigen des roten, runden Infosymbols schicken:
      _event<bool> e("Error_1", CEventNames::advice_symbol, true );
      m_pEventManager->RaiseEvent(e);
      active_error = 1; //Infomessage
    }
    else if (active_error == 1)
    {
      messagebox_text = p_msg->cmd2;
    }
  }
}

void Error_1::red_ball_pressedEvent(bool b)
{
  if(active_error == 1 )
  {
    { //Nach betaetigen des 'roten Infoballs' wird der errorhandler aktiv: 
      //Namen des aktiven Fensters ermitteln und zwischenspeichern:
      p_CDisplaymanager->it = p_CDisplaymanager->windowlist.begin();
      while (p_CDisplaymanager->it != p_CDisplaymanager->windowlist.end() //listenende erreicht
             && !((*p_CDisplaymanager->it)->state == ACTIVE) //aktives Fenster noch nicht gefunden
             && !((*p_CDisplaymanager->it)->state == JUST_ACTIVATED)) //gerade aktiviertes Fenster noch nicht gefunden
      {
        p_CDisplaymanager->it++;
      }
      // Sichern des Fenster -status und -namens
      former_active_window = (*p_CDisplaymanager->it)->name;
      former_windowstate =  (*p_CDisplaymanager->it)->state;
      // errorhandler aktiv schalten:
      state = JUST_ACTIVATED;
      //p_CDisplaymanager->set_state(former_active_window, INACTIVE);
      //Alle Fenster deaktivieren:
      p_CDisplaymanager->it = p_CDisplaymanager->windowlist.begin();
      while (p_CDisplaymanager->it != p_CDisplaymanager->windowlist.end())
      {
        (*p_CDisplaymanager->it)->state = INACTIVE;
        p_CDisplaymanager->it++;
      }
      state = JUST_ACTIVATED;
    }
  }
}


void Error_1::error_1_okEvent(bool b)
{//Ok-Button der Infomessage wurde betaetigt, alten Zustand wieder herstellen:
  //state = INACTIVE;
  //Alle Fenster deaktivieren:
  p_CDisplaymanager->it = p_CDisplaymanager->windowlist.begin();
  while (p_CDisplaymanager->it != p_CDisplaymanager->windowlist.end())
  {
    (*p_CDisplaymanager->it)->state = INACTIVE;
    p_CDisplaymanager->it++;
  }
  //p_CDisplaymanager->set_state(former_active_window, former_windowstate);
  error_button_clicked = true;
  p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
  //Warnungssymbol im Mainmenu (roter Ball) wieder ausblenden:
  _event<bool> e("Error_1", CEventNames::advice_symbol, false );
  m_pEventManager->RaiseEvent(e);
	
	// Das Zur�cksetzen aller Fehler funktioniert noch nicht!
  //_event<int> e1("Error_1", CEventNames::reset_all_errors, 1);
  //m_pEventManager->RaiseEvent(e1);
}

void Error_1::drop_fatalerrormessageEvent(bool b)
{ //Eine schwere Fehlermeldung soll angezeigt werden:
    messagebox_text = p_msg->cmd2; //Nachricht Speichern
    //Namen des aktiven Fensters ermitteln und zwischenspeichern:
    p_CDisplaymanager->it = p_CDisplaymanager->windowlist.begin();
    while (p_CDisplaymanager->it != p_CDisplaymanager->windowlist.end() //listenende erreicht
           && !((*p_CDisplaymanager->it)->state == ACTIVE) //aktives Fenster noch nicht gefunden
           && !((*p_CDisplaymanager->it)->state == JUST_ACTIVATED)) //gerade aktiviertes Fenster noch nicht gefunden
    {
      p_CDisplaymanager->it++;
    }
    // Sichern des Fenster -status und -namens
    if ((*p_CDisplaymanager->it)->name != name)
    { //Niederpriore Meldungen ausschliessen:
      former_active_window = (*p_CDisplaymanager->it)->name;
    }
    else former_active_window = "mainmenu";
    former_windowstate =  (*p_CDisplaymanager->it)->state;
    // errorhandler aktiv schalten:
    state = JUST_ACTIVATED;
    p_CDisplaymanager->set_state(&former_active_window, INACTIVE);
    active_error = 3; //Einfache Fehlermeldung
    //Warnungssymbol im Mainmenu (roter Ball) falls vorhanden ausblenden:
    _event<bool> e("Error_1", CEventNames::advice_symbol, false );
    m_pEventManager->RaiseEvent(e);
}


void Error_1::cycCalc()
{
	// Check if window-object was initialised at least once before execution
	// If not, this window may show harmful behaviour and will not be further executed:
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
	switch(state)
	{
	case INACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name;
            }
            else if (p_msg->cmd1 == "escape")
            { //escapebutton wurde gedr�ckt
              //Die Fenster aktivieren/deaktivieren:
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
            }
            if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Nachricht als empfangen zurueckschicken...
          }
          break;
	case JUST_ACTIVATED:
          if (active_error != 0)
          {
            if (active_error == 1)
            {//Infomessage anzeigen (OK-Button bet�tigen ist ausreichend)
                int Zeile = 1;
                int y_space = 24;
                int y_start = 130;
                if (!alignment)
                {//Horizontal
                  y_start = 40;
                }
                while (!direct_cmd.empty())direct_cmd.pop_back(); //empty the vector before use
                //Kopieren der Nachricht &
                //Jedem #-Symbol wird eine neue Zeile zugeordnet...
                //Schrift einstellen:
                pushing_back(&direct_cmd, "#WY1,0,#MN76,#ZF22,#FZ1,8,", sizeof("#WY1,0,#MN76,#ZF22,#FZ1,8,")-1); //MnInfoWindow = 76 (Schwarze Felder loeschen)
                
                for (int g=0; g<messagebox_text.size();g++)
                {
                  if ((g == 0) || (messagebox_text[g] == '#')) //Erste Zeile oder Neue-Zeile-Zeichen
                  {
                    if (g != 0) direct_cmd.push_back('\x0A');
                    if (messagebox_text[g] == '#') Zeile++;
                    if (!alignment)
                    {//Horizontal
                      s_cmd = "#ZL130,";
                    }
                    else
                    {//Vertikal
                      s_cmd = "#ZL26,";
                    }
                    for(int i=0; i<s_cmd.size(); i++)
                    {direct_cmd.push_back((char)s_cmd[i]);}//copy data
                    
                    sprintf(_acBuffer,"%d,",(y_start+y_space*Zeile)); //y ermitteln                  
                    for(int i=0; _acBuffer[i]!=0;i++) //Text in den vector kopieren
                    {direct_cmd.push_back(_acBuffer[i]);}
                    
                    if (messagebox_text[g] != '#') direct_cmd.push_back(messagebox_text[g]);
                  }
                  else
                  {
                    if (messagebox_text[g] != '#') direct_cmd.push_back(messagebox_text[g]);
                  }
                }
                direct_cmd.push_back('\x0A');
                _event<void*> e("Error_1", CEventNames::send_direct_cmd3_data, &direct_cmd );
                m_pEventManager->RaiseEventSync(e);
            }
            else if (active_error == 2)
            {//Fehler anzeigen (Fehler beheben notwendig)
                int Zeile = 1;
                int y_space = 24;
                int y_start = 130;
                if (!alignment)
                {//Horizontal
                  y_start = 40;
                }

                while (!direct_cmd.empty())direct_cmd.pop_back(); //empty the vector before use
                //Kopieren der Nachricht &
                //Jedem #-Symbol wird eine neue Zeile zugeordnet...
                //Schrift einstellen:
                pushing_back(&direct_cmd, "#WY1,0,#MN78,#ZF16,#FZ1,8,", sizeof("#WY1,0,#MN78,#ZF16,#FZ1,8,")-1); //MnErrorWindow = 78
                
                for (int g=0; g<messagebox_text.size();g++)
                {
                  if ((g == 0) || (messagebox_text[g] == '#')) //Erste Zeile oder Neue-Zeile-Zeichen
                  {
                    if (g != 0) direct_cmd.push_back('\x0A');
                    if (messagebox_text[g] == '#') Zeile++;
                    if (!alignment)
                    {//Horizontal
                      s_cmd = "#ZL130,";
                    }
                    else
                    {//Vertikal
                      s_cmd = "#ZL26,";
                    }
                    for(int i=0; i<s_cmd.size(); i++)
                    {direct_cmd.push_back((char)s_cmd[i]);}//copy data
                    
                    sprintf(_acBuffer,"%d,",(y_start+y_space*Zeile)); //y ermitteln                  
                    for(int i=0; _acBuffer[i]!=0;i++) //Text in den vector kopieren
                    {direct_cmd.push_back(_acBuffer[i]);}
                    
                    if (messagebox_text[g] != '#') direct_cmd.push_back(messagebox_text[g]);
                  }
                  else
                  {
                    if (messagebox_text[g] != '#') direct_cmd.push_back(messagebox_text[g]);
                  }
                }
                direct_cmd.push_back('\x0A');
                _event<void*> e("Error_1", CEventNames::send_direct_cmd3_data, &direct_cmd );
                m_pEventManager->RaiseEventSync(e);
            }
            else if (active_error == 3)
            {//Schweren Fehler anzeigen (Reset notwendig)
                int Zeile = 1;
                int y_space = 24;
                int y_start = 130;
                if (!alignment)
                {//Horizontal
                  y_start = 40;
                }

                while (!direct_cmd.empty())direct_cmd.pop_back(); //empty the vector before use
                //Kopieren der Nachricht &
                //Jedem #-Symbol wird eine neue Zeile zugeordnet...
                //Schrift einstellen:
                pushing_back(&direct_cmd, "#WY1,0,#MN77,#ZF16,#FZ1,8,", sizeof("#WY1,0,#MN77,#ZF16,#FZ1,8,")-1);//MnFatalErrorWindow = 77
                
                for (int g=0; g<messagebox_text.size();g++)
                {
                  if ((g == 0) || (messagebox_text[g] == '#')) //Erste Zeile oder Neue-Zeile-Zeichen
                  {
                    if (g != 0) direct_cmd.push_back('\x0A');
                    if (messagebox_text[g] == '#') Zeile++;
                    if (!alignment)
                    {//Horizontal
                      s_cmd = "#ZL130,";
                    }
                    else
                    {//Vertikal
                      s_cmd = "#ZL26,";
                    }
                    for(int i=0; i<p2_msg->cmd2.size(); i++)
                    {direct_cmd.push_back((char)s_cmd[i]);}//copy data
                    
                    sprintf(_acBuffer,"%d,",(y_start+y_space*Zeile)); //y ermitteln                  
                    for(int i=0; _acBuffer[i]!=0;i++) //Text in den vector kopieren
                    {direct_cmd.push_back(_acBuffer[i]);}
                    
                    if (messagebox_text[g] != '#') direct_cmd.push_back(messagebox_text[g]);
                  }
                  else
                  {
                    if (messagebox_text[g] != '#') direct_cmd.push_back(messagebox_text[g]);
                  }
                }
                direct_cmd.push_back('\x0A');
                _event<void*> e("Error_1", CEventNames::send_direct_cmd3_data, &direct_cmd );
                m_pEventManager->RaiseEventSync(e);
            }
          }
          //timeshift_calls = 0;
          state = ACTIVE;
          break;
	case ACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name; //msg wieder einlagern
            }
            else if (p_msg->cmd1 == "escape")
            { //escapebutton wurde gedr�ckt
              //Die Fenster aktivieren/deaktivieren:
              p_CDisplaymanager->set_state(&name, INACTIVE);
              p_CDisplaymanager->set_state("mainmenu", JUST_ACTIVATED);
            }
          if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Als Trash zurueckschicken
          }
          

          
          break;
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}


#if 0

Dimmer_1::Dimmer_1()
{
  displayname.reserve(WINDOWSNAMES_SIZE);
  name.reserve(WINDOWSNAMES_SIZE);
  state = INACTIVE;
  name = "0";
  p_view = NULL;
  p_CDisplaymanager = NULL;
}



void Dimmer_1::Init(CEventManager* pEventManager, CView* p_viewobj,  CDisplaymanager *p_dispmanager, bool b_alignment)
{
  state = INACTIVE;
  
  m_pEventManager = pEventManager;
  p_view = p_viewobj;
  p_CDisplaymanager = p_dispmanager;
  callcount = 0;
  alignment = b_alignment;
  is_dimmed = false;
}

void Dimmer_1::cycCalc()
{
//	if ((get_name() == "0") || (p_displaymailbox == NULL) || displayname == "0" || p_CDisplaymanager == NULL) return;
	switch(state)
	{
	case INACTIVE:
          p_msg = NULL;//p_displaymailbox->grab_msg(&name);
          if (p_msg != NULL)
          {
            if (p_msg->cmd1 == "trash" && p_msg->dest == name) //zurueckerhaltene Nachricht recyceln
            {
              p_msg->dest = "";//p_displaymailbox->name;
            }
            else if (p_msg->cmd1 == "touched") //USer hat das Display ber�hrt, Helligkeit wird auf 100% gesetzt.
            {
              if (is_dimmed)
                {
                  p2_msg = NULL;//p_displaymailbox->take_free_msg();
                  if (p2_msg != NULL)
                  {
                    p2_msg->dest = "display_1";  
                    p2_msg->origin = name;
                    p2_msg->cmd1 = "send_direct_cmd3_data";
                    while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use
                    
                   p2_msg->cmd2 = "#YH100,"; //Displayhelligkeit auf 100% setzen
                    for(int i=0; i<p2_msg->cmd2.size(); i++)
                    {p2_msg->cmd3.push_back((char)p2_msg->cmd2[i]);}//copy data
                    is_dimmed = false;
                  }
               }
              callcount = 0; //Anzahl der Aufrufe zuruecksetzen
            }
            if (p_msg->cmd1 != "trash") ;//p_displaymailbox->trashmark(p_msg); //Unbekannte Nachricht als empfangen zurueckschicken...
          }
          
          callcount++;
          if (callcount > 1600)
          {
              p2_msg = NULL;//p_displaymailbox->take_free_msg();
              if (p2_msg != NULL)
              {
                p2_msg->dest = "display_1";  
                p2_msg->origin = name;
                p2_msg->cmd1 = "send_direct_cmd3_data";
                while (!p2_msg->cmd3.empty())p2_msg->cmd3.pop_back(); //empty the vector before use
                if (alignment)
                {//Vertikal
                  pushing_back(&(p2_msg->cmd3), "#YH50,#FE,0,0,0,0,0,0,#AT,0,0,271,479,173,0,", sizeof("#YH50,#FE,0,0,0,0,0,0,#AT,0,0,271,479,173,0,")-1); //Displayhelligkeit auf 20% setzen
                }
                else
                {//Horizontal
                  pushing_back(&(p2_msg->cmd3), "#YH50,#FE,0,0,0,0,0,0,#AT,0,0,479,271,173,0,", sizeof("#YH50,#FE,0,0,0,0,0,0,#AT,0,0,479,271,173,0,")-1); //Displayhelligkeit auf 20% setzen
                }
                p2_msg->cmd3.push_back('\x0A');
                is_dimmed = true;
                callcount = 0; //Anzahl der Aufrufe zuruecksetzen
              }
          }
          
          
          break;
	case JUST_ACTIVATED:
          break;
	case ACTIVE:
          break;
	case JUST_DEACTIVATED:
          break;
	case SLEEPING:
          break;
	case MY_ERROR:
          break;
	default:
          break;
        }
}


#endif
