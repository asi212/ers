/**
*  \file
*    
*   
*  \brief Implementation of the Class windowstate
*  \date 10-Jan-2011 16:20:42
*  \author
*    Michael Brunner
*    , Lars Possberg
*/

#if !defined(WINDOWSTATE_H__INCLUDED_)
#define WINDOWSTATE_H__INCLUDED_

/**
 * This enumeration describes the state of the window-object, but has no conection
 * to the 'wake'/'sleeping'-state.
 * These states of a window are important (also the 'wake'-state) when the
 * cyCalc() function-call happens.
 * ACTIVE  -  The current window draws itself to the display.
 * INACTIVE  -  The current windows does not draw itself to the display, but it
 * may do some calculations or communications anyway.
 * JUST_ACTIVATED  -  The window was INACTIVE before and is now ACTIVE. This state
 * is useful when there are some components of a window to be drawn that should
 * not be drawn every time. The components which should be drawn every time will
 * take place in the ACTIVE state. Those might be measurement results which change
 * from time to time for example.
 * JUST_DEACTIVATED  -  The window was ACTIVE before and is now INACTIVE. There is
 * no recommondation how to use this state at the moment, but it might be useful.
 * FIRST_CALL  -  The window gets the first cycCalc() function-call during runtime,
 * or the first function call after a sleepphase ('wake'-state). The window may
 * want to do some initialisations.
 * SLEEPING - The window is not awake and does no calculations or whatsoever when
 * the cycCalc-call happens. This state is useful when there are multiple
 * implementations of the same window, which have the same recipient-name in the
 * mailbox.
 * ERROR - Something bad happened. Actually this state should never be reached at
 * the moment, but it could be of use in the future. It is for example used as a
 * return-value by the displaymanager when trying to get the windowstate of a
 * window which does not exist.
 */
enum windowstate
{
	/**
	 * Destination of the message.
	 */
	ACTIVE,
	INACTIVE,
	JUST_ACTIVATED,
	JUST_DEACTIVATED,
	SLEEPING,
  MY_ERROR
};
#endif // !defined(WINDOWSTATE_H__INCLUDED_)
