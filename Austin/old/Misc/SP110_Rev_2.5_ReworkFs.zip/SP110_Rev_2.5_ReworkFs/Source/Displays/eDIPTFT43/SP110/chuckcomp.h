/* Macro 106 as include */

#define CHUCKCOMP_LEN  17

const char CHUCKCOMP[CHUCKCOMP_LEN] =
{
   27, 90, 70,  4, 27, 70, 90,  1,  8, 27, 90, 82,167,  1,113,  0,  0
};
