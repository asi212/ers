/* Macro 107 as include */

#define CHUCKSTAT_LEN  39

const char CHUCKSTAT[CHUCKSTAT_LEN] =
{
   27, 82, 69, 11,  0, 27, 70, 82, 24, 24,  8, 27, 82, 82,142,  0,149,  0,175,  1,
  189,  0, 27, 90, 70, 18, 27, 70, 90,  1,  8, 27, 90, 67,  9,  1,158,  0,  0
};
