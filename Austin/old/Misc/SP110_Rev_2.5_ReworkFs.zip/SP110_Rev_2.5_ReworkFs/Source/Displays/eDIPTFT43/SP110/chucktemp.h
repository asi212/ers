/* Macro 105 as include */

#define CHUCKTEMP_LEN  17

const char CHUCKTEMP[CHUCKTEMP_LEN] =
{
   27, 90, 70, 13, 27, 70, 90,  1,  8, 27, 90, 82,167,  1, 59,  0,  0
};
