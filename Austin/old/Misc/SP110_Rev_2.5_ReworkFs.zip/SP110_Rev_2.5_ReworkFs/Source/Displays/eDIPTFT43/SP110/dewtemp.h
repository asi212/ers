/* Macro 108 as include */

#define DEWTEMP_LEN  39

const char DEWTEMP[DEWTEMP_LEN] =
{
   27, 90, 70,  4, 27, 70, 90,  1,  8, 27, 82, 69, 11,  0, 27, 70, 82, 24, 24,  8,
   27, 82, 82,  6,  0,149,  0,136,  0,189,  0, 27, 90, 67, 65,  0,158,  0,  0
};
