/* Macro 140 as include */

#define DIAG4LEFT_LEN  8

const char DIAG4LEFT[DIAG4LEFT_LEN] =
{
   27, 90, 76, 11,  0, 45,  0,  0
};
