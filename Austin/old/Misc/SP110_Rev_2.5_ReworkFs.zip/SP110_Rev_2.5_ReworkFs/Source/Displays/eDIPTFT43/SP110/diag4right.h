/* Macro 141 as include */

#define DIAG4RIGHT_LEN  8

const char DIAG4RIGHT[DIAG4RIGHT_LEN] =
{
   27, 90, 76,211,  0, 45,  0,  0
};
