/* Macro 220 as include */

#define DIMDISP_LEN  36

const char DIMDISP[DIMDISP_LEN] =
{
   27, 89, 90, 31, 27, 65, 69,  0,  0, 27, 70, 69,  0,  0,  0,  0,  0,  0, 27, 65,
   84,  0,  0,  0,  0,224,  1, 16,  1,254,  0,  0, 27, 89, 72, 50
};
