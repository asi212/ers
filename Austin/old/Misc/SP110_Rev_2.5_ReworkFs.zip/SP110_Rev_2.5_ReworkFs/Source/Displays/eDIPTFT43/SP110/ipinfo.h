/* Macro 122 as include */

#define IPINFO_LEN  17

const char IPINFO[IPINFO_LEN] =
{
   27, 70, 90,  9,  0, 27, 90, 70,  5, 27, 90, 82,224,  1,  2,  1,  0
};
