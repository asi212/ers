/* Macro 67 as include */

#define MENUEBUTV1_LEN  20

const char MENUEBUTV1[MENUEBUTV1_LEN] =
{
   27, 65, 69,101,  0, 27, 65, 84,155,  1,  6,  0,219,  1, 47,  0,  0, 61, 49,  0
};
