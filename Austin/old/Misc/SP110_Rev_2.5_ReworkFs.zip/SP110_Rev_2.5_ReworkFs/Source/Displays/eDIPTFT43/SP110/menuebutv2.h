/* Macro 68 as include */

#define MENUEBUTV2_LEN  20

const char MENUEBUTV2[MENUEBUTV2_LEN] =
{
   27, 65, 69,101,  0, 27, 65, 84,155,  1, 50,  0,219,  1, 91,  0,  0, 62, 50,  0
};
