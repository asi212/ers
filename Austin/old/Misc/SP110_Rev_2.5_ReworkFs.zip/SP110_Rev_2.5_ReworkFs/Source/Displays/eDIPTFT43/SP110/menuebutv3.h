/* Macro 69 as include */

#define MENUEBUTV3_LEN  20

const char MENUEBUTV3[MENUEBUTV3_LEN] =
{
   27, 65, 69,101,  0, 27, 65, 84,155,  1, 94,  0,219,  1,135,  0,  0, 63, 51,  0
};
