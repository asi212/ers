/* Macro 70 as include */

#define MENUEBUTV4_LEN  20

const char MENUEBUTV4[MENUEBUTV4_LEN] =
{
   27, 65, 69,101,  0, 27, 65, 84,155,  1,138,  0,219,  1,179,  0,  0, 64, 52,  0
};
