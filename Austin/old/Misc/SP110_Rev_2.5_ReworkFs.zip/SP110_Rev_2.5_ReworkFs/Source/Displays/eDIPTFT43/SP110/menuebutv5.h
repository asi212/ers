/* Macro 71 as include */

#define MENUEBUTV5_LEN  20

const char MENUEBUTV5[MENUEBUTV5_LEN] =
{
   27, 65, 69,101,  0, 27, 65, 84,155,  1,182,  0,219,  1,223,  0,  0, 66, 53,  0
};
