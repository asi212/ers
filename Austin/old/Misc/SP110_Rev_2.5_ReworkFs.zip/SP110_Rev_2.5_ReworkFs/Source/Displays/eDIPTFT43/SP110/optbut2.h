/* Macro 103 as include */

#define OPTBUT2_LEN  29

const char OPTBUT2[OPTBUT2_LEN] =
{
   27, 65, 69,101,  0, 27, 65, 70,  4, 27, 65, 76,171,  0, 27, 65, 84, 51,  1,206,
    0,133,  1,252,  0,  0,171, 67,  0
};
