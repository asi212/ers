/* Macro 104 as include */

#define SETTEMP_LEN  24

const char SETTEMP[SETTEMP_LEN] =
{
   27, 77, 78,  6, 27, 65, 76,120,  0, 27, 65, 84,  6,  0, 29,  0,136,  0, 67,  0,
    0,120, 67,  0
};
