/* Macro 221 as include */

#define UNDIMDISP_LEN  13

const char UNDIMDISP[UNDIMDISP_LEN] =
{
   27, 89, 90,  0, 27, 65, 76,254,  0, 27, 89, 72,100
};
