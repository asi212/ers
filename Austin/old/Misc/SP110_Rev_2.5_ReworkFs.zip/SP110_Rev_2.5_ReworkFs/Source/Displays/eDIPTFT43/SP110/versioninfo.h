/* Macro 121 as include */

#define VERSIONINFO_LEN  17

const char VERSIONINFO[VERSIONINFO_LEN] =
{
   27, 70, 90,  9,  0, 27, 90, 70,  5, 27, 90, 76,  0,  0,  2,  1,  0
};
