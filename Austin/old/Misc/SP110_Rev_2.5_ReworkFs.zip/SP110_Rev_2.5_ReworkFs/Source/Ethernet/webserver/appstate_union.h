//#include "appstate_union.h"
#ifndef __APPSTATE_UNION_H__
#define __APPSTATE_UNION_H__

/*
typedef union {
   struct httpd_state a1;
   struct telnetd_state a2;
} uip_tcp_appstate_t;

*/

//typedef struct httpd_state uip_tcp_appstate_t;
//typedef struct telnetd_state uip_tcp_appstate_t;



#endif /* __APPSTATE_UNION_H__ */