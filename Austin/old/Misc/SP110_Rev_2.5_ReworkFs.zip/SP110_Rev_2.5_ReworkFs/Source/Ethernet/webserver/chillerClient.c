/******************************************************************************
* Author: Paddy Khaukha-mabinda
* Date: 17.01.2013
* 
* File: ChillerClient.h
* 
* Purpose: Implements a client for communicating with Huber Chiller PilotONE
*          This client connects to Port 8101 using TCP/IP Protocol 
*         
* ****************************************************************************/
#define CHILLERCLIENT_STATE_STATUS          0
#define CHILLERCLIENT_STATE_NOT_CONNECTED   1
#define CHILLERCLIENT_STATE_CONNECTED       2
#define CHILLERCLIENT_STATE_ACKED           3
#define CHILLERCLIENT_STATE_DATA            4
#define CHILLERCLIENT_STATE_SEND_CMD        5
#define CHILLERCLIENT_STATE_CLOSE           6
#define CHILLERCLIENT_STATE_CLOSED          7
#define CHILLERCLIENT_STATE_TIMEOUT         8

#define CMD_REQUEST_VERSION     0
#define CMD_REQUEST_STATE       1
#define CMD_SWITCH_ON_COMP      2
#define CMD_SWITCH_OFF_COMP     3
#define CMD_REQUEST_ALARM_CODE  4
#define CMD_RESET_ALARM         5
#define CMD_CLOSE_CONNECTION    6

#define COMM_TIMER 80  // 32 = 2s therefore 128 = 8 Seconds. (1 = 62.5 ms)
#define COMM_TIMER_R 40
/******************************************************************************
* Author: Paddy Khaukha-mabinda
* Date:17.01.2013
* 
* Function: chillerclient_init
*
* Purpose: Initialises the connection to Chilller
*
* Comments:
*
*
*  -------------------------------------------------------------------------------------*/
#include "uip.h"
#include "string.h"
#include "uiplib.h"
#include "stdlib.h"
#include "chillerclient.h"

#ifdef __cplusplus
extern "C" { 
  
#endif
 
  
   int octet1,octet2,octet3,octet4;
    uip_ipaddr_t *cc_ipaddr;
    u16_t cc_port;
    unsigned char client_chiller_active = 0;
    u8_t send_cmd = 0;
    u8_t ext_cmd = 0;
    
    int cc_toggle = 0;
    
    char cc_xmtbuf[20];
    static char cc_rcvbuf[40];
    typedef struct CHILLERCLIENT_STATE
    {
      u8_t timer;
      u8_t state;
      u8_t cmd;
      u8_t data_len;
    }chillerclient_state;
    
//    typedef struct CHILLER_INFO
//    {
//        u8_t compressor_state;
//        u8_t alarm_code;
//        u8_t connected;
//        
//    } chillerinfo;
    
    struct CHILLERCLIENT_STATE cc_state;
    static struct CHILLER_INFO chiller_info;
    
    static void(*pNotifyDataReceived)(struct CHILLER_INFO *info);
   /* 
 void chillerclient_init(char *ipaddr, u16_t _port, void *pcallback)
 {
   int i,j;
   char buf[4];
   
   if( ipaddr != 0 )
   {
     j = 0;
     i = 0;
     while( (ipaddr[j] != '.')&&( j < 15)&&(i < 4) ) // limit to 15 characters, e.g. 172.030.240.220 and 3 digits
       buf[i++] = ipaddr[j++];
     
     buf[i] = 0;
     octet1 =   atoi(buf);
     i = 0;
     while( (ipaddr[j] != '.')&&( j < 15)&&(i < 4) ) // limit to 15 characters, e.g. 172.030.240.220 and 3 digits
       buf[i++] = ipaddr[j++];
     
     buf[i] = 0;
     octet2 = atoi(buf);
     i = 0;
      while( (ipaddr[j] != '.')&&( j < 15)&&(i < 4) ) // limit to 15 characters, e.g. 172.030.240.220 and 3 digits
       buf[i++] = ipaddr[j++];
     
     buf[i] = 0;
     octet3 = atoi(buf);
     i = 0;
     while( (ipaddr[j] != '.')&&( j < 15)&&(i < 4) ) // limit to 15 characters, e.g. 172.030.240.220 and 3 digits
       buf[i++] = ipaddr[j++];
     
     buf[i] = 0;
     octet4 = atoi(buf);
     
     if( _port != 0)
       cc_port = _port;
     else
        cc_port = HUBER_CHILLER_PORT;
   }
   else
   {
     octet1 = 172;
     octet2 = 30;
     octet3 = 240;
     octet4 = 254;
     cc_port = 8101;
   }
    chiller_info.compressor_state = 'I'; // 0x49  Compressor ON 
    chiller_info.alarm_code[0] = '0'; // No Alarm    
    chiller_info.alarm_code[1] = '0';
    chiller_info.alarm_code[2] = '0';
    chiller_info.alarm_code[3] = '0';
    
    chiller_info.connected = 0; // not connected 
    chiller_info.raw_data = &cc_rcvbuf[0];
    cc_state.timer = 32;
    chiller_info.connected = 0;
 
    pNotifyDataReceived = pcallback;
    uip_ipaddr(&cc_ipaddr, octet1, octet2,octet3,octet4);
    uip_app_register(chillerclient_appcall, REG_TCP, HTONS(cc_port), REG_ACTIVE);
 }
 */
  void chillerclient_init(int *ipaddr, u16_t _port, void *pcallback)
 {
    
   if( ipaddr != 0 )
   {
     octet1 = ipaddr[0];
     octet2 = ipaddr[1];
     octet3 = ipaddr[2];;
     octet4 = ipaddr[3];
     
     if( _port != 0)
       cc_port = _port;
     else
        cc_port = HUBER_CHILLER_PORT;
   }
   else
   {
     octet1 = 172;
     octet2 = 30;
     octet3 = 240;
     octet4 = 254;
     cc_port = 8101;
   }
    chiller_info.compressor_state = 'I'; /* 0x49  Compressor ON */
    chiller_info.alarm_code[0] = '0'; /* No Alarm */   
    chiller_info.alarm_code[1] = '0';
    chiller_info.alarm_code[2] = '0';
    chiller_info.alarm_code[3] = '0';
    chiller_info.alarm_code[4] = 0x00;
    
    chiller_info.connected = 0; /* not connected */
    chiller_info.raw_data = &cc_rcvbuf[0];
    cc_state.timer = 0;
    chiller_info.connected = 0;
 
    pNotifyDataReceived = pcallback;
    uip_ipaddr(&cc_ipaddr, octet1, octet2,octet3,octet4);
    uip_app_register(chillerclient_appcall, REG_TCP, HTONS(cc_port), REG_ACTIVE);
 }

 /**********************************************************************************
 * Function:   chillerclient_setcallback
 * 
 * Purpose: The calling routine can set a Callback Function Pointer by calling
 *          this function
 * 
 * Input : *pcallback pointer to the callback function.
 *  
 ********************************************************************************/
 void chillerclient_setcallback(void *pcallback)
 {
    pNotifyDataReceived = pcallback;
 }

unsigned char chillerclient_connected_status(void)
{
    return chiller_info.connected;
}

 /******************************************************************************
* Author: Paddy Khaukha-mabinda
* Date:17.01.2013
* 
* Function: chillerclient_connect
*
* Purpose: Initialises the connection to Chilller
*
* Comments:
*
*
*  -------------------------------------------------------------------------------------*/
 void chillerclient_connect(void)
 {
    struct uip_conn *_cc;
   
    _cc = uip_connect(&cc_ipaddr,HTONS(cc_port));
    if( _cc == 0)
    {
        cc_state.state = CHILLERCLIENT_STATE_NOT_CONNECTED;
         chiller_info.connected = 0;
    }
    else
        chiller_info.connected = 1; /* connection requested */ 
 }
 
 void chillerclient_reconnect(void)
 {
   chillerclient_closed();
   chillerclient_connect();
 }
 void chillerclient_close(void)
 {
    cc_state.state = CHILLERCLIENT_STATE_CLOSE;
 }
   
void chillerclient_timedout(void)
{
  
}
void chillerclient_aborted(void)
{
  cc_state.state = CHILLERCLIENT_STATE_CLOSED;
}

 void chillerclient_closed(void)
 {
   cc_state.state = CHILLERCLIENT_STATE_CLOSED;
   chiller_info.connected = 0; /* client closed */
   uip_close();
 }
 void chillerclient_appcall(void)
 {
    cc_state.data_len = 0;
   
    if( uip_connected())
    {
          cc_state.cmd =  CMD_REQUEST_VERSION;
          cc_state.timer = 0;
          send_cmd = 1;
          return;
    }
    if( uip_aborted() )
    {
       chillerclient_closed();
        return;
    }
    if( uip_timedout() )
    {
       cc_state.state = CHILLERCLIENT_STATE_TIMEOUT;
       chillerclient_closed();
        return;
    }
 
    if( uip_closed())
    {
        chillerclient_closed();
        return;
    }
    if(uip_rexmit() )
    {
      send_cmd = 1;
      return;
    }
    if( uip_acked())
    {
        cc_state.state =  CHILLERCLIENT_STATE_ACKED;
    }
    if(uip_newdata() )
    {
        chillerclient_newdata();
        return;
    }    
    if( uip_poll() )
    {
        chillerclient_poll(); // chillerclient_request_state();
        chillerclient_senddata();
    }
    

    
 }
 void chillerclient_request_state(void)
 {
     cc_state.data_len = 16; 
     strncpy(cc_xmtbuf,"[M01G0D******C0\r",cc_state.data_len);
 }
 
 void chillerclient_senddata(void)
 {
   if( cc_state.data_len > 0 )
   {
        uip_len = cc_state.data_len;
        uip_send(&cc_xmtbuf[0],cc_state.data_len);
   }
 }
 
 void chillerclient_version(void)
 {
    cc_state.data_len = 10; 
    strncpy(cc_xmtbuf,"[M01V07C6\r",cc_state.data_len);
    cc_state.timer = COMM_TIMER;
    cc_state.state = CHILLERCLIENT_STATE_CONNECTED;
    chiller_info.connected = 2; /* client connected */
   
 }
 
 void chillerclient_newdata(void)           
 {
    int len = uip_len < 40 ? uip_len : 40;
    if( len > 0)
    {
        chiller_info.connected = 2; /* client connected */
      
        strncpy(cc_rcvbuf,(char*) (uip_appdata),len);
        
        switch( cc_state.cmd)
        {
            case CMD_REQUEST_VERSION:
              cc_state.cmd = CMD_REQUEST_STATE; 
            break;
            
            case CMD_REQUEST_STATE: /* [S01G15sattttiiiieeeepp\r  s=C,E,I,O a= Alarm 0/1, tttt=settemp. iiii=intern temp. eeee =externtemp */ 
                if( cc_rcvbuf[7] ==  'I') 
                   chiller_info.compressor_state = 'I'; /* 0x49  Compressor ON */
                else if( cc_rcvbuf[7] ==  'O') 
                   chiller_info.compressor_state = 'O';
              if( cc_rcvbuf[8] ==  '0') 
              {
                chiller_info.alarm_code[0] = '0'; /* No Alarm */   
                chiller_info.alarm_code[1] = '0';
                chiller_info.alarm_code[2] = '0';
                chiller_info.alarm_code[3] = '0';
                cc_state.cmd = CMD_REQUEST_STATE; 
              }
              else
              {
                   cc_state.cmd =  CMD_REQUEST_ALARM_CODE; //       chillerclient_request_alarm_code();
              }
            break;  
            case CMD_SWITCH_ON_COMP:
                if( cc_rcvbuf[7] ==  'I') /* Compressor is now ON request state again. */
                     cc_state.cmd = CMD_REQUEST_STATE; // request for status;
            break;  
            case CMD_SWITCH_OFF_COMP:
                if( cc_rcvbuf[7] ==  'O') /* Compressor is now OFF request state again. */
                     cc_state.cmd = CMD_REQUEST_STATE; // request for status
            break;  
            case CMD_REQUEST_ALARM_CODE:
                chiller_info.alarm_code[0] = cc_rcvbuf[7]; /* Alarm  code */   
                chiller_info.alarm_code[1] = cc_rcvbuf[8];
                chiller_info.alarm_code[2] = cc_rcvbuf[9];
                chiller_info.alarm_code[3] = cc_rcvbuf[10];
                cc_state.cmd = CMD_REQUEST_STATE; 
            break;  
            case CMD_RESET_ALARM :  
              cc_state.cmd = CMD_REQUEST_STATE; 
            break;  
        }
       
        if(  pNotifyDataReceived != 0)
            pNotifyDataReceived(&chiller_info);
        
        send_cmd = 0;
        cc_state.timer = COMM_TIMER; 
    if(cc_toggle == 0)
        cc_toggle = 1;
    else
        cc_toggle = 0;
        
    }
 }

 void chillerclient_poll(void)
 {
    cc_state.data_len = 0;
    chiller_info.connected = 2; /* client connected */
    if( cc_state.timer == 0)
    {
      if(send_cmd == 0)
      {
        send_cmd = 1;
        cc_state.timer = COMM_TIMER;
        if(  ext_cmd != 0) // transmit an external request!
            cc_state.cmd  = ext_cmd;
        ext_cmd = 0;
      }
    }
    else
       cc_state.timer--;
    
    if( send_cmd == 1 )
    {
        switch( cc_state.cmd)
        {
            case CMD_REQUEST_VERSION:
              chillerclient_version();
            break;
            
            case CMD_REQUEST_STATE: /* [M01G15sattttiiiieeeepp\r  s=C,E,I,O a= Alarm 0/1, tttt=settemp. iiii=intern temp. eeee =externtemp */ 
              chillerclient_request_state();
            break;  
            case CMD_SWITCH_ON_COMP:
                chillerclient_switch_compressor_on();
            break;  
            case CMD_SWITCH_OFF_COMP:
                chillerclient_switch_compressor_off();
            break;  
            case CMD_REQUEST_ALARM_CODE:
              chillerclient_request_alarm_code();
            break;  
            case CMD_RESET_ALARM:
              chillerclient_reset_alarm_code();
            break;  
            case CMD_CLOSE_CONNECTION:
              chillerclient_closed();
            break;  
                        
        }
        send_cmd = 0;


    }
 }

 void chillerclient_switch_compressor_on(void)
 {
       cc_state.data_len = 16; 
       strncpy(cc_xmtbuf,"[M01G0DI*****DF\r",cc_state.data_len);  
 }
 void chillerclient_switch_compressor_off(void)
 {
       cc_state.data_len = 16; 
         strncpy(cc_xmtbuf,"[M01G0DO*****E5\r",cc_state.data_len);    
 }
 
 void chillerclient_switch_compressor(u8_t on_off)
 {
     if( on_off == 1)
     {
         ext_cmd =  CMD_SWITCH_ON_COMP;
     }
     else
     {
         ext_cmd =  CMD_SWITCH_OFF_COMP;
     }
 }

void chillerclient_request_alarm_code(void)
{
      cc_state.data_len = 8; 
      strncpy(cc_xmtbuf,"ERROR?\r\n",cc_state.data_len);  
}

void chillerclient_reset_alarm(void)
{
      cc_state.cmd =  CMD_RESET_ALARM;
}

void chillerclient_reset_alarm_code(void)
{
    cc_state.data_len =16; 
    strncpy(cc_xmtbuf,"[M01G0D*1****C7\r",cc_state.data_len);      
}


#ifdef __cplusplus
}
#endif
