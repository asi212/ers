/******************************************************************************
* Author: Paddy Khaukha-mabinda
* Date: 17.01.2013
* 
* File: ChillerClient.h
* 
* Purpose: Implements a client for communicating with Huber Chiller PilotONE
*          This client connects to Port 8101 using TCP/IP Protocol 
*         
* ****************************************************************************/
#ifndef __CHILLERCLIENT_H
#define __CHILLERCLIENT_H

#define HUBER_CHILLER_PORT 8101

#ifdef __cplusplus
extern "C" {
#endif
    
    //extern struct CHILLER_INFO chiller_info;
    typedef struct CHILLER_INFO
    {
        unsigned char compressor_state;
        unsigned char alarm_code[5];
        unsigned char connected;
        char *raw_data;
    } chillerinfo;
    
    extern unsigned char client_chiller_active;
    extern int cc_toggle;
    
    void chillerclient_appcall(void);
    void chillerclient_connect(void);
    void chillerclient_version(void);
    void chillerclient_init(int *ipaddr, unsigned short  _port,void *pcallback);
    void chillerclient_senddata(void);
    void chillerclient_newdata(void);  
    void chillerclient_closed(void);
    void chillerclient_poll(void);
    
    unsigned char chillerclient_connected_status(void);
    /*
    void chillerclient_timedout(void);
    void chillerclient_aborted(void);
    void chillerclient_close(void);
    */
    void chillerclient_setcallback(void *pcallback);
    void chillerclient_switch_compressor(unsigned char on_off);
    void chillerclient_switch_compressor_on(void);
    void chillerclient_switch_compressor_off(void); 
    void chillerclient_request_state(void);
    void chillerclient_request_alarm_code(void);
    void chillerclient_reset_alarm(void);
    void chillerclient_reset_alarm_code(void);
    void chillerclient_reconnect(void);
    
    void chillerclient_start_timer(void); // test routine
    void chillerclient_start_timing(void);
    
#ifdef __cplusplus
}
#endif
  

#endif // __CHILLERCLIENT_H
