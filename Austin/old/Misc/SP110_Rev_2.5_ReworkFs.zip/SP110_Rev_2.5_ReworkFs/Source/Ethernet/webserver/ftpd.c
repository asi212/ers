/******************************************************************************
* Author: Paddy Khaukha-mabinda
* Date: 26.09.2012
* 
* Function: _newdata
*
* Purpose: This function is called by the uip stack when Client sends a new
*          command.
*         
* 
* Comments: For commands that do need the data port (20) i.e. return no or
*           receive data a response immediately sent back to client.
*           Only the LIST,STOR and RETR commands use the data port to send
*           or receive data.
*
*           Since the commands LIST,STOR and RETR might take long to complete
*           (several packets and handshaking) a command needs to tracked to completion.
*           Therefore this modified version uses 2 signal variables to track the
*           data session.
*
*           1. active_cmd:   if the active command like LIST
*           2. active_state: State of the command e.g STATE_CONNECTED_FTPDATA,
*              STATE_SENDING_LIST,..
*
*           These 3 commands demand that the control Port 20 and data port are
*           interchangeably used. This means that Responses like 150 and 226 messages
*            are sent on the Control while data is sent on the data port.
*===================================================================================
* NOTE: VERY IMPORTANT!!!!
*
* I have not intensively tested for several simulteneous connection from same or
* different clients (IP-Address).
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
* Possible Solution:
* 1. Use an array of active connection equivalent to UIP_CONNS defined in uip.h
*   As of this writing it has been set to 40 connections. There are ofcourse other
*   applications like telnet and diagnostics using some connections.
*   Since FTP needs 2 ports (aka two connections) for each client a maximum of
*   10 FTP clients can theoritically simultineously connect to the server.
*
*   The problem with FTP in this uip stack it not clear how to map the control
*   port to the data port (Port correlation).
*
* Use the following strategy:
*  1. Create a list of connections paars. In our case 20 values of port paars
* 1. FTP Control Port connects
*    (i) Initialize our structure with control port with remote IP-Address and
*        and remote Port.
*    (ii) Save the structure into the List.
*
* 2. wait for LIST command. This is normally the first command.
*    (i) set a flag showing we are waiting for a connection from client.
*    This step might be not neccessary!
*
* 3. Client connects to the data port.
*     Here is where we have just got to assume that the first CONTROL PORT 
*         has NOT JET OPENNED the data is the one we shall use.
*    (i) Just for the first port whose data port is set to 0 and map it to this
*        new data port.
*
* 4. Data is transfered to the client or received from client.
*    The correlation between the ports is done as follows:
*
*    (i) Control Port 21 needs the corresponding remote data communication port
*        for local port 20.
*        It uses its remote IP-Address, and port. The routine returns
*        the remote data port. This remote port and remote IP-Address
*        is used to determine the communication struction uip_conn.
*
*   (ii) Data Port 20 needs the corresponding remote control communication port 
*        for local port 21. Same process is used as above.
* 
* 5. When the data port is closed, or a new command is received from the client
*    the data port mapped to this control port is reset to 0.
* 
* ****************************************************************************/

#include "uip.h"
#include "ftpd.h"
#include "string.h"
#include "stdio.h"
#include "FS.h"

FS_FILE *pFile = 0;

u8_t ftp_data_closed =0;

unsigned long fileSize = 0;

unsigned tracking = 0;

int g_FTP_number=999; //Nur eine Testnummer um den FTP-Server zu debuggen

#ifdef __cplusplus
extern "C" {
#endif
	static void _abort(void);
	static void _timeout(void);
	static void _close(void);
	static void _connect(void);
	static void _newdata(void);
	static void _ack(void);
	static void _poll(void);
	static void _senddata(void);
	static void _retrasmit(void);
	int  _dir( char * pBuf );
	void _getFile( char * pFileName );

	static void SplitCmdArg(char * line, char ** cmd, char ** args);

	static const char cmd_cwd_P[] = "CWD";
	static const char cmd_dele_P[] = "DELE";
	static const char cmd_list_P[] = "LIST";
	static const char cmd_mkd_P[] = "MKD";
	static const char cmd_xmkd_P[] = "XMKD";
	static const char cmd_nlst_P[] = "NLST";
	static const char cmd_noop_P[] = "NOOP";
	static const char cmd_pass_P[] = "PASS";
	static const char cmd_pasv_P[] = "PASV";
	static const char cmd_port_P[] = "PORT";
	static const char cmd_pwd_P[] = "PWD";
	static const char cmd_xpwd_P[] = "XPWD";
	static const char cmd_quit_P[] = "QUIT";
	static const char cmd_retr_P[] = "RETR";
	static const char cmd_rmd_P[] = "RMD";
	static const char cmd_xrmd_P[] = "XRMD";
	static const char cmd_size_P[] = "SIZE";
	static const char cmd_stor_P[] = "STOR";
	static const char cmd_syst_P[] = "SYST";
	static const char cmd_type_P[] = "TYPE";
	static const char cmd_user_P[] = "USER";
        static const char cmd_list_D[] = "LIST";
        static const char cmd_dir_D[] =  "LIST";


	static const char rep_banner[] = "220 uIP/arnSys FTP server ready\r\n";

	static const char okCode200[] = "200 OK\r\n";
	static const char okCode221[] = "221 OK\r\n";
	static const char okCode225[] = "225 OK\r\n";
	static const char okCode226[] = "226 OK\r\n";
	static const char okCode230[] = "230 OK\r\n";

	static const char FailCode500[] =  "500 syntax error; command unrecognized.\r\n";
	static const char FailCode501[] =  "501 syntax error; arg unrecognized.\r\n";
	static const char FailCode502[] =  "502 command not implemented.\r\n";
	static const char FailCode504[] =  "504 command not implemented for that parameter.\r\n";
	static const char FailCode421[] =  "421 servivece not available; closing connection.\r\n";
	static const char FailCode550[] =  "550 Requested action not taken. File unavailable (e.g., file not found, no access).\r\n";
        //PM: 20.09.2012
        static const char LST150[]  = "150 opening data connection for LST\r\n";
        static const char STOR150[] = "150 opening data connection for STOR\r\n";
        static const char RETR150[] = "150 opening data connection for RETR\r\n";

/**********************************************************************
 * 21.09.2012 PM:
 * New effective COMMANDS and STATES
 *
 **********************************************************************/
#define CMD_NONE   	0
#define CMD_CWD	   	1
#define CMD_DELETE 	2
#define CMD_LIST	3
#define CMD_MKD		4
#define CMD_XMKD	5
#define CMD_NLST	6
#define CMD_PASS	7
#define CMD_PASV	8
#define CMD_PORT	9
#define CMD_PWD		10
#define CMD_XPWD	11
#define CMD_QUIT	12
#define CMD_RETR	13
#define CMD_RMD		14
#define CMD_XRMD	15
#define CMD_SIZE	16
#define CMD_STOR	17
#define CMD_SYS		18
#define CMD_TYPE        19
#define CMD_USER	20
#define CMD_NOOP        21
#define CMD_UNKNOWN     22

#define STATE_NONE			0  // set in -> processed in
#define STATE_CONNECTED_FTP		1  // set in -> processed in
#define STATE_CONNECTING_FTPDATA	2  // newdata -> _connect()
#define STATE_CONNECTED_FTPDATA		3  // _connect_data -> _poll
#define STATE_150_RESPONSE		4  // _poll -> _ack
#define STATE_260_RESPONSE		5  // _poll -> _ack
#define STATE_SENDING_LIST		6  // _ack -> _poll_data
#define STATE_SENT_LIST			7  // _poll_data -> _ack_data
#define STATE_CLOSED_FTPDATA		8  // _ack_data ->  _poll
#define STATE_SENDING_226OK		9  // ack_data -> _poll
#define STATE_RECEIVING_FILE_DATA	10 // _ack -> _newdata_data
#define STATE_RECEIVED_FILE_DATA	11 // _ack -> _newdata_data
#define STATE_SENDING_FILE_DATA		12  // newdata_data ->_poll_data
#define STATE_SENT_FILE_DATA		13  // newdata_data ->_poll_data    
#define STATE_RESPONSE_NO_DATA		14  // newdata -> _ack
/* END of Section *****************************************************/


	// this is the section defining the TYPE
#define FTPDTYP_NONE				0
#define FTPDTYP_ASCII				(1 + FTPDTYP_NONE)
#define FTPDTYP_BINARY				(1 + FTPDTYP_ASCII)
	//END this is the section defining the TYPE

	// this is the section defining the MODE
#define FTPDMOD_NONE				0
#define FTPDMOD_STREAM				(1 + FTPDMOD_NONE)
	//END this is the section defining the MODE

	// this is the section defining the STRUCTURE
#define FTPDSTRU_NONE				0
#define FTPDSTRU_FILE				(1 + FTPDSTRU_NONE)
	//END this is the section defining the STRUCTURE


#define PACK_DATA_SIZE	512


	static void _abort_data(void);
	static void _timeout_data(void);
	static void _close_data(void);
	static void _connect_data(void);
	static void _newdata_data(void);
	static void _ack_data(void);
	static void _poll_data(void);
	static void _senddata_data(void);
	static void _retrasmit_data(void);

	// PM: 20.09.2012
	static void Send150Response(void);
	static void Send226OKResponse(void);
        static struct ftpd_state *GetFTPControlPortState(void);
        static struct ftpd_state *GetFTPDataPortState(void);
        static void ResetPortStates(void);
        
	struct  {
		unsigned char Status;
		unsigned char RecvCmd;
		unsigned char AnsToCmd;
		unsigned char ftpMode;
		unsigned char ftpType;
		unsigned char ftpStru;
	} exchgParams;

        struct COM_PORTS 
        {
          u16_t port21;
          u16_t port20;
        }com_ports;
        
        
	unsigned long ftpd_size = 0x000000;
	__no_init char cSendePuffer[32767] @ "EXRAM";
	unsigned long ftpd_sadd = (unsigned long)cSendePuffer;
	char* ftpd_name = "DDF.ddf";
	//END

        struct ftpd_state
        {
            unsigned int count;
            char *dataptr;
            u8_t active_cmd;
            u8_t active_state;
            u8_t data_pending;
            u8_t response_pending;
            FS_FILE *hFile;
            u8_t last_packet;
            u8_t first_packet;
            
            unsigned long file_size;
        };
      
        struct ftpd_state *ftps_con_port = 0;
        struct ftpd_state *ftps_data_port= 0;
        u16_t retry_len = 0;
      
#ifdef __cplusplus
}
#endif


void ftpd_init(void)
{
	/* Listen to port 21. */
	uip_listen(HTONS(21));

}

void ftpd_init_data(void)
{
	/* Listen to port 20. */
	uip_listen(HTONS(20));
}

void ftpd_appcall_data(void)
{
	if(uip_aborted()) {
		_abort_data();
	}
	if(uip_timedout()) {
		_timeout_data();
	}
	if(uip_closed()) {
		_close_data();
	}
	if(uip_connected()) {
		_connect_data();
	}
	if(uip_acked()) {
		_ack_data();
	}
	if(uip_newdata()) {
		_newdata_data();
	}
	if(uip_poll()) {
		_poll_data();
	}
	if(uip_rexmit()) {
		_retrasmit_data();
 	}
	if(uip_rexmit() ||
		uip_newdata() ||
		uip_acked() ||
		uip_connected() ||
		uip_poll())
        {
            _senddata_data();
	}
}

void ftpd_appcall(void)
{

	if(uip_aborted()) {
		_abort();
	}
	if(uip_timedout()) {
		_timeout();
	}
	if(uip_closed()) {
		_close();
	}
	if(uip_connected()) {
		_connect();
	}
	if(uip_acked()) {
		_ack();
	}
	if(uip_newdata()) {
		_newdata();
	}
	if(uip_poll()) {
		_poll();
 	}
	if(uip_rexmit()) {
		_retrasmit();
	}
	if(uip_rexmit() ||
		uip_newdata() ||
		uip_acked() ||
		uip_connected() ||
		uip_poll()) {
			_senddata();
	}

}

void _abort(void)
{
      uip_abort();
}

void _timeout(void)
{
      uip_close();
}

void _close(void)
{
      struct ftpd_state *ftps = (struct ftpd_state *)&(uip_conn->appstate);
}


void _connect(void)
{
	struct ftpd_state *ftps = (struct ftpd_state *)&(uip_conn->appstate);
	ftps->count = strlen(rep_banner);
	uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
	strncpy((char*) (uip_appdata),(char*)(rep_banner),uip_len);

        ResetPortStates();
        
	ftps->active_cmd   = CMD_NONE;
        ftps->active_state = STATE_CONNECTED_FTP;
        ftps->response_pending = 0;
        ftps->data_pending = 0;
        ftps_con_port = ftps;
        com_ports.port21 = uip_conn->rport;
}
/******************************************************************************
* Author: Paddy Khaukha-mabinda
* Date: 26.09.2012
* 
* Function: _newdata
*
* Purpose: This function is called by the uip stack when Client sends a new
*          command.
*         
* 
* Comments: For commands that do need the data port (20) i.e. return no or
*           receive data a response immediately sent back to client.
*           Only the LIST,STOR and RETR commands use the data port to send
*           or receive data.
*
*           Since the commands LIST,STOR and RETR might take long to complete
*           (several packets and handshaking) a command needs to tracked to completion.
*           Therefore this modified version uses 2 signal variables to track the
*           data session.
*
*           1. active_cmd:   if the active command like LIST
*           2. active_state: State of the command e.g STATE_CONNECTED_FTPDATA,
*              STATE_SENDING_LIST,..
*
*           These 3 commands demand that the control Port 20 and data port are
*           interchangeably used. This means that Responses like 150 and 226 messages
*            are sent on the Control while data is sent on the data port.
*===================================================================================
* NOTE: VERY IMPORTANT!!!!
*
* I have not intensively tested for several simulteneous connection from same or
* different clients (IP-Address).
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
* Possible Solution:
* 1. Use an array of active connection equivalent to UIP_CONNS defined in uip.h
*   As of this writing it has been set to 40 connections. There are ofcourse other
*   applications like telnet and diagnostics using some connections.
*   Since FTP needs 2 ports (aka two connections) for each client a maximum of
*   10 FTP clients can theoritically simultineously connect to the server.
*
*   The problem with FTP in this uip stack it not clear how to map the control
*   port to the data port (Port correlation).
*
* Use the following strategy:
*  1. Create a list of connections paars. In our case 20 values of port paars
* 1. FTP Control Port connects
*    (i) Initialize our structure with control port with remote IP-Address and
*        and remote Port.
*    (ii) Save the structure into the List.
*
* 2. wait for LIST command. This is normally the first command.
*    (i) set a flag showing we are waiting for a connection from client.
*    This step might be not neccessary!
*
* 3. Client connects to the data port.
*     Here is where we have just got to assume that the first CONTROL PORT 
*         has NOT JET OPENNED the data is the one we shall use.
*    (i) Just for the first port whose data port is set to 0 and map it to this
*        new data port.
*
* 4. Data is transfered to the client or received from client.
*    The correlation between the ports is done as follows:
*
*    (i) Control Port 21 needs the corresponding remote data communication port
*        for local port 20.
*        It uses its remote IP-Address, and port. The routine returns
*        the remote data port. This remote port and remote IP-Address
*        is used to determine the communication struction uip_conn.
*
*   (ii) Data Port 20 needs the corresponding remote control communication port 
*        for local port 21. Same process is used as above.
* 
* 5. When the data port is closed, or a new command is received from the client
*    the data port mapped to this control port is reset to 0.
* 
* ****************************************************************************/
void _newdata(void)
{
	struct ftpd_state *ftps = (struct ftpd_state *)&(uip_conn->appstate);
	char* cmd;
	char* arg;
        com_ports.port21 = uip_conn->rport;
        
	SplitCmdArg((char*)uip_appdata,&cmd,&arg);

        if (!strcmp(cmd,cmd_user_P))
        {
		ftps->count = strlen(okCode230);
		uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
		strncpy((char*) (uip_appdata),(char*)(okCode230),uip_len);

	        ftps->active_cmd = CMD_USER;
                ftps->active_state = STATE_RESPONSE_NO_DATA;
	}
	else if (!strcmp(cmd,cmd_syst_P))
        {
		char *msg = "215 UNIX Type: L8\r\n";
		ftps->count = strlen(msg);
		uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
		strncpy((char*) (uip_appdata),(char*)(msg),uip_len);

                ftps->active_cmd = CMD_SYS;
                ftps->active_state = STATE_RESPONSE_NO_DATA;

	}
	else if (!strcmp(cmd,cmd_pwd_P) || (!strcmp(cmd,cmd_xpwd_P)))
        {
		char *msg = "257 \"/\"\r\n";
		ftps->count = strlen(msg);
		uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
		strncpy((char*) (uip_appdata),(char*)(msg),uip_len);

                ftps->active_cmd = CMD_PWD;
                ftps->active_state = STATE_RESPONSE_NO_DATA;

	}
	else if (!strcmp(cmd,cmd_type_P))
        {
		if (!strcmp(arg,"A")) exchgParams.ftpType = FTPDTYP_ASCII;
		else exchgParams.ftpType = FTPDTYP_BINARY;
		ftps->count = strlen(okCode200);
		uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
		strncpy((char*) (uip_appdata),(char*)(okCode200),uip_len);

                ftps->active_cmd = CMD_TYPE;
                ftps->active_state = STATE_RESPONSE_NO_DATA;
	}
	else if (!strcmp(cmd,cmd_quit_P))
        {
		ftps->count = strlen(okCode221);
		uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
		strncpy((char*) (uip_appdata),(char*)(okCode221),uip_len);

                 ftps->active_cmd = CMD_QUIT;
                ftps->active_state = STATE_RESPONSE_NO_DATA;

	}

	else if (!strcmp(cmd,cmd_dele_P))
	{
              if( pFile != 0) // 11.09.2012 PM:close file only when it is still open.
              {
                        FS_FClose(pFile);
                        pFile = 0;
                }
		if(FS_Remove(arg) == 0)
		{
			ftps->count = strlen(okCode200);
			uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
			strncpy((char*) (uip_appdata),(char*)(okCode221),uip_len);

 	        }
		else if (FS_RmDir(arg) == 0) //removedir worked
		{
			ftps->count = strlen(okCode200);
			uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
			strncpy((char*) (uip_appdata),(char*)(okCode200),uip_len);

		}
		else
		{
			ftps->count = strlen(FailCode550);
			uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
			strncpy((char*) (uip_appdata),(char*)(FailCode550),uip_len);

		}
                ftps->active_cmd = CMD_DELETE;
                ftps->active_state = STATE_RESPONSE_NO_DATA;

	}
	else if (!strcmp(cmd,cmd_pasv_P))
        {
		unsigned short hadd[2];
		uip_gethostaddr(hadd);
		sprintf((char*)uip_appdata,"227 Passive (%u,%u,%u,%u,%u,%u).\r\n",
			(unsigned char) (hadd[0] & 0x00ff), (unsigned char) (hadd[0] >> 8),
			(unsigned char) (hadd[1] & 0x00ff), (unsigned char) (hadd[1] >> 8),
			0, 20); // port
		ftps->count = strlen((char*)uip_appdata);
		uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);

                ftps->active_cmd = CMD_PASV;
                ftps->active_state = STATE_RESPONSE_NO_DATA;

	}
	else if (!strcmp(cmd,cmd_size_P))
        {
		char tmpBff[32];tmpBff[0] = '/';
		strcpy(tmpBff + 1,ftpd_name);
		if (!strcmp(arg,tmpBff) || !strcmp(arg,ftpd_name))
                {
			sprintf((char*)uip_appdata,"213 %6lu\r\n",
				(unsigned long) ftpd_size);
			ftps->count = strlen((char*)uip_appdata);
			uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
		}
		else
                {
			ftps->count = strlen(FailCode502);
			uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
			strncpy((char*) (uip_appdata),(char*)(FailCode502),uip_len);
		}
               ftps->active_cmd = CMD_SIZE;
               ftps->active_state = STATE_RESPONSE_NO_DATA;
 	}
	else if (!strcmp(cmd,cmd_list_P) || !strcmp(cmd,cmd_nlst_P))
        {
                ftps->active_cmd   = CMD_LIST; // This is the Control Port 21 information
                ftps->active_state = STATE_CONNECTING_FTPDATA;
                ftps->data_pending = 0;
                ftps->response_pending = 0;
                uip_len = 0;
	}
	//Speichern einer Datei auf dem Server:
	else if (!strcmp(cmd,cmd_stor_P) || !strcmp(cmd,cmd_nlst_P))
        {
            fileSize = 0;
            if( pFile != 0) // 11.09.2012 PM:close file only when it is still open.
            {
              FS_FClose(pFile);
              pFile = 0;
            }
            //MB, wenn datei bereits vorhanden ist dann �berschreibe

            pFile = FS_FOpen(arg, "wb"); //Schreiboeffnenwrite
            if( pFile != 0)
            {
                  ftps->active_cmd = CMD_STOR;
                  ftps->active_state = STATE_CONNECTING_FTPDATA;
                  ftps->response_pending = 0;
                  ftps->hFile = pFile;
                  ftps->first_packet = 0;
                  ftps->last_packet = 0;
                  tracking = 1;
            }
            else // could not be opened for storing. Possible cause: Name too long!
            {
                  char* msg = "550 Requested action not taken. File cannot be saved.\r\n";
                  ftps->count = strlen(msg);
                  uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
                  strncpy((char*) (uip_appdata),(char*)(msg),uip_len);

                  ftps->active_cmd   = CMD_STOR;
                  ftps->active_state = STATE_RESPONSE_NO_DATA;
            }
	}
	else if (!strcmp(cmd,cmd_retr_P))
        {
                if( pFile != 0) // 11.09.2012 PM:close file only when it is still open.
                {
                        FS_FClose(pFile);
                        pFile = 0;
                }
		if (!strcmp(arg,"/"))
                {
			ftps->count = strlen(FailCode504);
			uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
			strncpy((char*) (uip_appdata),(char*)(FailCode504),uip_len);

                        ftps->active_cmd = CMD_RETR;
                        ftps->active_state = STATE_RESPONSE_NO_DATA;
		}
		else
                { //Client moechte eine Datei geschickt bekommen
			cSendePuffer[uip_len]=0;
			pFile = FS_FOpen(arg, "rb"); //Leseoeffnen
			ftpd_size = FS_GetFileSize(pFile); //Anzahl der zu lesenden Bytes

                        if (ftpd_size < 0xFFFFFFFF)
                        {

                          ftps->active_cmd   = CMD_RETR;
                          ftps->active_state = STATE_CONNECTING_FTPDATA;
                          ftps->hFile = pFile;
                          ftps->file_size = ftpd_size;
                          uip_len = 0;

			}
			else //Benutzer moechte eine leere Datei gesendet bekommen.//In diesem Fall wird ein Fehler ausgegeben.
            		{
                          ftps->count = strlen(FailCode504);
                          uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
                          strncpy((char*) (uip_appdata),(char*)(FailCode504),uip_len);

                          ftps->active_cmd = CMD_RETR;
                          ftps->active_state   = STATE_RESPONSE_NO_DATA;
                          ftps->hFile = 0;
                          ftps->file_size = 0;
			}
		}
	}
	else if (!strcmp(cmd,cmd_cwd_P))
        {
		if (!strcmp(arg,"/"))
                {
			char* msg = "200 directory changed to /.\r\n";
			ftps->count = strlen(msg);
			uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
			strncpy((char*) (uip_appdata),(char*)(msg),uip_len);
		}
		else
                {
			ftps->count = strlen(FailCode504);
			uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
			strncpy((char*) (uip_appdata),(char*)(FailCode504),uip_len);
		}
                ftps->active_cmd    = CMD_RETR;
                ftps->active_state   = STATE_RESPONSE_NO_DATA;
   	}
	else if(!strcmp(cmd,cmd_mkd_P))
        {
		if(FS_MkDir(arg) == 0) //makedir worked
		{
			ftps->count = strlen(okCode200);
			uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
			strncpy((char*) (uip_appdata),(char*)(okCode200),uip_len);
		}
		else
		{
			ftps->count = strlen(FailCode550);
			uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
			strncpy((char*) (uip_appdata),(char*)(FailCode550),uip_len);
		}

            ftps->active_cmd = CMD_MKD;
            ftps->active_state   = STATE_RESPONSE_NO_DATA;

	}
	else if(!strcmp(cmd,cmd_rmd_P)) {
		if(FS_RmDir(arg) == 0) //removedir worked
		{
			ftps->count = strlen(okCode200);
			uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
			strncpy((char*) (uip_appdata),(char*)(okCode200),uip_len);
		}
		else
		{
			ftps->count = strlen(FailCode550);
			uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
			strncpy((char*) (uip_appdata),(char*)(FailCode550),uip_len);
		}
            ftps->active_cmd = CMD_RMD;
            ftps->active_state   = STATE_RESPONSE_NO_DATA;
	}
	else if (!strcmp(cmd,cmd_noop_P))
        {
		ftps->count = strlen(okCode200);
		uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
		strncpy((char*) (uip_appdata),(char*)(okCode200),uip_len);
                ftps->active_cmd = CMD_NOOP;
                ftps->active_state   = STATE_RESPONSE_NO_DATA;

	}
	else
        {
		ftps->count = strlen(FailCode502);
		uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
		strncpy((char*) (uip_appdata),(char*)(FailCode502),uip_len);

                ftps->active_cmd = CMD_UNKNOWN;
                ftps->active_state   = STATE_RESPONSE_NO_DATA;
	}
 }

/******************************************************************************
* Author: Paddy Khaukha-mabinda
* Date: 26.09.2012
* 
* Function: _poll
*
* Purpose: Function called when FTP Control Port 21 polls for data from the server.
* Comments:
*
* QUESTION: Why should we use a polling? 
*
* ANSWER: Because the uip stack offers no direct method for switching between the
*         control Port 21 and data port 20 programatically.

* All commands that do not send data to client or receive data from the client should take
* no action at all!
* 
* Commmands: LIST, and RETR have to be managed as follows:
*  LIST: 
*     Before we send the directory list we have to signal that the Data Port(20) has been
*     opened and we are ready to send the List. In this function the client has just
*     connected to the port 20 so we sende the 150 message siignal the client that we 
*     shall send the list immediately we get an ackwlegement top this message.
*     The 226OK Message is all sent after the directory has be send. The signaling
*     when to send this message is done _close_data() function.
*     The function _poll_data() finishes sending the list it closes the data port 20
*     and signals the control Port 20 to sent the 226OK message.
*
*    150 message: active_state = STATE_CONNECTED_FTPDATA
*    226 message: active_state = STATE_SENDING_226OK
*  -------------------------------------------------------------------------------------
*  RETR:  behaves like LIST
*
* --------------------------------------------------------------------------------------
*
*  STOR: (downloading a file)
*  STOR command is handled just like the LIST and RETR up to the 150 Message.
*  However, since we are receiving a file whose size is unknown, we have to
*  treat the 226OK message differentlly.  We can not use the received length
*  of the packets to signal the end (see _newdata_data()). We have to wait until
*  the stack has closed the data port so that we send the 226OK message. This
*  done when the client sends the las packet by setting the TCP FIN flag. 
*
*  we use ftp_data_closed == 1 to send the 226OK message!
*
*******************************************************************************/
void _poll(void) 
{
      struct ftpd_state *ftps = (struct ftpd_state *)&(uip_conn->appstate);
      struct ftpd_state *fs =  GetFTPDataPortState();

      switch(ftps->active_cmd)
      {
            case CMD_LIST:
             switch(ftps->active_state)
             {
                  case STATE_CONNECTED_FTPDATA:
                        Send150Response();
                        ftps->active_state = STATE_150_RESPONSE;
                        fs->data_pending = 0;
                  break;

                  case STATE_SENDING_226OK:
                        Send226OKResponse();
                        ftps->active_state = STATE_NONE;
                        ftps->active_cmd   = CMD_NONE;
                        fs->data_pending = 0;
                        fs->active_cmd    = CMD_NONE;
                        fs->active_state  = STATE_NONE;
                  break;
            }
           break;
          case CMD_STOR:
            if(ftps->active_state == STATE_CONNECTED_FTPDATA)
            {
                  Send150Response();
                  ftps->active_state = STATE_150_RESPONSE;

                  fs->data_pending = 0;
                  tracking = 2;
            }
            else if( ftp_data_closed == 1 )
            {
                  ftp_data_closed = 0;
                  Send226OKResponse();
                  ftps->active_state = STATE_NONE;
                  ftps->active_cmd   = CMD_NONE;
                  fs->data_pending = 0;
                  fs->active_cmd    = CMD_NONE;
                  fs->active_state  = STATE_NONE;
            }
          break;
          case CMD_RETR:
            if( ftps->active_state == STATE_CONNECTED_FTPDATA)
            {
                  Send150Response();
                  ftps->active_state = STATE_150_RESPONSE;
                  fs->data_pending = 0;
                  
            }
            else if( ftps->active_state == STATE_SENDING_226OK)
            {
                  Send226OKResponse();
                  ftps->active_state = STATE_NONE;
                  ftps->active_cmd   = CMD_NONE;
                  fs->data_pending = 0;
                  fs->active_cmd    = CMD_NONE;
                  fs->active_state  = STATE_NONE;
                
            }
              
          break;
      
          default:
          break;
	}

}

  
// test testt test
unsigned char TSTrtx;
//END
void _retrasmit(void)
{
	TSTrtx++;
}

/******************************************************************************
* Author: Paddy Khaukha-mabinda
* Date: 26.09.2012
* 
* Function: _ack
*
* Purpose: Function called when FTP Control Port 21 has sent a Response to the Client.
* Comments:
*
* All commands that do not send data to client or receive data from the client should take
* no action at all!
* 
* Commmands: LIST, and RETR have to be managed as follows:
*  LIST:
*     Before we send the directory list we have to signal that the Data Port(20) has been
*     opened and we are ready to send the List. In this function the client has just
*     acknowledged having received the 150 Response. Therefore we signal the data port with
*     data_pending = 1. When the data port is polled _poll_data then it sends the List.
*  -------------------------------------------------------------------------------------
*  RETR: (sending a file to the client: Uploading)
     In this function the client has just acknowledged having received the 150 Response.
*      Therefore we signal the data port (20) with
*     data_pending = 1. When the data port is polled _poll_data then it starts sending
*     the contents of the files. Sending the file contents starts in _poll_data and continues
*     _ack_data.
*
*
*******************************************************************************/
void _ack(void)
{
      struct ftpd_state *ftps = (struct ftpd_state *)&(uip_conn->appstate);
      struct ftpd_state *fs = GetFTPDataPortState();
      switch (ftps->active_cmd)
      {

            case CMD_LIST:
                  switch( ftps->active_state)
                  {
                        case STATE_150_RESPONSE:
                              ftps->active_state = STATE_SENDING_LIST;
                              uip_len = 0;
                              fs->active_state = STATE_SENDING_LIST;
                              fs->data_pending = 1;
                        break;

                        default:
                        break;
                   }
            break;
            case CMD_RETR:
                  if( ftps->active_state == STATE_150_RESPONSE)
                  {
                        ftps->active_state = STATE_SENDING_FILE_DATA;
                        uip_len = 0;
                        fs->active_state = STATE_SENDING_FILE_DATA;
                        fs->data_pending = 1;
                  }
            break;
            case CMD_STOR:
                  if( ftps->active_state == STATE_260_RESPONSE)
                  {
                        if( pFile != 0 ) // file not closed because it was small
                        {
                              FS_FClose(pFile);
                              pFile = 0;
                        }  
                        ftps->active_cmd = CMD_NONE;
                        ftps->active_state = STATE_NONE;
                        fs->active_cmd = CMD_NONE;
                        fs->active_state = STATE_NONE;
                        uip_len = 0;
                  }
            default:
                  if( ftps->active_state == STATE_RESPONSE_NO_DATA)
                  {
                        ftps->active_cmd = CMD_NONE;
                        ftps->active_state = STATE_NONE;
                        fs->active_cmd = CMD_NONE;
                        fs->active_state = STATE_NONE;
                        uip_len = 0;
                  }
            break;

      }
}



void _senddata(void)
{
	struct ftpd_state *ftps = (struct ftpd_state *)&(uip_conn->appstate);
	if (uip_len > 0)
        {
   		uip_send(uip_appdata,uip_len);
        }
}

void SplitCmdArg(char * line, char ** cmd, char ** args)
{
	/* Skip leading spaces. */
	while (*line && *line <= ' ') {
		line++;
	}

	/* The first word is the command. Convert it to upper case. */
	*cmd = line;
	while (*line > ' ') {
		if (*line >= (unsigned char) 'a' && *line <= (unsigned char) 'z') {
			*line -= (unsigned char) 'a' - 'A';
		}
		line++;
	}

	/* Mark end of the command word. */
	if (*line) {
		*line++ = '\0';
	}

	/* Skip spaces. */
	while (*line && *line <= ' ') {
		++line;
	}

	/* Arguments start here. */
	*args = line;
	while (*line && *line != '\r' && *line != '\n') {
		line++;
	}

	/* Mark end of arguments. */
	*line = 0;
}


void _abort_data(void)
{
}

void _timeout_data(void)
{
	uip_close();
}

/******************************************************************************
* Author: Paddy Khaukha-mabinda
* Date: 26.09.2012
* 
* Function: _close_data
*
* Purpose: Function called when the ftpdata port is being closed.
* Comments:
* We cannot send okCode226 because the Port is being closed.
* The Ok command can only be sent on FTP Control Port 21.
* From debugging the session, it was established that this command is sent
* before the last packet is processed.
* We should not use the ftps structure because this function is called on Port 20.
* Port21 should poll for LIST and send 226OK, while for STOR we set it when 
* the last packet has been processed!
*******************************************************************************/
void _close_data(void)
{
  struct ftpd_state *ftps = (struct ftpd_state *)&(uip_conn->appstate);
  struct ftpd_state *fs = GetFTPControlPortState();

  switch (ftps->active_cmd)
  {
      case CMD_LIST:
      case CMD_RETR:
      		switch(ftps->active_state)
      		{
                        case STATE_CLOSED_FTPDATA:
                              ftps->active_cmd = CMD_NONE;
                              ftps->active_state = STATE_NONE;
                              fs->active_state = STATE_SENDING_226OK;
                              fs->response_pending = 1;
	                break;
		}
      break;
      case CMD_STOR:
        ftp_data_closed = 1;
      break;
     default: break;
  }
}



/****************************************************************************
* Author: Paddy Khaukha-mabinda
* Date: 26.09.2012
* 
* Function: _connect_data
* Description
* This function is called by uip Stack after the remote client has connected
* to the Server on its data port 20. Now it is time to send a 150 Response
* This function is called when the remote client:
* 1. requests for a directory List
* 2. wants to download a file (RETR command)
* 3. wants to upload a file (STOR command)
*
*  In order to send a 150 Response on Port 21 we have to trigger the uip
*  stack to poll the 21 connection.
*  If we set response_pending on this data port (20) structure our
*  control port 21 will never see it. Therefore we have to get the Port 21 structrure
*   that corresponds to our new data port.
* ****************************************************************************/
void _connect_data(void)
{
      struct ftpd_state *ftps = (struct ftpd_state *)&(uip_conn->appstate);
      struct ftpd_state *fts = GetFTPControlPortState();
      com_ports.port20 =  uip_conn->rport;
      ftps->dataptr = 0;
      ftp_data_closed = 0;
      ftps->count = 0;
      if( fts != 0)
      {
            ftps->active_cmd   = fts->active_cmd; // save command in the data Port structure.
            ftps->active_state = STATE_CONNECTED_FTPDATA;
            ftps->file_size    = fts->file_size;
            ftps->hFile = fts->hFile;
            ftps->first_packet = 1;
            ftps->last_packet = 0;
            fts->active_state = STATE_CONNECTED_FTPDATA;// inform control port
            fts->response_pending = 1; // now send response and after that send directory info.
      }

      ftps_data_port = ftps;
}

// test testt test
unsigned char TSTrtx_data;
//END
/****************************************************************************
* Author: Paddy Khaukha-mabinda
* Date: 26.09.2012
* 
* Function: _retrasmit_data
* Purpose:  retransmit data has that was not fully received. 
*
* Remarks:
*           This function is used for LIST and RETR commands. Only the last packet
*           is retransmitted.
*=========================================================================== */
void _retrasmit_data(void)
{
      struct ftpd_state *ftps = (struct ftpd_state *)&(uip_conn->appstate);
      struct ftpd_state *fts = GetFTPControlPortState();
 
      switch( ftps->active_cmd)
      {
            case CMD_LIST:
                  if(ftps->active_state == STATE_SENDING_LIST)
                  {     
                        ftps->count = _dir((char*)uip_appdata);
                        uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
                        ftps->active_state = STATE_SENT_LIST;
                        fts->active_state  = STATE_SENT_LIST;
                  }
             break;
            
            case CMD_RETR:
		  ftps->count += retry_len;
                  uip_len = ((ftps->count >=  uip_mss()) ?  uip_mss() : ftps->count);
                  memcpy((void*)uip_appdata,cSendePuffer ,uip_len);
                 
                  ftps->dataptr+= retry_len;
                  
                  if (ftps->count >=  uip_mss())// more to be sent.
                  {
                        ftps->count-=  uip_mss();
                        ftps->dataptr = &cSendePuffer;
                        ftps->active_state = STATE_SENT_FILE_DATA;
                        fts->active_state   = STATE_SENT_FILE_DATA;// update control port 21

		  }
                  else
                  {
	                ftps->active_state = STATE_SENDING_FILE_DATA;
	                fts->active_state   = STATE_SENDING_FILE_DATA;// update control port 21
                        ftps->count = 0;
                  }
              
            break;
      }  
  
}

//unsigned char c;
char *dataptr;

/******************************************************************************
** Author: Paddy Khaukha-mabinda
* Date: 26.09.2012
* 
* Function: _newdata_data
*
* Purpose: Function called when the client is uploading a file to us.
*          We recieve file contents as packets. 
*         The function for the STOR command only.
* 
* Comments:
* 
*  Since we are receiving a file whose size is unknown, we don't know when
*  files has been completelty transfer.
*  The only think we know is that when the Client sends the last packet
*  its sets the TCP FIN flag hence the uip stack informs through the
*  _close_data() function.
* ----------------------------------------------------------------------------
* Whenever we receive a packet we set the control port (21) status variables
* 
*  response_pending  = 1,
*  active_cmd = CMD_STOR,
*  active_state = STATE_SENDING_226OK
*
*  Therefore when the uip stack calls _close_data() function we sent the 226OK
*  message. When this message is acknowdged, we can safely close the file and
* and clear status varaibles.
*
*  The earlier Versions used (len < PACKET_DATA_SIZE) and (  len <  uip_mss() )
*  but the tranfers did not perform as expected.
*  Reasons being:
*  1. If the stack used the maximum packet size UIP_MSS and the last packet was
*     bigger than PACKET_DATA_SIZE then the test len < PACKET_DATA_SIZE would fail.
*
*    Result: Timeout at the client side occurred because 226OK message was not sent!
*
*  2. If the stack used packet sizes smaller than UIP_MSS or PACKET_DATA_SIZE
*     the transfer would be prematurely terminated. 
*     Result: Only part of the file was saved.
*
*******************************************************************************/
void _newdata_data(void)
{
   struct ftpd_state *fs   = GetFTPControlPortState();
   struct ftpd_state *ftps = (struct ftpd_state *)&(uip_conn->appstate);;
   unsigned short len;
  
  if(!ftps->last_packet)
  {
 	len = uip_datalen();
        if (len > 0)
        {
          dataptr = (char *)uip_appdata;

          for(int i=0; i < len; i++)
          {
            cSendePuffer[i] = *dataptr;
            ++dataptr;
          }

          FS_Write(pFile, cSendePuffer, len);

      }

      fileSize += len;    
      if(  ftp_data_closed == 1) // this was a big file thn, let us signal receiving the file.
      {
           FS_FClose(pFile);
           pFile = 0;
           fs->active_cmd = CMD_STOR;
           fs->active_state = STATE_SENDING_226OK;
           fs->response_pending  = 1;
           ftps->last_packet = 0;
           tracking = 20;
      }
      uip_len = 0;
  }
}

/****************************************************************************
* Author: Paddy Khaukha-mabinda
* Date: 26.09.2012
* 
* Function: _ack_data
* Description
* This function is called by uip stack to report acknowledgment of data
* by the remote client.
* This function is called when the remote client:
* 1. requested for a directory List
* 2. downloading a file (RETR command)
*
* REMARKS:
* 1. If it is a directory list being acknowledged the we close the data port (20)
* 2. If we were sending (RETR) a file to the client and it is the last packet
*    we also close the File and the data port.
* ****************************************************************************/
void _ack_data(void)
{
    struct ftpd_state *ftps = (struct ftpd_state *)&(uip_conn->appstate);
    struct ftpd_state *fs   = GetFTPControlPortState();


  //  pFile = ftps->hFile;

    switch (ftps->active_cmd)
    {
        case CMD_LIST:
            switch (ftps->active_state)
            {
            	case STATE_SENT_LIST:
                    uip_close(); // close data port
                    ftps->active_state =  STATE_CLOSED_FTPDATA;
                    fs->active_state = STATE_CLOSED_FTPDATA;
                 break;
            }
        break;

        case CMD_RETR:
            if (ftps->count > 0)
            {   //Es muessen noch Daten gesendet werden:
                  if (ftps->first_packet == 1) //aller erster Sendeaufruf
                  {
                        ftps->count = ftps->file_size;
                        ftps->first_packet  = 0;
                  }
                  uip_len = ((ftps->count >=  uip_mss()) ? uip_mss() : ftps->count);
                  if (uip_len > 0)
                  {
                        FS_Read(pFile, cSendePuffer ,uip_len);
                        memcpy((void*)uip_appdata,cSendePuffer ,uip_len);
                  }
                  if (ftps->count >=  uip_mss())//Gesamtdatenanzahl noch groesser als TCP_MSS_SIZE
                  {
                        ftps->count-=  uip_mss();
                   }
                  else
                  {
                        ftps->count = 0;
                  }
                  ftps->dataptr = &cSendePuffer;
            }
            else //Es gibt nichts mehr zu senden
            {
                  FS_FClose(pFile);
                  pFile = 0;
                  uip_close();
                  ftps->active_state = STATE_CLOSED_FTPDATA;
                  fs->active_state = STATE_SENDING_226OK;
                  fs->response_pending = 1;
                  
            }
            break;
            default: break;
      }
 }

/******************************************************************************
* Author: Paddy Khaukha-mabinda
* Date: 26.09.2012
* 
* Function: _poll_data
*
* Purpose: Function called when FTP data Port 20 polls for data from the server.
* Comments:
*
* QUESTION: Why should we use a polling? 
*
* ANSWER: Because the uip stack offers no direct method for switching between the
*         control Port 21 and data port 20 programatically.

* All commands that do not send data to client or receive data from the client should take
* no action at all!
* 
* Commmands: LIST, and RETR have to be managed as follows:
*  LIST: 
*     Before we send the directory list we have to signal that the Data Port(20) has been
*     opened and we are ready to send the List. In this function we have sent the
*     150 message and received an acknowledge on the Control Port 21 _ack() function.
*     The _ack() function signal the uip_stack to _poll_data so that it can send the
*     directory list.
* 

*  -------------------------------------------------------------------------------------
*  RETR:  
*  The RETR command (uploading or sending a file to the client). In function we send the
*  first packet to the client. The rest of the file is sent in _ack_data() when we
*  receive acknowledge from the client.
*
* --------------------------------------------------------------------------------------
*
*******************************************************************************/
void _poll_data(void)
{

      struct ftpd_state *ftps = (struct ftpd_state *)&(uip_conn->appstate);
      struct ftpd_state *fts = GetFTPControlPortState();
 
////      pFile = ftps->hFile;
      
      struct ftpd_state *fs = 0;

      switch( ftps->active_cmd)
      {
            case CMD_LIST:
                  switch(ftps->active_state)
                  {
                        case STATE_SENDING_LIST:
	                   ftps->count = _dir((char*)uip_appdata);
                           uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
                           ftps->active_state = STATE_SENT_LIST;
                           fts->active_state  = STATE_SENT_LIST;
                        break;
                  }
            break;

            case CMD_RETR:
                  if (ftps->first_packet == 1) //aller erster Sendeaufruf
                  {
                        ftps->count = ftps->file_size;
                        ftps->first_packet = 0;
                   }
                  ftps->dataptr = &cSendePuffer; //Datapointer zeigt auf den grossen Buffer
                  uip_len = ((ftps->count > uip_mss()) ? uip_mss() : ftps->count);
                  FS_Read(pFile, cSendePuffer ,uip_len);
                  memcpy((void*)uip_appdata,cSendePuffer,uip_len);
                  
                  retry_len = uip_len; // used for retransmitting the last packet
                  
                  if (ftps->count >=  uip_mss())// more to be sent.
                  {
                        ftps->count-=  uip_mss();
                        ftps->dataptr = &cSendePuffer;
                        ftps->active_state = STATE_SENT_FILE_DATA;
                        fs->active_state   = STATE_SENT_FILE_DATA;// update control port 21

		  }
                  else
                  {
	                ftps->active_state = STATE_SENDING_FILE_DATA;
	                fs->active_state   = STATE_SENDING_FILE_DATA;// update control port 21
                        ftps->count = 0;
                  }

            break;
            default: break;
      }

}

void _senddata_data(void)
{
//	struct ftpd_state *ftps = (struct ftpd_state *)&(uip_conn->appstate);

	if (uip_len > 0)
	{
		uip_send(uip_appdata,uip_len);

	}
}


//Zureuckgabe der im Verzeichnis enthaltenen Dateien
//Die Dateinamen muessen nacheinander mit space getrennt ueber der
// Datenbus gejagt werden
#define SIZEOFFILENAME_BUFFERSIZE 100
//#define SIZEOFEXTENDEDFILENAME_BUFFERSIZE 60
#define SIZEOFEXTENDEDFILENAME_BUFFERSIZE 1000
#define FILE_NAME_LIST_SIZE 1000
//arg wird im Moment noch nicht verwendet
int _dir( char * pBuf )
{
	char sFilenamebuffer[SIZEOFFILENAME_BUFFERSIZE] = {0};
	//fuer das Hauptverzeichnis muss ein leerer Verzeichnispfad genommen werden:
	char s_extended_Filenamebuffer[SIZEOFEXTENDEDFILENAME_BUFFERSIZE] = {0};
	char sPath[] = "\\";
	int fsrv; //filesystem_returnvalue 0=Erfolgreich, 1=Fehler
        int item_len = 0;
	sprintf(s_extended_Filenamebuffer,"");
	int entrysize = 0;
	FS_DIR    *pDir;
	FS_DIRENT *pDirEnt;
	pDir = FS_OpenDir("");      // Open root directory of default device
	if (pDir) {
		do {
			char acName[20];
			U8 Attr;
			pDirEnt = FS_ReadDir(pDir);
			FS_DirEnt2Name(pDirEnt, acName);
			FS_DirEnt2Attr(pDirEnt, &Attr);
			entrysize = FS_DirEnt2Size(pDirEnt);
			if ((void*)pDirEnt == NULL) {
				break; // No more files
			}
			sprintf(sFilenamebuffer, "%srwxrwxrwx 1 ers ers %d Nov 16 07:55 %s\r\n",(Attr & FS_ATTR_DIRECTORY) ? "d" : "-",entrysize, acName);
			//sprintf(s_extended_Filenamebuffer, "%s%s",s_extended_Filenamebuffer, sFilenamebuffer);
 		        strcat(s_extended_Filenamebuffer, sFilenamebuffer);
		} while (1);
		FS_CloseDir(pDir);

                //strncpy((char*) (uip_appdata),(char*)s_extended_Filenamebuffer,strlen(s_extended_Filenamebuffer));
                item_len = strlen(s_extended_Filenamebuffer);
		strncpy(pBuf,(char*)s_extended_Filenamebuffer, item_len);
	}
    return item_len;
}

void _getFile( char * pFileName )
{
      struct ftpd_state *ftps = (struct ftpd_state *)&(uip_conn->appstate);

	FS_FILE *pFile = FS_FOpen( &pFileName, "a" ); //#LP#FREERTOS#
	if (pFile != NULL)
	{
		ftpd_size = FS_GetFileSize(pFile);
	}
}


/********************************************************
* Author: Paddy Khaukha-mabinda
* Date: 26.09.2012
* 
 * Function: Send150Response
 *
 ******************************************************** */
void Send150Response(void)
{
      struct ftpd_state *ftps = (struct ftpd_state *)&(uip_conn->appstate);
      uip_len = 0;
      switch( ftps->active_cmd)
      {
            case CMD_LIST:
                  ftps->count = strlen(LST150);
                  uip_len = ((ftps->count >= PACK_DATA_SIZE) ? PACK_DATA_SIZE : ftps->count);
                  strncpy((char*) (uip_appdata),(char*)LST150, uip_len);
            break;
            case CMD_STOR:
                  ftps->count = strlen(STOR150);
                  uip_len = ((ftps->count >= PACK_DATA_SIZE) ? PACK_DATA_SIZE : ftps->count);
                  strncpy((char*) (uip_appdata),(char*)STOR150, uip_len);
            break;
            case CMD_RETR:
                  ftps->count = strlen(RETR150);
                  uip_len = ((ftps->count >= PACK_DATA_SIZE) ? PACK_DATA_SIZE : ftps->count);
                  strncpy((char*) (uip_appdata),(char*)RETR150, uip_len);
           break;
      }
 
}

void ResetPortStates(void)
{
      struct uip_conn *c_cs;
      int i;
      com_ports.port21 = 0;
      com_ports.port20 = 0;
      
      for( i = 0; i < UIP_CONNS; i++)
      {
            c_cs = &uip_conns[i];
            c_cs->appstate.data_pending    = 0;
            c_cs->appstate.response_pending = 0;
            c_cs->appstate.active_cmd = CMD_NONE;
            c_cs->appstate.active_state = STATE_NONE;
      }
      
}
void Send226OKResponse(void )
{
      struct ftpd_state *ftps = (struct ftpd_state *)&(uip_conn->appstate);
      ftps->count = strlen(okCode226);
      uip_len = ((ftps->count >= PACK_DATA_SIZE) ? PACK_DATA_SIZE : ftps->count);
      strncpy((char*) (uip_appdata),(char*)(okCode226),uip_len);
}
struct ftpd_state *GetFTPDataPortState(void)
{
      struct uip_conn *c_cs;
      struct ftpd_state *fs = 0;
      int i;
      for( i = 0; i < UIP_CONNS; i++)
      {
            c_cs = &uip_conns[i];
            if( uip_ipaddr_cmp(c_cs->ripaddr,uip_conn->ripaddr) )
            {
                  if( (c_cs->lport == htons(20)) &&(c_cs->rport == com_ports.port20 ) )
                  {
                    fs = (struct ftpd_state *)(&c_cs->appstate);
                    break;
                  }
            }
      }
      return fs;
}
struct ftpd_state * GetFTPControlPortState(void)
{
      struct uip_conn *c_cs;
      struct ftpd_state *fs = 0;
      int i;
      for( i = 0; i < UIP_CONNS; i++)
      {
            c_cs = &uip_conns[i];
            if( uip_ipaddr_cmp(c_cs->ripaddr,uip_conn->ripaddr) )
            {
                  if( (c_cs->lport == htons(21))&&(c_cs->rport == com_ports.port21)  )
                  {
                    fs = (struct ftpd_state *)(&c_cs->appstate);
                    break;
                  }
            }
      }
      return fs;
}
/******************************************************************************
* Author: Paddy Khaukha-mabinda
* Date: 26.09.2012
* 
* Function: SaveControlPort.
*
* Purpose: Save a new connection in the list.
*
* Comments: The routine searches for an empty slot and if it finds one then 
*           then the new structure is inserted into the list.
* 
* NOTE: If the list is full and none has been disconnected, then oldest connection
*       is overwritten. 
*       Ofcourse it is possible to overwrite an active communcation port!!
*
******************************************************************************/
////void SaveControlPort(struct comm_struct *com_str)
////{
////      u8_t i;
////      u8_t j;
////      
////      for( i=0;i <UIP_CONNS;i++)
////      {
////            if(uip_ipaddr_cmp(comm_List[i].ripaddr,0) )
////            {
////                  break;     
////            }
////            else
////            if( comm_List[i].con_state == COMM_STATE_DISCONNECTED);
////            {
////                  break;
////            }
////      }
////      if(i == UIP_CONNS) //If no free slot is found we have throught out the oldest in the list.
////      {
////              j = 1;
////              for( i=0; i < UIP_CONNS; i++)
////              {
////                  comm_List[i] = comm_list[j++]; // shift the items upwards
////              } 
////              i =  UIP_CONNS -1;
////      }
////      comm_List[i].ripaddr  = com_str->ripaddr;
////      comm_List[i].rcport   = com_str->rcport;
////      comm_List[i].rdport   = com_str->rdport;
////      comm_List[i].con_state = com_str->con_state;
////}