#include "uipopt.h"
#include "uip.h"

#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"

/* The queue used to hold received characters. */
xQueueHandle xHDiagRxChars;
xQueueHandle xHDiagTxChars;
char cBuf[1024];

/*-----------------------------------------------------------------------------------*/
void http_diag_init(void)
{
    xHDiagRxChars = xQueueCreate( 1024, ( unsigned portBASE_TYPE ) sizeof( char ) );
    xHDiagTxChars = xQueueCreate( 128, ( unsigned portBASE_TYPE ) sizeof( char ) );
    vQueueAddToRegistry( xHDiagRxChars, "HTTP Diagnos receive" );
    vQueueAddToRegistry( xHDiagTxChars, "HTTP Diagnos send" );
    uip_listen(HTONS(2000));
}

/*-----------------------------------------------------------------------------------*/
void http_diag_app(void)
{
    static int iTOut = 0;
    u8_t i;
    char *dataptr = (char *)uip_appdata;

    if(uip_connected()) {
         //uip_send("OK\n", 3);
         return;
      } 
      else if(uip_poll()) {
        int i = 4;
        while( xQueueReceive( xHDiagTxChars, &cBuf[i++], 0) == pdTRUE );
        if( i > 5 ){
          cBuf[0] = 0;
          cBuf[1] = 0;
          cBuf[3] = 0;
          cBuf[3] = 0;
          uip_send( (u8_t*)cBuf, i-1);
        }
        if( iTOut++ > 10000 ){
          uip_close();
        }
        return;
      } 
      else if(uip_newdata()) {
        iTOut = 0;
        int i = (dataptr[4] << 8) + dataptr[5];
        int j;
        portENTER_CRITICAL();
        for(j = 0 ;j < i; j++ ){
          xQueueSend( xHDiagRxChars, (void*)&dataptr[j+6], 0 );
        }
        portEXIT_CRITICAL();
        i = 4;
//        while( uxQueueMessagesWaiting(xHDiagTxChars) < 1 && iTOut < 100000) iTOut++;
        if( xQueueReceive( xHDiagTxChars, &cBuf[i++], 10000 ) == pdTRUE )
        {
            while( xQueueReceive( xHDiagTxChars, &cBuf[i++], 0) == pdTRUE );
            if( i > 5 ){
              cBuf[0] = 0;
              cBuf[1] = 0;
              cBuf[3] = 0;
              cBuf[3] = 0;
              portENTER_CRITICAL();
              uip_send( (u8_t*)cBuf, i-1);
              portEXIT_CRITICAL();
            }
        }
        return;
      } 
      else if( uip_acked() ){
        return;
      }

}
