#ifndef HTTP_DIAG_H
#define HTTP_DIAG_H

void http_diag_app(void);
void http_diag_init(void);

#endif