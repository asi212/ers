#include "..\system_wide_defs.h"
#include "uip.h"
#include "telnetd.h"
#include <string.h>
#include "telnetd-shell.h"
#include "bootloader_jump.h"
//#include "ff.h" //FatFs-Filesystem
#define MAX_COMMAND_LENGTH 30
//#include "diskio.h" // Declarations of low level disk I/O functions 


#include "stdio.h"
//#include "c2635.h"
#include "FS.h"
#include "yvals.h"

//extern FATFS fatfs; //Dateisystem. Wird in der Main gemountet, deswegen extern.
extern int g_my_formatting_flag;

extern int g_FTP_number; //Nur eine Testnummer um den FTP-Server zu debuggen

char g_cmd_buffer[MAX_COMMAND_LENGTH+1] = {0}; //Normal Command-Buffer
char g_2nd_lvl_cmd_buffer[MAX_COMMAND_LENGTH+1] = {0}; //Command Buffer for already cutted Command lines

int cmd_ready = 0; //Flag ob der Benutzer eine Befehlszeile mit ENTER abgeschickt hat
				   // und nun bearbeitet werden kann

char cmd1[MAX_COMMAND_LENGTH] = {0};  // Befehlsstring1 der herausgetrennt wird
char cmd2[MAX_COMMAND_LENGTH] = {0}; // Befehlsstring2 der herausgetrennt wird
char arg[MAX_COMMAND_LENGTH] = {0};  // Argumentssstring der herausgetrennt wird

int SplitCmdArg(char line[], char cmd_one[], char cmd_two[], char arg[]);

// Kleine enumeration um die Ausgabe der Erfolgreichen oder
// Fehlgeschlagenen Befehlsausgaben fuer uebersichtlichere Programme
// auszugliedern.

/*
typedef enum 
{ 
  CMD_f_mkfs,
  CMD_f_write,
  CMD_f_getfree,
  CMD_f_readdir,
  CMD_f_opendir,
  CMD_f_open,
  CMD_f_getcwd,  
} commandstatus;
*/

// Funktion zur Ausgabe der jeweiligen Erfolgs- und Fehlschlagsmeldungen:
//void status_output(struct telnetd_state *s, commandstatus cmd_stat, FRESULT status); //Bloss eine Vorwaertsdeklaration...



#define SIZEOFFILENAME_BUFFERSIZE 60

char sFilenamebuffer[SIZEOFFILENAME_BUFFERSIZE]@ "EXRAM";
char sFilenamebuffer2[SIZEOFFILENAME_BUFFERSIZE] @ "EXRAM";

#include "FS_NOR_PHY_M29W128G.h"

//Zureuckgabe der im Verzeichnis enthaltenen Dateien
//Die Dateinamen muessen nacheinander mit space getrennt ueber der
// Datenbus gejagt werden

#define FILENAME_BUFFERSIZE 30
#define BIFBUFFERSIZE 500
char sFilename[FILENAME_BUFFERSIZE] @ "EXRAM";
char sBigBuffer[BIFBUFFERSIZE] @ "EXRAM";

//PowerPac FS:
FS_FIND_DATA *p_finddata;
FS_FILE *p_FS_FILE;
/*
FIL fdst;
UINT bw;
*/
static void write_a_file(struct telnetd_state *s, char *str)
{
  int data_written = 0;
  sprintf(sBigBuffer,"%s","Dies ist der Inhalt der ersten Testdatei. And the Raven never flitting, is still sitting, is still sitting, on the pallid bust of pallas just above my chamber door.");
  p_FS_FILE = FS_FOpen("testfile.txt","a"); //create a file or write at the end of it // 0 byte written
	if (  p_FS_FILE != NULL ) 
	{
		data_written = FS_Write (p_FS_FILE, sBigBuffer, strlen(sBigBuffer));
		sprintf(sFilenamebuffer,"Data written:%d",data_written);
		telnetd_output(s, sFilenamebuffer, "");
		FS_FClose(p_FS_FILE);
		FS_MkDir ("testdir1");
		FS_MkDir ("testdir2");
	}
}

//Globales Flag aus der Main um ein Displayupdate zu starten:
extern char display_update_flag;

//------------------------------------------------------------------------------
//Folgende Funktionen finden sich in der Datei "FS_NOR_PHY_M29W128G.c":

// Reads data from the given offset of the flash:
// Return value: 0 -> O.K., data has been read from flash, other -> error
extern int _ReadOff(char Unit, void * pDest, unsigned int Off, unsigned int NumBytes);

// This routine writes data into any section of the flash.
// It does not check if this section has been previously erased!!!
// Return value: 0 -> O.K., data has been written from flash, other -> error
extern int _WriteOff(char Unit, unsigned int Off, const void * pSrc, unsigned int NumBytes);

// Erases one sector.
// Return value: 0 -> O.K., sector is ereased. other -> error, sector may not be erased
extern int _EraseSector(char Unit, unsigned int SectorIndex);

//Returns the offset and length of the given sector
extern void _GetSectorInfo(char Unit, unsigned int SectorIndex, unsigned int * pOff, unsigned int * pLen);

//Returns the number of flash sectors
extern int _GetNumSectors(char Unit);

//Configures a single instance of the driver
extern void _Configure(char Unit, unsigned int BaseAddr, unsigned int StartAddr, unsigned int NumBytes);

// Called right after selection of the physical layer
// This may be neccessary to retrieve the information from flash.
// #LP# Ok, ich vermute mal diese Funktion wird nur intern verwendet.
extern void _OnSelectPhy(char Unit);

//Sets every bit of a array to zero
void zero(char strg[], int len) {for(int i=0;i<len;i++) strg[i]=0;}

struct ptentry {
  char c;
  void (* pfunc)(struct telnetd_state *s, char *str);
};

struct my_ptentry {
  const char* cmd;
  void (* pfunc)(struct telnetd_state *s, char *str);
};

static void format(struct telnetd_state *s, char *str)
{
  //Initiere Formatierung der Flashdisk:
  // Nur Formattierung anstossen wenn nicht
  // bereits eine in arbeit ist:
  if(g_my_formatting_flag != -1)
  {
    g_my_formatting_flag = 2; //Formattierung in der Task initiieren
  }
}

/*-----------------------------------------------------------------------------------*/
/*
DWORD get_fattime (void)
{
	return	  ((DWORD)(2010 - 1980) << 25)	// Fixed to Jan. 1, 2010 
			| ((DWORD)1 << 21)
			| ((DWORD)1 << 16)
			| ((DWORD)0 << 11)
			| ((DWORD)0 << 5)
			| ((DWORD)0 >> 1);
}
*/
/*-----------------------------------------------------------------------------------*/
int SplitCmdArg(char line[], char cmd_one[], char cmd_two[], char arg[])
{
  char * pch;
  zero(cmd_one,MAX_COMMAND_LENGTH);
  zero(cmd_two,MAX_COMMAND_LENGTH);
  zero(arg,MAX_COMMAND_LENGTH);
  int i=0; //number of splitted commands
  pch = strtok (line," ");
  if (pch != NULL)
  {
	  i++;
	  strcpy(cmd_one,pch);
	  pch = strtok (NULL," ");
	  if (pch != NULL)
	  {
		  i++;
		  strcpy(cmd_two,pch);
		  pch = strtok (NULL," ");
		  if (pch != NULL)
		  {
			  i++;
			  strcpy(arg,pch);
		  }
	  }
  }
  return i; //Return the number of splitted commands
}

void fs_delete(struct telnetd_state *s, char *str)
{
	if(strlen(&arg)>0)
	{
		if(FS_Remove(&arg) == 0)
		{ //Datei entfernt
			sprintf(sFilenamebuffer,"File '%s' deleted", arg);
			telnetd_output(s, sFilenamebuffer, "");
		}
		else if (FS_RmDir(&arg) == 0) //removedir worked
		{ //Verzeichnis entfernt
			sprintf(sFilenamebuffer,"Folder '%s' deleted", arg);
			telnetd_output(s, sFilenamebuffer, "");
		}
		else //Fehlschlag
		{
			telnetd_output(s, "Delete failed!", "");
		}
	}
}

void space_free(struct telnetd_state *s, char *str)
{
sprintf(sFilenamebuffer,"Free Space: %d", FS_GetFreeSpace("ERS_DSK_1"));
telnetd_output(s, sFilenamebuffer, "");
}


/*-----------------------------------------------------------------------------------*/
static void
exitt(struct telnetd_state *s, char *str)
{
  telnetd_close(s);
}
/*-----------------------------------------------------------------------------------*/
static void
inttostr(register char *str, unsigned int i)
{
  str[0] = '0' + i / 100;
  if(str[0] == '0') {
    str[0] = ' ';
  }
  str[1] = '0' + (i / 10) % 10;
  if(str[1] == '0') {
    str[1] = ' ';
  }
  str[2] = '0' + i % 10;
  str[3] = ' ';
  str[4] = 0;
}
/*-----------------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------------*/

static void initFS(struct telnetd_state *s, char *str)
{
//FS_Init();
//FS_X_AddDevices();
telnetd_output(s, "I guess it initialized.. :)", "");
}




static void num_volumes(struct telnetd_state *s, char *str)
{
//sprintf(sFilenamebuffer,"Number of Volumes: %d", FS_GetNumVolumes());
//telnetd_output(s, sFilenamebuffer, "");
}

static void get_info(struct telnetd_state *s, char *str)
{
  /*
  FRESULT status;
  DWORD num_free_clusters=1;
//DWORD* p_num_free_clusters = DWORD num_free_clusters=1;
  status = f_getfree(0, &num_free_clusters, &fatfs);
    status_output(s, CMD_f_getfree, status);
    
  sprintf(sFilenamebuffer,"Number of free Clusters: %d", num_free_clusters);
  telnetd_output(s, sFilenamebuffer, "");
  */

 sprintf(sFilenamebuffer,"Number of Flash Sectors: %d", _GetNumSectors(0));
telnetd_output(s, sFilenamebuffer, "");


}

static void check_format(struct telnetd_state *s, char *str)
{
  /*
int status = -2;
status = FS_IsLLFormatted ("ERS_DSK_1");
 
== 1: The volume is low-level formatted.
== 0: The volume is not low-level formatted.
==-1: The device is not ready or a general error occurred.
switch (status) {
  case 1:
    telnetd_output(s, "The volume is low-level formatted. :)", "");
  break;
				
  case 0:
    telnetd_output(s, "The volume is not low-level formatted! :(", "");
    break;
    
  case -1:
    telnetd_output(s, "The device is not ready or a general error occurred! :(", "");
    break;
  default: break;
  }
 */
}



/*-----------------------------------------------------------------------------------*/



static void did_bootloader_work(struct telnetd_state *s, char *str)
{
  telnetd_output(s, "Yes! It worked, which means you are awesome!!! :D", ""); 
}

/*
// File status structure (FILINFO)
typedef struct {
	DWORD	fsize;			// File size
	WORD	fdate;			// Last modified date
	WORD	ftime;			// Last modified time
	BYTE	fattrib;		// Attribute
	TCHAR	fname[13];		// Short file name (8.3 format)
} FILINFO;
*/
//Ausgabe von Dateinformationen ueber Telnet.
/*
void print_fileinfo(struct telnetd_state *s, FILINFO* FileInfo)
{
    sprintf(sFilenamebuffer, "Filename: %s", FileInfo->fname);
    telnetd_output(s, sFilenamebuffer, "");
  
    sprintf(sFilenamebuffer, "Filesize: %d", FileInfo->fsize);
    telnetd_output(s, sFilenamebuffer, "");
  
    sprintf(sFilenamebuffer, "Last modified date: %d", FileInfo->fdate);
    telnetd_output(s, sFilenamebuffer, "");
  
    sprintf(sFilenamebuffer, "Last modified time: %d", FileInfo->ftime);
    telnetd_output(s, sFilenamebuffer, "");
  
    sprintf(sFilenamebuffer, "Attribute: %d", FileInfo->fattrib);
    telnetd_output(s, sFilenamebuffer, "");
}
*/


//#define SIZEOFEXTENDEDFILENAME_BUFFERSIZE 60
#define SIZEOFEXTENDEDFILENAME_BUFFERSIZE 500
#define FILE_NAME_LIST_SIZE 500

//char sFilenamebuffer[SIZEOFFILENAME_BUFFERSIZE]} @ "EXRAM";
char s_extended_Filenamebuffer[SIZEOFEXTENDEDFILENAME_BUFFERSIZE] @ "EXRAM";

static void listing(struct telnetd_state *s, char *str)
{
  int status;
  int data_read = 0;
  int filesize = 0;
  int entrysize = 0;
  FS_DIR    *pDir;
  FS_DIRENT *pDirEnt;
  char _acBuffer[200];
  pDir = FS_OpenDir("");      // Open root directory of default device 
  if (pDir) {
    do {
      char acName[20];
      U8 Attr;
      pDirEnt = FS_ReadDir(pDir);
      FS_DirEnt2Name(pDirEnt, acName);
      FS_DirEnt2Attr(pDirEnt, &Attr);
      entrysize = FS_DirEnt2Size(pDirEnt);
      if ((void*)pDirEnt == NULL) {
        break; // No more files
      }
      sprintf(_acBuffer,"  %s %s Attr.: %s%s%s%s %s %d", acName,
                        (Attr & FS_ATTR_DIRECTORY) ? "(Dir)" : "     ",
                        (Attr & FS_ATTR_ARCHIVE)   ? "A"     : "-",
                        (Attr & FS_ATTR_READ_ONLY) ? "R"     : "-",
                        (Attr & FS_ATTR_HIDDEN)    ? "H"     : "-",
                        (Attr & FS_ATTR_SYSTEM)    ? "S"     : "-",
                        "size:",
                        entrysize);
      telnetd_output(s, _acBuffer, "");
    } while (1);
    FS_CloseDir(pDir);
  }
 
  /*
  
  int uiplen=0;
  pDir = FS_OpenDir("");      // Open root directory of default device 
  if (pDir) {
    do {
      char acName[20];
      U8 Attr;
      pDirEnt = FS_ReadDir(pDir);
      FS_DirEnt2Name(pDirEnt, acName);
      FS_DirEnt2Attr(pDirEnt, &Attr);
      entrysize = FS_DirEnt2Size(pDirEnt);
      if ((void*)pDirEnt == NULL) {
        break; // No more files
      }
      sprintf(sFilenamebuffer, "%srwxrwxrwx 1 ers ers %d Mar 22 22:37 %s\r\n",(Attr & FS_ATTR_DIRECTORY) ? "d" : "-",entrysize, acName);
      //strcat(&s_extended_Filenamebuffer, &sFilenamebuffer);
      telnetd_output(s, sFilenamebuffer, "");
    } while (1);
    FS_CloseDir(pDir);
	*/
}


//-----------------------------------------------------------------------------------
static void
none(struct telnetd_state *s, char *str)
{
  if(strlen(str) > 0) {
    telnetd_output(s, "Unknown command", "");
  }
}

//-----------------------------------------------------------------------------------

static void
superinfo2(struct telnetd_state *s, char *str)
{
  
}
//-----------------------------------------------------------------------------------
int status = -2;
static void
superinfo(struct telnetd_state *s, char *str)
{

status = FS_IsLLFormatted ("ERS_DSK_1");

//== 1: The volume is low-level formatted.
//== 0: The volume is not low-level formatted.
//==-1: The device is not ready or a general error occurred.

switch (status) {
  case 1:
    telnetd_output(s, "The volume is low-level formatted. :)", "");
  break;
				
  case 0:
    telnetd_output(s, "The volume is not low-level formatted! :(", "");
    break;
    
  case -1:
    telnetd_output(s, "The device is not ready or a general error occurred! :(", "");
    break;
	
  default: break;
}
sprintf(sFilenamebuffer,"Number of Volumes: %d", FS_GetNumVolumes());
telnetd_output(s, sFilenamebuffer, "");

sprintf(sFilenamebuffer,"Free Space: %d", FS_GetFreeSpace("ERS_DSK_1"));
telnetd_output(s, sFilenamebuffer, "");

sprintf(sFilenamebuffer,"Total Space: %d", FS_GetTotalSpace("ERS_DSK_1"));
telnetd_output(s, sFilenamebuffer, "");

FS_GetVolumeName(0,sFilenamebuffer,SIZEOFFILENAME_BUFFERSIZE);
strcat(sFilenamebuffer, " is the name of the Volume");
telnetd_output(s, sFilenamebuffer, "");

sprintf(sFilenamebuffer,"Volume Size: %d", FS_GetVolumeSize("ERS_DSK_1"));
telnetd_output(s, sFilenamebuffer, "");

status =  FS_GetVolumeStatus("ERS_DSK_1");
switch (status) {
  case FS_MEDIA_STATE_UNKNOWN:
    telnetd_output(s, "The volume state is unknown! :(", "");
  break;
				
  case FS_MEDIA_NOT_PRESENT:
    telnetd_output(s, "A volume is not present.! :(", "");
    break;
    
  case FS_MEDIA_IS_PRESENT:
    telnetd_output(s, "A volume is present.! :)", "");
    break;
	
  default: break;
}
status = FS_IsVolumeMounted("ERS_DSK_1");
  if (status)
  {
    telnetd_output(s, "Volume is mounted. :)", "");
  }
  else
  {
    telnetd_output(s, "Volume is not correct mounted. :(", "");
  }

FS_DISK_INFO *p_disk_info;


// typedef struct {
//   U32 NumTotalClusters;
//   U32 NumFreeClusters;
//   U16 SectorsPerCluster;
//   U16 BytesPerSector;
// } FS_DISK_INFO;


FS_GetVolumeInfo ("ERS_DSK_1", p_disk_info);
sprintf(sFilenamebuffer,"NumTotalClusters: %d", p_disk_info->NumTotalClusters);
telnetd_output(s, sFilenamebuffer, "");
sprintf(sFilenamebuffer,"NumFreeClusters: %d", p_disk_info->NumFreeClusters);
telnetd_output(s, sFilenamebuffer, "");
sprintf(sFilenamebuffer,"SectorsPerCluster: %d", p_disk_info->SectorsPerCluster);
telnetd_output(s, sFilenamebuffer, "");
sprintf(sFilenamebuffer,"BytesPerSector: %d", p_disk_info->BytesPerSector);
telnetd_output(s, sFilenamebuffer, "");

}

//extern FRESULT g_my_formatting_status;
extern int g_my_formatting_flag;

static void
formatting_statuscheck(struct telnetd_state *s, char *str)
{
  if(g_my_formatting_flag == 1) // Formattierung fertig, gebe Statusbericht ab
  {
    //status_output(s, CMD_f_mkfs, g_my_formatting_status);
    telnetd_output(s, "Disk format done! :)","");
  }
  else if(g_my_formatting_flag == -1) // Formattierung angestossen, aber noch nicht beendet
  {
    telnetd_output(s, "Disk formatting is in progress, please be patient... :)", "");
  }
  else if(g_my_formatting_flag == 2) //Formattierung initiert, von der FormatTask aber nicht gestartet
  {
    telnetd_output(s, "Disk formatting is initiated,", "");
    telnetd_output(s, "but the responsible Task did not", "");
    telnetd_output(s, "start the formatting process! :(", "");
  }
  else
  {
    // Es wurde keine Formattierung angestossen.
    telnetd_output(s, "Disk format wasn't initiated by user...", "");
    telnetd_output(s, "...so theres nothing to talk about.", "");
    telnetd_output(s, "Actually, i wonder why you started this dialog. :)", "");
  }
}

static void
switch_to_root_dir(struct telnetd_state *s, char *str)
{
  /*
	rc = f_opendir(&dir, "");
	switch (rc) {
				case FR_NO_PATH:
				telnetd_output(s, "Could not find the path.", "");
				break;
				
				case FR_INVALID_NAME:
				telnetd_output(s, "The path name is invalid.", "");
				break;
				
				case FR_INVALID_DRIVE:
				telnetd_output(s, "The drive number is invalid.", "");
				break;
				
				case FR_NOT_READY:
				telnetd_output(s, "The disk drive cannot work due to no medium in the drive or any other reason.", "");
				break;
				
				case FR_DISK_ERR:
				telnetd_output(s, "The function failed due to an error in the disk function.", "");
				break;
				
				case FR_INT_ERR:
				telnetd_output(s, "The function failed due to a wrong FAT structure or an internal error.", "");
				break;
				
				case FR_NOT_ENABLED:
				telnetd_output(s, "The logical drive has no work area.", "");
				break;
				
				case FR_NO_FILESYSTEM:
				telnetd_output(s, "There is no valid FAT volume on the drive.", "");
				break;
				default:
				telnetd_output(s, "done! :)", "");
				break;
				}
  */
}


static void
read_number(struct telnetd_state *s, char *str)
{
  sprintf(sFilenamebuffer,"Testnummerwert: %d", g_FTP_number);
  telnetd_output(s, sFilenamebuffer, "");
}

void remove_uppercase(struct telnetd_state *s, char *str)
{
  g_FTP_number = FS_Remove("GARFIELD.TXT");
  if (g_FTP_number == -1)
  {
    telnetd_output(s, "Uppercase remove FAILED!", "");
  }
  else
  {
    telnetd_output(s, "Uppercase remove SUCCEDED! :D", "");
  }
}

void remove_lowercase(struct telnetd_state *s, char *str)
{
  g_FTP_number = FS_Remove("garfield.txt");
  if (g_FTP_number == -1)
  {
    telnetd_output(s, "Lowercase remove FAILED!", "");
  }
  else
  {
    telnetd_output(s, "Lowercase remove SUCCEDED! :D", "");
  }
}

/*-----------------------------------------------------------------------------------*/
static struct ptentry configparsetab[] =
  {{'s', listing},
   {'e', exitt},
   {'?', listing},
   {'m', listing},
   {'l', listing},
   {'r', switch_to_root_dir},
   {'f', format},
//   {'i', initFS},
   {'u', space_free}, //(unused space)
   {'v', num_volumes}, //Number of volumes
   {'i', get_info},
//   {'c', check_format},
   {'x', superinfo}, //PowerPacFS
   {'y', superinfo2}, //FATFsFS
   {'a', formatting_statuscheck}, //show formatting status 
        {'c', read_number},
        {'d', remove_uppercase},
        {'g', remove_lowercase},
   {'w', write_a_file},
   {'b', did_bootloader_work},
   
   // Default action
   {0, none}};
   
/*--- Meine neue Version mit vollstaendigen Befehlen---------------------------------*/
static struct my_ptentry my_configparsetab[] =
  {{"stats", listing},
   {"exit", exitt},
   {"?", listing},
   {"help", listing},

   /* Default action */
   {"none", none}};
   
/*-----------------------------------------------------------------------------------*/
void
telnetd_connected(struct telnetd_state *s)
{
  telnetd_output(s, "ERS electronic GmbH telnet shell", "");
  telnetd_output(s, "Type 'help' for a command overview", "");  
  telnetd_prompt(s, "> "); 
}

/*-----------------------------------------------------------------------------------*/

/*
void status_output(struct telnetd_state *s, commandstatus cmd_stat, FRESULT status)
{
  switch (cmd_stat)
  {
  case CMD_f_getcwd:
      switch (status)
        {
        case FR_OK:
          telnetd_output(s, "f_getcwd: The function succeeded. :)", "");
          break;
        case FR_NOT_READY:
          telnetd_output(s, "f_getcwd:The disk drive cannot work due to no medium in the drive or any other reason! :(", "");
          break;
        case FR_DISK_ERR:
          telnetd_output(s, "f_getcwd:The function failed due to an error in the disk function. :(", "");
          break;
        case FR_INT_ERR:
          telnetd_output(s, "f_getcwd:The function failed due to a wrong FAT structure or an internal error! :(", "");
          break;
        case FR_NOT_ENABLED:
          telnetd_output(s, "f_getcwd:The logical drive has no work area. :(", "");
          break;
        case FR_NO_FILESYSTEM:
          telnetd_output(s, "f_getcwd:There is no valid FAT volume on the drive. :(", "");
          break;
        case FR_NOT_ENOUGH_CORE:
          telnetd_output(s, "f_getcwd:Insufficient size of Buffer. :(", "");
          break;
        default:
          break;
        }
  break;
  
  case CMD_f_open:
      switch (status)
        {
        case FR_OK:
          telnetd_output(s, "f_open: The function succeeded and the file object is valid. :)", "");
          break;
        case FR_NO_FILE:
          telnetd_output(s, "f_open: Could not find the file. :(", "");
          break;
        case FR_NO_PATH:
          telnetd_output(s, "f_open: Could not find the path. :(", "");
          break;					
        case FR_INVALID_NAME:
          telnetd_output(s, "f_open: The file name is invalid.", "");
          break;
        case FR_INVALID_DRIVE:
          telnetd_output(s, "f_open: The drive number is invalid. :(", "");
          break;	
        case FR_EXIST:
          telnetd_output(s, "f_open: The file is already existing. :(", "");
          break;	
        case FR_DENIED:
          telnetd_output(s, "f_open: The required access was denied due to one of the following reasons:  :(", "");
          telnetd_output(s, "f_open: Write mode open against a read-only file.", "");
          telnetd_output(s, "f_open: File cannot be created due to a directory or read-only file is existing.", "");
          telnetd_output(s, "f_open: File cannot be created due to the directory table is full.", "");
          break;	
        case FR_NOT_READY:
          telnetd_output(s, "f_open: The disk drive cannot work due to no medium in the drive or any other reason. :(", "");
          break;	
        case FR_WRITE_PROTECTED:
          telnetd_output(s, "f_open: Write mode open or creation under the medium is write protected. :(", "");
          break;
        case FR_DISK_ERR:
          telnetd_output(s, "f_open: The function failed due to an error in the disk function. :(", "");
          break;
        case FR_INT_ERR:
          telnetd_output(s, "f_open: The function failed due to a wrong FAT structure or an internal error. :(", "");
          break;
        case FR_NOT_ENABLED:
          telnetd_output(s, "f_open: The logical drive has no work area. :(", "");
          break;
        case FR_NO_FILESYSTEM:
          telnetd_output(s, "f_open: There is no valid FAT volume on the drive. :(", "");
          break;
        case FR_LOCKED:
          telnetd_output(s, "f_open: The function was rejected due to file shareing policy (_FS_SHARE). :(", "");
          break;
        default:
          break;
        }
    break;
    case CMD_f_opendir:
      switch (status)
        {
        case FR_OK:
          telnetd_output(s, "f_opendir: The function succeeded and the directory object is created. :)", "");
          break;
        case FR_NO_PATH:
          telnetd_output(s, "f_opendir: Could not find the path. :(", "");
          break;
        case FR_INVALID_NAME:
          telnetd_output(s, "f_opendir: The path name is invalid. :(", "");
          break;
        case FR_INVALID_DRIVE:
          telnetd_output(s, "f_opendir: The drive number is invalid. :(", "");
          break;
        case FR_NOT_READY:
          telnetd_output(s, "f_opendir: The disk drive cannot work due to no medium in the drive or any other reason. :(", "");
          break;
        case FR_DISK_ERR:
          telnetd_output(s, "f_opendir: The function failed due to an error in the disk function. :(", "");
          break;
        case FR_INT_ERR:
          telnetd_output(s, "f_opendir: The function failed due to a wrong FAT structure or an internal error. :(", "");
          break;
        case FR_NOT_ENABLED:
          telnetd_output(s, "f_opendir: The logical drive has no work area. :(", "");
          break;
        case FR_NO_FILESYSTEM:
          telnetd_output(s, "f_opendir: There is no valid FAT volume on the drive. :(", "");
          break;
        default:
          break;
        }
    break;
    case CMD_f_readdir:
      switch (status)
        {
        case FR_OK:
          telnetd_output(s, "f_readdir: The function succeeded. :)", "");
          break;
        case FR_NOT_READY:
          telnetd_output(s, "f_readdir: The disk drive cannot work due to no medium in the drive or any other reason. :(", "");
          break;
        case FR_DISK_ERR:
          telnetd_output(s, "f_readdir: The function failed due to an error in the disk function. :(", "");
          break;
        case FR_INT_ERR:
          telnetd_output(s, "f_readdir: The function failed due to a wrong FAT structure or an internal error. :(", "");
          break;
        case FR_INVALID_OBJECT:
          telnetd_output(s, "f_readdir: The directory object is invalid. :(", "");
          break;
        default:
          break;
        }
    break;
    case CMD_f_getfree:
      switch (status)
        {
        case FR_OK:
          telnetd_output(s, "f_getfree: The function succeeded. :)", "");
          break;
        case FR_INVALID_DRIVE:
          telnetd_output(s, "f_getfree: The drive number is invalid. :(", "");
          break;
        case FR_NOT_READY:
          telnetd_output(s, "f_getfree: The disk drive cannot work due to no medium in the drive or any other reason. :(", "");
          break;
        case FR_DISK_ERR:
          telnetd_output(s, "f_getfree: The function failed due to an error in the disk function. :(", "");
          break;
        case FR_INT_ERR:
          telnetd_output(s, "f_getfree: The function failed due to a wrong FAT structure or an internal error. :(", "");
          break;
        case FR_NOT_ENABLED:
          telnetd_output(s, "f_getfree: The logical drive has no work area. :(", "");
          break;
        case FR_NO_FILESYSTEM:
          telnetd_output(s, "f_getfree: There is no valid FAT partition on the drive. :(", "");
          break;
        default:
          break;
        }
    break;
    case CMD_f_write:
      switch (status)
        {
        case FR_OK:
          telnetd_output(s, "f_write: The function succeeded. :)", "");
          break;
        case FR_DENIED:
          telnetd_output(s, "f_write: The function denied due to the file has been opened in non-write mode. :(", "");
          break;
        case FR_DISK_ERR:
          telnetd_output(s, "f_write: The function failed due to an error in the disk function. :(", "");
          break;
        case FR_INT_ERR:
          telnetd_output(s, "f_write: The function failed due to a wrong FAT structure or an internal error. :(", "");
          break;
        case FR_NOT_READY:
          telnetd_output(s, "f_write: The disk drive cannot work due to no medium in the drive or any other reason. :(", "");
          break;
        case FR_INVALID_OBJECT:
          telnetd_output(s, "f_write: The file object is invalid. :(", "");
          break;
        default:
          break;
        }
      break;
    case CMD_f_mkfs:
      switch (g_my_formatting_status)
        {
        case FR_OK:
          telnetd_output(s, "The function succeeded. :)", "");
            break;
        case FR_INVALID_DRIVE:
          telnetd_output(s, "The drive number is invalid. :(", "");
          break;
        case FR_NOT_READY:
          telnetd_output(s, "The drive cannot work due to any reason. :(", "");
          break;
        case FR_WRITE_PROTECTED:
          telnetd_output(s, "The drive is write protected. :(", "");
          break;
        case FR_NOT_ENABLED:
          telnetd_output(s, "The logical drive has no work area. :( ", "");
          telnetd_output(s, "I guess you forgot to mount before this try!", "");
          break;
        case FR_DISK_ERR:
          telnetd_output(s, "The function failed due to an error in the disk function. :(", "");
          break;
        case FR_MKFS_ABORTED:
          telnetd_output(s, "The function aborted before start in format due to a reason as follows. :(", "");
          telnetd_output(s, "The disk size is too small.", "");
          telnetd_output(s, "Invalid parameter was given to any parameter.", "");
          telnetd_output(s, "Not allowable cluster size for this drive. This can occure when number of clusters gets near the 0xFF7 and 0xFFF7.", "");
          break;
        default: break;
        }
      break;
    default: break;
  }
}

*/

static void
stats(struct telnetd_state *s, char *strr)
{
  char str[TELNETD_LINELEN];
  inttostr(str, uip_stat.tcp.rexmit);
  telnetd_output(s, "TCP packets retransmitted ", str);
  inttostr(str, uip_stat.tcp.synrst);
  telnetd_output(s, "TCP connection attempts ", str); 
  
  inttostr(str, uip_stat.ip.recv);
  telnetd_output(s, "IP packets received ", str);
  inttostr(str, uip_stat.ip.sent);
  telnetd_output(s, "IP packets sent ", str);
  inttostr(str, uip_stat.ip.drop);
  telnetd_output(s, "IP packets dropped ", str);
  
  inttostr(str, uip_stat.icmp.recv);
  telnetd_output(s, "ICMP packets received ", str);
  inttostr(str, uip_stat.icmp.sent);
  telnetd_output(s, "ICMP packets sent ", str);
  inttostr(str, uip_stat.icmp.drop);
  telnetd_output(s, "ICMP packets dropped ", str);

  inttostr(str, uip_stat.tcp.recv);
  telnetd_output(s, "TCP packets received ", str);
  inttostr(str, uip_stat.tcp.sent);
  telnetd_output(s, "TCP packets sent ", str);
  inttostr(str, uip_stat.tcp.drop);
  telnetd_output(s, "TCP packets dropped ", str);
}


static void
help(struct telnetd_state *s)
{
  telnetd_output(s, " Available commands:", "");
  telnetd_output(s, " help            -Shows this table", "");
  telnetd_output(s, " exit            -Closes the telnet connection", "");
  telnetd_output(s, " --------Filesystem----------------------------------", "");
  telnetd_output(s, " fs df           -Display free disk space", "");
  telnetd_output(s, " fs diskinfo     -Displays very much disk info", "");
  telnetd_output(s, " fs ls | fs dir  -Briefly list directory contents", "");
  telnetd_output(s, " fs formatstatus -Shows a formatting progress info", "");
  telnetd_output(s, " fs write        -Writes some example files and folders", "");
  telnetd_output(s, " fs del ####     -Deletes a file or folder", "");
  telnetd_output(s, " ---------Ethernet-----------------------------------", "");
  telnetd_output(s, " tcp stats       -Shows ethernet packet statistics", "");
  telnetd_output(s, " ---------Display-----------------------------------", "");
  telnetd_output(s, " display update  -Starts a update of the display software", "");
  telnetd_output(s, " ---------System-----------------------------------", "");
  telnetd_output(s, " reset           -Resets the processor", "");

}

void parse(struct telnetd_state *s, register char *str, struct ptentry *t)
{
	int num = SplitCmdArg(&g_cmd_buffer,&cmd1,&cmd2,&arg);
	if(num)
	{
		if (!strcmp(cmd1,"help")) help(s);
		else if (!strcmp(cmd1,"fs"))
		{
			if (!strcmp(cmd2,"format")) format(s,sFilenamebuffer);
			else if (!strcmp(cmd2,"ls") || !strcmp(cmd2,"dir")) listing(s,sFilenamebuffer);
			else if (!strcmp(cmd2,"df")) space_free(s,sFilenamebuffer);
			else if (!strcmp(cmd2,"formatstatus")) formatting_statuscheck(s,sFilenamebuffer);
            else if (!strcmp(cmd2,"write")) write_a_file(s,sFilenamebuffer);
			else if (!strcmp(cmd2,"del")) fs_delete(s,sFilenamebuffer);
			else if (!strcmp(cmd2,"diskinfo"))superinfo(s,sFilenamebuffer);
		}
		else if (!strcmp(cmd1,"tcp"))
		{
			if (!strcmp(cmd2,"stats")) stats(s,sFilenamebuffer);
		}
		else if (!strcmp(cmd1,"exit")) exitt(s,sFilenamebuffer);
                else if (!strcmp(cmd1,"display"))
                {
                  if (!strcmp(cmd2,"update"))
                  {
                    display_update_flag = 1;
                  }
                }           
                else if (!strcmp(cmd1,"reset"))
                {
                  jump_to_bootloader();
                }
		else telnetd_output(s, "--Unknown command--", "");
	}
}



/*-----------------------------------------------------------------------------------*/
void
telnetd_input(struct telnetd_state *s, char *cmd)
{
	if (cmd_ready)
	{
		//Befehl abarbeiten:
		parse(s, cmd, configparsetab);
		//Befehlsspeicher zuruecksetzen:
		cmd_ready = 0;
		zero(g_cmd_buffer,MAX_COMMAND_LENGTH);
	}
  //my_parse(s, cmd, my_configparsetab);
  telnetd_prompt(s, "> "); 
}