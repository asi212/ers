/*
    FreeRTOS V6.1.0 - Copyright (C) 2010 Real Time Engineers Ltd.

    ***************************************************************************
    *                                                                         *
    * If you are:                                                             *
    *                                                                         *
    *    + New to FreeRTOS,                                                   *
    *    + Wanting to learn FreeRTOS or multitasking in general quickly       *
    *    + Looking for basic training,                                        *
    *    + Wanting to improve your FreeRTOS skills and productivity           *
    *                                                                         *
    * then take a look at the FreeRTOS books - available as PDF or paperback  *
    *                                                                         *
    *        "Using the FreeRTOS Real Time Kernel - a Practical Guide"        *
    *                  http://www.FreeRTOS.org/Documentation                  *
    *                                                                         *
    * A pdf reference manual is also available.  Both are usually delivered   *
    * to your inbox within 20 minutes to two hours when purchased between 8am *
    * and 8pm GMT (although please allow up to 24 hours in case of            *
    * exceptional circumstances).  Thank you for your support!                *
    *                                                                         *
    ***************************************************************************

    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation AND MODIFIED BY the FreeRTOS exception.
    ***NOTE*** The exception to the GPL is included to allow you to distribute
    a combined work that includes FreeRTOS without being obliged to provide the
    source code for proprietary components outside of the FreeRTOS kernel.
    FreeRTOS is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details. You should have received a copy of the GNU General Public
    License and the FreeRTOS license exception along with FreeRTOS; if not it
    can be viewed here: http://www.freertos.org/a00114.html and also obtained
    by writing to Richard Barry, contact details for whom are available on the
    FreeRTOS WEB site.

    1 tab == 4 spaces!

    http://www.FreeRTOS.org - Documentation, latest information, license and
    contact details.

    http://www.SafeRTOS.com - A version that is certified for use in safety
    critical systems.

    http://www.OpenRTOS.com - Commercial support, development, porting,
    licensing and training services.
*/

/* Standard includes. */
#include <string.h>

/* Library includes. */
#include "91x_lib.h"
#include "91x_enet.h"

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

#include "uIP_Task.h"

/* uip includes. */
#include "uip.h"
#include "uip_arp.h"
#include "httpd.h"
//#LP#FREERTOS#MARK
#include "telnetd.h"
#include "ftpd.h"
#include "uip_app_registration.h"

#include "timer.h"
#include "clock-arch.h"
#include "http-diag.h"

#ifdef __cplusplus
extern "C" {
#endif
#include "chillerclient.h"
#ifdef __cplusplus
}
#endif
/*-----------------------------------------------------------*/

/* MAC address configuration. */
#define uipMAC_ADDR0	0x00
#define uipMAC_ADDR1	0x50
#define uipMAC_ADDR2	0x72
#define uipMAC_ADDR3	0xD9
#define uipMAC_ADDR4	0x7F
#define uipMAC_ADDR5	0xFE

/* Gateway address configuration. */
#define uipGATEWAY_ADDR0 127
#define uipGATEWAY_ADDR1 25
#define uipGATEWAY_ADDR2 218
#define uipGATEWAY_ADDR3 1

/* Shortcut to the header within the Rx buffer. */
#define xHeader ((struct uip_eth_hdr *) &uip_buf[ 0 ])

/* uIP update frequencies. */
#define uipMAX_BLOCK_TIME	(configTICK_RATE_HZ / 4)//2

/* Interrupt status bit definition. */
#define uipDMI_RX_CURRENT_DONE 0x8000

/* If no buffers are available, then wait this long before looking again. */
#define uipBUFFER_WAIT_DELAY	( 10 / portTICK_RATE_MS )
#define uipBUFFER_WAIT_ATTEMPTS	( 10 )

/* Standard constant. */
#define uipTOTAL_FRAME_HEADER_SIZE	54

//-----------------------------------------------------------

/*
//Send the uIP buffer to the MAC.
static void prvENET_Send(void);

//Setup the MAC address in the MAC itself, and in the uIP stack.
static void prvSetMACAddress( void );

//Used to return a pointer to the next buffer to be used.
extern unsigned char *pcGetNextBuffer( void );

//Port functions required by the uIP stack.
void clock_init( void );
clock_time_t clock_time( void );
*/

extern char cMacConfigDone;
extern u8 Ok226_pending;
extern u8 dir_pending;
extern u8 response_pending;
extern u8 data_pending;

extern struct uip_conn uip_conns[UIP_CONNS];
struct uip_conn *cf;
extern struct ftpd_state *ftps_con_port;
extern struct ftpd_state *ftps_data_port;

int ipAddr[4], ipMask[4];
int chiller_ipaddr[4],chiller_ipmask[4] ;
char net_adresses_saved = 0;

extern  unsigned char client_chiller_active;
typedef void  ChillerClientNotify(struct CHILLER_INFO *info);
void ChillerClientNotifyOnDataReceived(struct CHILLER_INFO *info);

 ChillerClientNotify *pCallback = ChillerClientNotifyOnDataReceived;



//-----------------------------------------------------------
//The semaphore used by the ISR to wake the uIP task.
xSemaphoreHandle xSemaphore = NULL;
//-----------------------------------------------------------

void clock_init(void)
{
	/* This is done when the scheduler starts. */
}
/*-----------------------------------------------------------*/

clock_time_t clock_time( void )
{
	return xTaskGetTickCount();
}
/*-----------------------------------------------------------*/

u32 macHW, macLW;

__ramfunc void get_mac_from_otp_ram(void)
{
   struct uip_eth_addr xAddr;

     *(vu16 *)(FMI_BANK_1) = 0x98;

     macHW = (*(vu32*)(FMI_BANK_1 + FMI_OTP_WORD_4));
     macLW = (*(vu32*)(FMI_BANK_1 + FMI_OTP_WORD_5));

     xAddr.addr[ 0 ] =  (macLW >>  8) & 0xFF;
     if(xAddr.addr[ 0 ]  == 0xFF )
     {
        macHW = (*(vu32*)(FMI_BANK_1 + FMI_OTP_WORD_6));
        macLW = (*(vu32*)(FMI_BANK_1 + FMI_OTP_WORD_7));
     }
     *(vu16 *)(FMI_BANK_1) = 0xFF;

 }
void get_mac_from_otp(void)
{
    u8 addr;

     macHW = FMI_ReadOTPData( FMI_OTP_WORD_4 );
     macLW = FMI_ReadOTPData( FMI_OTP_WORD_5 );
     addr =  (macHW >>  0) & 0xFF;

     if(addr  != 0x00 )
     {
        macHW  = FMI_ReadOTPData( FMI_OTP_WORD_6 );
        macLW  = FMI_ReadOTPData( FMI_OTP_WORD_7 );
     }

}



void vuIP_Task(void *pvParameters)
{
      portBASE_TYPE i;
      uip_ipaddr_t xIPAddr;
      struct timer periodic_timer, arp_timer;
      struct ftpd_state *ftps; 

	/* Create the semaphore used by the ISR to wake this task. */
	vSemaphoreCreateBinary( xSemaphore );

	/* Initialise the uIP stack. */
	timer_set( &periodic_timer, configTICK_RATE_HZ / 8 /*2*/ );
	timer_set( &arp_timer, configTICK_RATE_HZ * 10 );
	uip_init();
        //BOOM
        get_mac_from_otp();
        //u32 macLW = FMI_ReadOTPData( FMI_OTP_WORD_7 );

//	uip_ipaddr( xIPAddr, uipIP_ADDR0, uipIP_ADDR1, uipIP_ADDR2, (uipIP_ADDR3 & 0xF0) +  ((macLW >> 8) & 0x0F));
	uip_ipaddr( xIPAddr, ipAddr[0], ipAddr[1], ipAddr[2], ipAddr[3]);
	uip_sethostaddr( xIPAddr );
//	uip_ipaddr( xIPAddr, uipNET_MASK0, uipNET_MASK1, uipNET_MASK2, uipNET_MASK3 );
	uip_ipaddr( xIPAddr, ipMask[0], ipMask[1], ipMask[2], ipMask[3] );
	uip_setnetmask( xIPAddr );
	uip_ipaddr( xIPAddr, uipGATEWAY_ADDR0, uipGATEWAY_ADDR1, uipGATEWAY_ADDR2, uipGATEWAY_ADDR3 );
	uip_setdraddr( xIPAddr );

    httpd_init(); //#LP#FREERTOS#
    telnetd_init(); //#LP#FREERTOS#
    ftpd_init();
    ftpd_init_data();
    http_diag_init();
    
     
	
    //MUST be done before registering and initializing uIP applications such as HTTPd and so forth.
    // This initializes the uIP Application List to a known, default state. (EMPTY            
	uip_app_list_init();



        //uip_app_register(httpd_appcall, REG_TCP, HTONS(80), REG_ACTIVE); //HTTP-Server
	uip_app_register(httpd_appcall, REG_TCP, HTONS(80), REG_PASSIVE); //HTTP-Server
	uip_app_register(telnetd_app, REG_TCP, HTONS(23), REG_PASSIVE); //Telnet-Server
	uip_app_register(ftpd_appcall, REG_TCP, HTONS(21), REG_PASSIVE);//FTP-Server-Befehlskanal
	uip_app_register(ftpd_appcall_data, REG_TCP, HTONS(20), REG_PASSIVE);//FTP-Server-Datenkanal
	uip_app_register(http_diag_app, REG_TCP, HTONS(2000), REG_PASSIVE);//Diagnose-Server-Datenkanal
      
     if (client_chiller_active > 0 )
     {
        chillerclient_init(&chiller_ipaddr[0],0,pCallback);
        uip_app_register(chillerclient_appcall, REG_TCP, HTONS(8101), REG_ACTIVE);
     }


	/* Initialise the MAC. */
	ENET_InitClocksGPIO();
	ENET_Init();
	portENTER_CRITICAL();
	{
		ENET_Start();
                prvSetMACAddress();

		VIC_Config( ENET_ITLine, VIC_IRQ, 1 );
		VIC_ITCmd( ENET_ITLine, ENABLE );
		ENET_DMA->ISR = uipDMI_RX_CURRENT_DONE;
 		ENET_DMA->IER = uipDMI_RX_CURRENT_DONE;
	}
	portEXIT_CRITICAL();

        
	while(1)
	{
		/* Is there received data ready to be processed? */
		uip_len = ENET_HandleRxPkt( uip_buf );

		// After the IP-Adress and Mask has been changed by the user, we try to consider the new one during runtime
		if (net_adresses_saved)
		{
			uip_ipaddr( xIPAddr, ipAddr[0], ipAddr[1], ipAddr[2], ipAddr[3]);
			uip_sethostaddr( xIPAddr );
			uip_ipaddr( xIPAddr, ipMask[0], ipMask[1], ipMask[2], ipMask[3] );
			uip_setnetmask( xIPAddr );
			net_adresses_saved = 0;
		}
		
		if( uip_len > 0 )
		{
			/* Standard uIP loop taken from the uIP manual. */
			if( xHeader->type == htons( UIP_ETHTYPE_IP ) )
			{
				uip_arp_ipin();
				uip_input();

				/* If the above function invocation resulted in data that
				should be sent out on the network, the global variable
				uip_len is set to a value > 0. */
				if( uip_len > 0 )
				{
					uip_arp_out();
					prvENET_Send();
				}
			}
			else if( xHeader->type == htons( UIP_ETHTYPE_ARP ) )
			{
				uip_arp_arpin();

				/* If the above function invocation resulted in data that
				should be sent out on the network, the global variable
				uip_len is set to a value > 0. */
				if( uip_len > 0 )
				{
					prvENET_Send();
				}
			}
		}
		else
		{
  
                         
                  for( i = 0; i < UIP_CONNS; i++)
                  {
                      cf= &uip_conns[i];
                       
                       if(cf->lport == htons(21))  
                       {
                              if(cf->appstate.response_pending == 1 )
                              {
                                    cf->appstate.response_pending = 0;
                                    uip_poll_conn(&uip_conns[i]);
                                    if( uip_len > 0 )
                                    {
                                           uip_arp_out();
                                          prvENET_Send();
                                    }
                              }
                          
                      }
                  }
                  
                  for( i = 0; i < UIP_CONNS; i++)
                  {
                        cf= &uip_conns[i];
                  
                        if( (cf->lport == htons(20))&&(cf->appstate.data_pending == 1) )
                        {
                              cf->appstate.data_pending = 0;
                              uip_poll_conn(&uip_conns[i]);
                              if( uip_len > 0 )
                              {
                                    uip_arp_out();
                                    prvENET_Send();
                              }
                         }                      
                  
                  }
 // ==== END POLLING ON FTP PORTS 20 and 21 ===============      
                  if( timer_expired( &periodic_timer ) )
                  {
                          timer_reset( &periodic_timer );
                          for( i = 0; i < UIP_CONNS; i++ )
                          {
                                  uip_periodic( i );
      
                                  /* If the above function invocation resulted in data that
                                  should be sent out on the network, the global variable
                                  uip_len is set to a value > 0. */
                                  if( uip_len > 0 )
                                  {
                                          uip_arp_out();
                                          prvENET_Send();
      
                                  }
                          }
      
                          /* Call the ARP timer function every 10 seconds. */
                          if( timer_expired( &arp_timer ) )
                          {
                                  timer_reset( &arp_timer );
                                  uip_arp_timer();
                          }
                  }
                  else
                  {
                          /* We did not receive a packet, and there was no periodic
                          processing to perform.  Block for a fixed period.  If a packet
                          is received during this period we will be woken by the ISR
                          giving us the Semaphore. */
                            xSemaphoreTake( xSemaphore, configTICK_RATE_HZ /2 );
                  }
              }
 	}
}
/*-----------------------------------------------------------*/

static void prvENET_Send(void)
{
portBASE_TYPE i;
static unsigned char *pcTxData;

	/* Get a DMA buffer into which we can write the data to send. */
	for( i = 0; i < uipBUFFER_WAIT_ATTEMPTS; i++ )
	{
		pcTxData = pcGetNextBuffer();

		if( pcTxData )
		{
			break;
		}
		else
		{
			vTaskDelay( uipBUFFER_WAIT_DELAY );
		}
	}

	if( pcTxData )
	{
		/* Copy the header into the Tx buffer. */
		memcpy( ( void * ) pcTxData, ( void * ) uip_buf, uipTOTAL_FRAME_HEADER_SIZE );
		if( uip_len > uipTOTAL_FRAME_HEADER_SIZE )
		{
			memcpy( ( void * ) &( pcTxData[ uipTOTAL_FRAME_HEADER_SIZE ] ), ( void * ) uip_appdata, ( uip_len - uipTOTAL_FRAME_HEADER_SIZE ) );
		}

		ENET_TxPkt( &pcTxData, uip_len );
	}
}
/*-----------------------------------------------------------*/

void ENET_IRQHandler(void)
{
    portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;

	/* Give the semaphore in case the uIP task needs waking. */
	xSemaphoreGiveFromISR( xSemaphore, &xHigherPriorityTaskWoken );

	/* Clear the interrupt. */
	ENET_DMA->ISR = uipDMI_RX_CURRENT_DONE;

	/* Switch tasks if necessary. */
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}
/*-----------------------------------------------------------*/

static void prvSetMACAddress( void )
{
    struct uip_eth_addr xAddr;

    /* Configure the MAC address in the uIP stack. */
    xAddr.addr[ 0 ] = (macHW >>  0) & 0xFF;
    xAddr.addr[ 1 ] = (macHW >>  8) & 0xFF;
    xAddr.addr[ 2 ] = (macHW >> 16) & 0xFF;
    xAddr.addr[ 3 ] = (macHW >> 24) & 0xFF;
    xAddr.addr[ 4 ] = (macLW >>  0) & 0xFF;
    xAddr.addr[ 5 ] = (macLW >>  8) & 0xFF;
    uip_setethaddr( xAddr );

    /*Write the MAC address to the MAC. */
     ENET_MAC->MAL = ( xAddr.addr[3] << 24 ) | ( xAddr.addr[2] << 16 ) | ( xAddr.addr[1] << 8 ) | ( xAddr.addr[0] );
     ENET_MAC->MAH = ( xAddr.addr[5] << 8 ) | ( xAddr.addr[4] );

     cMacConfigDone = -1;
}

/*
 * Read IP-Address from a file
 */
char readIPAddress( void ) {
	return 0;
}

