
#ifndef __UIP_TASK_H
#define __UIP_TASK_H

/* Library includes. */
#include "91x_lib.h"
#include "timer.h"
#include "clock-arch.h"

/*
 * Read IP-Address from a file
 */
char readIPAddress ( void );

/*
 * Send the uIP buffer to the MAC.
 */
static void prvENET_Send(void);

/*
 * Setup the MAC address in the MAC itself, and in the uIP stack.
 */
static void prvSetMACAddress( void );

/*
 * Used to return a pointer to the next buffer to be used.
 */
extern unsigned char *pcGetNextBuffer( void );

/*
 * Port functions required by the uIP stack.
 */
void clock_init( void );
clock_time_t clock_time( void );

void vuIP_Task(void *pvParameters);

static void prvENET_Send(void);

void ENET_IRQHandler(void);

#endif


// static void prvSetMACAddress( void );