
//#include "ff.h" //FSFAT File System
#include "FS.h" //PowerPac File System
#include "FSFormattingtask.h"
#include "stdlib.h"
//extern FATFS fatfs;
#include "FreeRTOS.h"
#include "task.h"

//extern FRESULT g_my_formatting_status;
//extern FRESULT g_my_formatting_status;
extern int g_my_formatting_flag;

// Innerhalb dieser Task wird die Formattierung vogenommen.
// Sie kann ueber Telnet gestartet werden.
/*
void FSFormat_Task(void *pvParameters)
{
  while(1)
  {
    if (g_my_formatting_flag == 2) //Formatierung initiiert;
    {
      g_my_formatting_flag = -1; //Formatierung in arbeit
      g_my_formatting_status = f_mkfs(0, 0, 51200);
      //g_my_formatting_status = f_mkfs(0, 0, 512);
      g_my_formatting_flag = 1; //Formattierung beendet
    }
  }
}
*/
void FSFormat_Task(void *pvParameters)
{
  while(1)
  {
    if (g_my_formatting_flag == 2) //Formatierung initiiert;
    {
      g_my_formatting_flag = -1; //Formatierung in arbeit
      //Formattieren mit PowerPac File System:
      //FS_Init();
      //FS_X_AddDevices();
      FS_FormatLow("ERS_DSK_1");
      FS_Format("ERS_DSK_1", NULL);
      g_my_formatting_flag = 1; //Formattierung beendet
    }
    vTaskDelay( 10 );
  }
}