/*-----------------------------------------------------------------------*/
/* Glue functions for FatFs - MCI/NAND drivers            (C)ChaN, 2010  */
/*-----------------------------------------------------------------------*/

#include "diskio.h"
#include "c2635.h"
#include "stdint.h"
#include "FS_NOR_PHY_M29W128G.h"
#include "ff.h"


//------------------------------------------------------------------------------
//Folgende Funktionen finden sich in der Datei "FS_NOR_PHY_M29W128G.c":

// Reads data from the given offset of the flash:
// Return value: 0 -> O.K., data has been read from flash, other -> error
extern int _ReadOff(char Unit, void * pDest, unsigned int Off, unsigned int NumBytes);

// This routine writes data into any section of the flash.
// It does not check if this section has been previously erased!!!
// Return value: 0 -> O.K., data has been written from flash, other -> error
extern int _WriteOff(char Unit, unsigned int Off, const void * pSrc, unsigned int NumBytes);

// Erases one sector.
// Return value: 0 -> O.K., sector is ereased. other -> error, sector may not be erased
extern int _EraseSector(char Unit, unsigned int SectorIndex);

//Returns the offset and length of the given sector
extern void _GetSectorInfo(char Unit, unsigned int SectorIndex, unsigned int * pOff, unsigned int * pLen);

//Returns the number of flash sectors
extern int _GetNumSectors(char Unit);

//Configures a single instance of the driver
extern void _Configure(char Unit, unsigned int BaseAddr, unsigned int StartAddr, unsigned int NumBytes);

// Called right after selection of the physical layer
// This may be neccessary to retrieve the information from flash.
// #LP# Ok, ich vermute mal diese Funktion wird nur intern verwendet.
extern void _OnSelectPhy(char Unit);

ParameterType fp; //Union mit den Parametern fuer die durchzufuehrenden Befehle.

//------------------------------------------------------------------------------

//#define MY_BLOCK_SIZE 0x010000 //Blockgroesse aus c2635.h entnommen
#define MY_NUMBER_OF_SECTORS 128 //Anzahl Sektoren.

DSTATUS disk_initialize (
	BYTE drv
)
{
  _Configure( drv, (unsigned int)FLASH0_BASE_ADDR, (unsigned int)FLASH0_START_ADDR, (unsigned int)FLASH0_SIZE);
  FlashReset(); //#LP# Hmmm...  ?
  return 0;
}



DSTATUS disk_status (
	BYTE drv
)
{
  return 0;
}

DRESULT disk_read (
	BYTE drv,	    /* Physical drive number (0) */
	BYTE *buff,	    /* Pointer to the data buffer to store read data */
	DWORD SectorNumber, /* Start sector number (LBA) */
	BYTE SectorCount    /* Sector count (1..255) */
)
{
  DRESULT status=RES_ERROR;
  
  uint16_t Transfer_Length;
  uint32_t Memory_Offset;
 Transfer_Length =  SectorCount * 512;
 Memory_Offset = SectorNumber * 512;
  
 //   Transfer_Length =  SectorCount * MY_BLOCK_SIZE;
//  Memory_Offset = SectorNumber * MY_BLOCK_SIZE;
  
 if(!_WriteOff(drv, Memory_Offset, buff, Transfer_Length))
 {
   status = RES_OK;
 }
 else
 {
   status = RES_ERROR;
 }
 return status;
}



DRESULT disk_write (
	BYTE drv,
	const BYTE* buff,
	DWORD SectorNumber,
	BYTE SectorCount
)
{
  DRESULT status=RES_ERROR;
  uint16_t Transfer_Length;
  uint32_t Memory_Offset;
  Transfer_Length =  SectorCount * 512;
  Memory_Offset = SectorNumber * 512;
  
 if(!_ReadOff(drv, buff, Memory_Offset, Transfer_Length))
 {
   status = RES_OK;
 }
 else
 {
   status = RES_ERROR;
 }
 return status;
}


/*----------------------------------------------*/
/* Force blanked logical blocks                 */

static
DRESULT blank_log_blocks (
	DWORD *region		/* Block of logical sectors to be blanked {start, end} */
)						/* If start sector is not top of a logical block, the block is left not blanked. */
{						/* If end sector is not end of a logical block, the block is left not blanked. */
	WORD stlb, edlb, pb;


	if (region[1] >= 16384 || region[0] > region[1]) return RES_PARERR; //##done
	stlb = (WORD)((region[0] + 128 - 1) / 128);	/* Start LB */
	edlb = (WORD)((region[1] + 1) / 128);				/* End LB + 1 */

	for (pb = 0; pb < 128; pb++) {
		if (pb >= stlb && pb < edlb)
                {
		fp.BlockErase.ublBlockNr = (uBlockType)pb;
                Flash(BlockErase, &fp);
		}
	}

	return RES_OK;
}


DRESULT disk_ioctl (
	BYTE drv,
	BYTE cmd,
	void* buff
)
{
  DRESULT status=RES_ERROR;
	switch (cmd) {
	case CTRL_SYNC:
          
          status=RES_OK;
          break;
		/*
	case GET_SECTOR_SIZE:
          buff = (WORD*)MY_BLOCK_SIZE;
          status=RES_OK;
          break;
          */
	case GET_SECTOR_SIZE:	/* Get sector size = 512 */
		*(WORD*)buff = 512; //a sector gets 512 byte from me
		return RES_OK;
          
        case GET_SECTOR_COUNT: //Number of ALL Sectors on a drive
          //128*128 = 16384 (128 Blocks, mit jeweils 128 Sektoren)
          //buff = (DWORD*)_GetNumSectors(drv);
//          buff = (DWORD*)16384;
          *(DWORD*)buff = 16384;
          status=RES_OK;
          break;

          //  Return 1 if the erase block size is unknown:
          
	case GET_BLOCK_SIZE: //In unit of sector!!! (128 Sectors in a Block)
//          buff = (WORD*)128;
          *(DWORD*)buff = 128;
          status=RES_OK;
          break;
          
	case CTRL_ERASE_SECTOR:
          
          //Keine Ahnung ob ich unprotecten vorher machen muss,
          //ich mache das einfach mal :) :
          //Flash(ChipUnprotect, &fp);
          //char cbuff[32];
          //short * array = (short*) &buff; // my failed attempt
          
         // for (int i=0; i < NUM_BLOCKS+1; i++)// unprotecten der Sektoren:
         //   {           
         //   fp.BlockErase.ublBlockNr = (uBlockType)i;
         //   Flash(BlockErase, &fp);
         //   }
          
          status = blank_log_blocks(buff);
         // status=RES_ERROR;
          break; 
          
        default:
          status=RES_ERROR;
          break;
		
	}
        return status;
}



//*************************************************************************

