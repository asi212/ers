/*********************************************************************
*
*   IAR PowerPac - File system
*
*   (c) Copyright IAR Systems 2008.  All rights reserved.
*
**********************************************************************
----------------------------------------------------------------------
----------------------------------------------------------------------
File        : ConfigNOR_CFI_1x16.c
Purpose     : Configuration file for FS with 1 * 16bit CFI compliant NOR flash
---------------------------END-OF-HEADER------------------------------
*/


#include <stdio.h>
#include <cstring>
#include "FS.h"
extern const FS_NOR_PHY_TYPE FS_NOR_PHY_M29DW128F;
extern const FS_NOR_PHY_TYPE FS_NOR_PHY_M29W128G;
/*********************************************************************
*
*       Defines, configurable
*
*       This section is the only section which requires changes for typical embedded systems
*       using the NOR flash driver with a single device.
*
**********************************************************************
*/
//#LP# Hab Ram kleiner gemacht
//#define ALLOC_SIZE 1632 //#LP# Aus FS_NumBytesAllocated nach der Initialisierung abgelesen
#define ALLOC_SIZE         	 0x00010000      // Size of memory dedicated to the file system. This value should be fine tuned according for your system.
//#define FLASH0_BASE_ADDR   0x38000000     // Base addr of the NOR flash device to be used as storage
//#define FLASH0_START_ADDR  0x38000000     // Start addr of the first sector be used as storage. If the entire chip is used for file system, it is identical to the base addr.
//#define FLASH0_SIZE        0x1000000       // Number of bytes to be used for storage


/*********************************************************************
*
*       Static data.
*
*       This section does not require modifications in most systems.
*
**********************************************************************
*/
//__no_init static U32   _aMemBlock[ALLOC_SIZE / 4] @ "EXRAM";    // Memory pool used for semi-dynamic allocation.
static U32   _aMemBlock[ALLOC_SIZE / 4] @ "EXRAM";    // Memory pool used for semi-dynamic allocation.

/*********************************************************************
*
*       Public code
*
*       This section does not require modifications in most systems.
*
**********************************************************************
*/

/*********************************************************************
*
*       FS_X_AddDevices
*
*  Function description
*    This function is called by the FS during FS_Init().
*    It is supposed to add all devices, using primarily FS_AddDevice().
*
*  Note
*    (1) Other API functions
*        Other API functions may NOT be called, since this function is called
*        during initialisation. The devices are not yet ready at this point.
*/
void FS_X_AddDevices(void) 
{
	U8 Unit = 0;
	
	//memset(&_aMemBlock[0], 0, sizeof(_aMemBlock));
  FS_AssignMemory(&_aMemBlock[0], sizeof(_aMemBlock));
  //
  //  Add driver
  //
  FS_AddDevice(&FS_NOR_Driver);
	
	//Unit = FS_AddPhysDevice(&FS_NOR_Driver);
	
		
  //
  //  Confgure the NOR flash interface
  //
#ifdef M29DW128F
  FS_NOR_SetPhyType(Unit, &FS_NOR_PHY_M29DW128F); //#LP#
#else
  FS_NOR_SetPhyType(Unit, &FS_NOR_PHY_M29W128G); //#LP#
#endif
  FS_NOR_Configure(Unit, 0x38000000, 0x38000000, 0x0400000 );
	//FS_NOR_ConfigureReserve(Unit, 50);
  
	//FS_LOGVOL_Create("FLASH");
	//FS_LOGVOL_AddDevice("FLASH", &FS_NOR_Driver, Unit, 0, 32);

}

/*********************************************************************
*
*       FS_X_GetTimeDate
*
*  Description:
*    Current time and date in a format suitable for the file system.
*
*    Bit 0-4:   2-second count (0-29)
*    Bit 5-10:  Minutes (0-59)
*    Bit 11-15: Hours (0-23)
*    Bit 16-20: Day of month (1-31)
*    Bit 21-24: Month of year (1-12)
*    Bit 25-31: Count of years from 1980 (0-127)
*
*/
U32 FS_X_GetTimeDate(void) {
  U32 r;
  U16 Sec, Min, Hour;
  U16 Day, Month, Year;

  Sec   = 0;        // 0 based.  Valid range: 0..59
  Min   = 0;        // 0 based.  Valid range: 0..59
  Hour  = 0;        // 0 based.  Valid range: 0..23
  Day   = 1;        // 1 based.    Means that 1 is 1. Valid range is 1..31 (depending on month)
  Month = 1;        // 1 based.    Means that January is 1. Valid range is 1..12.
  Year  = 0;        // 1980 based. Means that 2007 would be 27.
  r   = Sec / 2 + (Min << 5) + (Hour  << 11);
  r  |= (U32)(Day + (Month << 5) + (Year  << 9)) << 16;
  return r;
}

/*************************** End of file ****************************/


void FS_X_Log(const char *s) {
//  printf("%s", s);
}

void FS_X_Warn(const char *s) {
  FS_X_Log(s);
}

void FS_X_ErrorOut(const char *s) {
  FS_X_Log( s);
}

