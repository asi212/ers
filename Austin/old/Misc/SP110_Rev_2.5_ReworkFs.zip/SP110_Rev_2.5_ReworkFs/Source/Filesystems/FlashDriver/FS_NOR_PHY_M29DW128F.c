/*********************************************************************
*
*   IAR PowerPac - File system
*
*   (c) Copyright IAR Systems 2008.  All rights reserved.
*
**********************************************************************
----------------------------------------------------------------------
----------------------------------------------------------------------
File        : NOR_PHY_Template.c
Purpose     : Low level flash driver template
----------------------------------------------------------------------
------------  END-OF-HEADER  -----------------------------------------
*/

#include "FS_Int.h"
#include "c2313.h"

volatile ReturnType protStatus;
/*********************************************************************
*
*      Defines
*
**********************************************************************
*/

/*********************************************************************
*
*       Configurable defines
*
**********************************************************************
*/

#define NUM_SECTORS      128

/*********************************************************************
*
*       Fixed defines
*
**********************************************************************
*/


/*********************************************************************
*
*      Types
*
**********************************************************************
*/


/*********************************************************************
*
*      Static data
*
**********************************************************************
*/

/*********************************************************************
*
*      Static code
*
**********************************************************************
*/



/*********************************************************************
*
*      Exported code thru call backs
*
**********************************************************************
*/

/*********************************************************************
*
*      _WriteOff
*
* Function description
*   This routine writes data into any section of the flash. It does not
*   check if this section has been previously erased; this is in the
*   responsibility of the user program.
*   Data written into multiple sectors at a time can be handled by this
*   routine.
*
* Return value:
*   0       O.K., data has been written
*   other   error
*/
static int _WriteOff(U8 Unit, U32 Off, const void * pSrc, U32 NumBytes) {
  if( FlashProgram( 0, Off / 2, NumBytes / 2, (void*)pSrc ) != Flash_Success){
    return 1;
  }
  else{
    return 0;
  }
}

/*********************************************************************
*
*       _ReadOff
*
* Function description
*   Reads data from the given offset of the flash.
*
* Return value:
*   0       O.K., data has been read from flash
*   other   error
*/
static int _ReadOff(U8 Unit, void * pDest, U32 Off, U32 NumBytes) {
  //
  //  Implement here the read of the flash
  //
  unsigned char * pFlash = (unsigned char*)BASE_ADDR;
  int i;
  for( i = 0; i < NumBytes; i++ ){
    ((unsigned char*)pDest)[i] = *(pFlash + Off + i);
  }
  return 0;
}

/*********************************************************************
*
*      _EraseSector
*
* Function description
*   Erases one sector.
*
*
* Return value:
*   0       O.K., sector is ereased
*   other   error, sector may not be erased
*
*/
static int _EraseSector(U8 Unit, unsigned int SectorIndex) {
  //
  //  Implement here the erase of a sector
  //
  if( FlashBlockErase( SectorIndex ) == Flash_Success ){
    return 0;
  }
  else{
    return 1;
  }
}

/*********************************************************************
*
*       _GetSectorInfo
*
* Function description
*   Returns the offset and length of the given sector
*/
static void _GetSectorInfo(U8 Unit, unsigned int SectorIndex, U32 * pOff, U32 * pLen) {
  if (pOff) {
    *pOff = BlockOffset[SectorIndex] * 2;
  }
  if (pLen) {
    *pLen = (BlockOffset[SectorIndex+1] - BlockOffset[SectorIndex]) * 2;
  }

}

/*********************************************************************
*
*       _GetNumSectors
*
* Function description
*   Returns the number of flash sectors
*/
int _GetNumSectors( char Unit) {
  return NUM_SECTORS;
}

/*********************************************************************
*
*       _Configure
*
*  Function description
*    Configures a single instance of the driver
*/
static void _Configure(U8 Unit, U32 BaseAddr, U32 StartAddr, U32 NumBytes) {
  int i = 0;
  for( i = 0; i < 128; i++ ){
    //FlashClearBlockVPB( i );
  }
  //FlashClearBlockNVPB( );
  //protStatus = FlashCheckProtectionMode();
}

/*********************************************************************
*
*       _OnSelectPhy
*
*  Function description
*    Called right after selection of the physical layer
*    This may be neccessary to retrieve the information from flash.
*/
static void _OnSelectPhy(U8 Unit) {
  FlashCheckCompatibility();
}


/*********************************************************************
*
*      Public code
*
**********************************************************************
*/
/*********************************************************************
*
*       Global data
*
**********************************************************************
*/
// NOR flash physical driver structure
const FS_NOR_PHY_TYPE FS_NOR_PHY_M29DW128F = {
  _WriteOff,
  _ReadOff,
  _EraseSector,
  _GetSectorInfo,
  _GetNumSectors,
  _Configure,
  _OnSelectPhy
};


/*************************** End of file ****************************/
