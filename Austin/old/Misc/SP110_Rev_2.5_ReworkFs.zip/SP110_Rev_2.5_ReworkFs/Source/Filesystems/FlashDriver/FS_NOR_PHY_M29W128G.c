/*********************************************************************
*
*   IAR PowerPac - File system
*
*   (c) Copyright IAR Systems 2008.  All rights reserved.
*
**********************************************************************
----------------------------------------------------------------------
----------------------------------------------------------------------
File        : NOR_PHY_Template.c
Purpose     : Low level flash driver template
----------------------------------------------------------------------
------------  END-OF-HEADER  -----------------------------------------
*/

#include "FS_Int.h"
#include "FS_NOR_PHY_M29W128G.h"
#include "c2635.h"


volatile ReturnType protStatus;
/*********************************************************************
*
*      Defines
*
**********************************************************************
*/

/*********************************************************************
*
*       Configurable defines
*
**********************************************************************
*/

//#define NUM_SECTORS      64

int gNumSectors = 64; //NUM_SECTORS;


/*********************************************************************
*
*       Fixed defines
*
**********************************************************************
*/


/*********************************************************************
*
*      Types
*
**********************************************************************
*/


/*********************************************************************
*
*      Static data
*
**********************************************************************
*/

/*********************************************************************
*
*      Static code
*
**********************************************************************
*/



/*********************************************************************
*
*      Exported code thru call backs
*
**********************************************************************
*/

/*********************************************************************
*
*      _WriteOff
*
* Function description
*   This routine writes data into any section of the flash. It does not
*   check if this section has been previously erased; this is in the
*   responsibility of the user program.
*   Data written into multiple sectors at a time can be handled by this
*   routine.
*
* Return value:
*   0       O.K., data has been written
*   other   error
*/
int _WriteOff(char Unit, unsigned int Off, const void * pSrc, unsigned int NumBytes) {
  if( FlashProgram( 0, Off / 2, NumBytes / 2, (void*)pSrc ) != Flash_Success){
    return 1;
  }
  else{
    return 0;
  }
}

/*********************************************************************
*
*       _ReadOff
*
* Function description
*   Reads data from the given offset of the flash.
*
* Return value:
*   0       O.K., data has been read from flash
*   other   error
*/
int _ReadOff(char Unit, void * pDest, unsigned int Off, unsigned int NumBytes) {
  //
  //  Implement here the read of the flash
  //
  unsigned char * pFlash = (unsigned char*)BASE_ADDR;
  int i;
  for( i = 0; i < NumBytes; i++ ){
    ((unsigned char*)pDest)[i] = *(pFlash + Off + i);
  }
  return 0;
}

/*********************************************************************
*
*      _EraseSector
*
* Function description
*   Erases one sector.
*
*
* Return value:
*   0       O.K., sector is ereased
*   other   error, sector may not be erased
*
*/
int _EraseSector(char Unit, unsigned int SectorIndex) {
  //
  //  Implement here the erase of a sector
  //
  
  if( FlashBlockErase( SectorIndex ) == Flash_Success ){
    return 0;
  }
  else{
    return 1;
  }
}

/*********************************************************************
*
*       _GetSectorInfo
*
* Function description
*   Returns the offset and length of the given sector
*/
void _GetSectorInfo(char Unit, unsigned int SectorIndex, unsigned int * pOff, unsigned int * pLen) {
  if (pOff) {
    *pOff = SectorIndex * 0x20000;
  }
  if (pLen) {
    *pLen = 0x20000;
  }

}

/*********************************************************************
*
*       _GetNumSectors
*
* Function description
*   Returns the number of flash sectors
*/
int _GetNumSectors(char Unit) {
  return gNumSectors;
}

/*********************************************************************
*
*       _Configure
*
*  Function description
*    Configures a single instance of the driver
*/
void _Configure(char Unit, unsigned int BaseAddr, unsigned int StartAddr, unsigned int NumBytes) {
  for( int i = 0; i < gNumSectors; i++ ){
    if( FlashCheckBlockNVPB( i ) != Flash_NonVolatile_Unprotected ){
      if( FlashClearBlockNVPB() == Flash_Success ){
        break;
      }
      else{
        i = 0;
      }
    }
  }
}

/*********************************************************************
*
*       _OnSelectPhy
*
*  Function description
*    Called right after selection of the physical layer
*    This may be neccessary to retrieve the information from flash.
*/
void _OnSelectPhy(char Unit) {
  FlashCheckCompatibility();
}


/*********************************************************************
*
*      Public code
*
**********************************************************************
*/
/*********************************************************************
*
*       Global data
*
**********************************************************************
*/

// NOR flash physical driver structure
const FS_NOR_PHY_TYPE FS_NOR_PHY_M29W128G = {
  _WriteOff,
  _ReadOff,
  _EraseSector,
  _GetSectorInfo,
  _GetNumSectors,
  _Configure,
  _OnSelectPhy
};


/*************************** End of file ****************************/
