

#ifndef __FS_NOR_PHY_M29W128G_H__
#define __FS_NOR_PHY_M29W128G_H__

int _WriteOff(char Unit, unsigned int Off, const void * pSrc, unsigned int NumBytes);
int _ReadOff(char Unit, void * pDest, unsigned int Off, unsigned int NumBytes);
int _EraseSector(char Unit, unsigned int SectorIndex);
void _GetSectorInfo(char Unit, unsigned int SectorIndex, unsigned int * pOff, unsigned int * pLen);
int _GetNumSectors(char Unit);
void _Configure(char Unit, unsigned int BaseAddr, unsigned int StartAddr, unsigned int NumBytes);
void _OnSelectPhy(char Unit);

#endif /* __FS_NOR_PHY_M29W128G_H__ */