Software Driver Readme File Of M29DW128F

- Alpha Release Version 0.0 (2006/02/21) 
  c2313.h   V0.0
  c2313.c   V0.0

- Qualified Release Version 1.0 (2006/05/10) 
  c2313.h   V1.0
  c2313.c   V1.0

