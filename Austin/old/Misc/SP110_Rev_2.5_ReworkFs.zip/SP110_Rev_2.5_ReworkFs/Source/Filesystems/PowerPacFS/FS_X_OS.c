/*********************************************************************
*  
*   IAR PowerPac
*
*   (c) Copyright IAR Systems 2007.  All rights reserved.
*
**********************************************************************
----------------------------------------------------------------------
File        : FS_X_OS.c
Purpose     : RTOS Layer for the file system
---------------------------END-OF-HEADER------------------------------
*/

/*********************************************************************
*
*             #include Section
*
**********************************************************************
*/

#include <stdio.h>
#include "FS_Int.h"
#include "FS_OS.h"
//#include "RTOS.h"
//#include "PowerPacFS_FREERTOS_port.h"
#include "FreeRTOS.h"
#include "semphr.h"
#include "task.h"

#include <vector>

#define FS_OS_LOCKING 1 //Es soll ein OS benutzt werden

/*********************************************************************
*       Static data
**********************************************************************
*/
static vector<xSemaphoreHandle> semacont;
/*********************************************************************
*       Public code
**********************************************************************
*/

/*********************************************************************
*       FS_X_OS_Lock
*/
/*
void FS_X_OS_Lock(unsigned LockIndex) {
  OS_RSEMA * pSema;

  pSema = _paSema + LockIndex;
  OS_Use(pSema);
}
*/

/*
 Entnehmen der Semaphore.
 Die 0 bewirkt ein pollen der Semaphore bis diese
 frei wird. Alternativ kann man an dieser Stelle
 eine xBlockTime-Wartezeit angeben.
*/
void FS_X_OS_Lock(unsigned LockIndex)
{
  xSemaphoreTake(semacont[LockIndex],0);
}

/*********************************************************************
*       FS_X_OS_Unlock
*/
/*
void FS_X_OS_Unlock(unsigned LockIndex) {
  OS_RSEMA * pSema;

  pSema = _paSema + LockIndex;
  OS_Unuse(pSema);
}
*/
void FS_X_OS_Unlock(unsigned LockIndex)
{
  xSemaphoreGive(semacont[LockIndex]);
}

/*********************************************************************
*
*       FS_X_OS_Init
*
*  Description:
*    Initializes the OS resources. Specifically, you will need to
*    create four binary semaphores. This function is called by
*    FS_Init(). You should create all resources required by the
*    OS to support multithreading of the file system.
*
*  Parameters:
*    None.
*
*  Return value:
*    0    - on success
*    -1   - on failure.
*/

/*
void FS_X_OS_Init(unsigned NumLocks) {
  unsigned i;
  OS_RSEMA * pSema;

  _paSema = (OS_RSEMA *)FS_AllocZeroed(NumLocks* sizeof(OS_RSEMA));
  pSema =_paSema;
  for (i = 0; i < NumLocks; i++) {
    OS_CREATERSEMA(pSema++);
  }
}
*/
/*
 Erstelle neue Semaphoren und pumpe sie in den Vector,
 kurz darauf werden diese initialisiert.
*/
void FS_X_OS_Init(unsigned NumLocks)
{
  unsigned i;
  semacont.reserve(NumLocks);
  for (i = 0; i < NumLocks; i++)
  {
    semacont.push_back(new xSemaphoreHandle);
    vSemaphoreCreateBinary(semacont[i]);
  }
}



/*********************************************************************
*       FS_X_OS_GetTime
*/
U32  FS_X_OS_GetTime(void) {
  //return OS_GetTime();
  return (U32)xTaskGetTickCount();
}

/*************************** End of file ****************************/












