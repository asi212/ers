/*********************************************************************
*  
*   IAR PowerPac
*
*   (c) Copyright IAR Systems 2010.  All rights reserved.
*
**********************************************************************
----------------------------------------------------------------------
File        : NOR_HW_SPI_X.h
Purpose     : Serial NOR SPI hardware layer
---------------------------END-OF-HEADER------------------------------
*/

#ifndef __NOR_HW_SPI_X_H__
#define __NOR_HW_SPI_X_H__

/*********************************************************************
*
*       Global function prototypes
*
**********************************************************************
*/

/* Control line functions */
void          FS_NOR_SPI_HW_X_EnableCS   (U8 Unit);
void          FS_NOR_SPI_HW_X_DisableCS  (U8 Unit);
int           FS_NOR_SPI_HW_X_Init       (U8 Unit);

/* Data transfer functions */
void          FS_NOR_SPI_HW_X_Read (U8 Unit,       U8 * pData, int NumBytes);
void          FS_NOR_SPI_HW_X_Write(U8 Unit, const U8 * pData, int NumBytes);

#endif  /* __NOR_SPI_X_HW_H__ */

/*************************** End of file ****************************/
