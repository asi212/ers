#include "CEventManager.h"



CEventManager::CEventManager()
{
    pFloat = new _event_service<float> (60);
    pInteger = new _event_service<int> (30); //PM: 03.12.2012:: Increased from  20 because  void AddEventHandler( CEventNames::_event_name e, void (*func)(T)) 
    pBool = new _event_service<bool> (99);   // was hitting the limit of 20 resulting into endless loop (while(true);)! 
    pShort = new _event_service<short> (10);
    pChar = new _event_service<char> (10);
    pLimits = new _event_service<_set_limits_EventArgument> (10);
    pStrings = new _event_service<_string> (30);
    pPointers = new _event_service<void*>(20);
    pInputIntArguments = new _event_service<_input_int_EventArgument>(6);
    pInputFloatArguments = new _event_service<_input_float_EventArgument>(2);
}

void CEventManager::HandlePID()
{
    pFloat->HandlePID();
    pInteger->HandlePID();
    pBool->HandlePID();
    pShort->HandlePID();
    pChar->HandlePID();
    pLimits->HandlePID();
    pStrings->HandlePID();
    pPointers->HandlePID();
    pInputIntArguments->HandlePID();
    pInputFloatArguments->HandlePID();
    //tii handler
    for( int i = 0; i < tii_hsize && tii_handler[i] != 0; i++ )
    {
        if( tii_handler[i]->getPID() == xTaskGetCurrentTaskHandle() )
        {
            if( tii_handler[i]->getEventRaised() )
            {
                tii_handler[i]->callEventHandler();
            }
        }
    }
}


//tii event handler
void CEventManager::RaiseEvent( _event< _two_params<int,int> > e)
{
    for( int i = 0; i < tii_hsize && tii_handler[i] != 0; i++ )
    {
        if( tii_handler[i]->getEventName() == e.getEventName() )
        {
            tii_handler[i]->setEventParameter( e.getEventParameter() );
            tii_handler[i]->raiseEvent();
        }
    }
 
}

void CEventManager::AddEventHandler( CEventNames::_event_name e, void (*func)( _two_params<int,int> ))
{
    _event_handler< _two_params<int,int> > * handler = new _event_handler< _two_params<int,int> >( e, func);
    
    for( int i = 0; i < tii_hsize; i++ )
    {
        if( tii_handler[i] == 0 )
        {
            tii_handler[i] = handler;
            break;
        }
    }
}

void CEventManager::AddEventHandler( CEventNames::_event_name e, void (*func)(void*, _two_params<int,int> ), void* pObject)
{
    _event_handler< _two_params<int,int> > * handler = new _event_handler< _two_params<int,int> >( e, func, pObject);
    
    for( int i = 0; i < tii_hsize; i++ )
    {
        if( tii_handler[i] == 0 )
        {
            tii_handler[i] = handler;
            break;
        }
    }
}