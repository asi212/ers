#ifndef _C_EVENT_HANLDER
#define _C_EVENT_HANLDER


extern "C"{
    #include "FreeRTOS.h"
    #include "task.h"
}
#include <cstdio>
#include <cstring>

#define MAX_ERR_TXT_LEN			16		// Maximal length of error texts
#define MAX_ERR_INFO_LINES	 6    // Maximal number of lines (=errors) displayed in info window

extern int event_count;

template <typename T, typename T1>
class _two_params
{
    public:
        T p1;
        T1 p2;
};

class _set_limits_EventArgument
{
    public:
        float limitMax;
        float limitMin;
};

class _string
{
    public:
        _string(){};
        _string( char * pSource )
        {
            if( strlen( pSource ) >= maxlen )
            {   
                taskENTER_CRITICAL();
                while(1); //Problem, string zu lang
            }
            strcpy( c, pSource);
        };
        
        void operator=(char * pSource)
        {
            if( strlen( pSource ) >= maxlen )
            {   
                taskENTER_CRITICAL();
                while(1); //Problem, string zu lang
            }
            strcpy( c, pSource);
        };

        void operator=(char const * pSource)
        {
            if( strlen( pSource ) >= maxlen )
            {   
                taskENTER_CRITICAL();
                while(1); //Problem, string zu lang
            }
            strcpy( c, pSource);
        };
        
        void operator=(_string p)
        {
            strcpy( c, p.c);
        };
        
        int len(){ return strlen(c);};

        void operator+=(char * pSource)
        {
            int lSource = strlen(pSource);
            int lDest = strlen(c);
            if( lSource + lDest >= maxlen )
            {   
                taskENTER_CRITICAL();
                while(1); //Problem, string zu lang
            }
            strcat( c, pSource);
        };

        void operator+=(_string s)
        {
            int lDest = strlen(c);
            if( s.len() + lDest >= maxlen )
            {   
                taskENTER_CRITICAL();
                while(1); //Problem, string zu lang
            }
            strcat( c, s.c );
        };

        bool operator==( char const * pSource ) const
        {
            if( strcmp( c, pSource) == 0 ){
                return true;
            }
            else
            {
                return false;
            }
        };
        
        bool operator!=( char const * pSource ) const
        {
           if( strcmp( c, pSource) == 0 ){
                return false;
            }
            else
            {
                return true;
            }
        };

        
        char const * getBuffer(){ return c;};
        
    private:
			// Max len from : EXXX ERROR_TEXT# = len( EXXX ERROR_TEXT)+6
        static const int maxlen = (MAX_ERR_TXT_LEN+6)*MAX_ERR_INFO_LINES; // Max length due to display of error msgs.
        char c[maxlen];        
};

/**
Klassen zum abbilden eines Event-Managers. Funtkioniert folgendermasen:
  1. Ein ereigniss kann registriert werden, m�glich Ereignisse m�ssen im enum _event_name definiert sein
  2. Ein Zyklischer aufruf des Managers muss in jeden Task rein
  3. Ist eine EventHandler in dieser Task definiert wird dieser aufgerufen
*/
class CEventNames
{
    public:
        enum _event_name
        {
            //Key Input Events
            but_option_1,             //Optionsbutton 1 gedr�ckt
            but_option_2,             //Optionsbutton 2 gedr�ckt
            set_option_mode,        //Option Button Konfiguration ge�ndert
            config,
            s_temp_1,               //Temeperatur eingabe taste gedr�ckt
            init_int_input,         //Initialisere Integer Input dialog
            keyboard_int_command,   //Eingabe bzw. Befehl vom int- keyboard
            init_float_input,       //Initialisiere Float Input dialog
            keyboard_float_command, //Eingabe bzw. Befehl vom float- keyboard
            user_entered_diag,      //Benutzer trinn in Diagnose ein
            user_left_diag,         //Benutzer hat Diagnose verlassen
            pin_request_1,          //Pin Request Fenster �ffnen
						display_unlocked,				//Pin f�r Display-Unlock wurde eingegeben	
						display_touched,				//An defined display button has been touched
            diag_page_1,            //Diagnose Seite 1 �ffnen
            diag_page_2,            //Diagnose Seite 2 �ffnen
            diag_page_3,            //Diagnose Seite 3 �ffnen
            diag_page_4,            //Diagnose Seite 4 �ffnen
            update_filesys_view,    //Dateisystem auslesen und auf Bildschirm
            diag_page_5,            //Diagnose Seite 5 �ffnen
            diag_page_6,            //Diagnose Seite 6 �ffnen
            user_config_page_1,     //User Config Seite 1 �ffnen
            user_config_page_2,     //User Config Seite 2 �ffnen
            user_config_page_3,     //User Config Seite 3 �ffnen
            user_config_page_4,     //User Config Seite 4 �ffnen
            user_config_page_5,     //User Config Seite 5 �ffnen
            user_config_power_sense,//Power Sense Konfiguration �ffnen
            set_temp1_changed,      //neuer Sollwert f�r Chuck 1
            set_temp2_changed,      //neuer Sollwert f�r Chuck 2
            set_temp3_changed,      //neuer Sollwert f�r Chuck 3
            set_temp4_changed,      //neuer Sollwert f�r Chuck 4
            chuck_temp,             //neuer Istwert f�r Chuck 1
            temp_1_comp,            //neuer kompensierter Istwert
            status_temp_1,          //neuer Status f�r die Temperatur 1 (Pfeilsteuerung)
            chiller_temp,						//neuer Istwert f�r Chiller Temperature
            base_temp,							//neuer Istwert f�r Basisplatten-Temperatur (KTY)
            intern_temp,            //neuer Istwert f�r interne Temperatur (Geh�use)
            forward_to_active_window,   //Gehe zu fenster als string parameter �bergeben
            set_con_mode_standard,      //Standardregelung aktivieren
            set_con_mode_progressive,   //Progressive regeln aktivieren
            set_con_mode_lnoise,        //Low Noise Regelung aktivieren
            controller_status,
            new_controller_mode,
            new_chiller_settemp,        //Neur Sollwert f�r den Chiller
            new_chiller_mode,           //Neur Zustand f�r den Chiller
            new_chiller_ctrl,           //Neur Zustand des Reglers f�r den Chille3r
            key_lock_symbol,      			//Chillerdisplay sperre , 0 = offen, 2 gesperrt, 1 lokal reales noch nicht implementiert
            external_display_state,     //Wird ausgel�st wenn sich der Zustand eines externen Dsiplays �ndert 0 intern, 1 extern
            controller_mode,
            inp_cool_air_value,         //aktiviere Eingabe f�r den Durchfluss am Kaltluft-Ventil
            hit_cool_air_value,         //Durchfluss f�r Kaltluft-Ventil wurde eingegeben
            inp_warm_air_value,         //aktiviere Eingabe f�r den Durchfluss am Warmluft-Ventil
            hit_warm_air_value,         //Durchfluss f�r Warmluft-Ventil wurde eingegeben
						toggle_bypass_valve,				//Toggle-Button f�r Bypass-Ventil (Bypass 1) wurde gedr�ckt
						switch_bypass_valve,				//Bypass-Ventil (Bypass 1) Status wurde ge�ndert
						toggle_main_valve,			  	//Toggle-Button f�r Haupt-Ventil (Bypass 2) wurde gedr�ckt
						switch_main_valve,			  	//Haupt-Ventil (Bypass 2) Status wurde ge�ndert
						toggle_chiller_relay,			  //Toggle-Button f�r Chiller wurde gedr�ckt
						switch_chiller_relay,			  //Chiller Relay Status wurde ge�ndert
            toggle_standby_mode,				//Den Standby-Modus wechseln
						toggle_enabled_mode,				//Den Enabled-Modus wechseln			
           	set_hold_mode,  						//System in Hold-Modus versetzen
            toggle_purge_mode, 					//Den Purge-Modus wechseln
            toggle_defrost_mode, 			  //Den Defrost-Modus wechseln
            set_version_info,
            set_ip_info,                // Anzeigen der IP-Adresse im Display
            config_window_activation,
            set_limits_1,
            set_power_supply_1_voltage_limits,  //Setzen der Limits f�r die Eingabe der Spannung in der Diagnose
            set_power_supply_2_voltage_limits,  //Setzen der Limits f�r die Eingabe der Spannung in der Diagnose
            set_power_suppply_1_set_voltage,    //Allgemeines ereignis, setzen der Spannung am Leistungsteil 1
            set_power_suppply_2_set_voltage,    //Allgemeines ereignis, setzen der Spannung am Leistungsteil 2
            set_power_suppply_3_set_voltage,    //Allgemeines ereignis, setzen der Spannung am Leistungsteil 3
            set_power_suppply_4_set_voltage,    //Allgemeines ereignis, setzen der Spannung am Leistungsteil 4
            set_power_suppply_5_set_voltage,    //Allgemeines ereignis, setzen der Spannung am Leistungsteil 5
            set_power_suppply_6_set_voltage,    //Allgemeines ereignis, setzen der Spannung am Leistungsteil 6
            inp_power_suppply_1_set_voltage,    //aktiviere Eingabe f�r die Spannung am Leistungsteil 1
            hit_power_suppply_1_set_voltage,    //Spannung f�r Netzteil 1 wurde eingegegben
            inp_power_suppply_2_set_voltage,    //aktiviere Eingabe f�r die Spannung am Leistungsteil 1
            hit_power_suppply_2_set_voltage,    //Spannung f�r Netzteil 2 wurde eingegegben
            set_power_supply_1_active,          //Festlegen welches Netzteil aktiv sein soll
            set_power_supply_2_active,          //Festlegen welches Netzteil aktiv sein soll
            set_power_supply_3_active,          //Festlegen welches Netzteil aktiv sein soll
            set_power_supply_4_active,          //Festlegen welches Netzteil aktiv sein soll
            set_power_supply_5_active,          //Festlegen welches Netzteil aktiv sein soll
            set_power_supply_6_active,          //Festlegen welches Netzteil aktiv sein soll
						set_power_supply_56_relay,					//Das Relay der Lamdas f�r die Chuck-Heizung hat seinen Status ver�ndert
						toggle_power_supply_56_relay,			  //Das Relay der Lamdas f�r die Chuck-Heizung wird getoggelt
            power_suppply_1_current,
            power_suppply_2_current,
            power_suppply_1_voltage,
            power_suppply_2_voltage,
            get_all_comp_tables,    				// Neuladen aller Kompensationstabellen notwendig
            receive_table1,
            receive_table2,
            receive_table3,
            set_active_comp_table,          // Aktive Kompensationstabelle bestimmen
            activate_comp_table_but,        // Umweg um die ausge�hlte Kompensationstabelle zu aktivieren
            send_table1,
            send_table2,
            send_table3,  
            set_comp_temp_limits,           // Limits f�r Kompensierte Werte
            set_norm_temp_limits,           // Limits f�r normale Werte
            user_config_5_key,              // Tastaureingabe im Kompensationsmen�
            set_norm_temp,                  // Ereigniss, setzen der Normaltemperatur in Komensationstabelle
            set_comp_temp,                  // Ereigniss, setzen der Kompensierten Temperatur in Komensationstabelle
            display_update,
            display_update_finished,        // Nachricht zeigt das Ende des Dipsplayupdates and
            send_direct_cmd2_data,          // Sende CMD2 Data Direkt, nur Synchrone ausf�hrung empfohlen
            send_direct_cmd3_data,          // Sende CMD3 Data Direkt, nur Synchrone ausf�hrung empfohlen
            compressor_status,
            set_network_mac,                // MAC Adresse wurde gelesen
            input_network_config,						// One of the input fields for network configuration was touched
            network_config_changed,					// The value for one of the network config inputs was entered in keyboard
            save_button_pressed,						// A save button has been pressed
            exit_button_pressed,						// An exit button has been pressed
            up_button_pressed,						  // An up button has been pressed
            down_button_pressed,						// A down button has been pressed
            drop_infomessage,               // Info Fenster auf den Bildschirm
            drop_errormessage,              // Fehlermeldung auf den Bildschirm
            drop_fatalerrormessage,         // Schwere Fehlermeldung auf den Bildschirm bringen
            remove_errormessage,            // Fehlermldung wieder entfernen
            red_ball_pressed,               // Rottes Symbol im Hauptfenster gedr�ckt
            error_1_ok,                     // OK Button im Info- Feld gedr�ckt
            chiller_comm_symbol,            // Kommunikationssymbol in Hauptfenster
            advice_symbol,                  // Rotes Achtung Bild auf den Hauptbildschirm ausgeben
            option_button_config,           // Option Button Konfiguration �ffnen
            set_plusminus_value,            // Option Button Konfiguration
            set_static_1_value,             // Option Button Konfiguration  
            set_static_2_value,             // Option Button Konfiguration            
            set_mode_plusminus,             // Option Button Konfiguration
            set_mode_static,
            system_config,									// System configuration window has to be displayed
            temp_limits,										// Temperature limits window has to be displayed
            network_config,									// Network configuration window has to be displayed
            change_temp_limit,							// User wants to change lower/upper temperature limit in "Temperature Limits" window
            reset_user_limits,							// The user temp limits are reset to the config temp limits		
            temp_limit_changed,							// The upper or lower temperature limit has been changed by user
            controller_stable,              // Controller ist stabil am Regeln
            NEW_PORB_ERROR,                 // Fehlernummer f�r Proberkommunikation
            NEW_DEWPOINT,                   
            operation_mode_changed,         // Operation Mode Changed. Raised when the Prober changes the Operation Mode
						inp_dewpoint_offsett,						// User wants to enter an new dewpoint offset
            new_dewpoint_offsett,           // Taupunktabstand hat sich ge�ndert
            set_active_dewpoint,            // Aktiviere Taupunkt�berwachung
            DEFROST_CHANGED,
						STANDBY_CHANGED,								// Informs about entering or leaving standby mode for protocol manager 
            VALVE_1_SET,
            VALVE_2_SET,
            VALVE_1_ADC1,
            VALVE_1_ADC2,
            VALVE_2_ADC1,
            VALVE_2_ADC2,
            VALVE_IN_PRESS_ERROR,
            VALVE_IN_PRESS_OK,
            VALVE_OUT_PRESS_ERROR,
            VALVE_OUT_PRESS_OK,
            VALVE_FLOW_ERROR,    
            VALVE_FLOW_OK,
            dew_point_adc,
            air_pressure_adc,   				// Ein neuer A/D-gewandelter Wert f�r den Eingangs-Luftdruck-Messwert steht zur Verf�gung
						air_pressure_new_val,				// Ein neuer Wert des Luftdrucks wird ins System gemeldet
						over_temp_adc,							// Ein neuer A/D-gewandelter Wert f�r den �bertemperatur-Messwert steht zur Verf�gung
            set_error,                  // Ein neuer Fehler ist aufgetreten, Fehlernummer wird als int parameter mitgeliefert
            reset_error,                // Ein Fehler ist nicht mehr vorhanden, Fehlernummer wird als int parameter mitgeliefert
            reset_all_errors,           // Alle Fehlermeldungen l�schen
            mod_stat_changed,
            set_peer_chiller_error,   	// External or Dual Chiller Error
            reset_peer_chiller_error,   // External or Dual Chiller Error           
            init_menue_v,								// Initializes a vertical menue in display
            
            MAX_EVENTS									// Kein Event, beinhaltet aber die Anzahl der definierten Events
        };    
};

/**
    Klasse kapselt alle Informatione die zum initialisieren des Keyboards notwendig sind
*/
class _input_float_EventArgument : public _set_limits_EventArgument
{
    public:
        float actValue;                 //Aktueller Float Wert
        _string mode;                   //Modues in dem eingegeben werden soll
        _string origin;                 //Names des Fensters das aufgerufen hat
        CEventNames::_event_name e_dst; //Ereigniss das bei der Eingabe ausgel�st werden soll
};


//EventArgument f�r Eingabe von Integerzahlen
class _input_int_EventArgument
{
    public:
        int i1;
        int i2;
        int i3;
        CEventNames::_event_name e_dst;
        _string origin;
};

template <typename T>
class _event
{
    public: 
        _event( char * source, CEventNames::_event_name event, T param, bool noRecall = false )
        {
            if( strlen(source) > 25 )
            {
                printf("String zu lang Class _event Konstruktor");
                taskENTER_CRITICAL();
                while(1);
            }
            else
            {
                strcpy( this->source, source );
            }
            this->noRecall = noRecall;
            event_name = event;
            pid = xTaskGetCurrentTaskHandle();
            parameter = param;           
         };
        
        T getEventParameter(){ return parameter; };
        CEventNames::_event_name getEventName(){ return event_name; };
        
        void modifyParameter( T p )
        {
            parameter = p;
        };
        
    private:
        T parameter;
        xTaskHandle pid;       
        char source[25];
        bool noRecall;
        CEventNames::_event_name event_name;
};

template < typename T>
class _event_handler
{
    public:
        _event_handler( CEventNames::_event_name event, void (*func)(T))
        {
            this->func = func;
            this->objectFunc = 0;
            this->event = event;
            this->pObject = 0;
            pid =  xTaskGetCurrentTaskHandle();
        };
        
        _event_handler( CEventNames::_event_name event, void (*func)(void*,T), void * pObject )
        {
            this->func = 0;
            this->objectFunc = func;
            this->event = event;
            this->pObject = pObject;
            pid = xTaskGetCurrentTaskHandle();
             
        };
       
        void raiseEvent(){ raised = true; };
        bool getEventRaised(){ return raised; };
        void setEventParameter( T parameter ){ this->parameter = parameter; };
        CEventNames::_event_name getEventName(){ return event; };
        void callEventHandler()
        {
            if( pObject == 0 )
            {
                func(parameter);
            }
            else
            {  
                objectFunc( pObject, parameter );
            }
            raised = false;
        };
        void * pObject;
        xTaskHandle getPID(){ return pid; };
    
    private:
        CEventNames::_event_name event;
        bool raised;
        xTaskHandle pid;
        void (*func)(T);
        void (*objectFunc)(void*,T);
        T parameter;
};

template < typename T >
class _event_service
{
    public:
        _event_service( int size )
        {
					if( size >= 100 ) while(1); //Wenn gr��e �ber 100 handler ansteigt stimmt was nicht
            hsize = size;
            for( int i = 0; i < hsize; i++ )
            {
                handler[i] = 0;
            }
        };
        
        //Abarbeiten der Ereignisse
        void HandlePID(void)
        {
            for( int i = 0; i < hsize && handler[i] != 0; i++ )
            {
                if( handler[i]->getPID() == xTaskGetCurrentTaskHandle() )
                {
                    if( handler[i]->getEventRaised() )
                    {
                        handler[i]->callEventHandler();
                    }
                }
            }    
        };
       //Ausl�sen eines Ereignisses
        void RaiseEvent( _event<T> e )
        {
            for( int i = 0; i < hsize && handler[i] != 0; i++ )
            {
                
                if( handler[i]->getEventName() == e.getEventName() )
                {
                    handler[i]->setEventParameter( e.getEventParameter() );
                    handler[i]->raiseEvent();
                }
            }
        };
        
        void RaiseEvent( _event<T> * p_e)
        {
            for( int i = 0; i < hsize && handler[i] != 0; i++ )
            {
                if( handler[i]->getEventName() == p_e->getEventName() )
                {
                    handler[i]->setEventParameter( p_e->getEventParameter() );
                    handler[i]->raiseEvent();
                }
            }         
        }

        //L�se Ereigniss aus und Warte bis alle Ereignisse abgearbeitet sind        
        void RaiseEventSync( _event<T> e)
        {
            for( int i = 0; i < hsize && handler[i] != 0; i++ )
            {
                if( handler[i]->getEventName() == e.getEventName() )
                {
                    handler[i]->setEventParameter( e.getEventParameter() );
                    handler[i]->raiseEvent();
                }
            }
            //Ereignisse in dieser Task abarbeiten
            HandlePID();
            //Warten bis die anderen Tasks die Ereignisse abgearbeited haben
            bool bWait;
            do
            {
                bWait = false;
                for( int i = 0; i < hsize && handler[i] != 0; i++ )
                {
                    if( handler[i]->getEventName() == e.getEventName() && handler[i]->getEventRaised() )
                    {
                        bWait = true;
                    }
                }
                vTaskDelay(1);
            }
            while( bWait );
        }


        //Eventhandler registrieren
        void AddEventHandler( CEventNames::_event_name e, void (*func)(T))
        {
            _event_handler<T> * h = new _event_handler<T>( e, func);
             
            for( int i = 0; i <= hsize; i++ )
            {
                if( i == hsize )
                {
                   taskENTER_CRITICAL();
                   while(true); //Fehler, nicht gro� genug
                }
                else if( handler[i] == 0 )
                {
                    handler[i] = h;
                    break;
                }
            }
        };

        void AddEventHandler( CEventNames::_event_name e, void (*func)(void*, T), void* pObject)
        {
            _event_handler<T> * h = new _event_handler<T>( e, func, pObject);
            
            for( int i = 0; i <= hsize; i++ )
            {
                if( i == hsize )
                {
                    taskENTER_CRITICAL();
                    while(true); //Fehler, nicht gro� genug
                }
                else if( handler[i] == 0 )
                {
                    handler[i] = h;
                    break;
                }
            }
        };


    private:
        int hsize;
        _event_handler<T> * handler[100];  

};


class CEventManager
{
    private:
        static const int tii_hsize = 10;
        
    public:    

        CEventManager();                       //Initialisieren der Klasse
        void HandlePID();                      //Zyklischer aufruf des Managers
        //Registrieren eines Ereignisses
        void RaiseEvent( _event<bool> e){ pBool->RaiseEvent(e);};    
        void RaiseEvent( _event<bool> * p){ pBool->RaiseEvent(p);};    
        void RaiseEvent( _event<float> e){ pFloat->RaiseEvent(e);};    
        void RaiseEvent( _event<float> * p){ pFloat->RaiseEvent(p);};    
        void RaiseEvent( _event<int> e){ pInteger->RaiseEvent(e);};    
        void RaiseEventSync( _event<int> e){ pInteger->RaiseEventSync(e);};
        void RaiseEvent( _event<short> e){ pShort->RaiseEvent(e);};
        void RaiseEvent( _event<char> e){ pChar->RaiseEvent(e);};
        void RaiseEvent( _event< _two_params<int,int> >);
        void RaiseEvent( _event<_set_limits_EventArgument> e){ pLimits->RaiseEvent(e);};
        void RaiseEvent( _event<_string> e){ pStrings->RaiseEvent(e);};
        void RaiseEvent( _event<_string> * p){ pStrings->RaiseEvent(p);};
        void RaiseEvent( _event<void*> e){ pPointers->RaiseEvent(e);};
        void RaiseEventSync( _event<void*> e){ pPointers->RaiseEventSync(e);};
        void RaiseEvent( _event<_input_int_EventArgument> e){ pInputIntArguments->RaiseEvent(e);};
        void RaiseEvent( _event<_input_float_EventArgument> e){ pInputFloatArguments->RaiseEvent(e);};
        //F�ge einen Handler f�r das Ereigniss hinzu
        void AddEventHandler( CEventNames::_event_name n, void (*func)(bool) ){ pBool->AddEventHandler( n, func);};
        void AddEventHandler( CEventNames::_event_name n, void (*func)(void*,bool), void * pObject){ pBool->AddEventHandler( n, func, pObject);};
        void AddEventHandler( CEventNames::_event_name n, void (*func)(float) ){ pFloat->AddEventHandler( n, func);};
        void AddEventHandler( CEventNames::_event_name n, void (*func)(void*,float), void * pObject){ pFloat->AddEventHandler( n, func, pObject);};
        void AddEventHandler( CEventNames::_event_name n, void (*func)(int) ){ pInteger->AddEventHandler( n, func);};
        void AddEventHandler( CEventNames::_event_name n, void (*func)(void*,int), void * pObject){ pInteger->AddEventHandler( n, func, pObject);};
        void AddEventHandler( CEventNames::_event_name n, void (*func)(short) ){ pShort->AddEventHandler( n, func);};
        void AddEventHandler( CEventNames::_event_name n, void (*func)(void*,short), void * pObject){ pShort->AddEventHandler( n, func, pObject);};
        void AddEventHandler( CEventNames::_event_name n, void (*func)(char) ){ pChar->AddEventHandler( n, func);};
        void AddEventHandler( CEventNames::_event_name n, void (*func)(void*,char), void * pObject){ pChar->AddEventHandler( n, func, pObject);};
        void AddEventHandler( CEventNames::_event_name n, void (*func)( _two_params<int,int> ) );
        void AddEventHandler( CEventNames::_event_name n, void (*func)(void*, _two_params<int,int> ), void * pObject);
        void AddEventHandler( CEventNames::_event_name n, void (*func)( _set_limits_EventArgument )){ pLimits->AddEventHandler( n, func );};
        void AddEventHandler( CEventNames::_event_name n, void (*func)(void*, _set_limits_EventArgument ), void * pObject){ pLimits->AddEventHandler( n, func, pObject );};
        void AddEventHandler( CEventNames::_event_name n, void (*func)( _string )){ pStrings->AddEventHandler( n, func );};
        void AddEventHandler( CEventNames::_event_name n, void (*func)(void*, _string ), void * pObject){ pStrings->AddEventHandler( n, func, pObject );};
        void AddEventHandler( CEventNames::_event_name n, void (*func)( void* )){ pPointers->AddEventHandler( n, func );};
        void AddEventHandler( CEventNames::_event_name n, void (*func)(void*, void* ), void * pObject){ pPointers->AddEventHandler( n, func, pObject );};
        void AddEventHandler( CEventNames::_event_name n, void (*func)( _input_int_EventArgument )){ pInputIntArguments->AddEventHandler( n, func );};
        void AddEventHandler( CEventNames::_event_name n, void (*func)(void*, _input_int_EventArgument ), void * pObject){ pInputIntArguments->AddEventHandler( n, func, pObject );};
        void AddEventHandler( CEventNames::_event_name n, void (*func)( _input_float_EventArgument )){ pInputFloatArguments->AddEventHandler( n, func );};
        void AddEventHandler( CEventNames::_event_name n, void (*func)(void*, _input_float_EventArgument ), void * pObject){ pInputFloatArguments->AddEventHandler( n, func, pObject );};
        
    private:
        _event_handler< _two_params<int,int> > * tii_handler[tii_hsize];
        _event_service<float> * pFloat; 
        _event_service<int> * pInteger;
        _event_service<bool> * pBool;
        _event_service<short> * pShort;
        _event_service<char> * pChar;
        _event_service<_set_limits_EventArgument> * pLimits;
        _event_service<_string> * pStrings;
        _event_service<void*> * pPointers;        
        _event_service<_input_int_EventArgument> * pInputIntArguments;       
        _event_service<_input_float_EventArgument> * pInputFloatArguments;    
};

#endif //_C_EVENT_HANDLER