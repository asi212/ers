#include "CGlobalExchange.h"


/** 
 * Class Constructor
 */
CGlobalExchange::CGlobalExchange( void )
{
		// We create queues for all global variables to be handeled here.
		Add <float> ( CHUCK_TEMP_MIN_LIMIT );
}


/** 
 * Class Destructor
 */
CGlobalExchange::~CGlobalExchange( void )
{
	// Delete all queues
	for ( int i=0; i<NUM_GLOBEX_NAMES; i++ )
	{
		vQueueDelete( queue[i]);
	}
}

/**
 * @brief Adds a variable to global exchange
 *
 * This is done by creating a queue and storing the handler in an
 * array indexed by name
 *
 * @param name, the reference to the variable, any of \ref _glob_exch_name
 */
template <class T> void CGlobalExchange::Add( _glob_exch_name name )
{
	queue[name] = xQueueCreate( GLOBEX_QUEUE_LEN, sizeof( T ) );
}


/**
 * @brief Set a global value
 *
 * This is done by 
 *   a) sending a value to the back of queue referenced by name
 *   b) receiving one value, bringing the new value to the queues front
 * 
 * @param name, 	the reference to the variable, any of \ref _glob_exch_name
 * @param val, 		the value to be set
 */
template<class T> void CGlobalExchange::SetValue( _glob_exch_name name, T val )
{
	// We send item to queue and then remove the older item (queue length is 2)
	// This ensures, that for GetVal calls, always a value is available
	if ( xQueueSend( queue[name], (void *) &val, (portTickType) 0 ) == pdTRUE )
		xQueueReceive( queue[name], (void *) &val, (portTickType) 0 );
}

/**
 * @brief Get a global value
 *
 * This is done by peeking the front queue value
 * 
 * @param name, 	the reference to the variable, any of \ref _glob_exch_name
 * @param val, 		the value to be set
 */
template<class T> T CGlobalExchange::GetValue( _glob_exch_name name )
{
	T val;
	
	// We peek into queue without removing the item 
	xQueuePeek( queue[name], (void *) &val, (portTickType) 100 );
	
	return val;
}

