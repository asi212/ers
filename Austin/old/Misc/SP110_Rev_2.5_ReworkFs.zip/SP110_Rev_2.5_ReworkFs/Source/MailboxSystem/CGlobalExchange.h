/***********************************************************************
 * @brief Exchange of global variables between tasks
 *
 ***********************************************************************/

#include "FreeRTOS.h"
#include "queue.h"
              
#define GLOBEX_QUEUE_LEN	2			/**< The queue length we create each queue with */

/**
 * The following list defines the values, which can be referenced by 
 * Set and Get functions
 */


class CGlobalExchange
{

public:
	
	// Class Constructor and Destructor
	CGlobalExchange( void );
	~CGlobalExchange( void );
		
  // List of defined names we handle within this class
	enum _glob_exch_name {
	
		CHUCK_TEMP_MIN_LIMIT,		/**< Minimal limit of allowed chuck temperature */
		
		NUM_GLOBEX_NAMES				/**< Number of values defined in this list			*/
	};

	// Set and Get functions
	template <class T> void SetValue( _glob_exch_name name, T val ); 
	template <class T>   T  GetValue( _glob_exch_name name );
	

private:
	// Array of queue handles, indexed by name
	xQueueHandle queue[NUM_GLOBEX_NAMES];
	
	// Template function to add a variable of certain data type
	template <class T> void Add( _glob_exch_name name );
	
};
