/**
*  \file
*    msg.cpp
*   
*  \brief Implementation of the Class msg
*  \date 10-Jan-2011 16:09:53
*  \author
*    Michael Brunner
*    , Lars Possberg
*/
#include "..\system_wide_defs.h"
#include "msg.h"


msg::msg()
{
  	cmd1.reserve(25);
	//cmd2.reserve(250);
        cmd2.reserve(25);
	dest.reserve(25);
	origin.reserve(25);
        cmd3.reserve(250);
          
	cmd1 = "0";
	cmd2 = "0";
	data = NULL;
	dest = "0";
	origin = "0";
	//multimessage = false;
        //number = 0;
}

msg::~msg(){

}

msg& msg::operator= (const msg & other)
{
	if (this != &other) // protect against invalid self-assignment
	{
		cmd1 = other.cmd1;
		cmd2 = other.cmd2;
                cmd3 = other.cmd3;
		data = other.data;
		dest = other.dest;
                //number = other.number;
		origin = other.origin;
		//multimessage = other.multimessage;
	}
	// by convention, always return *this
	return *this;
}

msg::msg(const msg& other)   // copy constructor
{
	cmd1 = other.cmd1;
	cmd2 = other.cmd2;
        cmd3 = other.cmd3;
	data = other.data;
	dest = other.dest;
	//number = other.number;
	origin = other.origin;
	//multimessage = other.multimessage;
}
