/**
*  \file
*    msg.cpp
*   
*  \brief Implementation of the Class msg
*  \date 10-Jan-2011 16:09:53
*  \author
*    Michael Brunner
*    , Lars Possberg
*/
#include "..\system_wide_defs.h"
#include <string>
#include <vector>

#if !defined(MSG_H__INCLUDED_)
#define MSG_H__INCLUDED_

class msg
{
public:
	/**
	 * After creation, the following initialisations are done:
	 * - every string has the value "0"
	 * - data points to NULL
	 * - multimessage is 'false'
	 */
	msg();
	virtual ~msg();
	msg(const msg& p);   // copy constructor for deep copies
	msg& operator= (const msg & other); // assignment operator
        
	/**
	 * This is a field for a self defined command which should tell the recipient of
	 * the message what he has to do with the data behind the datapointer.
	 */
	string cmd1; //res
	/**
	 * This is a field for a self defined command which should tell the recipient of
	 * the message what he has to do with the data behind the datapointer. This is an
	 * additional command-field. You may define here the type of data that the
	 * recipient has to expect behind the datapointer for a safer casting.
	 */
	string cmd2; //res
        
	vector<char> cmd3;
        
	void* data;
	/**
	 * Destination of the message.
	 */
	string dest; //res
	/**
	 * Name of the sender who sent the message.
	 */
	string origin; //res

	/**
	 * THIS OPTION IS NOT IMPLEMENTED YET!
	 * When 'true', the message is delivered to all recipients with
	 * the same name. New messages are generated (copy) during this process.
	 * The data behind the void*-pointer can not be copied!
	 * Data-delivery with this mode should be handled very carefully.
	 * If you need to deliver data, you might try the 'trash'-option
	 * to be sure there will be no data-leak.
	 * This mode might be used for sniffer-applications for debugging
	 * or logfiles.
	 * It is not recommended for normal object communication,
	 * due to its behaviour which might cause
	 * RAM-fragmentation when used too excessive.
	 * After creating a new msg-object, this parameter is set as 'false'.
	 */
	// bool multimessage;
        
       // int number;
        int i_number[3];
        float f_number[3];
};
#endif // !defined(MSG_H__INCLUDED_)
