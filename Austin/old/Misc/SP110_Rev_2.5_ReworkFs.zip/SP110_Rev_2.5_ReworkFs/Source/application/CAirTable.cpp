#include "CAirTable.h"
#include "FS.h"
#include "CSetup.h"

#include <cmath>
#include <cstring>

#define AIR_DIV 3.3

CAirTable::CAirTable(){
  //Init accordingly, othwerwise simple search will not work
  for( int i = 0; i <  AIR_TABLE_LEN; i++ ){
    pTable[i].fTemp = (i * 20.0) - 60;
    pTable[i].fFlow = 0.0;
    pTable[i].fCold = 0.0;
    pTable[i].fAirTemp = 0.0;
    pTable[i].fSpare1 = 0.0;
    pTable[i].fSpare2 = 0.0;
  }
  pTable[19].fTemp = 550.0;
}

void CAirTable::InitialAirTable(AIR_TABLE_OPTION option)
{
    float *atable;
   
    switch(option)
    {
        case E_AT_OPTION300:
            atable = &AirTable_300[0][0];
        break;
        
         case E_AT_OPTION200:
            atable = AirTable_200;
        break;
        
         case E_AT_OPTION150:
            atable = AirTable_200;
        break;
   }
   if( atable != 0)
   {
      
        for( int i = 0; i < AIR_TABLE_LEN; i++ )
        {
            pTable[i].fTemp =  *(atable+ 4*i);
            pTable[i].fFlow =  *(atable+1+ 4*i);
            pTable[i].fCold =  *(atable+2+4*i);
            pTable[i].fAirTemp= *(atable+3+4*i);
            pTable[i].fSpare1 = 0.0;
            pTable[i].fSpare2 = 0.0;
      }       
   }
}

void CAirTable::loadAirTable( char * pFileName ){
    int i, set = 0;
    FS_FILE * pFile = FS_FOpen( pFileName, "rb" );
    if( pFile != 0 ){
        do{
            i = FS_Read(pFile, &pTable[set].fTemp, 4); 
            i = FS_Read(pFile, &pTable[set].fFlow, 4); 
            i = FS_Read(pFile, &pTable[set].fCold, 4);
            i = FS_Read(pFile, &pTable[set].fAirTemp, 4);
            i = FS_Read(pFile, &pTable[set].fSpare1, 4);
            i = FS_Read(pFile, &pTable[set].fSpare2, 4);
            set++;
        } while( i );
        FS_FClose(pFile);
    }
}

void CAirTable::saveAirTable( char * pFileName )
{
    FS_FILE * pFile = FS_FOpen( pFileName, "wb" );
    if( pFile != 0 )
    {
        for( int i = 0; i <  AIR_TABLE_LEN; i++ )
        {
            FS_Write(pFile, &pTable[i].fTemp, 4); 
            FS_Write(pFile, &pTable[i].fFlow, 4); 
            FS_Write(pFile, &pTable[i].fCold, 4);
            FS_Write(pFile, &pTable[i].fAirTemp, 4);
            FS_Write(pFile, &pTable[i].fSpare1, 4);
            FS_Write(pFile, &pTable[i].fSpare2, 4);
        };
        FS_FClose(pFile);
    }  
}

bool CAirTable::recalcTemp( float Set, float Act )
{
  for( int i = 0; i < AIR_TABLE_LEN; i++ )
  {
    //Nur wenn die aktuelle Temperatur nahe an einem Tabellenwert ist neu berechnen
    if(  abs(pTable[i].fTemp - Set) <= 0.1 )
    {
      pTable[i].fAirTemp = pTable[i].fAirTemp * 0.9 + Act * 0.1;
      //True zur�ckliefern wenn Tabllenwert neu berechnet werden konnte
      return true;
    }
  }
  return false;
}

sAirValue CAirTable::getAirValue( float fTemp ){
  int i = 19;
  for( ; fTemp < pTable[i].fTemp && i > 0; i-- );  //find Entry
  if( i == 19 ){
    return pTable[19];
  }
  else if ( i == 0 && fTemp < pTable[0].fTemp )
  {
      return pTable[0];
  }
  else{
    float fTempDlt = pTable[i+1].fTemp - pTable[i].fTemp;  //Temperature Delta beetwenn Table Sets
    float fTempDst = fTemp-pTable[i].fTemp;                //Distance from lower Point
    float fTempMlt = abs(fTempDst/fTempDlt);               //Calculate Multiplicator
    float fFlowDlt = pTable[i+1].fFlow-pTable[i].fFlow;
    float fColdDlt = pTable[i+1].fCold-pTable[i].fCold;
    float fATmpDlt = pTable[i+1].fAirTemp-pTable[i].fAirTemp;

    sAirValue sAirTmp;
    sAirTmp.fTemp = fTemp;
    sAirTmp.fFlow = pTable[i].fFlow + fFlowDlt * fTempMlt;
    sAirTmp.fCold = pTable[i].fCold + fColdDlt * fTempMlt;
    sAirTmp.fAirTemp = pTable[i].fAirTemp + fATmpDlt * fTempMlt;
    return sAirTmp;
  }
}

/**
 * Writes the name of a certain air table into given buffer.
 * The buffer must have at least size AIR_FILE_NAME_LEN!!!
 *
 * Which airtable name to be given is defined by opt, one of \ref AIR_TABLE_OPTION
 */
void CAirTable::getAirTableName( char* buf, AIR_TABLE_OPTION opt)
{
  switch( opt )
  {
      case CSetup::_s_config::E_AIR_300:
        strcpy( buf, AirTabelFile_300 );
        break;
      case CSetup::_s_config::E_AIR_200:
        strcpy( buf, AirTabelFile_200 );
        break;
      case CSetup::_s_config::E_AIR_150:
        strcpy( buf, AirTabelFile_150 );
        break;
  }
}

