#ifndef C_AIR_TABLE
#define C_AIR_TABLE

typedef enum _AirTableOption
{
    E_AT_OPTION300,
    E_AT_OPTION200,
    E_AT_OPTION150
}AIR_TABLE_OPTION;

const float AirTable_300[][4] = {
{-60, 330, 100,-55}, // Set Temperature, Flow in liters/min, Percentage Col�d air, Start Air Temperature 
{-50, 330, 100,-50.45496},  
{-30, 316, 78,-39.5609},  
{-10, 240, 53,-16.3285},  
{+10, 134, 29,+4.911314},  
{+25, 88,  17,+16.19925},  
{+40, 70,  33,+28.5407},  
{+60,  0,   0,+12.79438},  
{+100, 0,   0,+7.02459},    
{+120, 0,   0,+2.419899}, 
{+140, 0,   0,+4.399976},      
{+160, 0,   0,0},       
{+180, 0,   0,0}, 
{+200, 0,   0,0}, 
{+220, 0,   0,0}, 
{+240, 0,   0,0},
{+260, 0,   0,0},
{+280, 0,   0,0},
{+300,0,0,+27.7997},
{+550,0,0,0},
};

const float AirTable_200[][4] = {
{-60, 230, 100,-79.62289}, // Set Temperature, Flow in liters/min, Percentage Col�d air, Start Air Temperature 
{-55, 230, 100,-80},  
{-50, 230, 95,-70},  
{-40, 220, 86,-64.31605},  
{-30, 220, 75,-50},  
{-20, 220, 62,-32.16263},  
{-10, 220, 48,-18.39588},
{  0, 198, 40,-2.697642},  
{+10, 167, 26,+6.291523},  
{+20, 134, 25,+7.871109},  
{+25, 52,  42,-9.23293},  
{+40, 32,   0,+29.15121},  
{+50,  0,   0,0},  
{+200, 0,   0,0}, 
{+220, 0,   0,0}, 
{+240, 0,   0,0},
{+260, 0,   0,0},
{+280, 0,   0,0},
{+300,0,0,+18.49477},
{+550,0,0,0},
};

#define AIR_TABLE_LEN 		20 	// Alway increase or decrease this value when table length changes!
#define AIR_FILE_NAME_LEN  9  // Length of air table file name including terminating \0 character

const char AirTabelFile_300[]={"A300.AIR"};
const char AirTabelFile_200[]={"A200.AIR"};
const char AirTabelFile_150[]={"A150.AIR"};

struct sAirValue{
  float fTemp;
  float fFlow;   //Flow in liters per minute
  float fCold;   //Cold percentage value related on Flow
  float fAirTemp;//Lufttemperatur f�r dynamisches Luftregelung
  float fSpare1; //Platzhalter falls mir noch was einf�llt
  float fSpare2; //Platzhalter falls mir noch was einf�llt
};

class CAirTable{
  private:
    sAirValue pTable[ AIR_TABLE_LEN];
  public:
    CAirTable();
    void loadAirTable( char * pFileName );
    void saveAirTable( char * pFileName );
    sAirValue getAirValue( float fTemp );
    bool recalcTemp( float Set, float Act );
    void InitialAirTable(AIR_TABLE_OPTION option);
		void getAirTableName( char* buf, AIR_TABLE_OPTION opt);
};


#endif //C_AIR_TABLE