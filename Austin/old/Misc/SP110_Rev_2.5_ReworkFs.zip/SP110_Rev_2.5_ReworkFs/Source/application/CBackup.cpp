#include "CBackup.h"
#include "CFiles.h"
#include "CSetup.h"
#include "CAirTable.h"

#include "hl_md5.h" 		/**< Library for Checksum calculation		*/	
#include <cstring>

extern "C" {
#include "91x_lib.h"		/**< STM peripheral library        			*/
#include "FS.h" 				/**< PowerPac File System    						*/
#include "FS_NOR_PHY_M29W128G.h"
#include "c2635.h"
#include "version.h"
}

_data bck @ "EXRAM";							// Buffer for one backup sector


/*******************
* METHOD: CBackup
*
* DESCRIPTION:
*  Constructor
*
* CREATED: 15.05.2013, by KLaus M�ller
*
* FILE: CBackup.cpp
*/
CBackup::CBackup()
{
}

/*******************
* METHOD: Save
*
* DESCRIPTION:
*  Saves a backup in Flash
*
* CREATED: 15.05.2013, by Klaus M�ller
*
* FILE: CBackup.cpp
*/
void CBackup::Save ( bck_type type )
{
	extern CSetup * p_CSetup;
	
	volatile unsigned int sec=0;
	volatile unsigned int off=0;

	// Define sector and offset
	switch (type)
	{
	case BCK_TYPE_CUR:
		// current backup sector
		sec = BCK_BLOCK_DATA_CUR;
		break;
	case BCK_TYPE_ORG:
		// original  backup sector
		sec = BCK_BLOCK_DATA_ORG;
		break;
	default:
		return;
	}
	off = (unsigned int)BlockOffset[sec-1];

	// Compose backup data
	memset ((void *)&bck, 0, sizeof(bck));
	
	// a) Data
	// First, complete Setup has to be loaded from files.
	p_CSetup->readOffsetTable();  									
	p_CSetup->readSetup();
	p_CSetup->readConfig();
	p_CSetup->readPIDSet(p_CSetup->getPidSetNr());
  // Then, we copy Setup-Struct to our backup buffer
	memcpy ((void *)&bck.setup, (const void*)p_CSetup, sizeof(bck.setup) );
	
	// b) Header
	bck.header.version = BUILD;
	bck.header.image_len = 0;
	strcpy (bck.header.id, "ERSBCKUP" );
	
	// c) Compute Hash
	Hash( &bck.setup, &bck.header.md5 );	
	
  if( FlashCheckBlockNVPB( sec-1 ) != Flash_NonVolatile_Unprotected ) FlashClear1BlockNVPB( sec-1 );

	// Erase sector and store backup
	_EraseSector(0, sec-1);
	_WriteOff(0, off, (void*)&bck, (unsigned int)sizeof(bck));
 	_ReadOff(0, (void*)&bck, off, (unsigned int)sizeof(bck));

	return;
};


/*******************
* METHOD: Restore
*
* DESCRIPTION:
*  Restores filesystem from backup
*
* CREATED: 15.05.2013, by Klaus M�ller
*
* FILE: CBackup.cpp
*/
void CBackup::Restore ( bck_type type )
{
	//_data  bck;
	_data* pBck = &bck;
	
	// Get content of backup sector
	switch (type)
	{
	case BCK_TYPE_CUR:
		// current backup sector
	  _ReadOff(0, (void*)pBck, (unsigned int)BlockOffset[BCK_BLOCK_DATA_CUR-1], (unsigned int)sizeof(bck));
		break;
	case BCK_TYPE_ORG:
		// original  backup sector
	  _ReadOff(0, (void*)pBck, (unsigned int)BlockOffset[BCK_BLOCK_DATA_ORG-1], (unsigned int)sizeof(bck));
		break;
	default:
		return;
	}
	
	// Now restore files
	pBck->setup.writeSetup();
	pBck->setup.writeOffsetTable();
	pBck->setup.writeConfig();
	pBck->setup.writePIDSet(pBck->setup.getPidSetNr());
	pBck->setup.WriteDefaultAirTables();

	return;
};


/*******************
* METHOD: CheckFs
*
* DESCRIPTION:
*  Checks filesystem for 
*
* RETURN:
*  true, if fs is OK, false otherwise
*
* CREATED: 15.05.2013, by Klaus M�ller
*
* FILE: CBackup.cpp
*/
bool CBackup::CheckFs ( void )
{
  extern CFiles * p_CFiles;
	extern CSetup * p_CSetup;
	extern CAirTable * p_AirTable;
	
	int fs=0, vs=0;		// Temp variables for storage of file sizes
	
	// Then check size and existance of important files
	// 1) CONFIG.INI
	if (p_CFiles->fileSize("CONFIG.INI") != sizeof(CSetup::_s_config)) return false;
	
	// 2) SETUP.INI
	if (p_CFiles->fileSize("SETUP.INI") != sizeof(CSetup::_s_setup)) return false;
	
	// 3) OFFSETT.INI
	if (p_CFiles->fileSize("OFFSETT.INI") != sizeof(_o_table)) return false;
	
	// Now we have to load configuration to decide for further filenames
	p_CSetup->readConfig();

	// 4) PIDXX.INI
	unsigned short n = p_CSetup->getPidSetNr();
	char f[PID_FILE_NAME_LEN] = {0};
	p_CSetup->getPidFileName( f, n);
	fs = p_CFiles->fileSize(f);
	vs = sizeof(t_pid_setup)*SETUP_NUM_PID_SETS;
	if (fs != vs) return false;
	
	// 5) AXXX.AIR
 	char cAFile[AIR_FILE_NAME_LEN] = {0};
	p_AirTable->getAirTableName(cAFile,(AIR_TABLE_OPTION)p_CSetup->getAirTable());
	fs = p_CFiles->fileSize(cAFile);
	vs = sizeof(sAirValue)*AIR_TABLE_LEN;
	if (fs != vs) return false;
		
	// If we are here, all test have been passed.
	return true;
};


/*******************
* METHOD: Exist
*
* DESCRIPTION:
*  Checks if a filesystem backup exists
*
* CREATED: 03.06.2013, by Klaus M�ller
*
* FILE: CBackup.cpp
*/
bck_exist_stat CBackup::Exist( void )
{
	 bck_exist_stat ret =  BCK_EXIST_NONE; 	// Pessimistic approach
	 uint8_t hash[MD5_LEN+1]  = {0};			  // Buffer for hash-calculation
	
	/******************
	 * CURRENT BACKUP
	 ******************/
	 
	// Get content of current backup sector
	_ReadOff(0, (void*)&bck, (unsigned int)BlockOffset[BCK_BLOCK_DATA_CUR-1], (unsigned int)sizeof(bck));
  //_ReadOff(0, (void*)&bck, (unsigned int)BlockOffset[0], (unsigned int)500);

	// Check header identifier
	if( strcmp( bck.header.id, "ERSBCKUP" )==0 )
	{
		// Check backup version. Must be at least the minimum version required by software
		if( bck.header.version >= MIN_CFG_REV )
		{
			// Check MD5 hash of backup
			Hash( &bck.setup, hash );
			if( strncmp( bck.header.md5, hash, MD5_LEN )==0 )
			{
				ret = BCK_EXIST_CUR;
			}
		}
	}	

	/******************
	 * ORIGINAL BACKUP
	 ******************/

	// Get content of original backup sector
  _ReadOff(0, (void*)&bck, (unsigned int)BlockOffset[BCK_BLOCK_DATA_ORG-1], (unsigned int)sizeof(bck));

	// Check header identifier
	if( strcmp( bck.header.id, "ERSBCKUP" /*STR_EXPAND(BACKUP_ID)*/ )==0 )
	{
		// Check backup version. Must be at least the minimum version required by software
		if( bck.header.version >= MIN_CFG_REV )
		{
			// Check MD5 hash of backup
			Hash( &bck.setup, hash );
			if( strncmp( bck.header.md5, hash, MD5_LEN )==0 )
			{
				if( ret==BCK_EXIST_CUR ) ret = BCK_EXIST_BOTH;
				else ret = BCK_EXIST_ORG;
			}			
		}
	}		
	return ret;
};


/*******************
* METHOD: Hash
*
* DESCRIPTION:
*  Computes the MD5 Hash of backup data
*
* INPUT:
*  pBck, pointer to backup data the hash shall be computed on
*
* OUTPUT:
*  pHash, pointer to a buffer to store computed hash string (16 chars)
*
* CREATED: 04.06.2013, by Klaus M�ller
*
* FILE: CBackup.cpp
*/
void CBackup::Hash ( uint8_t* pDat, uint8_t* pHash )
{
	HL_MD5_CTX ctx; 				/**< Context memory of MD5-calculator 	*/
	MD5 md5; 								/**< The calculator object itself       */

	// Init of MdD5 calculator
	md5.MD5Init(&ctx); 			
	
	// MD5 calculation on defined backup types
	md5.MD5Update(&ctx, pDat, sizeof(*pDat) );
	
	// Finalization of calculation
  md5.MD5Final(pHash, &ctx);

	return;
};
