/*******************
 * CLASS: CBackup
 *
 * DESCRIPTION:
 *  Implements the filesystem-backup mechanism, used by firmware reset
 *
 *
 * CREATED: 15.3.2013, by Klaus M�ller
 *
 * FILE: CBackup.h
 */


#ifndef CBACKUP_H
#define CBACKUP_H


/* include C/C++-libraries */
#include <stdint.h>

/* Include classes */	
#include "CSetup.h"			/**< Setup and Configuration storage		*/


extern "C"
{
/* Includes Libraries */
#include "91x_lib.h"
}

/**
 * Konfiguration
 *
 * We store the backup at the end of the flash. We use seperate blocks for 
 * original data, current data and image data. This allows us to change one 
 * of them without touching the others. One flash block (128 KB) is used 
 * for original configuration data (production status), one block is used for
 * current data and 4 blocks (512 KB, the main flash size of microcontroller) 
 *
 * Lowest: 64 , highest: 127, 0..63 are occupied by filesystem
 */

#define BCK_TOP_BLOCK				 100 	//NUM_BLOCKS

#define BCK_BLOCK_DATA_ORG  (BCK_TOP_BLOCK - 0)
#define BCK_BLOCK_DATA_CUR  (BCK_TOP_BLOCK - 1)
#define BCK_BLOCK_IMAGE_ORG	(BCK_TOP_BLOCK - 5)	

#define MD5_LEN	16

#define STR_EXPAND(tok) #tok
#define BACKUP_ID  ERSBCKUP

typedef enum
{
	BCK_EXIST_NONE,
	BCK_EXIST_CUR,
	BCK_EXIST_ORG,
	BCK_EXIST_BOTH,
} bck_exist_stat;

// The possible typed of stored backups
typedef enum
{
	BCK_TYPE_CUR,			/**< Current filesystem 			*/
	BCK_TYPE_ORG,			/**< Original filesystem 			*/                               	
	BCK_TYPE_IMG,			/**< Original firmware image 	*/
} bck_type;

// This structure holds a set of flags, where currently only two are used
//
// Valid flags: These flags tells, if data is consistent
// Before erase of a section, both flags are set to zero. After erase of section, 
// both flags should be 1. The valid flag 2 is individually set to zero, after section 
// has been written. This ensures, that a section can be marked valid in an atomic operation. 
// If during erase or writing power is switched off, sector is not marked as valid
struct _flags
{
	bool 			valid1;		 // 01: data is valid , all others: data is invalid
	bool			valid2;	 	 
	bool			reserve2;	 // Reserved flag
	bool			reserve3;	 // Reserved flag
	bool			reserve4;	 // Reserved flag
	bool			reserve5;	 // Reserved flag
	bool			reserve6;	 // Reserved flag
	bool			reserve7;	 // Reserved flag
};


// The backup header, containing data about backup structure
struct _header
{
	char 			id[9];		  	// ID string used to identify the header
	uint16_t	version;			// Should correspond to the build number of the corresponding software
	char 			sn[32];				// Serial number of device
	uint32_t	image_len;		// The length of the image in byte
	uint8_t 	md5[MD5_LEN];	// The md5-value of the data excluding the header
	_flags  	flags;				// Flags 
};

struct _data
{
	_header 	header;
	CSetup		setup;	  	// The complete setup data
};


/**
 * Backup class for handling filesystem backup
 */
class CBackup
{
public:
	CBackup();              					// Constructor
  ~CBackup();												// Destructor                         	
  
	void Save    ( bck_type type ); 	// Saves a new version of the backup
	void Restore ( bck_type type ); 	// Restores the backup into filesystem
	bool CheckFs ( void );  					// Checks the filesystem for errors
	bck_exist_stat Exist( void );			// Checks, if a valid backup exists	
	
	/**
   * The structure of the backup data. Backaup can be read into or written from this structure
   */
	
	//_backup_struct m_backup_struct;

protected:

	
private:

	void Hash    (  uint8_t* pDat, uint8_t* pHash );	// Computes the MD5 Hash of backup data

	
};


#endif // CBACKUP_H