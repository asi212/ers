#include "CCanIO.h"
#include "stdio.h"
#include "string.h"

#define FSM_CAN_STUP 0
#define FSM_CAN_RMD1 1
#define FSM_CAN_SMOD 2
#define FSM_CAN_AMOD 3
#define FSM_CAN_RMD4 4
#define FSM_CAN_RTEM 5

CCanIO::CCanIO(){
  TxCanMsg.IdType = CAN_STD_ID; TxCanMsg.Id = 0x61E; TxCanMsg.Dlc = 8;  TxCanMsg.Data[0] = 0x00; TxCanMsg.Data[1] = 0x01; TxCanMsg.Data[2] = 0x01; TxCanMsg.Data[3] = 0x00; TxCanMsg.Data[4] = 0x00; TxCanMsg.Data[5] = 0x00; TxCanMsg.Data[6] = 0x00; TxCanMsg.Data[7] = 0x00;
  iFSM_Can = FSM_CAN_STUP;
}

void CCanIO::cycExec( int iT ){

  switch( iFSM_Can ){

    case FSM_CAN_STUP:
      /* configure the message objects */
      CAN_SetRxMsgObj(CAN_ALMRX_MSGOBJ, CAN_STD_ID, 0x0DE, 0x0DE, TRUE );
      CAN_SetRxMsgObj(CAN_VAHRX_MSGOBJ, CAN_STD_ID, 0x220, 0x220, TRUE ); //T2 und T3 Modul
      CAN_SetRxMsgObj(CAN_VAJRX_MSGOBJ, CAN_STD_ID, 0x221, 0x221, TRUE ); //T2 und T3 Modul
      CAN_SetRxMsgObj(CAN_VAIRX_MSGOBJ, CAN_STD_ID, 0x222, 0x222, TRUE ); //T2 und T3 Modul
      CAN_SetRxMsgObj(CAN_VAKRX_MSGOBJ, CAN_STD_ID, 0x223, 0x223, TRUE ); //T2 und T3 Modul
      CAN_SetRxMsgObj(CAN_CMDRX_MSGOBJ, CAN_STD_ID, 0x65E, 0x65E, TRUE );
      CAN_SetTxMsgObj(CAN_CMDTX_MSGOBJ, CAN_STD_ID, DISABLE );
      iFSM_SubCnt = 0;
      iFSM_Can = FSM_CAN_RTEM;
      //iFSM_Can = FSM_CAN_RMD1;
    break;

    case FSM_CAN_RMD1:
      TxCanMsg.Data[3] = iFSM_SubCnt;
      CAN_UpdateMsgObj(CAN_CMDTX_MSGOBJ, &TxCanMsg );
      CAN_SendMessage (CAN_CMDTX_MSGOBJ, &TxCanMsg );
      CAN_WaitEndOfTx();
      if(CAN_ReceiveMessage(CAN_CMDRX_MSGOBJ, TRUE, &RxCanMsg)){
        cModules[iFSM_SubCnt++] = RxCanMsg.Data[4];
        if( iFSM_SubCnt > 4 ){
          iFSM_SubCnt = 0;
          //iFSM_Can = FSM_CAN_SMOD;
          iFSM_Can = FSM_CAN_RTEM;
        }
      }
    break;

    case FSM_CAN_SMOD:
      TxCanMsg.Data[1] = 11;
      TxCanMsg.Data[2] = 28;
      TxCanMsg.Data[3] = iFSM_SubCnt;
      TxCanMsg.Data[4] = 0x00;
      TxCanMsg.Data[5] = 0x03;
      TxCanMsg.Data[6] = 0x00;
      TxCanMsg.Data[7] = 0x03;
      CAN_UpdateMsgObj(CAN_CMDTX_MSGOBJ, &TxCanMsg );
      CAN_SendMessage (CAN_CMDTX_MSGOBJ, &TxCanMsg );
      CAN_WaitEndOfTx();
      if(CAN_ReceiveMessage(CAN_CMDRX_MSGOBJ, TRUE, &RxCanMsg)){
        if( iFSM_SubCnt++ > 0 ){
          iFSM_SubCnt = 0;
          iFSM_Can = FSM_CAN_AMOD;
        }
      }
    break;

    case FSM_CAN_AMOD:
      TxCanMsg.Data[1] = 12;
      TxCanMsg.Data[2] = 0;
      TxCanMsg.Data[3] = 0;
      TxCanMsg.Dlc = 4;
      CAN_UpdateMsgObj(CAN_CMDTX_MSGOBJ, &TxCanMsg );
      CAN_SendMessage (CAN_CMDTX_MSGOBJ, &TxCanMsg );
      CAN_WaitEndOfTx();
      if(CAN_ReceiveMessage(CAN_CMDRX_MSGOBJ, TRUE, &RxCanMsg)){
        iFSM_Can = FSM_CAN_RMD4;
      }
    break;

    case FSM_CAN_RMD4:
      if(CAN_ReceiveMessage(CAN_CMDRX_MSGOBJ, TRUE, &RxCanMsg)){
        iFSM_Can = FSM_CAN_RTEM;
      }
    break;

    case FSM_CAN_RTEM:
      if(CAN_ReceiveMessage(CAN_VAHRX_MSGOBJ, TRUE, &RxCanMsg))
      {
        switch( RxCanMsg.Id ){
           case 0x220:
            memcpy( &fTempValue[0], RxCanMsg.Data, 4);
          break;
          default:
#ifdef DEBUG
            printf( "Wrong Identifier: %x\r\n", RxCanMsg.Id );
#endif
          break;
        }
      }
      if(CAN_ReceiveMessage(CAN_VAJRX_MSGOBJ, TRUE, &RxCanMsg)){
        switch( RxCanMsg.Id ){
           case 0x221:
            memcpy( &fTempValue[1], RxCanMsg.Data, 4);
          break;
          default:
#ifdef DEBUG
            printf( "Wrong Identifier: %x\r\n", RxCanMsg.Id );
#endif
          break;
        }
      }
      if(CAN_ReceiveMessage(CAN_VAIRX_MSGOBJ, TRUE, &RxCanMsg)){
        switch( RxCanMsg.Id ){
           case 0x222:
            memcpy( &fTempValue[2], RxCanMsg.Data, 4);
          break;
          default:
#ifdef DEBUG
            printf( "Wrong Identifier: %x\r\n", RxCanMsg.Id );
#endif
          break;
        }
      }
      if(CAN_ReceiveMessage(CAN_VAKRX_MSGOBJ, TRUE, &RxCanMsg)){
        switch( RxCanMsg.Id ){
           case 0x223:
            memcpy( &fTempValue[3], RxCanMsg.Data, 4);
          break;
          default:
#ifdef DEBUG
            printf( "Wrong Identifier: %x\r\n", RxCanMsg.Id );
#endif
          break;
        }
      }
      if(CAN_ReceiveMessage(CAN_CMDRX_MSGOBJ, TRUE, &RxCanMsg)){
#ifdef DEBUG
         printf( "Wrong Command from Module %x\r\n", RxCanMsg.Id );
#endif
      }
      if(CAN_ReceiveMessage(CAN_ALMRX_MSGOBJ, TRUE, &RxCanMsg)){
#ifdef DEBUG
        printf( "Alarm on Module %x\r\n", RxCanMsg.Id );
#endif
      }
     break;

    default:
      iFSM_Can = FSM_CAN_STUP;
    break;
  }
}