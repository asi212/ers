#ifndef CANIO_H
#define CANIO_H

extern "C"{
  #include "91x_lib.h"
}




class CCanIO{

  private:

    int iFSM_Can;
    int iFSM_SubCnt;  //Indexcounter f�r FSM

    float fTempValue[16];
    unsigned char cModules[20];

    /* buffer for receive messages */
    canmsg RxCanMsg;
    // buffer for transmitt messages
    canmsg TxCanMsg;

    /* used message object numbers */
    enum {
      CAN_ALMRX_MSGOBJ = 0,
      CAN_VALRX_MSGOBJ = 1,
      CAN_VAHRX_MSGOBJ = 2,
      CAN_VAJRX_MSGOBJ = 3,
      CAN_VAIRX_MSGOBJ = 4,
      CAN_VAKRX_MSGOBJ = 5,
      CAN_CMDRX_MSGOBJ = 6,
      CAN_CMDTX_MSGOBJ = 7
    };


  public:
    CCanIO();
    void cycExec( int iT );
    float getExtTemp1(){ return (float)fTempValue[0]; };
    float getExtTemp2(){ return (float)fTempValue[1]; };
    float getExtTemp3(){ return (float)fTempValue[2]; };
    float getExtTemp4(){ return (float)fTempValue[3]; };
    float getExtTemp5(){ return (float)fTempValue[4]; };
    float getExtTemp6(){ return (float)fTempValue[5]; };
    float getExtTemp7(){ return (float)fTempValue[6]; };
    float getExtTemp8(){ return (float)fTempValue[7]; };
    float getExtTemp9(){ return (float)fTempValue[8]; };
    float getExtTemp10(){ return (float)fTempValue[9]; };
    float getExtTemp11(){ return (float)fTempValue[10]; };
    float getExtTemp12(){ return (float)fTempValue[11]; };
    float getExtTemp13(){ return (float)fTempValue[12]; };
    float getExtTemp14(){ return (float)fTempValue[13]; };
    float getExtTemp15(){ return (float)fTempValue[14]; };
    float getExtTemp16(){ return (float)fTempValue[15]; };


};


#endif