#include "CSetup.h"
#include "CChillerCom.h"
#include "CErrorNums.h"


#include <cstdlib>
#include <cstdio>
#include <cstring>

#define CR_CHAR 0x0D
#define LF_CHAR 0x0A


#define CMD_REQUEST_MACID       0
#define CMD_REQUEST_TEMP        2
#define CMD_REQUEST_OPMODE      3


extern CSetup * p_CSetup;
extern int MAC_Id;

/**Init pointers */
unsigned char * const CChillerCom::pRReg = (unsigned char*)(0x34000090);
unsigned char * const CChillerCom::pWReg = (unsigned char*)(0x34000091);
unsigned char * const CChillerCom::pISZ  = (unsigned char*)(0x34000092);
unsigned char * const CChillerCom::pOSZ  = (unsigned char*)(0x34000093);
unsigned char * const CChillerCom::pIBOX = (unsigned char*)(0x34000094);
unsigned char * const CChillerCom::pOBOX = (unsigned char*)(0x34000095);

/**
 Standard constructor
*/
CChillerCom::CChillerCom( void * pCallback, CEventManager * pEventManager ){
    ptNotifyIfcEvent = (bool(*)(CChillerCom::ifc_event, void*))pCallback;
    index = 0;
    bPacketReady = false;
    bNewValue = false;
    comStat = COM_IDLE;
    iTimerT2 = CMD_LOOP_PERIOD;
    m_pEventManager = pEventManager;
    m_IsActive = false;
    m_CommErrNum = ERR_CHILLER_COM;
    m_wasCooling = false;
    fTChiller = +999.0;
    binitialized = false;
    
    fTSetDualInt = +999.0;
    fTSetDualExt = 25.0;
    m_peerCom_Alive = false;
    m_peerSysStatus.SetTemp = fTSetDualExt;
    m_peerSysStatus.OperationMode = 0;
    m_peerSysStatus.ControlState  = 0;
    m_peerSysStatus.controller = true; // wait until communication has taken place or a timeout has occurred!
    m_peerSysStatus.MacId = 0;
    m_peerSysStatus.connectionState = 0;
    m_peerSysStatus.compressorOperation = 0;
    
    mySysStatus.OperationMode = 0;
    mySysStatus.ControlState = 0;
    mySysStatus.controller = false;
    mySysStatus.MacId  = 0;
    mySysStatus.connectionState = 0;
    mySysStatus.compressorOperation = 0;
    
    m_readyToSend = true;
    m_CmdSent = false;
    m_TXState = E_QSTATE_IDLE;
    m_RXState = E_QSTATE_IDLE;
    m_txIndex = 0;
    m_errorStatus = 0;
    m_nextCmd = CMD_REQUEST_MACID;
    m_opMode = 0;
}

void CChillerCom::Init( bool bActive )
{
    m_IsActive = bActive;
    if( m_IsActive )
    {
        m_pEventManager->AddEventHandler( CEventNames::compressor_status, CChillerCom::setCompressorEventWrapper, this );
        m_pEventManager->AddEventHandler( CEventNames::new_chiller_settemp, CChillerCom::new_chiller_settempEventWrapper, this );
        m_pEventManager->AddEventHandler( CEventNames::chuck_temp, CChillerCom::chuck_tempEventWrapper, this );
        m_pEventManager->AddEventHandler( CEventNames::new_chiller_mode, CChillerCom::new_chiller_modeEventWrapper, this );
        m_pEventManager->AddEventHandler( CEventNames::new_chiller_ctrl, CChillerCom::new_chiller_ctrlEventWrapper, this );
	  m_pEventManager->AddEventHandler( CEventNames::set_temp1_changed, CChillerCom::set_temp_1EventWrapper, this );
    }
    
    // Modify communication error number, if we are in a dual chiller system
    if ( p_CSetup->getConConfig() == CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600 )
    {
            m_CommErrNum = ERR_PEER_LOST;
    }
}

/**
    M�gliche Eventhandler f�r deie Chillerkommuikation
*/
void CChillerCom::new_chiller_settempEvent( float f )
{
  fTSet = f;
}

void CChillerCom::chuck_tempEvent( float f )
{
  fTAct = f;
}

void CChillerCom::new_chiller_modeEvent( char cMode )
{
    this->cMode = cMode;
}

void CChillerCom::new_chiller_ctrlEvent( int iMode )
{
  m_CtrlMode = iMode;
}

// TODO: Clarify, if we can use new_chiller_settempEvent instead
void CChillerCom::set_temp_1Event( float f )
{
	fTSetDualInt = f;
}

void CChillerCom::SetOperationControlMode(int opMode, int contState, int connstate, unsigned char compOp)
{
    mySysStatus.OperationMode = opMode;
    mySysStatus.ControlState = contState;
    mySysStatus.connectionState = connstate;
    mySysStatus.compressorOperation = compOp ; 
}
bool CChillerCom::cycExec( int ct )
{
      char controllerType = p_CSetup->getConConfig();
	
   
    // We send out commands with a defined timing
    iTimerT2--;
    if( iTimerT2 < 0 )
    {   if( controllerType == CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600 )
            iTimerT2 = CMD_LOOP_PERIOD;
        else
        {
           iTimerT2 = 3000;
        }
    }
    else
    {
        if((p_CSetup-> GetCoolingSubSys() ==  E_COOLING_SUBSYS_NONE)&&( iTimerT2 < 2500)) 
                iTimerT2 = 2750; // request only for Temperature.

        // In dual chiller mode, we dont send commands to external chiller
        // but we send the excange command to the other controller, respectively
        if ( controllerType == CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600 )
        {
            // Send one exchange command every 1000 ms (?)
            if ( iTimerT2==0 )                   
            {    
                while( msgQueue.size() > 0 ) msgQueue.pop();
                    m_readyToSend = true;
//                m_CmdSent = false; 
//                
                switch(m_nextCmd )
                {
                    case CMD_REQUEST_MACID:
                        GenRequestPeerMACId();
                    break;
                    
                    case CMD_REQUEST_TEMP:
                        genExchCmd( fTSetDualInt );
                     break;
                     
                    case  CMD_REQUEST_OPMODE:
                      GenRequestPeerOperationMode();
                    break;
                }                    
                iTimerT2=CMD_LOOP_PERIOD;
             }
        }
       else //send commands to external chiller
        {
          //Push cyclic commands to messageQueue;
        //Sendepuffer leeren bei COM- Timeout
            if( m_CommTOut )
            {
                while( msgQueue.size() > 0 ) msgQueue.pop();
            }    
          
            //Cyclic commands
            switch( iTimerT2 )
            {
                case 2500:
                    genTReaCmd();
                    if( m_opMode == 10)                       
                       iTimerT2 = 2400;
                break;
                
                case 2300:
                  if( m_opMode == 10) 
                  {
                        setCompressorEvent( true );
                        iTimerT2 = 2750;
                  }
                break;
                case 2250:
                    if( bInit )
                    {
                        genTSetCmd( -105.8 ); // Initialize Chiller 
                        setCompressorEvent( true );
                    } 
                break;
                case 2000:
                    genEReaCmd();
                break;
                
                case 1750:
                    genTActCmd();
                break;
    
                case 1500:
                    genIActCmd();
                break;
                           
                case 1250:
                    if( !bInit )
                    {
                      if( cMode == '4' || cMode == 'D' )
                      {
                        if( cMode == 'D') // Defrost Mode: Kompressor AUS, volle Kaltluft
                            genTSetCmd( -100.0 );
                        else 
                          genTSetCmd( -105.5 ); // Purge: Kompressor AUS, nicht sehr viel Luft.
                      }
                      else if(cMode == 'R' ) // Re-Initializing after Defrost or Purge
                      {
                        genTSetCmd( -105.8 ); // Initialize Chiller
                      }
                      else if( cMode == '6' || cMode == '7' ) // Dewpoint Warning = 6, Dewpoint Alarm = 7
                      {
                          if( cMode == 6)
                             genTSetCmd( -100.0 );
                          else
                            genTSetCmd( 90.0 ); // Dewpoint Alarm, nur volle Warmluft
                      }
                      else if( m_CtrlMode == 2 )
                      {
                        genTSetCmd( -100.0 );
                         m_wasCooling = true;
                      }
                      else if( m_CtrlMode == 1 )
                      {
                         m_wasCooling = false;
                         
                        if( fTAct <= 15.0 ){
                            genTSetCmd( 90.0 );
                        }
                        else{
                            genTSetCmd( 100.0 );
                        }            
                      }
                      else
                      {
                          if( fTSet >= 50.0 )
                          {
                            genTSetCmd( 100.0 );
                          }
                          else
                          {
                            if(m_wasCooling == true)
                            {
                              if(fTSet < 10.1 )
                                 m_wasCooling = false;
                              else if((fTAct - fTSet) < 0.5 )
                                m_wasCooling = false;
                            }
                            else
                                genTSetCmd( fTSet );
                          }
                      }
                      if( cMode== '4' || cMode == 'D' ) // Defrost and Purge
                          setCompressorEvent(false);
                      else
                         setCompressorEvent(true);                 
                  }
                break;          

                case 1000:
                    if( m_MErr == 0 )
                    {
                        genMSetCmd();
                    }
                break;
        
                case 750:
                    if( m_MErr != 0 )
                    {
                        genESetCmd();
                    }
                break;

                case 500:
                    genDReaCmd();
                break;
            
            }
        }        
    }
    if ( controllerType == CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600 )
      CoordinateCommunication(ct);
    else
      dataCommunication(ct);
    
    // If in dual-chiller mode, we now ensure, that the minimal set temperature limits 
    // are kept, dependent on set temperatures of both chillers (controllers)
    if ( controllerType == CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600 )
    {
          float minSetTemp;
          
          // The rules
          if( m_CommTOut )
          {
                minSetTemp = -60.0;
                m_peerSysStatus.SetTemp = 90.0; // allow us to switch off kompressor
                m_peerSysStatus.ControlState = 1; 
                m_peerSysStatus.controller = false;
                mySysStatus.controller = true;
                m_peerSysStatus.compressorOperation = 0;
          }
          else if (fTSetDualExt < -40.0) minSetTemp = 25.0;
          else if (fTSetDualExt < +25.0) minSetTemp = -40.0;
          else minSetTemp = -60.0;
          
          m_peerSysStatus.SetTemp  = fTSetDualExt;
          
          // Store result in user settings. This limits the setting of a new chuck temp
          // to the stored lower limit, which depends on set temp of other chuck
          if ( SysInit::m_usersettings.ChuckTempMinLimit != minSetTemp )
          {
                SysInit::m_usersettings.ChuckTempMinLimit = minSetTemp;
               // SysInit::SaveUserSettings(SysInit::GetUserSettings());
                
                // Inform system about changed limits
                _set_limits_EventArgument a;
                a.limitMax = SysInit::m_usersettings.ChuckTempMaxLimit;
                a.limitMin = SysInit::m_usersettings.ChuckTempMinLimit;							
                _event<_set_limits_EventArgument > e( "CChillerCom", CEventNames::set_limits_1, a );
                m_pEventManager->RaiseEvent(e);
          }
    }
    return true;
}
void  CChillerCom::dataCommunication(int ct)
{
     switch( comStat )
    {
        case COM_IDLE:
            index = 0;
        // Check if there are any request from slave
            if( ReadUARTChar() > 0 )
            {
                if( MsgRxBuf[0] == ENQ )
                {
                    SendUARTChar( ACK );
                    //comStat = COM_WASW;  It is unclear, why originally we jumped to COM_WASW here. If we are IDLE, we do not expect a chiller answer.
                    iTimerT1 = 2000;
                    index = 0;
                    comStat = COM_WCAS;
                    m_readyToSend = false;
                }
            }            
            else if( msgQueue.size() > 0)  //Check if ther is some information for the slave to send
            {    
                comStat = COM_SENQ;
            }
            else
                m_readyToSend = true;
         break;
        case COM_SENQ: // Send ENQ to chiller as start of our command
            SendUARTChar( ENQ );
            comStat = COM_WQAS;
            m_readyToSend = false;
            //Timeout for action 1 sec
            iTimerT1 = 1000;
        break;
        
        // Wait for ACK of chiller as reply to this ENQ
        case COM_WQAS:
            if( ReadUARTChar() > 0 )
            {
                if( MsgRxBuf[0] == ACK )
                {
                    index = 0;
                    comStat = COM_PCMD;
                    m_cntTOuts = 0;     //Answer received
                    if( m_CommTOut == true )
                    {
                        if( m_IsActive && binitialized )
                        {
                          //  _event<int> e("CChillerCom", CEventNames::reset_error, m_CommErrNum );
                          //   m_pEventManager->RaiseEventSync(e);
                                m_errorStatus = 3;
                        }
                        m_CommTOut = false;
                     }
                    m_peerCom_Alive = true;
                }
            }
            //Check for Timeout
            iTimerT1 -= ct;
            if( iTimerT1 < 0 )
            {
                comStat = COM_IDLE;
                if( m_cntTOuts++ > 10 )// Counting up Timeouts
                {
                    if( m_CommTOut == false )
                    {                      
                        if( m_IsActive && binitialized )
                        {
                          /*  _event<int> e("CChillerCom", CEventNames::set_error, m_CommErrNum );
                            m_pEventManager->RaiseEventSync(e);*/
                           m_errorStatus = 1;
                        }
                        m_CommTOut = true;
                        m_peerCom_Alive = false;
                    }
                }
            }
        break;
        
        case COM_PCMD: // Get next command to send
            strcpy( MsgTxBuf, msgQueue.front().msg.data());
            bIsCmd = msgQueue.front().wait;
            msgQueue.pop();
            comStat = COM_SCMD;
         break;
  
        case COM_SCMD: // Send command
            for( int i = 0; i < strlen(MsgTxBuf); i++ )
            {
                SendUARTChar(MsgTxBuf[i]);
            }
            iTimerT1 = 1000;
            bCmdAck = false;
            comStat = COM_WASW;
            index = 0;
        break;
    
        // Wait for chiller ACK to our command
        case COM_WASW:
            if( ReadUARTChar() > 0 )// Chiller has sent ACK, after receiving our command.
            {
                index = 0; // We dont test here on NAK!
                if( /*bCmdAck &&*/ bIsCmd )
                {
                    iTimerT1 = 1000;
                    comStat = COM_WENQ;
                }
                if( MsgRxBuf[0] == ACK ) //check if ACK was received
                {
                    index = 0;
                    bCmdAck = true;
                    if( !bIsCmd )
                    {
                        comStat = COM_IDLE;
                        m_readyToSend = true;
                    }
                }
            }
            //Check for Timeout
            iTimerT1 -= ct;
            if( iTimerT1 < 0 )
            {
                comStat = COM_IDLE;
            }
        break;
    
    // Wait for enquiry of chiller as start of reply to our command
        case COM_WENQ:
            if( ReadUARTChar() > 0 )
            {
                if( MsgRxBuf[0] == ENQ )
                {
                    index = 0;
                    SendUARTChar(ACK);
                    comStat = COM_WCAS;
                    iTimerT1 = 2000;
                }
            }
            //Check for Timeout
            iTimerT1 -= ct;
            if( iTimerT1 < 0 )
            {
                comStat = COM_IDLE;
                m_readyToSend = true;
            }
        break;
    
        // Continue receiving answer or request from chiller
        case COM_WCAS:
            if( ReadUARTChar() > 0 )
            {
                if( bPacketReady )
                {
                    InterpreteCmd();
                    bPacketReady = false;
                    SendUARTChar( ACK );
                    comStat = COM_IDLE;
                    m_readyToSend = true;
                } 
            }
            //Check for Timeout
            iTimerT1 -= ct;
            if( iTimerT1 < 0 )
            {
                comStat = COM_IDLE;
                m_readyToSend = true;
            }
        break;
    
        default:
            comStat = COM_IDLE;
            m_readyToSend = true;
        break;
    }

}

/*****************************************************************************************************************
* Method: CoordinateCommunication
*
* Description: Coordinates communication between the peer ports. 
*
* Input: None
* Output: None
* Return: None
*
* REMARKS: 
* This routine maanages simulitaneous transmission and receiving
*****************************************************************************************************************/

void CChillerCom::CoordinateCommunication(int ct)
{
    int bytes = ReadUARTByte();

    switch(m_RXState)
    {
        case E_QSTATE_IDLE:
           if( bytes > 0)
           {
             if( rx_char != LF_CHAR)
             {
                m_rxIndex = 1;
                MsgRxBuf[0] = STX;
                MsgRxBuf[m_rxIndex++] = rx_char;
                m_RXState =  E_QSTATE_RX_RECEIVING;
                iTimerT1  = 40000;//Timeout for action 1 sec ( equivalent to 100 bytes)
                
                m_cntTOuts = 0;     //Answer received
                if( m_CommTOut == true ) // if we had a timeout reset error!
                {
                    if( m_IsActive && binitialized )
                    {
                      m_errorStatus = 3;
                    }
                    m_CommTOut = false;
                }
             }
           }
           else if (m_CmdSent == true)
           {
                //Check for Timeout
                iTimerT1 -= ct;
                if( iTimerT1 < 0 )
                {
                    if( ++m_cntTOuts > 10 )// Counting up Timeouts
                    {
                        if( m_CommTOut == false )
                        {                      
                            if( m_IsActive && binitialized )
                            {
                                m_errorStatus = 1;
                                m_CommTOut = true;
                            }
                        }
                        m_CmdSent  = false;
                        iTimerT1  = 40000;//Timeout for action 1 sec ( equivalent to 100 bytes)
                        m_peerCom_Alive = false;
                        m_readyToSend = true;
                    }
                }
           }
  
        break;
        
        case E_QSTATE_RX_RECEIVING:
            if( bytes > 0 )
            {
                if( rx_char == LF_CHAR )
                {
                   MsgRxBuf[--m_rxIndex] = 0; // remove CR
                   m_rxIndex = 0;
                   m_RXState = E_QSTATE_IDLE;
                   m_CmdSent = false;
                   m_readyToSend = true;
                   InterpreteCmd();
                }
                else
                   MsgRxBuf[m_rxIndex++] = rx_char;
                
               iTimerT1 = 40000;  
            }
            else
            {
                 //Check for Timeout
                iTimerT1 -= ct;
                if( iTimerT1 < 0 )
                {
                    if( ++m_cntTOuts > 10 )// Counting up Timeouts
                    {
                        if( m_CommTOut == false )
                        {                      
                            if( m_IsActive && binitialized )
                            {
                                m_errorStatus = 1;
                                m_CommTOut = true;
                             }
                            m_peerCom_Alive = false;
                        }
                        m_CmdSent = false; 
                        m_readyToSend = true;
                        m_RXState = E_QSTATE_IDLE;
                    }
                }             
            }
        break;        
    }
     switch(m_TXState)
     {
        case E_QSTATE_IDLE:
             if( (msgQueue.size() > 0 )&&( m_CmdSent == false) )//Something to send
             {    
                strcpy( &MsgTxBuf[0], msgQueue.front().msg.data());
                msgQueue.front().wait;
                msgQueue.pop();
                m_txCount = strlen(MsgTxBuf);
                m_txIndex = 0;
                SendUARTChar( MsgTxBuf[m_txIndex++]);
                iTimerT1  = 40000;//Timeout for action 1 sec ( equivalent to 100 bytes)
                m_TXState = E_QSTATE_TX_SENDING;
                m_readyToSend = false;
             }
         break;
         case E_QSTATE_TX_SENDING:            
            if( m_txIndex < m_txCount )  
            {
                SendUARTChar(MsgTxBuf[m_txIndex++]);
            }
            else
            {
                iTimerT1 = 40000;
                m_TXState =  E_QSTATE_IDLE;
                m_txCount = 0;
                m_txIndex = 0;
                m_cntTOuts = 0;
                m_CmdSent = true;
            }          
        break;
     }
}
/**
    Build command for Compressor ON / OFF functionality and push
    the command to the queue
*/
void CChillerCom::setCompressorEvent( bool bStat )
{
    if( p_CSetup->getConConfig() != CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600 )
    {
        char msg[16];
        msg[0] = STX;
        msg[1] = 'S';
        msg[2] = 'F';
        msg[3] = 'K';
        msg[4] = bStat ? '1' : '0';
        msg[5] = 'B';
        msg[6] = '0';
        msg[7] = '0';
        msg[8] = '0';
        msg[11] = 0;
        FormatMessage( &msg[1], 8 );
        _msg s_msg;
        s_msg.wait = false;
        s_msg.msg = msg;
        msgQueue.push( s_msg );
    }
}

/**
    Build setChillerTAct Command
*/
void CChillerCom::genTActCmd( void  ){
    char msg[11];
    msg[0] = STX;
    msg[1] = 'S';
    msg[2] = 'C';
    int iValue = (int)(fTAct * 10.0);
    sprintf( &msg[3], "%+0.4d", iValue );
    msg[10] = 0;  //Terminate string
    FormatMessage( &msg[1], 7 );
    _msg s_msg;
    s_msg.wait = false;
    s_msg.msg = msg;
    msgQueue.push( s_msg );
}

/**
    Store actual temperature to local storage
*/
void CChillerCom::setI( float fTemp ){
    fIAct = fTemp;
}

/**
    return chiller temperature
*/
float CChillerCom::getTemp( void ){
    return fTChiller;
}

/**
    Build setChillerIAct Command
*/
void CChillerCom::genIActCmd( void  ){
    char msg[11];
    msg[0] = STX;
    msg[1] = 'S';
    msg[2] = 'I';
    int iValue = (int)(fIAct * 1000.0);
    if( iValue > 9999) iValue = 0;
    sprintf( &msg[3], "%+d", iValue );
    int iLen = strlen( &msg[1] );
    msg[10] = 0;  //Terminate string
    FormatMessage( &msg[1], iLen );
    _msg s_msg;
    s_msg.wait = false;
    s_msg.msg = msg;
    msgQueue.push( s_msg );
}

/**
    Build Chiller setMode command
*/
void CChillerCom::genMSetCmd(void){
    char msg[10];
    msg[0] = STX;
    msg[1] = 'S';
    msg[2] = 'M';
    msg[3] = cMode;
    FormatMessage( &msg[1], 3 );
    _msg s_msg;
    s_msg.wait = false;
    s_msg.msg = msg;
    msgQueue.push( s_msg );
}


/**
    Set Controller Error
*/
void CChillerCom::setMErr( unsigned char cError ){
    m_MErr = cError;
}

/**
    Build Chiller setMode command
*/
void CChillerCom::genESetCmd(void)
{
    char msg[10];
    msg[0] = STX;
    msg[1] = 'S';
    msg[2] = 'E';
    msg[3] = m_MErr;
    FormatMessage( &msg[1], 3 );
    _msg s_msg;
    s_msg.wait = false;
    s_msg.msg = msg;
    msgQueue.push( s_msg );
}

/**
    Build Read Temperature Command
*/
void CChillerCom::genTReaCmd( void ){
    char msg[10];
    msg[0] = STX;
    msg[1] = 'R';
    msg[2] = 'T';
    FormatMessage( &msg[1], 2 );
    _msg s_msg;
    s_msg.wait = true;
    s_msg.msg = msg;
    msgQueue.push( s_msg );
}

void CChillerCom::genTSetCmd( float fTemp  ){
    char msg[11];
    msg[0] = STX;
    msg[1] = 'S';
    msg[2] = 'T';
    int iValue = (int)(fTemp * 10.0);
    sprintf( &msg[3], "%+0.4d", iValue );
    msg[10] = 0;  //Terminate string
    FormatMessage( &msg[1], 7 );
    _msg s_msg;
    s_msg.wait = false;
    s_msg.msg = msg;
    msgQueue.push( s_msg );  
}


/**
Generate Error Read Command
*/
void CChillerCom::genEReaCmd( void ){
    char msg[10];
    msg[0] = STX;
    msg[1] = 'R';
    msg[2] = 'E';
    FormatMessage( &msg[1], 2 );
    _msg s_msg;
    s_msg.wait = true;
    s_msg.msg = msg;
    msgQueue.push( s_msg );
}

/**
    Build DewPoint Read Command
*/
void CChillerCom::genDReaCmd( void ){
    char msg[10];
    msg[0] = STX;
    msg[1] = 'R';
    msg[2] = 'D';
    FormatMessage( &msg[1], 2 );
    _msg s_msg;
    s_msg.wait = true;
    s_msg.msg = msg;
    msgQueue.push( s_msg );
}

/********** BEGIN DUAL CHILLER COMMANDS AND REQUESTS ******************************/

void CChillerCom::genExchCmd( float fTemp )
{
    char msg[16];
//    if( fTSetDualInt != fTemp) // only when different
    if(m_readyToSend)     
    {
        fTSetDualInt = fTemp;
        msg[0] = 'P';
        msg[1] = 'X';
        int iValue = (int)(fTemp * 10.0);
        sprintf( &msg[2], "%+0.4d", iValue );
        FormatMessageCRLF( &msg[0],7 );
        _msg s_msg;
        s_msg.wait = true;
        s_msg.msg = msg;
        msgQueue.push( s_msg );
        m_readyToSend = false;
    }
}

void CChillerCom::genExchRpl( float fTemp )
{
    char msg[16];
    msg[0] = 'R';
    msg[1] = 'X';
    int iValue = (int)(fTemp * 10.0);
    sprintf( &msg[2], "%+0.4d", iValue );
    FormatMessageCRLF( &msg[0], 7 );
    _msg s_msg;
    s_msg.wait = false;
    s_msg.msg = msg;
    msgQueue.push( s_msg );
    m_readyToSend = false;
}

/******************************************************************************************
* Method: GenRequestPeerMACId
*
* Description: Requests for Peer MACID which is the sum of the lowest 2 octets. eg. 00:50:C2:D9:7F:6B
*              7F + 6B = (127+107 =  234)
*                   
* Input: None
* Returns: None
* 
* Remarks: The MACId is used to determine the MASTER Controller. The Master controller has the right
*          to switch OFF Chiller Compressor etc
*          
*******************************************************************************************/
void CChillerCom::GenRequestPeerMACId(void)
{
   if(m_readyToSend)
   {
        char msg[10];
        msg[0] = 'P';
        msg[1] = 'I';
        sprintf( &msg[2], "%+0.3d", MAC_Id );
        FormatMessageCRLF( &msg[0], 6 );
        _msg s_msg;
        s_msg.wait = false;
        s_msg.msg = msg;
        msgQueue.push( s_msg );
        m_readyToSend = false;
   }  
}
/******************************************************************************************
* Method: GenResponsePeerMACId
*
* Description: Requests for Peer MACID which is the sum of the lowest 2 octets. eg. 00:50:C2:D9:7F:6B
*              7F + 6B = (127+107 =  234)
*                   
* Input: None
* Returns: None
* 
* Remarks: The MACId is used to determine the MASTER Controller. The Master controller has the right
*          to switch OFF Chiller Compressor etc
*          
*******************************************************************************************/
void CChillerCom::GenResponsePeerMACId(void)
{
   if(m_readyToSend)
   {
        char msg[10];
        msg[0] = 'R';
        msg[1] = 'I';
        msg[2] = mySysStatus.connectionState | 0x030;
        sprintf( &msg[3], "%+0.3d", MAC_Id );
        FormatMessageCRLF( &msg[0],7 );
        _msg s_msg;
        s_msg.wait = false;
        s_msg.msg = msg;
        msgQueue.push( s_msg );
        m_readyToSend = false;
   }  
}
/******************************************************************************************
* Method: GenRequestPeerChuckTemp
*
* Description: Requests for Peer Chuck temperature.
*                   
* Input: None
* Returns: None
* 
* Remarks: This Temperature is used to determine the amount of maximum cold air used for
*          cooling
*******************************************************************************************/
void CChillerCom::GenRequestPeerChuckTemp(void)
{
   if(m_readyToSend)
   {
        char msg[10];
        msg[0] = 'P';
        msg[1] = 'C';
        FormatMessageCRLF( &msg[0], 2 );
        _msg s_msg;
        s_msg.wait = true;
        s_msg.msg = msg;
        msgQueue.push( s_msg );
        m_readyToSend = false;
   }
}
/******************************************************************************************
* Method: GenResponsePeerChuckTemp
*
* Description: Response to Peer Chuck temperature request.
*                   
* Input: ChuckTemperature
* Returns: None
* 
* Remarks: This Temperature is used to determine the amount of maximum cold air used for
*          cooling
*******************************************************************************************/
void CChillerCom::GenResponsePeerChuckTemp(float fTemp)
{
    char msg[11];
    msg[0] = 'R';
    msg[1] = 'C';
    int iValue = (int)(fTemp * 10.0);
    sprintf( &msg[2], "%+0.4d", iValue );
    FormatMessageCRLF( &msg[0], 7 );
    _msg s_msg;
    s_msg.wait = true;
    s_msg.msg = msg;
    msgQueue.push( s_msg );
    m_readyToSend = false;
    
}
/******************************************************************************************
* Method: GenRequestPeerOperationMode
*
* Description: Requests for Peer Operation Mode
*                   
* Input: None
* Returns: None
* 
* Remarks: This mode is used to determine the amount of maximum cold air used for
*          cooling
*******************************************************************************************/
void CChillerCom::GenRequestPeerOperationMode( void)
{
    
   if(m_readyToSend)
   {
        char msg[10];
        msg[0] = 'P';
        msg[1] = 'O';
        msg[2] =  mySysStatus.OperationMode | 0x30;
        msg[3] =  mySysStatus.ControlState | 0x30;
        msg[4] =  mySysStatus.compressorOperation | 0x030;        
        FormatMessageCRLF( &msg[0],5 );
        _msg s_msg;
        s_msg.wait = true;
        s_msg.msg = msg;
        msgQueue.push( s_msg );
        m_readyToSend = false;
   }

}
/******************************************************************************************
* Method: GenResponsePeerOperationMode
*
* Description: Response to Peer Operation Mode
*                   
* Input: None
* Returns: None
* 
* Remarks: This mode is used to determine the amount of maximum cold air used for
*          cooling
*******************************************************************************************/
void CChillerCom::GenResponseOperationMode(void)
{
    char msg[10];
    msg[0] = 'R';
    msg[1] = 'O';
    msg[2] =  mySysStatus.OperationMode | 0x30;
    msg[3] =  mySysStatus.ControlState | 0x30;
    msg[4] =  mySysStatus.compressorOperation | 0x30;

    FormatMessageCRLF( &msg[0],5 );
    _msg s_msg;
    s_msg.wait = true;
    s_msg.msg = msg;
    msgQueue.push( s_msg );
    m_readyToSend = false;
    
}
/******************************************************************************************
* Method: GenKeepAlive
*
* Description: Sends a Keep Alive message with Operation Mode and Control Status 
*                   
* Input: Operation Mode, Control status
* Returns: None
* 
* Remarks: This mode is used to determine the amount of maximum cold air used for
*          cooling
*******************************************************************************************/
/*
void CChillerCom::GenKeepAlive(int opMode, int contState )
{
    char msg[10];
   
    if(m_readyToSend)
    {
        mySysStatus.OperationMode = opMode;
        mySysStatus.ControlState  = contState;
        
        msg[0] = 'P';
        msg[1] = 'A';
        msg[2] = opMode | 0x30;
        msg[3] = contState | 0x30;
        FormatMessageCRLF( &msg[1],3);
        _msg s_msg;
        s_msg.wait = true;
        s_msg.msg = msg;
        msgQueue.push( s_msg ); 
       m_readyToSend = false;
    }   
}
*/
/******************************************************************************************
* Method: GenKeepAlive
*
* Description: Sends a Keep Alive message with Operation Mode and Control Status 
*                   
* Input: Operation Mode, Control status
* Returns: None
* 
* Remarks: This mode is used to determine the amount of maximum cold air used for
*          cooling
*******************************************************************************************/
/*
void CChillerCom::GenKeepAliveResponse(void)
{
    char msg[10];
    msg[0] = 'R';
    msg[1] = 'A';
    msg[2] = mySysStatus.OperationMode | 0x30;
    msg[3] = mySysStatus.ControlState | 0x30;
    FormatMessageCRLF( &msg[1],3);
    _msg s_msg;
    s_msg.wait = true;
    s_msg.msg = msg;
    msgQueue.push( s_msg ); 
   m_readyToSend = false;
}
*/

/********** END DUAL CHILLER COMMANDS AND REQUESTS ******************************/

void CChillerCom::InterpreteCmd(){
    int iTemp = 0;
    //check for valid start frame mark
    if( MsgRxBuf[0] == STX )
    {        
        switch(MsgRxBuf[1])  
        {
            case 'T': // Answer to RT command
                iTemp = atoi(&MsgRxBuf[3]);
                fTChiller = iTemp / 10.0;
            break;
            
            case 'E': // Answer to RE command
                m_Error = atoi(&MsgRxBuf[2]);
            break;
   
            case 'S':// Chiller initiated command
                m_CMode = atoi(&MsgRxBuf[3]);
                if( m_CMode == 3 || m_CMode == 7 )
                {
                    int iTemp = 3;
                    ptNotifyIfcEvent( CChillerCom::NEW_MODE, (void*)&iTemp );
                }
            break;
     
            case 'D': // Answer to RD command
                fDewPoint = (float)atoi(&MsgRxBuf[3]) / 100.0;
                ptNotifyIfcEvent( CChillerCom::NEW_DPOINT, (void*)&fDewPoint );
            break;
            
            //case 'X':// RX command of chiller. This will only be sent in dual chiller systems
                //fTSetDualExt = (float)atoi(&MsgRxBuf[2]) / 10.0;
            //break;
			
            case 'P':
                switch(MsgRxBuf[2])
                {  
//                    case 'A':
//                        GenKeepAliveResponse();
//                        m_peerCom_Alive = true;
//                    break;  
                    
                    case 'X': 
                        fTSetDualExt = (float)atoi(&MsgRxBuf[3]) / 10.0;
                        m_peerSysStatus.SetTemp = fTSetDualExt;
                        genExchRpl( fTSetDualInt );
                    break;
                   
                    case 'O':
                       GenResponseOperationMode();
                       m_peerSysStatus.OperationMode = MsgRxBuf[3]  - 0x30; // remove the ASCII Part
                       m_peerSysStatus.ControlState  = MsgRxBuf[4] - 0x30;// remove the ASCII part.
                       m_peerSysStatus.compressorOperation = MsgRxBuf[5] - 0x30;
                    break;  
                    
                    case 'I':
                         GenResponsePeerMACId();
                   break;
                    
                }
            break;
           
            // We got a spontaneous request from an external chiller or controller
            case 'R':
                switch(MsgRxBuf[2])
                {  
//                    case 'A': // Response to KeepAlive Message
//                      m_peerSysStatus.OperationMode = atoi(&MsgRxBuf[3]);
//                      m_peerSysStatus.ControlState  = atoi(&MsgRxBuf[4]);
//                      m_readyToSend = true;
//                    break;  
                    
                    case 'X': // Response to SetTemp.
                        fTSetDualExt = (float)atoi(&MsgRxBuf[3]) / 10.0;
                        m_peerSysStatus.SetTemp = fTSetDualExt;
                        m_readyToSend = true;
                        m_nextCmd = CMD_REQUEST_OPMODE;
                    break;
                   
                    case 'O': // Response to Operation Mode
                       m_peerSysStatus.OperationMode = MsgRxBuf[3]  - 0x30; // remove the ASCII Part
                       m_peerSysStatus.ControlState  = MsgRxBuf[4] - 0x30;// remove the ASCII part.
                       m_peerSysStatus.compressorOperation = MsgRxBuf[5] - 0x30;
                       m_readyToSend = true;
                       m_nextCmd =CMD_REQUEST_MACID;
                    break;  
                    
                   case  'I': 
                      m_peerSysStatus.connectionState = MsgRxBuf[3] - 0x30;
                      m_peerSysStatus.MacId = atoi(&MsgRxBuf[4]);
                      if((MAC_Id <  m_peerSysStatus.MacId)&&(m_peerSysStatus.connectionState == 0))
                      {
                            m_peerSysStatus.controller = false;
                            mySysStatus.controller = true;
                      }
                      else
                      {
                            m_peerSysStatus.controller = true;
                            mySysStatus.controller =false;
                       
                      }
                       m_readyToSend = true;
                       m_nextCmd = CMD_REQUEST_TEMP;
                }
           break;
        }
    }
}

/**
    Copy from Patrick
*/
int CChillerCom::FormatMessage( char *msg, int len )
{
 	unsigned char crc = STX;

	msg[len++] = ETX;

	for( int i = 0; i < len; i++)
	{
		crc ^= msg[i];
	}

    msg[len++] = (char)crc;   
    msg[len++] = 0;

    return len;
}

int CChillerCom::FormatMessageCRLF( char *msg, int len )
{
    msg[len++] = CR_CHAR; // 0x0D
    msg[len++] = LF_CHAR; // 0x0A
    msg[len++] = 0;
    
    return len;
}

/**
    Read characters from UART and return command length
*/
int CChillerCom::ReadUARTChar( void ){
  for( ; *pISZ > 0; index++){
    *pRReg = 1;         //pop char from input fifio
    waitForFGPARx();    //wait until char is ready
    //additionaly safety for index checking
    if( index >= BUF_SIZE ){
      index = BUF_SIZE-1;
    }
    MsgRxBuf[index] = *pIBOX;  //store char to Input Message Buffer
    if( MsgRxBuf[index] == ETX && comStat == COM_WCAS){   //ETX marks communication frame end
      bPacketReady = true;
    }
  }

  return index;
}

int CChillerCom::ReadUARTByte( void )
{
    int ret_cnt = 0;
    if( *pISZ > 0)
    {
        *pRReg = 1;         //pop char from input fifio
        waitForFGPARx();    //wait until char is ready
        rx_char = *pIBOX;
        ret_cnt = 1;
    }
  return  ret_cnt;
}

int CChillerCom::SendUARTChar( char ch){
  *pOBOX = ch;
  *pWReg = 1;
  waitForFGPATx();
  return EDC_OK;
}

void CChillerCom::setInit( bool bInit ){
    this->bInit = bInit;
}


#pragma optimize=none
void CChillerCom::waitForFGPARx(void){
  //Problems with constant pointer, is optimized to nonsens from the compiler
  while( (unsigned char)0x01 == (unsigned char)(*pRReg));
}
#pragma optimize=none
void CChillerCom::waitForFGPATx(void){
  //Problems with constant pointer, is optimized to nonsens from the compiler
  while( (unsigned char)0x01 == (unsigned char)(*pWReg));
}



