#ifndef CHILLER_COM_H
#define CHILLER_COM_H

#include "../ComManager/CQueue.h"
#include "../MailboxSystem/CEventManager.h"
#include "CErrorNums.h"
#include "sysinit.h"


#include <string>

//return codes
#define EDC_OK 0
#define EDC_FAIL 1
#define EDC_WAIT 3
#define BUF_SIZE  80 // 256

#define STX  0x02
#define ETX  0x03
#define ENQ  0x05
#define ACK  0x06
#define NACK 0x15
#define cCAN 0x18
#define _CR  0x13
#define _LF  0x10

#define CMD_LOOP_PERIOD	500

struct _msg{
    bool wait;
    string msg;
};

typedef enum
{
    E_QSTATE_IDLE,       // Transmit or Receive STATE is Idle
    E_QSTATE_RX_STX,     // Waiting for STX code. Peer sending data after acknowledge has been sent
    E_QSTATE_RX_DATA,    // Receiving Data  
    E_QSTATE_RX_CRC,     // expecting Checksum
    E_QSTATE_TX_ENQ_ACK, // Sent ENQ expecting ACK
    E_QSTATE_TX_DATA,     // transmitting data
    E_QSTATE_TX_ACK,      // Acknowledging our Transmission
    E_QSTATE_RX_RECEIVING,
    E_QSTATE_TX_SENDING
}E_ENQACK_CMD_STATE; 
/**
Class for Communication according to LIEB- Standard
*/
class CChillerCom{

    public:
        enum ifc_event{
            NEW_MODE,   //Set Chuck active mode
            NEW_DPOINT  //New DewPoint offset received from Chiller          
        };
                                
    private:
        //States of the communication to the chiller
        enum _com_stat{
          COM_IDLE,     //Idle
          COM_SENQ,     //Send ENQ
          COM_WQAS,     //Wait for ENQ Answer
          COM_RACK,     //Received Acknowledg
          COM_PCMD,     //Prepare command to chiller
          COM_SCMD,     //Send command to chiller
          COM_WASW,     //Wait for chiller answer
          COM_WENQ,     //Wait for chiller ENQ for Comand anser
          COM_WCAS,     //Wait for command Answer
	    COM_WREQ,     //Wait for a chiller request, not a answer to a command
	    COM_GCMD	//Wait for chiller command
        };
        
  

        //Phsical chiller interface addresses    
        static unsigned char * const pRReg;
        static unsigned char * const pWReg;
        static unsigned char * const pISZ;
        static unsigned char * const pOSZ;
        static unsigned char * const pIBOX;
        static unsigned char * const pOBOX;
        
        _com_stat comStat;
        CQueue<_msg> msgQueue;       //Message Queue for Chiller messages
        
        E_ENQACK_CMD_STATE m_TXState;
        E_ENQACK_CMD_STATE m_RXState;
        int count;
        char rx_char;
        char m_rxCRC;
        int index;
        int m_txIndex;
        int m_rxIndex;
        int m_txCount;
        int iTimerT1;               //TCon Timeout timer
        int iTimerT2;               //TCyc Timer
        int m_cntTOuts;             //Counter for timeouts
        bool m_CommTOut;            //Chiller konnte nicht gefunden werden
	  int m_CommErrNum;		//Error number of comm error. Depends on controller type
        int m_nextCmd;
        
        char MsgRxBuf[BUF_SIZE];
        char MsgTxBuf[BUF_SIZE];
        bool bPacketReady;
        bool bNewValue;
        
        bool bIsCmd;                //Is Command with expeced answer
        bool bCmdAck;               //Command to Chiller acknowledged
        
        bool bInit;                 //Chiller is in initialize mode, ignore tem commands
                
        void waitForFGPARx(void);
        void waitForFGPATx(void);
        
        float fTAct;                //Storage for actual temperature
        float fTSet;                //Storage for set temperature
        float fIAct;                //Storage for actual current
        float fTChiller;            //Storage for chiller temperature
        float fDewPoint;            //Storage for chiller dewpont offset
        float fTSetDualExt;		//Storage for set temperature of other controller in dual chiller systems
        float fTSetDualInt;		//Storage for set temperature of this controller in dual chiller systems
        char cMode;                 //Storage for Chiller Mode
        char m_CMode;               //Sotrage for Mode from Chiller
        int m_Error;                //Storage for Chiller Error Code
        int m_CtrlMode;             // 
        bool binitialized;           //Chiller Initialisiert
        unsigned char m_MErr;       //Storage for Maste System Error Code
        bool m_IsActive;            //Legt fest ob das Chillermodul �berhaupt aktiv ist
        bool  m_wasCooling;         // cooling phase
        bool (*ptNotifyIfcEvent)( CChillerCom::ifc_event e, void * pParam );
        
        CEventManager * m_pEventManager;
        PeerSystemStatus  m_peerSysStatus;
        PeerSystemStatus  mySysStatus;
        bool m_peerCom_Alive;
        bool m_readyToSend;
        bool m_CmdSent;
        int m_errorStatus;
        int m_opMode;
        
    protected:
        void genTActCmd( void );
        void genIActCmd( void );
        void genTReaCmd( void );
        void genEReaCmd( void );
        void genDReaCmd( void );        	// generate Dew Point Read Message
        void genTSetCmd( float fTSet );
        void genCSetCmd( void );
        void genMSetCmd( void );
        void genESetCmd( void );
	  void genExchRpl( float fTemp );   // generate reply to dual chiller exchange message X
        
        int SendUARTChar( char ch );
        int ReadUARTChar( void );
        int ReadUARTByte( void );
        void InterpreteCmd( void );
        int FormatMessage( char *msg, int len );
        void dataCommunication(int ct);
        void CoordinateCommunication(int ct);
        int FormatMessageCRLF( char *msg, int len );

    public:
        CChillerCom( void * ptNotifyIfcEvent, CEventManager * pEventManager );
        void Init( bool bActive );
        bool cycExec( int ct );
        PeerSystemStatus GetPeerStatus(void){return m_peerSysStatus;};
        void GenRequestPeerChuckTemp(void);
        void GenResponsePeerChuckTemp(float fTemp);
        void GenRequestPeerOperationMode( void);
        void GenResponseOperationMode(void);
        void SetOperationControlMode(int opMode, int contState, int connState, unsigned char compOp);
//        void GenKeepAliveResponse(void);
        bool CommunicationAlive(void){return m_peerCom_Alive;};
        void GenRequestPeerMACId(void);
        void GenResponsePeerMACId(void);
      
        bool ReadyToSend(void){return m_readyToSend;};
 	  void genExchCmd( float fTemp );   // generate dual chiller exchange message RX
       
        float getTemp(void); //Temp solution to bypass INIT
        int getStatus(void);
        
        void setInitialized(bool b){binitialized = b;};
        bool getInitialized(void){return (m_IsActive && binitialized);};
        void setI( float fCurrent );
        void setInit( bool bInit );         		// switch class to init mode
        void setMErr( unsigned char cECode );   // Send Controller Error Code to chiller
				
        bool comErr( void ) { return m_CommTOut; };
        int getComErrNum( void ) { return m_CommErrNum; };
        int getErrorStatus(void) { return m_errorStatus;};
        void setErrorStatus(int status) { m_errorStatus = status;};
        void SetOperationMode(int mode ){m_opMode = mode;};
        // EventHandler
        static void setCompressorEventWrapper( void * pObject, bool b ){ ((CChillerCom*)pObject)->setCompressorEvent( b ); };
        void setCompressorEvent( bool bOn );
        static void new_chiller_settempEventWrapper( void * pObject, float f ){ ((CChillerCom*)pObject)->new_chiller_settempEvent( f ); };
        void new_chiller_settempEvent( float f );
        static void chuck_tempEventWrapper( void * pObject, float f ){ ((CChillerCom*)pObject)->chuck_tempEvent( f ); };
        void chuck_tempEvent( float f );
        static void new_chiller_modeEventWrapper( void * pObject, char c ){ ((CChillerCom*)pObject)->new_chiller_modeEvent( c ); };
        void new_chiller_modeEvent( char c );
        static void new_chiller_ctrlEventWrapper( void * pObject, int i ){ ((CChillerCom*)pObject)->new_chiller_ctrlEvent( i ); };
        void new_chiller_ctrlEvent( int i );
        static void controller_stableEventWrapper( void * pObject, bool b ){ ((CChillerCom*)pObject)->controller_stableEvent( b ); };
        void controller_stableEvent( bool b );
        static void set_temp_1EventWrapper( void * pObject, float f ){ ((CChillerCom*)pObject)->set_temp_1Event( f ); };
        void set_temp_1Event( float f );
        
        
        bool getError(){ return m_CommTOut;};  //Abfrage ob Chiller in Comm- Timeout ist
};
























#endif