#include "CChuckList.h"
#include "CFiles.h"

//#include "FS.h"

CEventManager* pEventManager;

/** Default constructor */
CChuckList::CChuckList(CEventManager * pEventManager)
{
	m_pEventManager = pEventManager;
	xList.cCurrChuck = 0;
}
/** Default constructor */
CChuckList::~CChuckList()
{
}

/** 
 * Chuck List Initialization
 * 
 * Loads chucklist from CHUCKLST.INI into class structure xList (of type _s_chuck_list)
 *
 * Because we dont know the size of the chuck list from beginning, pChucks is implemented as vector.
 * First, we read the number of entries, which is the first byte of the file
 * Then we read chuck entry for chuck entry, appending each to the vector
 */
void CChuckList::Init( void )
{	
	extern CFiles * p_CFiles;   // Pointer to CFiles object
	extern CSetup * p_CSetup;   // Pointer to CSetup object
	_s_chuck buffer;
	
	
	// Read number if chucklist entries from file
	char numListEntries = 0;
	int n = p_CFiles->ReadChuckList( &numListEntries, sizeof(char) , 0);
	if (n==0) numListEntries=0;  // Zero entries, if we did not read any byte from CHUCJLST.INI
	xList.cNumChucks = numListEntries;			
	xList.pChucks.reserve(numListEntries);
	
	xList.pChucks.clear();
	for (int i = 0; i<numListEntries; i++)
	{
		// Read one chuck entry from list and store in list vector
		p_CFiles->ReadChuckList( &buffer, sizeof(_s_chuck), sizeof(_s_chuck)*i+sizeof(char) );	
		xList.pChucks.push_back(buffer);
		
		// Try to find out, which chuck is currently configured. We store the corresponding list index in class var currChuck
		if (buffer.minTemp   == p_CSetup->getTempParamSet(1)->getMinLimit()  &&
				buffer.maxTemp   == p_CSetup->getTempParamSet(1)->getMaxLimit()  &&
				buffer.pid_set	 == p_CSetup->getPidSetNr()											 &&
				buffer.con_type  == p_CSetup->getConConfig() 										 &&
				buffer.air_table == p_CSetup->getAirTable()   )
		{
			xList.cCurrChuck = i;
		} 	
	}
}

void CChuckList::GetLabel( char* buf, int idx )
{
	if( (idx<0) || (idx>=xList.cNumChucks) ) 
	{	
		for (char c=0; c<MAX_LABEL_LEN; c++) buf[c] = '.';
	}
	else
	{
		for (char c=0; c<MAX_LABEL_LEN; c++) buf[c] = xList.pChucks[idx].label[c];
	}
}

void CChuckList::SetCurrChuck( char num ) 
{
	extern CSetup * p_CSetup;   // Pointer to CSetup object

	if( (num>=xList.cNumChucks) ) return;
	else
	{
		xList.cCurrChuck = num;
		
		// Set temperature limits corresponding to selected chuck
		p_CSetup->getTempParamSet(1)->setMinLimit(xList.pChucks[num].minTemp);
		p_CSetup->getTempParamSet(1)->setMaxLimit(xList.pChucks[num].maxTemp);

		// Inform system about changed limits
		_event<bool> e1( "CChuckList", CEventNames::reset_user_limits, true );
		m_pEventManager->RaiseEvent(e1);
		
		// Set PID-Set-Number corresponding to selected chuck
		p_CSetup->setPidSetNr(xList.pChucks[num].pid_set);

		// Set Air-Table-Number corresponding to selected chuck
		p_CSetup->setAirTable(xList.pChucks[num].air_table);
		
		// Set Controller Configuration
		p_CSetup->setConConfig(xList.pChucks[num].con_type);
		
		// Reload PID-Setup
		p_CSetup->readPIDSet(xList.pChucks[num].pid_set);
		
		// Write changed configuration to file
		p_CSetup->writeConfig();
	}
}
