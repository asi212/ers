#include "CDataContainers.h"
#include <cmath>
#include <cstdio>

#include "CEventManager.h"
#include "CErrorNums.h"
#include "..\ComManager\probercmds.h"

#define ErrorCount 100


const float CTempData::fIoVal = 0.0004;
const float CTempData::fFSRVal = (5.0/1.0)/0x7FFFFFFF;
const float CTempData::fFSR2ADC = (3.3)/0x0400;
const float CTempData::fOVLGAIN = 4.200;

extern CEventManager EventManager;

/**
  Constructor, intializing pointers und default values
*/
CTempData::CTempData(CSetup * pSetup)
{
  this->lP1Offsett = 0;
  this->lP2Offsett = 0;
  this->lP3Offsett = 0;
  this->lP4Offsett = 0;
  this->lROffsett = 0;
  this->pSetup = pSetup;
  iFSM_init = 0;
  lpP1_RVal = (long*)0x34000000;
  lpP1_VVal = (long*)0x34000004;
  lpP2_VVal = (long*)0x34000060;
  lpP3_VVal = (long*)0x34000064;
  lpP4_VVal = (long*)0x34000068;
  lpP5_IVal = (long*)0x3400000C;
  lpP5_SVal = (long*)0x34000010;
  lpP6_IVal = (long*)0x34000014;
  lpP6_SVal = (long*)0x34000018;
  ucCalReq = (unsigned char*)0x34000045;
  cpVerStrg = (char*)0x340000A0;
  resetErrors();
  iRIgnore = 10;
  
  for( int i = 0; i < 8; i++ ){
    //OS_CREATERSEMA(&sema_t[i]);
    iPTIgnore[i] = 10;
    
  }
  fT3Val = 0.0;
}

void CTempData::clearFilters(void){
  for( int i = 0; i < 50; i++ ){
    lR_FIR[i] = 0;
    for( int j = 0; j < 8; j++ ){
      lP_FIR[j][i] = 0x000FFFFF;
    }
  }
  fT5Val = 300.0;
}
/**
  cycCalc excuetes Cyclic calculations required in this class,
  please call this function periodicaly
  @param iCycleTime  used as base for all time related calculations
  @return always retungs true at the moment, for later use
*/
bool CTempData::cycCalc( int iCycleTime ){
  static int iCalc = 1;
  static int iInitDelay = 0;
  switch( iFSM_init ){

    case 0:
      if( iInitDelay++ > 25 ){
        iFSM_init = 1;
      }
      else{
        *ucCalReq = 0x00;
      }
    break;

    case 1:
      *ucCalReq = 1;
      iFSM_init_wcnt = 10;
      iFSM_init = 2;
    break;

    case 2:
      iFSM_init_wcnt -= iCycleTime;
      if( iFSM_init_wcnt < 0 ){
        iFSM_init_wcnt = 20;
        iFSM_init = 3;
        clearFilters();
      }
    break;

    case 3:
      iFSM_init_wcnt -= iCycleTime;
      //clacOffsets();
      if( iFSM_init_wcnt < 0 ){
        iFSM_init = 4;
      }
    break;

    case 4:
      *ucCalReq = 2;
      iFSM_init = 5;
    break;

    case 5:

    break;

    default:
      iFSM_init = 0;
    break;
  }

  if( iFSM_init < 5 ){
    return true;
  }

  //PT100 Calculation
  fT1Val = calcT( getP1Val());
  fT2Val = calcT( getP2Val() );
  fT3Val = calcT( getP3Val());
  fT4Val = calcT( getP4Val());
  fT5Val = calcT( getP5Val());
  fT6Val = calcT_KTY( getP6Val());
  fT7Val = calcT_KTY( getP7Val() );
  iCalc++;
  if( iCalc > 6 ){
    iCalc = 1;
  }

  if( iCalc <= 4 ){
    checkErrors( iCalc, 1  );
  }
  else if( iCalc == 5 ){
    checkErrors( iCalc, 2  );
  }
  else if( iCalc == 6 ){
    checkErrors( iCalc, 3  );
  }
  else if( iCalc == 7 )
  {
    checkErrors( iCalc, 4  );
  }

 return true;
}


/**
Calculate Temperatur to corespontig resistive PT100 value
*/
float CTempData::calcT( float r ){
  float R0 = 100.0;
  float A = 3.9083e-03;
  float B = -5.775e-07;
  //float C = -4.183e-12;
  float poly1 = -R0*A;
  float poly2 = pow(R0*A,2);
  float poly3 = poly2 - 4*R0*B*(R0-r);
  if( poly3 < 0.0 ) poly3 = 0.0;
  float poly_5 = sqrt( poly3 );
  float div = 2*R0*B;
  float t = ((poly1 + poly_5)/div);
  return t;
}

float CTempData::calcT_KTY( float R ){
  float Ro = 2000.0;
  float A = 0.00788;
  float B = 0.00001937;
  float Kt = R/Ro;
  float num = sqrt(A*A - 4.0*B + 4.0*B*Kt) - A;
  float div = 2.0*B;
  return 25.0 + num/div;
}

/**
Check for Erros on Temp Sensors
*/

void  CTempData::checkErrors( int iSensNum, int iChannelNum )
{
  long lIVal;
  long lSVal;
  float fTemp;
  
  switch( iSensNum ){
    case 1:
      fTemp = getTemp1();
    break;
    case 2:
      fTemp = getTemp2();
    break;
    case 3:
      fTemp = getTemp3();
    break;
    case 4:
      fTemp = getTemp4();
    break;
    case 5:
      lIVal = *lpP5_IVal;
      lSVal = *lpP5_SVal;
      fTemp = getTemp5();
    break;
    case 6:
      lIVal = *lpP6_IVal;
      lSVal = *lpP6_SVal;
      fTemp = getTemp6();
    break;
    default:
      //On invalid Sensor Number exit routine
     return;
  }

  if( isCalibrating() ){
    return;
  }


  if( sErrors[iSensNum-1].errors.cFlags == 0 ){
    //First Error Condition Wire Break for all serial connected 4 Wire sensors
    if( iSensNum < 5 && (abs(0.100 - getRVoltage())) > 0.01 ){
      if( sErrors[iSensNum-1].iDelayError-- <= 0 ){
        sErrors[iSensNum-1].errors.b.WireBreak = 1;
        if( iSensNum == 3 )
        {
            _event<int> e( "Temp Sensor", CEventNames::set_error, ERR_CHUCKCABLE );
            EventManager.RaiseEventSync(e);
        }
      }
    }
    //First Error Condition Wire Break for all 3 Wire sensors
    else if( iSensNum > 4 && ((lIVal - lSVal <= 0) || (lIVal >= 0x7FFFFE00) || (lIVal <= 0))){
      if( sErrors[iSensNum-1].iDelayError-- <= 0 ){
        sErrors[iSensNum-1].errors.b.WireBreak = 1;
      }
    }
    //Second Error Condition, Temperature below range
    else if( fTemp < (pSetup->getTempParamSet(iChannelNum)->getMinLimit() - 10.0) || !isnormal(fTemp)){
      if( sErrors[iSensNum-1].iDelayError-- <= 0 ){
        sErrors[iSensNum-1].errors.b.URange = 1;
        if( iSensNum == 6 )
        {
            _event<int> e( "Temp Sensor", CEventNames::set_error, ERR_INT_TEMP );
            EventManager.RaiseEventSync(e);
        }
        if( iSensNum == 3 )
        {
            _event<int> e( "Temp Sensor", CEventNames::set_error, ERR_UNDER_TEMP );
            EventManager.RaiseEventSync(e);
        }
        if( iSensNum == 7 )
        {
            _event<int> e( "Temp Sensor", CEventNames::set_error, ERR_BASE_SENSOR );
            EventManager.RaiseEventSync(e);
        }
      }
    }
    //third Error Condition, Temperature excedding range
    else if( fTemp > (pSetup->getTempParamSet(iChannelNum)->getMaxLimit() + 10.0) ){
      if( sErrors[iSensNum-1].iDelayError-- <= 0 ){
        sErrors[iSensNum-1].errors.b.ORange = 1;
        if( iSensNum == 6 )
        {
            _event<int> e( "Temp Sensor", CEventNames::set_error, ERR_INT_TEMP );
            EventManager.RaiseEventSync(e);
        }
        if( iSensNum == 3 )
        {
            _event<int> e( "Temp Sensor", CEventNames::set_error, ERR_OVER_TEMP );
            EventManager.RaiseEventSync(e);
        }
        if( iSensNum == 7 )
        {
            _event<int> e( "Temp Sensor", CEventNames::set_error, ERR_BASE_SENSOR );
            EventManager.RaiseEventSync(e);
        }
      }
    }
    //forth error, temperature is frozen, doensnt work on PT1000
    else if( fTemp == sErrors[iSensNum-1].fOldTemp && iSensNum != 5 ){
      if( sErrors[iSensNum-1].iDelayError-- <= 0 ){
        sErrors[iSensNum-1].errors.b.Hold = 1;
      }
    }
    else{
      sErrors[iSensNum-1].iDelayError = ErrorCount;
    }
  }

  sErrors[iSensNum-1].fOldTemp = fTemp;
}

/**
Reset Errors
*/
void CTempData::resetErrors(void){
  for( int i = 0; i < 8; i++ ){
    sErrors[i].iDelayError = ErrorCount;
    sErrors[i].errors.cFlags = 0;
  }
}

/**
  @return true if system is in calibration mode, false otherwise
*/
bool CTempData::isCalibrating(){
  if( iFSM_init < 5 ){
    return true;
  }
  else{
    return false;
  }
}

/**
Return resistance value of PT100 1 in Ohms
*/
float CTempData::getRVal(){
  float fR = fRVoltage / 0.001;
  return fR;
}


/**
Return resistance value of PT100 1 in Ohms
*/
float CTempData::getP1Val(){
  float fsr = (5.0/8.0)/0x7FFFFFFF;
  long lPVal_In =  *lpP1_VVal;
  if( (abs((float)(lPVal_In - lPVal[0])) < 700000 ) || iPTIgnore[0] < 1 ){ 
    lPVal[0] = clacFIR( lPVal_In, lP_FIR[0], 10 ) - (bNewVersion ? 0 : lP1Offsett);
    fP1Voltage = fsr * lPVal[0];
    if( abs((float)(lPVal_In - lPVal[0])) < 700000 ){
      iPTIgnore[0] = 10;
    }
  }
  else{
    iPTIgnore[0]--;
  }
  //Reference Resistor
  long lRValIn = *lpP1_RVal;
  if( (abs((float)(lRValIn - lRVal)) < 700000 ) || iRIgnore < 1 ){ 
    lRVal = clacFIR( lRValIn, lR_FIR, 20 ) - (bNewVersion ? 0 : lROffsett);
    fRVoltage = fsr * lRVal;
    if( abs((float)(lRValIn - lRVal)) < 700000 ){
      iRIgnore = 10;
    }
  }
  else{
    iRIgnore--;
  }
  
  float fR = ((float)lPVal[0]) * 100.0 / ((float)lRVal) * pSetup->getTempLinCorr(1) - pSetup->getTempOffset(1);
  return fR;
}

float CTempData::getP1Voltage(){
  return fP1Voltage;
}

float CTempData::getRVoltage(){
  return fRVoltage;
}

void CTempData::clacOffsets(void){
  lP1Offsett = clacFIR( *lpP1_VVal, lP_FIR[0], 10);
  lP2Offsett = clacFIR( *lpP2_VVal, lP_FIR[1], 10);
  lP3Offsett = clacFIR( *lpP3_VVal, lP_FIR[2], 10);
  lP4Offsett = clacFIR( *lpP4_VVal, lP_FIR[3], 10);
  lROffsett =  clacFIR( *lpP1_RVal, lR_FIR, 20 );
}
/**
Return resistance value of PT100 2 in Ohms
*/
float CTempData::getP2Val(){
  long lPValIn = *lpP2_VVal;
  if( (abs((float)(lPValIn - lPVal[1])) < 700000 ) || iPTIgnore[1] < 1 ){ 
    lPVal[1] = clacFIR( lPValIn, lP_FIR[1], 10 ) - (bNewVersion ? 0 : lP2Offsett);
    if( abs((float)(lPValIn - lPVal[1])) < 700000 ){
      iPTIgnore[1] = 10;
    }
  }
  else{
    iPTIgnore[1]--;
  }
    
  float fR = ((float)lPVal[1]) * 100.0 / ((float)lRVal) * pSetup->getTempLinCorr(2) - pSetup->getTempOffset(2);
  return fR;
}

/**
Return resistance value of PT100 3 in Ohms
*/
float CTempData::getP3Val(){
  long lPValIn = *lpP3_VVal;
	
  if( (abs((float)(lPValIn - lPVal[2])) < 700000 ) || iPTIgnore[2] < 1 ){ 
    lPVal[2]  = clacFIR( lPValIn, lP_FIR[2], 10 ) - (bNewVersion ? 0 : lP3Offsett);
    if( abs((float)(lPValIn - lPVal[2])) < 700000 ){
      iPTIgnore[2] = 10;
    }
  }
  else{
    iPTIgnore[2]--;
  }
  
  float fR = 0.0;
  
  if (lRVal != 0)  // Avoid division by zero!
  {
    fR = ((float)lPVal[2]) * 100.0 / (float)lRVal *  pSetup->getTempLinCorr(3)  - pSetup->getTempOffset(3);
  }
     
  
#if 0	

	#define NZEROS 2
	#define NPOLES 2
	#define GAIN   2.761148367e+02
	static float xv[NZEROS+1], yv[NPOLES+1];

	xv[0] = xv[1]; xv[1] = xv[2]; 
	xv[2] = lPValIn / GAIN;
	yv[0] = yv[1]; yv[1] = yv[2]; 
	yv[2] =   (xv[0] + xv[2]) + 2 * xv[1]
							 + ( -0.8371816513 * yv[0]) + (  1.8226949252 * yv[1]);
  float fR = (yv[2]) * 100.0 / (float)lRVal *  pSetup->getTempLinCorr(3)  - pSetup->getTempOffset(3);
				
#endif

  return fR;
}

/**
Return resistance value of PT100 4 in Ohms
*/
float CTempData::getP4Val(){
  long lPValIn = *lpP4_VVal;
  if( (abs((float)(lPValIn - lPVal[3])) < 700000 ) || iPTIgnore[3] < 1 ){ 
    lPVal[3] = clacFIR( lPValIn, lP_FIR[3], 10 ) - (bNewVersion ? 0 : lP4Offsett);
    if( abs((float)(lPValIn - lPVal[3])) < 700000 ){
      iPTIgnore[3] = 10;
    }
  }
  else{
    iPTIgnore[3]--;
  }

  float fR = ((float)lPVal[3]) * 100.0 / (float)lRVal * pSetup->getTempLinCorr(4) - pSetup->getTempOffset(4);
  return fR;
}



/**
  Return Temperature of PT100 1
*/
float CTempData::getTemp1(){
  float fTemp;
  fTemp = fT1Val;
  return  fTemp;
}

/**
  Return Temperature of PT100 2
*/
float CTempData::getTemp2(){
  float fTemp;
  fTemp = fT2Val;
  return  fTemp;
}

/**
  Return Temperature of PT100 3
*/
float CTempData::getTemp3(){
  float fTemp;
  fTemp = fT3Val;
  float f2 = getTemp2();
  float fdiff =  fTemp - f2; // fTemp is allways warmer than f2
  if( (fdiff > 0)&&(fdiff < 5.0) ) // must be a valid value.
  {
////        fTemp -= 0.94; // correct with just 2.15�C
  }
  
  return  fTemp;
}

/**
  Return Temperature of PT100 4
*/
float CTempData::getTemp4(){
  float fTemp;
  fTemp = fT4Val;
  return  fTemp;
}

/**
Return resistance value of PT100 5 in Ohms
*/
float CTempData::getP5Val(){
  long lRVal = clacFIR(*lpP5_IVal - *lpP5_SVal, lP_FIR[4], 50 ); // 10 statt 
  float fR = (float)lRVal * fFSRVal / fIoVal;
  fR *= pSetup->getTempLinCorr(5);
  fR += pSetup->getTempOffset(5);
  return fR;
}
/**
Return resistance value of PT100 6 in Ohms
*/
float CTempData::getP6Val(){
  float fR = ((float)*lpP6_IVal - (float)*lpP6_SVal) * fFSRVal / fIoVal;
  fR *= pSetup->getTempLinCorr(6);
  fR += pSetup->getTempOffset(6);
  return fR;
}

/**
  Return Temperature of PT100 5
*/
float CTempData::getTemp5(){
  float fTemp;
  fTemp = fT5Val;
  return  fTemp;
}

/**
  Return Temperature of PT100 6
*/
float CTempData::getTemp6(){
  float fTemp;
  fTemp = fT6Val;
  return fTemp;
}

/**
  Return Temperature of PT100 7
*/
float CTempData::getTemp7(){
  return fT7Val;
}

/**
  Return Temperature of PT100 8
*/
float CTempData::getTemp8(){
  return fT8Val;
}

/**
  Return Temperature of PT100 1
  @param bWithOffsett used for offsett calculation swith off / on
*/
float CTempData::getTemp1( bool bWithOffsett ){
  if( bWithOffsett == true ){
    return getTemp1();// - pSetup->getOffsetTable(1);
  }
  else{
    return getTemp1();
  }
}
/**
  Return Temperature of PT100 2
  @param bWithOffsett used for offsett calculation swith off / on
*/
float CTempData::getTemp2( bool bWithOffsett ){
  if( bWithOffsett == true ){
    return getTemp2();// - pSetup->getOffsetTable(2);
  }
  else{
    return getTemp2();
  }
}
/**************************************************************************************
  Return Temperature of PT100 3
  @param bWithOffsett used for offsett calculation swith off / on
  
* REMARKS:
* For a P12XL Prober where the customer uses his own compensation Table.
* Therefore the local table must be diactivated.
**************************************************************************************/
float CTempData::getTemp3( int iTable ){
  if( iTable <= 0 )
  {
    if((ProberCmdSet::GetProberCmdSet() == E_TELP12_OPTION )||(ProberCmdSet::GetProberCmdSet() == E_TELP8_OPTION) )
    {
        return (getTemp3() - ProberCmdSet::GetProberRevisionOffset());
    }
    else
        return getTemp3();
  }
  else
  {
  // PM 16.04.2012  return calcTOffset( getTemp3(), iTable );
      float solltemp = pSetup->getTempParamSet(1)-> getSetTemp();   
      float offset = CalculateTemperatureOffset(solltemp,iTable);
 
      return (getTemp3() - offset);
  }
}
/**
  Return Temperature of PT100 4
  @param bWithOffsett used for offsett calculation swith off / on
*/
float CTempData::getTemp4( bool bWithOffsett ){
  if( bWithOffsett == true ){
    return getTemp4();// - pSetup->getOffsetTable(4);
  }
  else{
    return getTemp4();
  }
}

/**
  Return Error Status of specific Temp- Sensor
*/

uTError CTempData::getTErrorStatus( int iSensNum ){
  return sErrors[iSensNum-1].errors;
}

/**
  FIR Filter function for Temperatur
*/
long CTempData::clacFIR( long lNewVal, long pFIR[10] ){
  long lOut = 0;
  for( int i = 10 - 1; i >= 0; i-- ){
    pFIR[i] = i > 0 ? pFIR[i-1] : lNewVal / 10;
    lOut += pFIR[i];
  }
  return lOut;
}

/**
  FIR Filter function for Temperatur
*/
long CTempData::clacFIR( long lNewVal, long * pFIR, int iFilterLen ){
  long lOut = 0;
  for( int i = iFilterLen - 1; i >= 0; i-- ){
    pFIR[i] = i > 0 ? pFIR[i-1] : lNewVal / iFilterLen;
    lOut += pFIR[i];
  }
  return lOut;
}

float CTempData::calcTOffset( float t, int table )
{
  _o_tab * pTable = pSetup->getOffsetTable(table);
  if( pTable != 0 )
  {
    //find number off valid table entries
    int entries = 0;
    for( ; entries < 20 && pTable->temp[entries] != 2222; entries++ );
    if( entries == 1 )
    { //If only 1 entry same offset for all temperatures
      return t - pTable->offsett[entries-1];
    }
    else
    {
      //find position in table
      int i = 0; 
      for ( ; i < entries && pTable->temp[i] < t; i++ );
      if( i == 0 )
      {
        return t - pTable->offsett[0];
      }
      else if( i >= entries)
      {
        return t - pTable->offsett[entries-1];
      }
      else
      {
        float divT = pTable->temp[i] - pTable->temp[i-1];
        float divO = pTable->offsett[i] - pTable->offsett[i-1];
        float multi = ( t - pTable->temp[i])/divT;
        return t - (divO * multi + pTable->offsett[i]);
      }
    }
  }
  else
  { //Invalid Table Number
    return t;
  }
}
/******************************************************************************
* Method: CalculateTemperatureOffset 
*
*  Input: 
*          Soll - SollTemperature
*          TableNum - Table number
*  Output:
*          Temperature offset 
* Remarks
*   The Temperature offset is between 0 and +/-9.9�C
*******************************************************************************/
float CTempData::CalculateTemperatureOffset( float soll, int tableNum )
{
    int entries = 0;
    float offset = 0.0;
    bool found = false;
    float tablesoll;
    int index = 0;
    
    _o_tab * pTable = pSetup->getOffsetTable(tableNum);
    
    if( pTable != 0 )
    {
        //find number off valid table entries
        for(int i= 0; i < 20; i++)
        {    
            if(pTable->temp[i] != OFFSET_UNINITIALIZED)
                entries++;
        }
        if( entries > 0)
        {
            for( index = 0; index < entries; index++ )
            {
                tablesoll = pTable->temp[index];
                if(tablesoll== soll )
                {
                         found = true;
                         break;
                }
                if( soll < tablesoll )
                        break;
            }

            if( ( found == true)||(index == 0)||(index == entries) )
            {
                    if( index ==  entries)
                        index--;

                   offset = pTable->offsett[index] - pTable->temp[index];
            }
            else
            {
                
               float delta1 = pTable->offsett[index-1] -  pTable->temp[index-1];
               float delta2 = pTable->offsett[index]   -  pTable->temp[index];
               float diff_offset = delta2 - delta1;

               float divisor  = pTable->temp[index] - pTable->temp[index-1];
               float multi  = soll -  pTable->temp[index-1];
                     offset  = delta1 + ( multi * diff_offset)/divisor;

            }  
        }
     }
    return offset;
}



/**Pointer to Valve Group 1 setpoint value native hex code*/
unsigned short * const CValvData::uValv1SetVal = (unsigned short*)(0x34000030);
unsigned short * const CValvData::uValv2SetVal = (unsigned short*)(0x34000032);

/**
  Default Constructor
*/
CValvData::CValvData(){
  fVal1Set = 0.0;
  fVal2Set = 0.0;
  iDelayError[0] = 0;
  iDelayError[1] = 0;
}

const float CValvData::fIPress10Cal = 0.0;
const float CValvData::fIPress1FCal = 106.35;
const float CValvData::fOPress10Cal = 0.0;
const float CValvData::fOPress1FCal = 3.545;

const float CValvData::fIPress20Cal = 0.0;
const float CValvData::fIPress2FCal = 106.35;
const float CValvData::fOPress20Cal = 0.0;
const float CValvData::fOPress2FCal = 3.545;

const int CValvData::iTimeOut = 20000;  //Timeout for Valves = 10 seconds
/**
  Execute Caclyc Calculations
  \return true if all calculations are done succuessfully
*/
bool CValvData::cycCalc( int iCycleTime ){
  checkErrors( iCycleTime );
  return true;
}

/**
 Check for errors on valve flow
*/
void CValvData::checkErrors( int iCycleTime )
{
   
    if ( fVal1Set > 10.0 && (getValv1InPress()/(fVal1Set * 3.0)) < 0.5) //50 % is OK
    { 
        if( iDelayError[0] < iTimeOut ){
          iDelayError[0] += iCycleTime;
        }
        else{
          uErros[0].b.bOutFlowLow = 1;
        }
    }
    else
    {
        uErros[0].cFlags = 0;
    }
    
    if ( fVal2Set > 10.0 && (getValv2InPress()/(fVal2Set * 3.0)) < 0.5) //50 % is OK
    {  
        if( iDelayError[1] < iTimeOut ){
          iDelayError[1] += iCycleTime;
        }
        else
        {
          uErros[1].b.bOutFlowLow = 1;
        }
    }
    else
    {
        uErros[1].cFlags = 0;
    }
}

/**
  Get valv input pressure
  @return valve pressure in bar
*/
float CValvData::getValv1InPress(){
  float fPress = (((float)getNativeValue(5) * getFSR_VAL()) - fIPress10Cal)*fIPress1FCal;
  return fPress;
}

/**
  Get valv output pressure
  @return valve pressure in bar
*/
float CValvData::getValv1OutPress(){
  float fPress = (((float)getNativeValue(4) * getFSR_VAL()) - fOPress10Cal)*fOPress1FCal;
  return fPress;
}

/**
  Set valv output pressure
  @param valve pressure in percent (0-100)
*/
void CValvData::setValv1Press( float fPress ){
  if( fPress > 100.0 ){
    fPress = 100.0;
  }
  else if (  fPress < 0.0  ){
    fPress = 0.0;
  }
  fVal1Set = fPress;
  long lTemp = (long)(fPress*655.35);
  *uValv1SetVal = (unsigned short)lTemp;
}

float CValvData::getValv1SetPress(){
  return fVal1Set;
}

/**
  Get valv input pressure
  @return valve pressure in bar
*/
float CValvData::getValv2InPress(){
  float fPress = (((float)getNativeValue(7) * getFSR_VAL()) - fIPress20Cal)*fIPress2FCal;
  return fPress;
}

/**
  Get valv output pressure
  @return valve pressure in bar
*/
float CValvData::getValv2OutPress(){
  float fPress = (((float)getNativeValue(6) * getFSR_VAL()) - fOPress20Cal)*fOPress2FCal;
  return fPress;
}

/**
  Set valv output pressure
  @param valve pressure in percent (0-100)
*/
void CValvData::setValv2Press( float fPress ){
  if( fPress > 100.0 ){
    fPress = 100.0;
  }
  else if (  fPress < 0.0  ){
    fPress = 0.0;
  }
  fVal2Set = fPress;
  long lTemp = (long)(fPress*655.35);
  *uValv2SetVal = (unsigned short)lTemp;
}

float CValvData::getValv2SetPress(){
  return fVal2Set;
}

uVError CValvData::getVErrorStatus( int iValve ){
  if( iValve > 0 && iValve <= 2 ){
    return uErros[iValve-1];
  }
  else{
#ifdef DEBUG
    printf( "Invalid Valve Number in Class CValveData Function getValvError" );
#endif
    uVError uTemp;
    uTemp.cFlags = 0;
    return uTemp;
  }
}
