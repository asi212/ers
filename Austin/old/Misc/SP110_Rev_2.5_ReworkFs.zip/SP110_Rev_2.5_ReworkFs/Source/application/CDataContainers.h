#ifndef CDATA_CONTAINERS_H
#define CDATA_CONTAINERS_H

#include "CSetup.h"
#define OFFSET_UNINITIALIZED 2222
/**
  Common Data Structres
*/
union uTError{
  unsigned char cFlags;
  struct {
    unsigned char
      WireBreak : 1,
      URange    : 1,
      ORange    : 1,
      Hold      : 1,
      : 4;
  } b;
};

#define FLAG_TERR_WIRE_BREAK 		0x01
#define FLAG_TERR_U_RANGE 			0x02
#define FLAG_TERR_O_RANGE 			0x04
#define FLAG_TERR_HOLD				 	0x08

/**
  Struct conataining all Informations required for one Temperatur Sensor Error
*/
struct sTError {
  uTError errors;
  float fOldTemp;
  int iDelayError;
};

 

/**
  Class CTempData contains all Information releted to temperature in the system.
*/
class CTempData{
  private:

    static const float fIoVal;
    static const float fFSRVal;

    static const float fFSR2ADC;
    static const float fOVLGAIN;

    const long * lpP1_RVal; //Pointer to Reference 100Ohm 5 Input Voltage
    const long * lpP1_VVal; //Pointer to PT100 2 Voltage
    const long * lpP2_VVal; //Pointer to PT100 2 Voltage
    const long * lpP3_VVal; //Pointer to PT100 3 Voltage
    const long * lpP4_VVal; //Pointer to PT100 4 Voltage
    const long * lpP5_IVal; //Pointer to PT100 5 Input Voltage
    const long * lpP5_SVal; //Pointer to PT100 5 Sense Voltage
    const long * lpP6_IVal; //Pointer to PT100 6 Input Voltage
    const long * lpP6_SVal; //Pointer to PT100 6 Sense Voltage
    const char * cpVerStrg; //Pointer to Version String

    unsigned char * ucCalReq; //Pointer to Calibration request address

    long lP1Val;
    long lP5Val;
    long lP6Val;
    long lP7Val;
    long lP8Val;

    long lRVal;

    float fT1Val;
    float fT2Val;
    float fT3Val;
    float fT4Val;
    float fT5Val;
    float fT6Val;
    float fT7Val;
    float fT8Val;

    float calcT( float fRPT100);
    float calcT_KTY( float R );   
    float lPVal[8];
    int iRIgnore;
    int iPTIgnore[8];
    
    CSetup * pSetup;
    //OS_RSEMA  sema_t[8];

    long lR_FIR[200];
    long lP_FIR[8][50];

    long clacFIR( long lNewVal, long pFIR[10] );
    long clacFIR( long lNewVal, long * pFIR, int iFilterLen );
    bool bNewVersion;

public:  //zum testen
    long lP1Offsett;
    long lP2Offsett;
    long lP3Offsett;
    long lP4Offsett;
    long lROffsett;
    int iFSM_init;
    int iFSM_init_wcnt;

  protected:
    bool cycCalc( int iCycleTime );

    sTError sErrors[8];
    void checkErrors( int iSensNum, int iChannelNum );
    void resetErrors(void);
    void clacOffsets(void);
    virtual short getNativeValue( int iValue ) = 0;
    
    float calcTOffset( float t, int table );
    float CalculateTemperatureOffset( float soll, int tableNum );

    float fP1Voltage;
    float fRVoltage;
    void clearFilters(void);

  public:
    CTempData(CSetup * pSetup);
    float getRVal();
    float getP1Val();   //Return PT100 1 resistance value
    float getP2Val();   //Return PT100 2 resistance value
    float getP3Val();   //Return PT100 3 resistance value
    float getP4Val();   //Return PT100 4 resistance value
    float getP5Val();   //Return PT100 5 resistance value
    float getP6Val();   //Return PT100 6 resistance value
    virtual float getP7Val() = 0;   //Return PT100 7 resistance value
    float getP8Val();   //Return PT100 8 resistance value
    virtual float getTemp1();
    virtual float getTemp2();
    virtual float getTemp3();
    virtual float getTemp4();
    virtual float getTemp5();
    virtual float getTemp6();
    virtual float getTemp7();  // Return KTY value of chuck base
    virtual float getTemp8();
    virtual float getTemp1( bool bWithOffsett );
    virtual float getTemp2( bool bWithOffsett );
    virtual float getTemp3( int iTable );
    virtual float getTemp4( bool bWithOffsett );
    float getP1Voltage();
    float getRVoltage();
    virtual bool isCalibrating();

    uTError getTErrorStatus( int iSensNum );


};


/**
  Struct containig all Information for Valve Error Message
*/
union uVError{
  unsigned char cFlags;
  struct{
    unsigned char 
      bInPressLow : 1,     //Flags for Lany Valve
      bOutPressLow: 1,     //Flag for Lany Valve
      bOutFlowLow : 1,     //Flag for Jucomatic Valve
      temp:5;
     }b;
};
    

/**
   Class CValvData contains all Informations related to the Valves
*/
class CValvData{

  private:

    static const float fIPress10Cal;
    static const float fIPress1FCal;
    static const float fOPress10Cal;
    static const float fOPress1FCal;
    static const float fIPress20Cal;
    static const float fIPress2FCal;
    static const float fOPress20Cal;
    static const float fOPress2FCal;
    static unsigned short * const uValv1SetVal;
    static unsigned short * const uValv2SetVal;
    static const int iTimeOut;

  protected:
    /**
      Abstract function getNativeValue
    */
    virtual float getFSR_VAL(void) = 0; //Multiplicator for Native Value to Voltage
    virtual short getNativeValue( int iValue ) = 0;
    bool cycCalc( int iCycleTime );
    float fVal1Set;
    float fVal2Set;
    uVError uErros[2];
    int iDelayError[2];
    void checkErrors( int iCycleTime );
    
  public:
    CValvData();
    virtual float getValv1InPress();
    virtual float getValv1OutPress();
    virtual void setValv1Press( float fPress );
    virtual float getValv1SetPress();

    virtual float getValv2InPress();
    virtual float getValv2OutPress();
    virtual void setValv2Press( float fPress );
    virtual float getValv2SetPress();
    
    virtual uVError getVErrorStatus( int iValve );

};



#endif