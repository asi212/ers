#include "CDataLogger.h"
#include <cstring>

/**
Constructor for CDataLogger, takes only pointer to CFilesInstace
*/
CDataLogger::CDataLogger(){
  iLoggerHead = 0;
  iLoggerTail = 0;
  iLoggerSize = 0;
}


void CDataLogger::addLogg( float i1, float i2, float i3, float i4){
  if( ++iLoggerHead >= NUM_ENTRIES ){
    iLoggerHead = 0;
  }
  currLog[iLoggerHead][0] = i1;
  currLog[iLoggerHead][1] = i2;
  currLog[iLoggerHead][2] = i3;
  currLog[iLoggerHead][3] = i4;
  if( iLoggerSize >= NUM_ENTRIES ){
    if( ++iLoggerTail >= NUM_ENTRIES ){
      iLoggerTail = 0;
    }
  }
  else{
    iLoggerSize++;
  }
}

/**
getEntry is picking one entry from the logger
*/
bool CDataLogger::getEntry( void * pBuff ){
  if( --iLoggerSize > 0 ){
    memcpy( pBuff, currLog[iLoggerTail++], 16 );
    if( iLoggerTail >= NUM_ENTRIES ){
      iLoggerTail = 0;
    }
    return true;
  }
  else{
    return false;
  }
}



  
  