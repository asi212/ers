#ifndef C_DATALOGGER_H
#define C_DATALOGGER_H

#define NUM_ENTRIES 250

class CDataLogger{
  protected:
    float currLog[NUM_ENTRIES+2][4];
    int iLoggerHead;
    int iLoggerTail;
    int iLoggerSize;
    
  public:
    CDataLogger();
    void addLogg( float i1, float i2, float i3, float i4);  //Add entry to logger storage
    bool getEntry( void * pBuff );
      
};



#endif