//***************************************************************************
//Kommunikationsroutine f�r Diagnoseinformationen
extern "C"{
  #include "91x_lib.h"
}

#include "CDiagCom.h"
#include "CProcessData.h"
#include "CUtils.h"
#include "PIDController.h"
#include "CFiles.h"
#include "SP110_aggregate.h"
#include "CChillerCom.h"
#include "Devices/CValve.h"
#include "Devices/CDewPointSensor.h"
#include "Devices/CLambda.h"

#include "../MailboxSystem/CEventManager.h"

#include <cstdio>
#include <cstring>

#define FSM_DIAG_IDLE 0

//return codes
#define EDC_OK 0
#define EDC_FAIL 1
#define EDC_WAIT 3

extern bool bSaveSetup;
extern CFiles * p_CFiles;
extern CChillerCom * p_ChillerCom;
extern CDewPointSensor * pDewPointSensor;
extern CLambda * p_Lambdas[6];

__no_init char exrecbuf[65535] @ "EXRAM";
__no_init char exsndbuf[65535] @ "EXRAM";
extern IPIDController * p_con1;
extern IPIDController * p_con2;
extern IPIDController * p_con3;
extern IPIDController * p_con4;
extern IPIDController * p_con5;
extern IPIDController * p_con6;
extern MODE mode;
extern CEventManager EventManager;
extern CLanyValve m_lany1;
extern CJoucomaticValve m_jouco1;
extern CJoucomaticValve m_jouco2;

/**Inti pointers */
volatile unsigned char * const CDiagCom::pRReg = (unsigned char*)(0x340000B0);
volatile unsigned char * const CDiagCom::pWReg = (unsigned char*)(0x340000B1);
volatile unsigned char * const CDiagCom::pISZ  = (unsigned char*)(0x340000B2);
volatile unsigned char * const CDiagCom::pOSZ  = (unsigned char*)(0x340000B3);
volatile unsigned char * const CDiagCom::pIBOX = (unsigned char*)(0x340000B4);
volatile unsigned char * const CDiagCom::pOBOX = (unsigned char*)(0x340000B5);

//Construktor
CDiagCom::CDiagCom( CSetup * pSetup, IProcessData * pPData ){
  this->pSetup = pSetup;
  this->pPData = pPData;
  iFSM_Diag = FSM_DIAG_IDLE;
  iSeqCnt_Rec = 0;
  iSeqCnt_Snd = 0;
  cRecSeq = exrecbuf;
  m_RecBufSize = sizeof( exrecbuf ) - 1;
  bWriteThrough = false;
}

/**
  analyse received command and process request
*/
bool CDiagCom::processPacket(void){
  static crc CRC;
  iLen = this->ReceivePacket(this->cRecSeq);
  if( iLen > 0 ){    
    unsigned short crc_cal = CRC.getCRC16( (unsigned char*)cRecSeq, iLen - 2 );
    unsigned short crc_rec = 0x0;
    if( iLen > 2 ){
        crc_rec |= cRecSeq[iLen-1];
        crc_rec |= cRecSeq[iLen-2]<<8;
    }
    else{
      crc_rec = 0;
      crc_cal = 1;
    }
    char * cMsg = exsndbuf;
    if( crc_rec == crc_cal ){
      cMsg[0] = 0x07;
      cMsg[1] = cRecSeq[1];
      iRepLen = processPacket( &cRecSeq[2], &cMsg[2], cRecSeq[1] ) + 4;
      unsigned short crc_req = CRC.getCRC16((unsigned char*)cMsg, iRepLen - 2);
      cMsg[iRepLen - 2] = (crc_req >> 8) & 0xff;
      cMsg[iRepLen - 1] = crc_req & 0xff;
      while( EDC_WAIT == this->SendByte( cMsg, iRepLen));
     }
    else{
      cMsg[0] = 0x07;
      cMsg[1] = cRecSeq[1] | 0x80;
      unsigned short crc_req = CRC.getCRC16((unsigned char*)cMsg, 2 );
      cMsg[2] = (crc_req >> 8) & 0xff;
      cMsg[3] = crc_req & 0xff;
      while( EDC_WAIT == this->SendByte( cMsg, 4));
    }
    return true;
  }
  else
  {
      return false;
  }
}

int CDiagCom::processPacket( char * cPacket, char * pRet, char cFC ){
  float fTemp;
  int iTemp;
  switch( cFC ){

    case 64:
      fTemp = processReadReqs( cPacket[0], cPacket[1] );
      memcpy( pRet, (char*)&fTemp, 4 );
      return 4;

    case 65:
      memcpy( (char*)&fTemp, &cPacket[2], 4 );
      processWriteReqs( cPacket[0], cPacket[1], fTemp );
      pRet[0] = 0x0;
      pRet[1] = 0x0;
      pRet[2] = 0x0;
      pRet[3] = 0x0;
      return 4;

    case 66:
      bSaveSetup = true;
      pRet[0] = 0x0;
      pRet[1] = 0x0;
      pRet[2] = 0x0;
      pRet[3] = 0x0;
      return 4;

    case 67:
      pRet[0] = processByteRReqs( cPacket[0], cPacket[1] );
      pRet[1] = 0x0;
      return 2;

    case 68:
      processByteWReqs( cPacket[0], cPacket[1], cPacket[2] );
      pRet[0] = 0x0;
      pRet[1] = 0x0;
      return 2;

     //Initalisiere Display Update
    case 69:
      bWriteThrough = true;
      pRet[0] = 0x0;
      pRet[1] = 0x0;
      return 2;

    //Initialisiere Software Update
    case 80:
      iLen = 0;
      strcpy( pRet, REV );
      iLen += strlen( REV );
      strcpy( (char*)&pRet[iLen], __DATE__ );
      iLen += strlen( __DATE__ );
      pRet[iLen++] = ' ';
      strcpy( (char*)&pRet[iLen], __TIME__ );
      iLen += strlen( __TIME__ ) + 2;
      return iLen;

    case 81:
      p_CFiles->initUpdate( (cRecSeq[4] << 8) + cRecSeq[5]  );
      pRet[0] = 0x0;
      pRet[1] = 0x0;
      return 4;

    case 82:
      iTemp = p_CFiles->downloadBlock( (cRecSeq[2] << 8) + cRecSeq[3], iLen - 6, &cRecSeq[4] );
      pRet[0] = (iTemp >> 8) &0xFF;
      pRet[1] = iTemp & 0xFF;
      return 4;

    case 83:
      p_CFiles->downloadMD5( iLen - 4, &cRecSeq[2] );
      pRet[0] = 0x0;
      pRet[1] = 0x0;
      return 4;

    case 120:
      pRet[0] = 0;
      p_CFiles->dir( (char*)pRet );
      return strlen( (char*)pRet );

    case 121:
      pRet[0] = 0;
      p_CFiles->getLogFile( pRet );
      return strlen( pRet );

    case 122:
      pRet[0] = 0;
      return p_CFiles->getLoggerFile( pRet );

    case 125:
      pRet[0] = 0;
      p_CFiles->bakLogFile( pRet );
      return strlen( pRet );

    case 126:
      pRet[0] = 0;
      p_CFiles->delOlgFile( pRet );
      return strlen( pRet );

    case 127:
      return p_CFiles->getSetup( pRet );

    case 128:
      p_CFiles->setSetup( &cPacket[1] );
      pRet[0] = 0;
      strcpy( pRet, "SETUP.INI loaded" );
      return strlen( pRet );

    case 129:
      p_CFiles->formatDisk();
      pRet[0] = 0;
      strcpy( pRet, "Disk formated" );
      return strlen( pRet );

    default:
      pRet[0] = 0x0;
      pRet[1] = 0x0;
      pRet[2] = 0x0;
      pRet[3] = 0x0;
      return 4;
  }
}

float CDiagCom::processReadReqs(int iZeile, int iSpalte ){

  switch( iZeile ){
    //Temperatur lesen
    case 1:
      switch( iSpalte ){
        case 0:
          return pPData->getTemp1();
        case 1:
                return pPData->getTemp2();
        case 2:
          return pPData->getTemp3();
        case 3:
          return pPData->getTemp4();
        case 4:
          return pPData->getTemp5();
        case 5:
            return pPData->getTemp6(); // test Base Temperature
//           return pPData->getTemp7();
        case 6:
          return pPData->getTemp7();
        case 7:
          return pPData->getTemp8();
      }
    break;

    //Current / Voltage Measurement
    case 2:
      switch( iSpalte ){
        case 1:
          return p_Lambdas[4]->getCurr();
        case 2:
          return p_Lambdas[4]->getVolt();
        case 3:
          return p_Lambdas[5]->getCurr();
        case 4:
          return p_Lambdas[5]->getVolt();
        case 5:
          return 0.0;//pPData->getHC3Curr();
        case 6:
          return 0.0;
        case 7:
          return 0.0;//pPData->getHC4Curr();
        case 8:
          return 0.0;
      }
    break;

    //Tempereaturoffset lesen
    case 10:
      return pSetup->getTempOffset(iSpalte + 1 );
    //Temperatur liniarfaktor lesen
    case 11:
      return pSetup->getTempLinCorr(iSpalte + 1 );
    //Current measurement calibration factor
    case 12:
      return pSetup->getCurrCal(iSpalte);
    case 13:
      return pSetup->getVoltCal(iSpalte);

    //Lambda Skalierungsfaktoren
    case 21:
      return pSetup->getLambdaCal( iSpalte + 1);

    //PID Parameter
    case 24:
    case 26:
    case 28:
    case 30:
    case 32:
    case 34:
    case 36:
      switch( iSpalte ){
        case 0:
          return pSetup->getPIDSetup(((iZeile-23)/2) + 1)->Kp;
        case 1:
          return pSetup->getPIDSetup(((iZeile-23)/2) + 1)->Tn;
        case 2:
          return pSetup->getPIDSetup(((iZeile-23)/2) + 1)->Tv;
        case 3:
          return pSetup->getPIDSetup(((iZeile-23)/2) + 1)->window;
        case 4:
          return pSetup->getPIDSetup(((iZeile-23)/2) + 1)->min;
        case 5:
          return pSetup->getPIDSetup(((iZeile-23)/2) + 1)->max;
        case 6:
          return pSetup->getPIDSetup(((iZeile-23)/2) + 1)->Lin;
        case 7:
          return pSetup->getPIDSetup(((iZeile-23)/2) + 1)->Lin;
        case 8:
          return pSetup->getPIDSetup(((iZeile-23)/2) + 1)->Lin;
      }
    break;

    //PID Actual Values
    case 25:
      switch( iSpalte ){
        case 1:
          return p_con1->getP();
        case 2:
          return p_con1->getI();
        case 3:
          return p_con1->getD();
        case 4:
          return p_con1->getM();
        case 5:
          return p_con1->getY();
      }
    break;

    //PID Actual Values
    case 27:
      switch( iSpalte ){
        case 1:
          return p_con2->getP();
        case 2:
          return p_con2->getI();
        case 3:
          return p_con2->getD();
        case 4:
          return p_con2->getM();
        case 5:
          return p_con2->getY();
      default: return 0.0;
      }


    //PID Actual Values
    case 29:
      switch( iSpalte ){
        case 1:
          return p_con3->getP();
        case 2:
          return p_con3->getI();
        case 3:
          return p_con3->getD();
        case 4:
          return p_con3->getM();
        case 5:
          return p_con3->getY();
      }
      return 0.0;


    //PID Actual Values
    case 31:
      switch( iSpalte ){
        case 1:
          return p_con4->getP();
        case 2:
          return p_con4->getI();
        case 3:
          return p_con4->getD();
        case 4:
          return p_con4->getM();
        case 5:
          return p_con4->getY();
      }
      return 0.0;


    //PID Actual Values
    case 33:
      switch( iSpalte ){
        case 1:
          return p_con5->getP();
        case 2:
          return p_con5->getI();
        case 3:
          return p_con5->getD();
        case 4:
          return p_con5->getM();
        case 5:
          return p_con5->getY();
      }
    break;

    //PID Actual Values
    case 35:
      switch( iSpalte ){
        case 1:
          return p_con6->getP();
        case 2:
          return p_con6->getI();
        case 3:
          return p_con6->getD();
        case 4:
          return p_con6->getM();
        case 5:
          return p_con6->getY();
      }
    break;

    //Sollwerte
    case 40:
      return pSetup->getTempParamSet(iSpalte + 1)->getSetTemp();
    //Sollwerte Max Limit
    case 41:
      return pSetup->getTempParamSet(iSpalte + 1)->getMaxLimit();
    //Sollwerte Min Limit
    case 42:
      return pSetup->getTempParamSet(iSpalte + 1)->getMinLimit();
    //Current maximum limit
    case 43:
      return pSetup->getCurrLimit(iSpalte);
    case 44:
      return pSetup->getVoltLimit(iSpalte);

    //Stellwerte f�r Lambdas
    case 45:
      if( iSpalte > 0 && iSpalte <= 6 )
      {
        if( p_Lambdas[iSpalte-1] != 0 )
        {
          return p_Lambdas[iSpalte-1]->getPower();
        }
      }
      return 0.0;

    case 60:
      switch( iSpalte ){
         case 1:
          return 0.0;
        case 2:
          return 0.0;
        case 3:
          return 0.0;
        case 4:
          return 0.0;
        case 5:
          return 0.0;
        case 6:
          return 0.0;
        case 7:
          return 0.0;
        case 8:
          return 0.0;
      }
    break;

    case 61:
      switch( iSpalte ){
        case 1:
            if(pSetup->getGetPressDev())
            {
                if( pSetup->getTempParamSet(1)->getMinLimit() < 0  ) // System with dumb Chiller. Sp�ter besser l�sen!! 13.02.2013 
                  return pPData->getTemp5();
                else
                    return pPData->getTemp7();
            }
            else
            {
                if( pSetup->getExtChiller() ){
                    return p_ChillerCom->getTemp();
                }
                else{
                    return pPData->getTemp5();
                }
            }
        case 2:
	      if( pSetup->getGetPressDev() ) return m_lany1.getSetValue();  // Druckproportionalventil
          else return m_jouco1.getSetValue();                           // Joumatic-Ventile
        case 3:
          return m_jouco1.getFlow();//m_lany1.getIPress();
        case 4:
          return  0.0;//m_lany1.getOPress();
        case 5:
          //return pPData->getValv2SetPress() * 3.0;
          return m_jouco2.getSetValue();
        case 6:
          return m_jouco2.getFlow();
        case 7:
          return 0.0;
        case 8:
          return 0.0;
      }
    break;

    case 62:
      switch( iSpalte ){
        case 1:
       return pDewPointSensor->getDewPoint();  //   test 28.03.2013     
////#warning "Code is compiled with Diagnose Dew point used for second PT100 getTemp2!!!"          
////          return pPData->getTemp2();
        default:
          return 0.0;
       }
      
    default:
      return 0.0;
  }

  return 0.0;
}

void CDiagCom::processWriteReqs(int iZeile, int iSpalte, float fValue ){
  switch( iZeile ){
      //Tempereaturoffset schreiben
    case 10:
      pSetup->setTempOffset(iSpalte + 1, fValue );
    break;
    //Temperatur liniarfaktor schreiben
    case 11:
       pSetup->setTempLinCorr(iSpalte + 1, fValue );
    break;
    //Temperatur liniarfaktor schreiben
    case 12:
       pSetup->setCurrCal( iSpalte, fValue );
    break;

    case 13:
       pSetup->setVoltCal( iSpalte, fValue );
    break;


    //Lambda Skalierungsfaktoren
    case 21:
      pSetup->setLambdaCal( iSpalte + 1, fValue);
    break;

    //PID Parameter
    case 24:
    case 26:
    case 28:
    case 30:
    case 32:
    case 34:
    case 36:
        switch( iSpalte ){
        case 0:
          pSetup->setKpSetup( (((iZeile-23)/2) + 1), fValue );
        break;
        case 1:
          pSetup->setTnSetup( (((iZeile-23)/2) + 1), fValue );
        break;
        case 2:
          pSetup->setTvSetup( (((iZeile-23)/2) + 1), fValue );
        break;
        case 3:
          pSetup->setPwSetup( (((iZeile-23)/2) + 1), fValue );
        break;
        case 4:
          pSetup->setMinSetup( (((iZeile-23)/2) + 1), fValue );
        break;
        case 5:
          pSetup->setMaxSetup( (((iZeile-23)/2) + 1), fValue );
        break;
        case 6:
          pSetup->setLinSetup( (((iZeile-23)/2) + 1), fValue );
        break;
        case 7:
          pSetup->setLinSetup( (((iZeile-23)/2) + 1), fValue );
        break;
        case 8:
          pSetup->setLinSetup( (((iZeile-23)/2) + 1), fValue );
        break;
      }
    break;

    //Sollwerte
    case 40:
        if(iSpalte == 0 ){ 
            _event<float> e("aggregate", CEventNames::set_temp1_changed, fValue );
            EventManager.RaiseEvent(e);                  
        }
        else{
            pSetup->getTempParamSet(iSpalte + 1)->setSetTemp(fValue);
        }
    break;

    //Sollwerte Max Limit
    case 41:
      pSetup->getTempParamSet(iSpalte + 1)->setMaxLimit(fValue);
    break;

    //Sollwerte Min Limit
    case 42:
      pSetup->getTempParamSet(iSpalte + 1)->setMinLimit(fValue);
    break;

    //Maximum allowed current on chuck
    case 43:
      pSetup->setCurrLimit(iSpalte, fValue);
    break;
    
    case 44:
      pSetup->setVoltLimit(iSpalte, fValue);
    break;

    case 45:
    //MB muss sp�ter noch behandelt werden, einfach nur setzen der Stellwerte bring nichts
    /*
      switch( iSpalte )
      {
        case 1:
          pPData->setHC1Power(fValue);
        break;
        case 2:
          pPData->setHC2Power(fValue);
        break;
        case 3:
          pPData->setHC3Power(fValue);
        break;
        case 4:
          pPData->setHC4Power(fValue);
        break;
        case 5:
          pPData->setHC5Power(fValue);
        break;
        case 6:
          pPData->setHC6Power(fValue);
        break;
      }
    */
    break;

    default:

    break;
  }
}

unsigned char CDiagCom::processByteRReqs(int iZeile, int iSpalte ){

  switch( iZeile ){

    case 50:
      RTC_DATE date;
      RTC_TIME time;
      switch( iSpalte ){
        case 1:
          RTC_GetTime( BINARY, &time);
          return time.seconds;
        case 2:
          RTC_GetTime( BINARY, &time);
          return time.minutes;
        case 3:
          RTC_GetTime( BINARY, &time);
          return time.hours;
        case 4:
          RTC_GetDate( BINARY, &date);
          return date.weekday;
        case 5:
          RTC_GetDate( BINARY, &date);
          return date.day;
        case 6:
          RTC_GetDate( BINARY, &date);
          return date.month;
        case 7:
          RTC_GetDate( BINARY, &date);
          return date.year;
        case 8:
          RTC_GetDate( BINARY, &date);
          return date.century;
       }
    break;

    case 46:
      return 0.0;

    case 47:
        switch( iSpalte ){
            case 1:
                return (char)mode;
            case 2:
                return pSetup->getConConfig();
            case 3:
                return pSetup->getProtocollType();
            case 4:
                return pSetup->getAirTable();
            case 5:
                return pSetup->getScreenStatus();
            case 6:
                return pSetup->getOptions();
        }
  }
  return 0;
}


void CDiagCom::processByteWReqs(int iZeile, int iSpalte, unsigned char cValue ){
  switch( iZeile ){

    case 50:
      RTC_DATE date;
      RTC_TIME time;
      switch( iSpalte ){
        case 1:
          RTC_GetTime( BINARY, &time);
          time.seconds = cValue;
          RTC_SetTime( time );
        break;
        case 2:
          RTC_GetTime( BINARY, &time);
          time.minutes = cValue;
          RTC_SetTime( time );
        break;
        case 3:
          RTC_GetTime( BINARY, &time);
          time.hours = cValue;
          RTC_SetTime( time );
        break;
        case 4:
          RTC_GetDate( BINARY, &date);
          date.weekday = cValue;
          RTC_SetDate( date );
        break;
        case 5:
          RTC_GetDate( BINARY, &date);
          date.day = cValue;
          RTC_SetDate( date );
        break;
        case 6:
          RTC_GetDate( BINARY, &date);
          date.month = cValue;
          RTC_SetDate( date );
        break;
        case 7:
          RTC_GetDate( BINARY, &date);
          date.year = cValue;
          RTC_SetDate( date );
        break;
        case 8:
          RTC_GetDate( BINARY, &date);
          date.century = cValue;
          RTC_SetDate( date );
        break;
      }
    break;

    case 46:
      if( cValue == 0 ){
        //pSetup->setChuckDisable(iSpalte + 1);
      }
      else{
        //pSetup->setChuckEnable(iSpalte + 1);
      }
    break;

    case 47:
        switch( iSpalte ){
        
            case 1:
		    switchMode((MODE)cValue );
            break;
        
            case 2:
                pSetup->setConConfig(cValue);
            break;
            case 3:
                pSetup->setProtocollType((CSetup::_s_config::_e_proto_type)cValue);
            break;
            case 4:
                pSetup->setAirTable((CSetup::_s_config::_e_air_table)cValue);
            break;
            case 5:
                pSetup->setScreenStatus(cValue);
            break;
            case 6:
                pSetup->setOptions(cValue);
            break;
        }
    break;
  }
}


/**
  Check for new Byte in Inbuffer, if something is there
  put it on the commanc queue
  @param cSeq pointer to Command input buffer
  @param iLen expected sequence lenth
  @return returns EDC_OK if number of received bytes >= iLen, EDC_Wait else
*/
 int CDiagCom::ReceiveByte( char * cSeq, int iLen ){
  if( *pISZ > 0  ){
      *pRReg = 1;
      while( *pRReg != 0 );
      cSeq[iSeqCnt_Rec++] = *pIBOX;
  }
  if( iSeqCnt_Rec == iLen ){
    iSeqCnt_Rec = 0;
      return EDC_OK;
  }
  else{
    return EDC_WAIT;
  }
}

/**
  Receive Data Packet
*/
int CDiagCom::ReceivePacket( char * cSeq ){
    bool bComplete = true;
    int iTOut = 100000;
    while( *pISZ > 0 && iSeqCnt_Rec < m_RecBufSize){
        *pRReg = 1;
        while( *pRReg != 0  && iTOut-- > 1);
        cSeq[iSeqCnt_Rec++] = *pIBOX;
        bComplete = false;
    }
    if( bComplete ){             //If Bytes are received return there number
        int iTemp = iSeqCnt_Rec;
        iSeqCnt_Rec = 0;
        return iTemp;
    }
    else{
        return 0;
    }
}

 /**
  put answer to the send stack
  @param cSeq pointer to send sequence
  @param iLen number of bytes to send
  @return returns EDC_OK if sequence is complete transferd to output buffer else EDC_Wait
*/
int CDiagCom::SendByte( char * cSeq, int iLen ){
  while( *pOSZ < 30 && iSeqCnt_Snd < iLen){
      while( *pWReg != 0 );
      *pOBOX = cSeq[iSeqCnt_Snd++];
      *pWReg = 1;
  }
  if( iSeqCnt_Snd == iLen ){
    iSeqCnt_Snd = 0;
    return EDC_OK;
  }
  else{
    return EDC_WAIT;
  }
}

