#ifndef DIAGCOM_H
#define DIAGCOM_H

#include "CSetup.h"
#include "IProcessData.h"
#include "version.h"


/**
  Class CDiagCom is responsible for information interchange with
  the Setup und Konfiguratio Software occassionally runnin on the
  PC
*/

class CDiagCom {

  private:
  
    //Phsical diagnose interface addresses    
    volatile static unsigned char * const pRReg;
    volatile static unsigned char * const pWReg;
    volatile static unsigned char * const pISZ;
    volatile static unsigned char * const pOSZ;
    volatile static unsigned char * const pIBOX;
    volatile static unsigned char * const pOBOX;

    int iFSM_Diag;
    int iSeqCnt_Rec;
    int iSeqCnt_Snd;
    int iRepLen;    //Reply Lenght
    int iLen;

    bool bPacketComplete;
    bool bWriteThrough;
    bool bWithCRC;

    char * cRecSeq;
    int m_RecBufSize;
    CSetup * pSetup;
    IProcessData * pPData;

  public:
    CDiagCom( CSetup * pSetup, IProcessData * pPData );
    float processReadReqs(int iZeile, int iSpalte );
    void processWriteReqs(int iZeile, int iSpalte, float fValue );
    unsigned char processByteRReqs(int iZeile, int iSpalte );
    void processByteWReqs(int iZeile, int iSpalte, unsigned char cValue );
    bool processPacket(void);
    int processPacket( char * cPacket, char * pDest, char cFC );
    bool IsDisplayUpdate(void){
      return bWriteThrough;
    }
    void DipslayUpdateDone(void){
        bWriteThrough = false;
    }


  protected:
    int ReadMessage( char * cSeq );
    int SendMessage( char * cSeq, int iLen );
    int SendByte( char * cSeq, int iLen );
    int ReceiveByte( char * cSeq, int iLen );
    int ReceivePacket( char * cSeq );
    bool PackedReceived(void);

};



#endif