
#include "CErrorMsgs.h"
#include "CErrorNums.h"

#ifdef TUEV

// For T�V presentation all errors are warnings, to avoid red error window, which can not be closed 

const _e_text CErrorMessages::m_txt[34] = 
{
    { ERR_NO_ERROR,	false, false, false, "Kein Fehler", "NO ERROR", "" },
    { ERR_OVER_TEMP,  	false,  false,  true, "�bertemperatur", "OVER TEMP.", "" },
    { ERR_UNDER_TEMP, 	false,  false,  true, "Untertemperatur", "UNDER TEMP.", "" },
    { ERR_ADC,  		false,  false,  true, "ADC- Fehler", "ADC- Error", "" },
    { ERR_CHUCKCABLE, 	false,  false,  true, "Kabelbruch", "CHUCKCABLE", "" },
    { ERR_SAFETY_SHUTDOWN,  false, false,  true, "Sicherh.-Absch.", "SAFETY SHUTDOWN", "" },
    { ERR_BASE_SENSOR, 	false, false, false, "Grundplatt-Sens", "BASE SENSOR", "" },
    { ERR_CHILLER_COM, 	false, false, false, "Chiller Komm.", "CHILLER COM", "" },
    { ERR_DEWP_ALARM_1, false,  true, false, "Taupunktalarm 1", "DEWP. ALARM 1", "" },
    { ERR_DEWP_ALARM_2, false,  true, false, "Taupunktalarm 2", "DEWP. ALRAM 2", "" },
    { ERR_DEWP_SENSOR, 	false,  true, false, "Taupunktsensor", "DEWP. SENSOR", "" },
    {  20, 							false, false, false, "test", "test", "" },
    {  21, 							false, false, false, "test", "test", "" },
    { ERR_OV_CURR_HC_1,	false, false,   true, "�berstrom HK1", "OVERCUR. HC1", "" },
    { ERR_PWR_DEFECT_1, false, false,  true, "Endst. def. HK1", "PWR DEF. HC1", "" },
    { ERR_UN_CURR_HC_1, false, false,  true, "Unterstrom HK1", "UNDERCUR. HC1", "" },
    { ERR_INT_TEMP, 	false, false,  true, "Interne Temp.", "INTERNAL TEMP", "" },
    { ERR_OV_CURR_HC_2,  false, false,  true, "�berstrom HK2", "OVERCUR. HC2", "" },
    { ERR_PWR_DEFECT_2, false, false,  true, "Endst. def. HK2", "PWR DEF. HC2", "" },
    { ERR_UN_CURR_HC_2, false, false,  true, "Unterstrom HK2", "UNDERCUR. HC2", "" },
    { ERR_NO_COOL_SUBSYS, false, false, true, "Keine Chiller", "NO Chiller",""},    
    { ERR_AIRPRESS_MISS, false, false, false,"Luftdr. sensor",  "NO PRESS SENS.", "" },
    { ERR_AIRPRESS_LOW, false, false, false, "Luftdr. niedrig", "AIR PRESS LOW", "" },
    { THERMAL_CUT_OUT, 	false, false, false, "�bertemp-Absch.", "THRM CUT-OUT", "" },
    { ERR_CPU_FAIL_1, 	false,  true,  true, "CPU-Fehler 1", "CPU FAILURE1", "" },
    { ERR_CPU_FAIL_2, 	false,  true,  true, "CPU-Fehler 2", "CPU FAILURE2", "" },
    { ERR_PEER_LOST,    false, false, false, "PEER Kommunik.", "PEER COM", "" },
    { ERR_CHILLER_ERR,  false, false, false, "Chillerfehler", "Chiller Error", "" },
    { -1, false, false, false, "test", "test", "" },
    { -1, false, false, false, "test", "test", "" },
    { -1, false, false, false, "test", "test", "" },
    { -1, false, false, false, "test", "test", "" },
    { -1, false, false, false, "test", "test", "" },
    { -1, false, false, false, "test", "test", "" },
};

#else

//Hier sind die Fehletexte definiert, bitte in Fehlernummer aufsteigend sortiert
//und Plathalter mit Error- Code -1 Kennzeichnen
const _e_text CErrorMessages::m_txt[34] = 
{
    { ERR_NO_ERROR,			false, false, false, "Kein Fehler", "NO ERROR", "" },
    { ERR_OVER_TEMP,  	true,  false,  true, "�bertemperatur", "OVER TEMP.", "" },
    { ERR_UNDER_TEMP, 	true,  false,  true, "Untertemperatur", "UNDER TEMP.", "" },
    { ERR_ADC,  				true,  false,  true, "ADC- Fehler", "ADC- Error", "" },
    { ERR_CHUCKCABLE, 	true,  false,  true, "Kabelbruch", "CHUCKCABLE", "" },
    { ERR_SAFETY_SHUTDOWN,  true, false,  true, "Sicherh.-Absch.", "SAFETY SHUTDOWN", "" },
    { ERR_BASE_SENSOR, 	false, false, false, "Grundplatt-Sens", "BASE SENSOR", "" },
    { ERR_CHILLER_COM, 	false, false, false, "Chiller Komm.", "CHILLER COM", "" },
    { ERR_DEWP_ALARM_1, false,  true, false, "Taupunktalarm 1", "DEWP. ALARM 1", "" },
    { ERR_DEWP_ALARM_2, false,  true, false, "Taupunktalarm 2", "DEWP. ALRAM 2", "" },
    { ERR_DEWP_SENSOR, 	false,  true, false, "Taupunktsensor", "DEWP. SENSOR", "" },
    {  20, 							false, false, false, "test", "test", "" },
    {  21, 							false, false, false, "test", "test", "" },
    { ERR_OV_CURR_HC_1,	true, false,   true, "�berstrom HK1", "OV. CURR. HC1", "" },
    { ERR_PWR_DEFECT_1, false, false,  true, "Endst def. HK1", "PWR DEF. HC1", "" },
    { ERR_UN_CURR_HC_1, false, false,  true, "Unterstrom HK1", "UN. CURR. HC1", "" },
    { ERR_INT_TEMP, 		false, false,  true, "Interne Temp.", "INTERNAL TEMP", "" },
    { ERR_OV_CURR_HC_2,  true, false,  true, "�berstrom HK2", "OV. CURR HC2", "" },
    { ERR_PWR_DEFECT_2, false, false,  true, "Endst def. HK2", "PWR DEF. HC2", "" },
    { ERR_UN_CURR_HC_2, false, false,  true, "Unterstrom HK2", "UN. CURR", "" },
    { ERR_NO_COOL_SUBSYS, false, false, true, "Keine Chiller", "NO Chiller",""},    
    { ERR_AIRPRESS_MISS, false, false, false,"Luftdr. sensor",  "NO PRESS SENS.", "" },
    { ERR_AIRPRESS_LOW, false, false, false, "Luftdr. niedrig", "AIR PRESS LOW", "" },
    { THERMAL_CUT_OUT, 		false, false, false, "�bertemp-Absch.", "THERMAL SW-OFF", "" },
    { ERR_CPU_FAIL_1, 	false,  true,  true, "CPU-Fehler 1", "CPU FAILURE1", "" },
    { ERR_CPU_FAIL_2, 	false,  true,  true, "CPU-Fehler 2", "CPU FAILURE2", "" },
    { ERR_PEER_LOST,    false, false, false, "PEER Kommunik.", "PEER COM", "" },
    { ERR_CHILLER_ERR,  false, false, false, "Chillerfehler", "Chiller Error", "" },
    { -1, false, false, false, "test", "test", "" },
    { -1, false, false, false, "test", "test", "" },
    { -1, false, false, false, "test", "test", "" },
    { -1, false, false, false, "test", "test", "" },
    { -1, false, false, false, "test", "test", "" },
    { -1, false, false, false, "test", "test", "" },
};

#endif

/**
    Konstruktor
*/
CErrorMessages::CErrorMessages( CEventManager * pEventManager )
{
    m_pEventManager = pEventManager;
    m_changed = false;
    m_msgcnt = 0;
    m_lang = en;
    m_eText.reserve(128);
    m_wText.reserve(128);
    m_lText.reserve(32);
}

void CErrorMessages::Init(void)
{
    m_pEventManager->AddEventHandler( CEventNames::set_error, CErrorMessages::set_error_EventWrapper, this );    
    m_pEventManager->AddEventHandler( CEventNames::reset_error, CErrorMessages::reset_error_EventWrapper, this );
    m_pEventManager->AddEventHandler( CEventNames::reset_all_errors, CErrorMessages::reset_all_errors_EventWrapper, this );  
}

/**
EventHandler
*/

void CErrorMessages::set_error_Event( int i )
{
    //Pr�fe zuerst ob die Fehlenummer bereits in der Liste ist
    for( int k = 0; k < m_msgcnt; k++ )
    {
        if( m_codes[k] == i )
        {
            return; //Fehlernummer ist schon in der Liste, also raus hier
        }
    }
    m_codes[m_msgcnt++] = i;
    m_changed = true;
}



void CErrorMessages::reset_error_Event( int i )
{
    bool found = false;
    //Pr�fe zuerst ob die Fehlenummer bereits in der Liste ist
    for( int k = 0; k < m_msgcnt; k++ )
    {
        //Suche die Fehlernummer
        if( m_codes[k] == i )
        {
            found = true;
        }
        //Wenn Fehlernummer gefunden dann die Liste umsortieren
        if( found )
        {
            m_codes[k] = m_codes[k+1];
        }
    }
    if( found)
    {
        m_msgcnt--;
        m_changed = true;    
    }
}

/**
 * Setzt alle Fehler zur�ck.
 * FUNKTIONIERT NOCH NICHT !!!!!!
 */
void CErrorMessages::reset_all_errors_Event( int i )
{
    // L�sche alle Fehlercodes
    for( int k = 0; k < m_msgcnt; k++ )
    {
			_event<int> e("CErrorMsgs", CEventNames::reset_error, m_codes[k] );
      m_pEventManager->RaiseEvent(e);
    }
}

/**
Zyklischer abarbeitung
*/
        
void CErrorMessages::cycCalc(void)
{
    
    if( m_changed )
    {
        m_ProberError = 0;
        //Zuerst Fehler pr�fen
        if( m_msgcnt  > 0 )
        {
            m_eText = "";
            m_wText = "";
             
            for( int i = 0; i < m_msgcnt; i++ )
            {
                m_lText = "";
                char code[] = "000";
                code[0] += (m_codes[i] / 100) % 10;
                code[1] += (m_codes[i] /  10) % 10;
                code[2] += (m_codes[i] /   1) % 10;
                m_lText += " E";
                m_lText += code;
                m_lText += " ";
                m_lText += findText(m_codes[i]);
                m_lText += "#";
                if( IsError(m_codes[i]) )
                {
                    m_eText += m_lText;
                }
                else
                {
                    m_wText += m_lText;
                }
                //Prober Fehler Code
                if( IsProberError(m_codes[i]) )
                {
                    m_ProberError = m_codes[i];
                }
                
            }
            
            //Fehlermeldung auf den Bildschirm
            if( m_eText.size() > 0 )
            {
                _string s("");
                s = m_eText.data();
                _event<_string> e( "CErrorMsgs", CEventNames::drop_errormessage, s );
                m_pEventManager->RaiseEvent(e);
            }
            else
            {
                _event<bool> b("CErrorMsgs", CEventNames::remove_errormessage, true );
                m_pEventManager->RaiseEvent(b);  
            }
                        
            //Warnmeldungen aktualisieren
            if( m_wText.size() > 0 )
            {
                _string s("");
                s = m_wText.data();
                _event<_string> e( "CErrorMsgs", CEventNames::drop_infomessage, s );
                m_pEventManager->RaiseEvent(e);                    
            }                            

        }
        else
        {
            _event<bool> b("CErrorMsgs", CEventNames::remove_errormessage, true );
            m_pEventManager->RaiseEvent(b);
						
						_event<bool> e("CErrorMsgs", CEventNames::advice_symbol, false );
						m_pEventManager->RaiseEvent(e);			
        }
        //Proberfehlernummer auf jeden Fall aktualisieren
        _event<int> i("CErrorMsgs", CEventNames::NEW_PORB_ERROR, m_ProberError );
        m_pEventManager->RaiseEvent(i);
                    
        //Generierung des Textes f�r das Fehlermeldungsfenster
        m_changed = false;
    }
		else if (m_msgcnt > 0) {
 			_event<bool> e("Error_1", CEventNames::advice_symbol, true );
    	m_pEventManager->RaiseEvent(e);			
		}
    
}

char* CErrorMessages::findText( int i)
{
    for( int n = 0; n < 32; n++ )
    {
        if( m_txt[n].code == i )
        {
            switch( m_lang )
            {
                case de:
                    return (char*)&m_txt[n].de;
                case en:
                    return (char*)&m_txt[n].en;
                case jp:
                    return (char*)&m_txt[n].jp;
            }
        }
    }
    return (char*)-1;
}
            
bool CErrorMessages::IsError( int i )
{
    for( int n = 0; n < 32; n++ )
    {
        if( m_txt[n].code == i )
        {
            return m_txt[n].error;
        }
    }
    return false;
}
                    
bool CErrorMessages::IsProberError( int i )
{
    for( int n = 0; n < 32; n++ )
    {
        if( m_txt[n].code == i )
        {
            return m_txt[n].to_pr;
        }
    }
    return false;
}
                        