#ifndef C_ERRORMSGS_H
#define C_ERRORMSGS_H

#include "../../MailboxSystem/CEventManager.h"
#include <string>


struct _e_text
{
    int code;     //Erro Code Nummer
    bool error;   //Wenn true dann ist es ein Kritischer fehler ansonsten  nur eine Warnung
    bool to_ch;   //Fehler soll am Chiller angezeigt werden falls vorhanden
    bool to_pr;   //Fehler soll am Prober angezeigt werden
    char de[MAX_ERR_TXT_LEN];  //Klartext in Deutsch
    char en[MAX_ERR_TXT_LEN];  //Klartext in Englisch
    char jp[MAX_ERR_TXT_LEN];  //Zeichencode f�r Japanisch
    
    //Konstruktor zum unterbinden der Fehlermeldungen
};


//Diese Klasse h�ng sich and den EventManager und wandelt Fehlercodes in Text um und 
//sendet diese Ereignisse dann an den Displaymanager
class CErrorMessages
{
    public:
        CErrorMessages( CEventManager * pEventManager );
        void Init(void);
        void cycCalc(void);
        
        //EventHandler
        static void set_error_EventWrapper( void * pObject, int i ){ ((CErrorMessages*)pObject)->set_error_Event(i);};
        void set_error_Event( int i );
        static void reset_error_EventWrapper( void * pObject, int i ){ ((CErrorMessages*)pObject)->reset_error_Event(i);};
        void reset_error_Event( int i );
        static void reset_all_errors_EventWrapper( void * pObject, int i){ ((CErrorMessages*)pObject)->reset_all_errors_Event(i);};
				void reset_all_errors_Event( int i );

        enum _lang { de, en, jp };     //Sprachauswahlkonstanten
        
    protected:
        static const _e_text m_txt[34]; //Sammlung der Fehlermeldungen
        int m_msgcnt;                   //Anzahl der Aktiven Fehlermeldungen
        bool m_changed;                 //Fehlerldungen haben sich ver�ndert
        char* findText( int i );        //Zeiger auf Fehlermeldungstext f�r die Nummer
        bool IsError( int i );          //Pr�fe ob es eine Kritische Fehlemeldung ist, wenn
        bool IsProberError( int i );       
        _lang m_lang;                   //variable zur Sprachauswahl

    private:
        CEventManager * m_pEventManager;//Pointer auf den EventManager
        int m_codes[10];                //Liste der aktiven Fehlerzust�nde, maximal 10 m�gliche
        string m_eText;                 //String der den Text f�r die Anzeige enth�lt
        string m_wText;                 //String der den Anzeigtext f�r die Warnung enth�lt
        string m_lText;                 //eine Zeile des Strings
        int m_ProberError;              //Error Code f�r Prober
        
        
};
        

#endif