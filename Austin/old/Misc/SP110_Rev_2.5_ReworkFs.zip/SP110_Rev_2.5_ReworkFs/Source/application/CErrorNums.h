#ifndef C_ERRORNUMS_H
#define C_ERRORNUMS_H


#define ERR_NO_ERROR        	 0
#define ERR_OVER_TEMP       	 1
#define ERR_UNDER_TEMP      	 2
#define ERR_ADC        		03
#define ERR_CHUCKCABLE     	04
#define ERR_SAFETY_SHUTDOWN  	06
#define ERR_BASE_SENSOR		07
#define ERR_CHILLER_COM		8
#define ERR_DEWP_ALARM_1	16
#define ERR_DEWP_ALARM_2	17
#define ERR_DEWP_SENSOR       18
#define ERR_OV_CURR_HC_1	61
#define ERR_PWR_DEFECT_1      62 
#define ERR_UN_CURR_HC_1	63
#define ERR_INT_TEMP          70    /**< Interne Temperatur zu hoch oder niedrig */
#define ERR_INTTEMP_FAULT     71		/**< Sensor f�r interne Temperatur defekt. \todo: Erkennung und Behandlung ERR_INTTEMP_FAULT implementieren */ 
#define THERMAL_CUT_OUT		72    /**< Temperatur der Chuck-Grundplatte zu hoch. Abschaltung durch JUMO-Temperaturw�chter hat stattgefunden   */
#define ERR_OV_CURR_HC_2	81
#define ERR_PWR_DEFECT_2      82
#define ERR_UN_CURR_HC_2	83
#define ERR_NO_COOL_SUBSYS    89    /** No cooling Subsystem. This is valid for Systems that use either extern Chiller or Prop-Valve*/  
#define ERR_AIRPRESS_MISS     96    /**< Kein Luftdrucksensor vorhanden       */
#define ERR_AIRPRESS_LOW      97    /**< Luftdruck am Lufteintritt zu niedrig */
#define ERR_CPU_FAIL_1        98
#define ERR_CPU_FAIL_2        99
#define ERR_PEER_LOST	      208
#define ERR_CHILLER_ERR       218  /* Dual Chiller Error */


#endif  // C_ERRORNUMS_H