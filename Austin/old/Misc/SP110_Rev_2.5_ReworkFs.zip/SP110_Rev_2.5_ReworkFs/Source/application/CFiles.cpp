#include "CFiles.h"
#include "CProcessData.h"
#include <cstring>
#include <cstdio>
#include "CAirTable.h"
// #include "minIni.h"

extern CProcessData * p_CPData;
extern CSetup * p_CSetup;
extern CAirTable  * p_AirTable;

/**
  Intialize constatn pointers
*/
const char CFiles::event_text[4][10] = { "", "ST-UP", "NEW T", "ERROR" };

/**
  Default Konstruktor
*/
const char * CFiles::sVolName = "ERS_DSK_1";

CFiles::CFiles(void){
  bLogSizeEx = false;
  bLoggerSaved = false;
}

/**
  Function logEvent saves entrie to Log Archive
  @param iEvent valid event number constand as defined in this class
  @param iChannel Channel number where this event occured
  @param fTNew new temperature for event new temperature
  @return always true, resefed for future use
*/
bool CFiles::logEvent( unsigned char iEvent, int iChannel, float fTNew )
{
// if (  p_CSetup->getConConfig() == CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600 )
    return true;
 
////  log_entry entry;
////  float fTemp;
////  entry.event = iEvent;
////  entry.channel = iChannel;
////  entry.alarm_st = p_CPData->getOldErrorStatus(iChannel);
////  switch( iChannel ){
////    case 1:  fTemp = p_CPData->getTemp1(); break;
////    case 2:  fTemp = p_CPData->getTemp2(); break;
////    case 3:  fTemp = p_CPData->getTemp3(); break;
////    case 4:  fTemp = p_CPData->getTemp4(); break;
////    case 5:  fTemp = p_CPData->getTemp5(); break;
////    default: fTemp = 0.0; break;
////  }
////  entry.t_chuck = (short)(fTemp * 10.0);
////
////  entry.t_set = (short)(p_CSetup->getTempParamSet(iChannel)->getSetTemp() * 10.0);
////  entry.t_new = (int)(fTNew * 10.0);
////  RTC_DATE date;
////  RTC_TIME time;
////  RTC_GetDate( BINARY, &date);
////  RTC_GetTime( BINARY, &time);
////  entry.time_sec = time.seconds;
////  entry.time_min = time.minutes;
////  entry.time_hou = time.hours;
////  entry.date_day = date.day;
////  entry.date_mon = date.month;
////  entry.date_yea = date.year;
////
////  FS_FILE * pFile = FS_FOpen ( "main.log", "a+b" );
////  FS_Write (pFile, (void*)&entry, sizeof( log_entry ));
////  //If more than 500 entries mark log Size exeeded
////  if( pFile != 0 && (FS_GetFileSize(pFile) / sizeof( log_entry )) > 500 ){
////    bLogSizeEx = true;
////  }
////  FS_FClose( pFile );
////
////  return true;
}

/**
  Function getEvent returns the Event selected through index. Index selects the actual event - index
  @param : iIndex select event, valid range from 0 to 1023
  @return : pointer to the selected event structure or a 0 if the event was invallid
*/
bool CFiles::getEvent( int iIndex, log_entry * pEntry ){
  if( iIndex < 0 ){
    return false;
  }
  else{
    FS_FILE * pFile = FS_FOpen ( "main.log", "rb" );
    FS_FSeek( pFile, 0, FS_SEEK_END);
    int iElements = FS_FTell( pFile ) / sizeof( log_entry );
    if( iIndex > iElements ){
      FS_FClose( pFile );
      return false;
    }
    else{
      FS_FSeek( pFile, -iIndex * sizeof( log_entry), FS_SEEK_END);
      FS_Read( pFile, pEntry, sizeof( log_entry ) );
      FS_FClose( pFile );
      return true;
    }
  }
}


/**
  Get Text to event
*/
const char * CFiles::getEventText( unsigned char cEvent ){
  if( cEvent > 0 && cEvent < 4 ){
    return CFiles::event_text[cEvent];
  }
  else{
    return 0;
  }
}

/**
  Copy File- List to pBuf
*/
void CFiles::dir( char *pBuf ){
  U32 v;
  char acFilename[100];
  FS_FIND_DATA fd;
  if (FS_FindFirstFile(&fd, "\\", acFilename, sizeof(acFilename)) == 0) {
    do {
      FS_FILE *pFile = FS_FOpen(acFilename, "r");
      int iSize = FS_GetFileSize(pFile);
      sprintf( pBuf, "%s%s %d byte\n", pBuf, acFilename, iSize );
      FS_FClose( pFile );
    } while (FS_FindNextFile (&fd));
  }
  FS_FindClose(&fd);
  v = FS_GetFreeSpace(sVolName);
  sprintf( pBuf, "%sFree space: %u bytes\n", pBuf, v);
}

/**
  Put Formated Log- File- String to pBuf
*/
bool CFiles::getLogFile( char * pBuf ){
  int iStructIndex = 0;
  U32 eof;
  log_entry entry;
  FS_FILE *pFile = FS_FOpen("MAIN.LOG", "rb");
  if (pFile != 0) {
    do {
      eof = FS_Read(pFile, &entry, sizeof(log_entry));
      if (eof) {
        sprintf(&pBuf[strlen(pBuf)], "%s %03d|%04s|%1d|%02X|%04d|%04d|%04d|20%02d.%02d.%02d-%02d:%02d:%02d\n",
                "Entry:", iStructIndex, event_text[entry.event], entry.channel, entry.alarm_st,
                entry.t_chuck, entry.t_set, entry.t_new,
                entry.date_yea, entry.date_mon, entry.date_day, entry.time_hou,
                entry.time_min, entry.time_sec);
      }
      iStructIndex++;
    } while (eof);
    FS_FClose(pFile);
    return true;
  }
  return false;
}

/**
Function deletes all MAIN.BAx Files
*/
bool CFiles::delOlgFile( char * pBuf ){
  FS_FILE * pFile = (FS_FILE*)1;
  int i = 0;
  char sFileName[20];
  for( ; i < 9 && pFile != 0; i++ ){
    sprintf( sFileName, "MAIN.BK%d", i );
    pFile = FS_FOpen( sFileName, "r" );
    if( pFile != 0 ){
      FS_FClose(pFile);
      FS_Remove( sFileName );
      sprintf( pBuf, "%s \nDeleted: %s", pBuf, sFileName );
    }
  }
  return true;
}

/**
Function renames MAIN.LOG to MAIN.BA0 and reames MAIN.BA0 to BA9 + 1 and drops BA9
*/
bool CFiles::bakLogFile( char * pBuf ){
  FS_FILE * pFile = (FS_FILE*)1;
  int i = 9;
  char sNew[20];
  for( ; i >= 0; i-- ){
    sprintf( pBuf, "MAIN.BK%d", i );
    sprintf( sNew, "MAIN.BK%d", i + 1 );
    pFile = FS_FOpen( pBuf, "r" );
    if( pFile != 0 ){
      FS_FClose(pFile);
      if( i == 9 ){
        FS_Remove( pBuf );
      }
      else{
        FS_Rename( pBuf, sNew );
      }
    }
  }
  FS_Rename( "MAIN.LOG", pBuf );
  bLogSizeEx = false;
  return true;
}

/**
Get Setupini content and store it to pBuf
*/
int CFiles::getSetup( char * pBuf ){
  FS_FILE * pFile = FS_FOpen( "Setup.ini", "rb");
  if( pFile != 0 ){
    int iFSize =  FS_GetFileSize(pFile);
    FS_Read( pFile, pBuf, iFSize);
    FS_FClose(pFile);
    return iFSize;
  }
  return 0;
}

/**
Set Setupini content and store it to pBuf
*/
bool CFiles::setSetup(  char * pBuf ){
  char cFileName[15] = "Setup.ini";
  FS_FILE * pFile = FS_FOpen( cFileName, "wb");
  if( pFile != 0 ){
    FS_Write( pFile, pBuf, p_CSetup->iSetupSize() );
    FS_FClose(pFile);
    return true;
  }
  return false;
}

/**
Format Disk
*/
bool CFiles::formatDisk( void ){
    FS_FormatLow( "ERS_DSK_1" );
    if( FS_IsHLFormatted ( "ERS_DSK_1" ) == 0 ){
#ifdef DEBUB
      printf("High level Format" );
#endif
      FS_Format(  "ERS_DSK_1", NULL );
    }
    return true;
}

/**
Save Data vom DataLogger to File
*/
void CFiles::saveLoggerFile( int iSize, CDataLogger * pLogger){
  if( bLoggerSaved == false ){
    FS_FILE * pFile = FS_FOpen( "logg.bin", "wb" );
    char cBuff[20];
    if( pFile != 0 ){
      while( pLogger->getEntry( cBuff ) ){
        FS_Write( pFile, cBuff, iSize );
      }
      FS_FClose( pFile);
      bLoggerSaved = true;
    }
  }
}
 
/**
Get Loggerfile content and store it to pBuf
*/
int CFiles::getLoggerFile( char * pBuf ){
  FS_FILE * pFile = FS_FOpen( "logg.bin", "rb");
  if( pFile != 0 ){
    int iFSize =  FS_GetFileSize(pFile);
    FS_Read( pFile, pBuf, iFSize);
    FS_FClose(pFile);
    return iFSize;
  }
  return 0;
}

/**
  Init Update
*/
bool CFiles::initUpdate(int iBlocks){
  this->iBlocks = iBlocks;
  this->iBlock = -1;
  this->swu_pFile = FS_FOpen( "SUPDATE.bin", "wb" );
  return true;
}

/**
downloadBlock Transfer block to flash- disk
*/
int CFiles::downloadBlock( int iBlock, int iLen, char * pSource ){
  if( this->iBlock + 1 == iBlock ){
    this->iBlock = iBlock;
 	  FS_Write( this->swu_pFile, pSource, iLen );
    if( this->iBlocks == iBlock ){
  	  FS_FClose( swu_pFile );
    }
    return this->iBlock + 1;
  }
  else
  {
      return this->iBlock;
  }
}

/**
store MDF File for bootloader
*/
bool CFiles::downloadMD5(  int iLen, char * pBuf ){
  FS_FILE * pFile = FS_FOpen( "SUPDATE.MD5", "wb");
  if( pFile != 0 ){
    FS_Write( pFile, pBuf, iLen );
    FS_FClose(pFile);
    return true;
  }
  return false;
}


bool CFiles::getIPInfo( const char * key, string * pBuf, char *filename ) {
	char c, pos;
	bool found = false, eof = false;
	
	E_VOLUME_STATE mounted = mountFileSystem();
	if (mounted != E_VOLUME_UNKNOWN) {
	//	FS_FILE * pFile = FS_FOpen( "IPADDR.INI", "r");
            FS_FILE * pFile = FS_FOpen( filename, "r");
		if (pFile != 0)
			{
			while (!found && !eof) {
				c = pos = 0;
				pBuf->clear();
				while (c != 0x0A && !eof) {
					eof = FS_Read(pFile, &c, 1)?false:true;
					if (c>0x20 && c<0x5B) (*pBuf)+=c;//sBuf.push_back(c);
				}
				found = (pBuf->find(key) == 0)?true:false;
				*pBuf = pBuf->substr(strlen(key)+1); // key + "="
			}
			FS_FClose(pFile);
		}
		if (mounted == E_VOLUME_MOUNTED) FS_Unmount(sVolName);
		return found;
	}
	return false;
}

bool CFiles::writeIPInfo( void ) {

	bool success = false;
	
	E_VOLUME_STATE mounted = mountFileSystem();
	if (mounted != E_VOLUME_UNKNOWN) 
	{
		FS_FILE * pFile = FS_FOpen( "IPADDR.INI", "w");
		char cBuf[22];
    extern int ipAddr[4], ipMask[4];
		
		if (pFile != 0)
		{
			sprintf(cBuf,"IP=%03d.%03d.%03d.%03d%c%c",ipAddr[0],ipAddr[1],ipAddr[2],ipAddr[3],0x0D,0x0A);
			FS_Write( pFile, cBuf, 20);
			sprintf(cBuf,"MASK=%03d.%03d.%03d.%03d",ipMask[0],ipMask[1],ipMask[2],ipMask[3]);
			FS_Write( pFile, cBuf, 20);
			FS_FClose(pFile);
			success = true;
		}
		if (mounted == E_VOLUME_MOUNTED) FS_Unmount(sVolName);
	}
	return success;
}


int CFiles::ReadUserSettings(void *pBuf, int size ) 
{
        int filesize= 0;
        int readcount = 0;
        
	E_VOLUME_STATE mounted = mountFileSystem();
	if (mounted != E_VOLUME_UNKNOWN)
        {
		FS_FILE * pFile = FS_FOpen( "SETTINGS.INI", "r");
		if (pFile != 0)
		{
                    filesize = FS_GetFileSize(pFile);
                    readcount = (size < filesize) ? size : filesize;
                    FS_Read( pFile, pBuf, readcount);
		    FS_FClose(pFile);
		}
		if (mounted == E_VOLUME_MOUNTED)
                    FS_Unmount(sVolName);
	}
	return filesize;
}

int CFiles::WriteUserSettings(void *pBuf, int size ) 
{
        int filesize= 0;

 	E_VOLUME_STATE mounted = mountFileSystem();
	if (mounted != E_VOLUME_UNKNOWN)
        {
		FS_FILE * pFile = FS_FOpen( "SETTINGS.INI", "wb");
		if (pFile != 0)
		{
                    filesize = FS_Write( pFile, pBuf, size);
		    FS_FClose(pFile);
		}
		if (mounted == E_VOLUME_MOUNTED)
                    FS_Unmount(sVolName);
	}
	return filesize;   
}

int CFiles::ReadChuckList( void *pBuf, int size, long offset ) 
{
	int filesize= 0;
  int readcount = 0;
        
	E_VOLUME_STATE mounted = mountFileSystem();
	if (mounted != E_VOLUME_UNKNOWN)
	{
		FS_FILE * pFile = FS_FOpen( "CHUCKLST.INI", "r");
		if (pFile != 0)
		{
			filesize = FS_GetFileSize(pFile);
			readcount = ((size+offset)< filesize) ? size : (filesize-offset);
			FS_FSeek( pFile, (I32)offset, FS_SEEK_SET);
			readcount = FS_Read( pFile, pBuf, readcount );
		  FS_FClose( pFile );
		}
		if (mounted == E_VOLUME_MOUNTED) FS_Unmount(sVolName);
	}
	return readcount;
}


E_VOLUME_STATE CFiles::mountFileSystem(void) 
{
	if (FS_IsVolumeMounted(sVolName)==1) return E_VOLUME_PRESENT;
	else 
	{
		FS_Mount(sVolName);
		if (FS_IsVolumeMounted(sVolName)==1) return E_VOLUME_MOUNTED;
		else return E_VOLUME_UNKNOWN;
	}
}

void CFiles::UnMountFileSystem(void)
{
    if (FS_IsVolumeMounted(sVolName)==1)
    {
        FS_Unmount(sVolName);
    }
}

/**
 * \brief  tells us, if a given filename exists in filesystem
 *
 * \param  const char *pName, the name of the file to be tested
 * \return bool, true: file exists, false: file does not exist
 */
bool CFiles::fileExists(const char * pName)
{
	E_VOLUME_STATE mounted = mountFileSystem();
	if (mounted != E_VOLUME_UNKNOWN)
	{
		FS_FILE * pFile = FS_FOpen( pName, "r");
		if (pFile != NULL) {
			FS_FClose(pFile);
			return true;
		}
	}
	return false;
}

/**
 * \brief  tells us, if a given filename exists in filesystem
 *
 * \param  const char *pName, the name of the file to be tested
 * \return bool, true: file exists, false: file does not exist
 */
int CFiles::fileSize(const char * pName)
{
	int size = 0;
	
	E_VOLUME_STATE mounted = mountFileSystem();
	if (mounted != E_VOLUME_UNKNOWN)
	{
		FS_FILE * pFile = FS_FOpen( pName, "r");
		if (pFile != NULL) 
		{
			size = FS_GetFileSize( pFile );
			FS_FClose(pFile);
		}
	}
	return size;
}
