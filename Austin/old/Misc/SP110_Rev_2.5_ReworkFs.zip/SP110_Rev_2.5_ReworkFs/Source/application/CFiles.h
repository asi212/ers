#ifndef _CARCHIVE
#define _CARCHIVE
extern "C"{
  #include "91x_lib.h"
}

#include "CDataLogger.h"
#include "FS.h"
#include <string>

struct log_entry{
  unsigned char event;
  unsigned char channel;
  unsigned char alarm_st;
  unsigned char spare;      // Current Alarm- Status
  short t_chuck;
  short t_set;
  short t_new;
  unsigned char time_sec; //Time Seconds value
  unsigned char time_min; //Time- Minutes value
  unsigned char time_hou; //Time- Houer of Day value
  unsigned char date_day; //Date- Day ouf Month value
  unsigned char date_mon; //Date- Month of Year value
  unsigned char date_yea; //Date- Year Value
};

typedef enum
{
	E_VOLUME_UNKNOWN,				// No volume mounted
	E_VOLUME_MOUNTED,       // Volume was not mounted and has been mounted succesfully
	E_VOLUME_PRESENT,       // Volume is already mounted
}E_VOLUME_STATE;

/**
  Class CArchive covering archive log entries
*/
class CFiles{
  private:
    u8 FMI_Timeout_Status;
    static const char * sVolName;
    bool bLogSizeEx;
    bool bLoggerSaved;
    
    int iBlocks;         //nuber of blocks for software filetransfer
    int iBlock;          //last block number
    FS_FILE * swu_pFile; //Local File Pointer

  protected:
    static const char event_text[4][10];
    short tOldSet;

  public:
    CFiles(void);
    bool logEvent( unsigned char iEvent, int iChannel, float fTNew );
    bool getEvent( int iIndex, log_entry * pEntry );
    const char * getEventText( unsigned char cEvent );
    void dir( char * pBuf );
		bool fileExists(const char * pName); 									// Returns true, if given file exists, otherwise false
		int fileSize(const char * pName); 										// Returns file size > 0, or 0 in case of error
		bool getLogFile( char * pBuf );
    bool delOlgFile( char * pBuf );
    bool bakLogFile( char * pBuf );
    bool isLoSizeEx(){ return bLogSizeEx;};
    int  getSetup( char * pBuf );
    bool setSetup( char * pBuf );
    bool formatDisk( void );
    void saveLoggerFile( int iSize, CDataLogger * pLogger );
    int  getLoggerFile( char * pBuf );
		bool getIPInfo( const char * key, string * pBuf, char *filename );		// Reads a line from an opened file
		bool writeIPInfo( void );
    
    int ReadUserSettings(void *pBuf, int size );
    int WriteUserSettings(void *pBuf, int size );
		
		int ReadChuckList( void *pBuf, int size, long offset );
  
    E_VOLUME_STATE mountFileSystem(void);
    void UnMountFileSystem(void);
		
    //For Softwareupdate via Diag Interface
    bool initUpdate(int iBlocks);
    int downloadBlock(  int iBlock, int iLen, char * pSource );
    bool downloadMD5(  int iLen, char * pBuf );
    //Object Constants
    static const unsigned char event_startup = 0x01;    //Constant, System startup
    static const unsigned char event_newtemp = 0x02;    //Constant, New Temperatue was set
    static const unsigned char event_errorch = 0x03;    //Constant, Error State has changed
};

#endif