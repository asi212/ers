#include "CProcessData.h"
#include "../MailboxSystem/CEventManager.h"

extern "C"{
  #include "91x_lib.h"
}
#include <stdio.h>

extern CEventManager EventManager;

//Konstanten Initialisieren
unsigned char * const CProcessData::pMains  = (unsigned char*)(0x34000040);

/**
  Constructor for CProcessData
*/
CProcessData::CProcessData( int iCycleTime, CSetup * pSetup ) :
  CTempData(pSetup)
{
  p_CSetup = pSetup;
  
  this->iCycleTime = iCycleTime;
  bResetPending = false;
}

/**
  Cyclic calculations
*/
bool CProcessData::cycCalc( int iCycleTime ){
  // Read ADC Value und store results to the corresponding destinations
  if( !(ADC_GetFlagStatus(ADC_FLAG_ECV) == RESET)){
    sValvNative[0] = ADC_GetConversionValue(ADC_Channel_0);          /* Get the conversion value of dew point sensor     						*/
    sValvNative[1] = ADC_GetConversionValue(ADC_Channel_1);          /* Get the conversion value of KTY sensor at chuck base plate 	*/
    sValvNative[2] = ADC_GetConversionValue(ADC_Channel_2);          /* Get the conversion value of Jumo overtemperature sensor     */
    sValvNative[3] = ADC_GetConversionValue(ADC_Channel_3);          /* Get the conversion value of air pressure sensor							*/
    sValvNative[4] = ADC_GetConversionValue(ADC_Channel_4);          /* Get the conversion value of cold air valve					        */
    sValvNative[5] = ADC_GetConversionValue(ADC_Channel_5);          /* Get the conversion value of cold air valve					        */
    sValvNative[6] = ADC_GetConversionValue(ADC_Channel_6);          /* Get the conversion value of warm air valve			        		*/
    sValvNative[7] = ADC_GetConversionValue(ADC_Channel_7);          /* Get the conversion value of warm air valve			        		*/
    ADC_ClearFlag(ADC_FLAG_ECV);                                     /* Clear the end of conversion flag */
    ADC_ConversionCmd(ADC_Conversion_Start);                         /* Restart the conversion           */
    m_adcTOut = 0;
    _event<short> e1("New DewPoint Value", CEventNames::dew_point_adc, sValvNative[0]);
    EventManager.RaiseEvent(e1);                  
    _event<short> e2("New OverTemperature Value", CEventNames::over_temp_adc, sValvNative[2]);
    EventManager.RaiseEvent(e2);                  
    _event<short> e3("New AirPressure Value", CEventNames::air_pressure_adc, sValvNative[3]);
    EventManager.RaiseEvent(e3);                  
    _event<short> e4("New ADC4 Value", CEventNames::VALVE_1_ADC1, sValvNative[4]);
    EventManager.RaiseEvent(e4);                  
    _event<short> e5("New ADC5 Value", CEventNames::VALVE_1_ADC2, sValvNative[5]);
    EventManager.RaiseEvent(e5);                  
    _event<short> e6("New ADC6 Value", CEventNames::VALVE_2_ADC1, sValvNative[6]);
    EventManager.RaiseEvent(e6);                  
    _event<short> e7("New ADC7 Value", CEventNames::VALVE_2_ADC2, sValvNative[7]);
    EventManager.RaiseEvent(e7);                  
  }
  else{
    if( m_adcTOut++ > 50 ){
      ADC_ConversionCmd(ADC_Conversion_Start);                         /* Restart the conversion           */
    }
  }
  //CValvData::cycCalc( iCycleTime );
  CTempData::cycCalc( iCycleTime );
  return true;
}

/**
  Switch on main relais
*/
void CProcessData::setOnMains( int iSwitch ){
  *pMains |= (0x01<<iSwitch-1);
	
	switch( iSwitch )
	{
	// Inform System, if Lamda-Relay is switched ON
	case MAINS_LAMBDAS:
		{
			_event<bool> b( "ProcessData", CEventNames::set_power_supply_56_relay, true );
			EventManager.RaiseEvent(b);
		}
		break;
	// Inform System, if Baypass-Valve (Bypass 1) is switched ON
	case MAINS_BYPASS_VALVE_1:
		{
			_event<bool> b( "ProcessData", CEventNames::switch_bypass_valve, true );
			EventManager.RaiseEvent(b);
		}
		break;
	// Inform System, if Main-Valve (Bypass 2) or chiller is switched ON
	// Note: In systems with external chiller, chiller is connected to this switch
	case MAINS_CHILLER_OR_VALVE:
		{
			_event<bool> b1( "ProcessData", CEventNames::switch_main_valve, true );
			_event<bool> b2( "ProcessData", CEventNames::switch_chiller_relay, true );

			if ( p_CSetup->getIntChiller() ) EventManager.RaiseEvent(b1);
			else EventManager.RaiseEvent(b2);
		}
		break;
	// Inform System, if chiller relay is switched ON
	case MAINS_COMPRESSOR:
		{
			_event<bool> b( "ProcessData", CEventNames::switch_chiller_relay, true );
			EventManager.RaiseEvent(b);
		}
		break;
	}
}

/**
  Switch off main relais
*/
void CProcessData::setOffMains( int iSwitch )
{
	*pMains &= ~(0x01<<iSwitch-1);  

	switch( iSwitch )
	{
	// Inform System, if Lamda-Relay is switched OFF
	case MAINS_LAMBDAS:
		{
			_event<bool> b( "ProcessData", CEventNames::set_power_supply_56_relay, false );
			EventManager.RaiseEvent(b);
		}
		break;
	// Inform System, if Baypass-Valve (Bypass 1) is switched OFF
	case MAINS_BYPASS_VALVE_1:
		{
			_event<bool> b( "ProcessData", CEventNames::switch_bypass_valve, false );
			EventManager.RaiseEvent(b);
		}
		break;
	// Inform System, if Main-Valve (Bypass 2) or chiller is switched OFF
	// Note: In systems with external chiller, chiller is connected to this switch
	case MAINS_CHILLER_OR_VALVE:
		{
			_event<bool> b1( "ProcessData", CEventNames::switch_main_valve, false );
			_event<bool> b2( "ProcessData", CEventNames::switch_chiller_relay, false );

			if ( p_CSetup->getIntChiller() ) EventManager.RaiseEvent(b1);
			else EventManager.RaiseEvent(b2);
		}
		break;
	// Inform System, if chiller relay is switched OFF
	case MAINS_COMPRESSOR:
		{
			_event<bool> b( "ProcessData", CEventNames::switch_chiller_relay, false );
			EventManager.RaiseEvent(b);
		}
		break;
	}
}


float CProcessData::getFSR_VAL(void){
  return 3.3 / 1024.0;
}

short CProcessData::getNativeValue( int iValue ){
  if( iValue > 0 && iValue < 8 ){
    return sValvNative[iValue];
  }
  return 0;
}

bool CProcessData::resetPending( void ){
  bool bTemp = bResetPending;
  bResetPending = false;
  return bTemp;
}

void CProcessData::ResetErrors(void){
  CTempData::resetErrors();
  bResetPending = true;
}

bool CProcessData::GetErrorStatus(void){
  bool bRetVal = false;
  for( int i = 1; i <= 6; i++ ){
    if( getTErrorStatus(i).cFlags != 0 ){
      bRetVal = true;
    }
  }

  return bRetVal;
}

/**
  @return true on new error or false if nothing new
*/
bool CProcessData::hasNewError( int iChannel, int iL1, int iL2 ){
  unsigned char cNewError = getTErrorStatus(iChannel).cFlags;
  if( iChannel < 0 && iChannel > 8 ){
    return false;
  }
  if( cNewError != cErrorSatus[iChannel- 1] ){
    cErrorSatus[iChannel- 1] = cNewError;
    return true;
  }
  else{
    return false;
  }
}

/**
  If ther is a new Error in the system the function returns the new Error Status
  or 0 if no new Error is emerged. Error Status is only valid for 1 Call per channel.
  Meaning of respective Bits:
  MSB---------------------------------------------------------------------------------LSB
     | FSFail L2 | FBFail L2 | FSFailL1 | FBFailL2 | HOLD | ORANGE | URange | WBreak |
     ---------------------------------------------------------------------------------
*/
unsigned char CProcessData::getOldErrorStatus( int iChannel ){
  if( iChannel < 0 && iChannel > 5 ){
    return 0;
  }
  else{
    return cErrorSatus[iChannel- 1];
  }
}

  
/**
Calculate KTY Resistance
*/
float CProcessData::getP7Val(){
    const float ue = 949.0;
    const float m = 1000.0/2800.0;
    const float R3 = 1800.0;
    
    float r = R3/(1.0/((sValvNative[1]/(2.2*ue))+m) - 1);
    
    return r;
}


