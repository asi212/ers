#ifndef _PROCESS_H
#define _PROCESS_H

#include "CDataContainers.h"
#include "IProcessData.h"

#define MAINS_LAMBDAS						1		// Power supplies for chuck heating
#define MAINS_COMPRESSOR				2		// Compressor of chiller
#define MAINS_BYPASS_VALVE_1		3   // Bypass Valve 1
#define MAINS_CHILLER_OR_VALVE	4   // Chiller (SP110) or Bypass Valve 2 (TS09, TS010)


/**
 Class CProcessData contians a collection of all information required or used by this controllertype
 */
class CProcessData : public CTempData,
  public IProcessData
{

  private:
    int iCycleTime;
    bool bResetPending;
    int m_adcTOut;
    static unsigned char * const pMains;

  protected:
    short sValvNative[8];
    short getNativeValue( int iValue );
    float getFSR_VAL(void);

    unsigned char cErrorSatus[8];
    
    CSetup *p_CSetup;

  public:
    CProcessData( int iCycleTime, CSetup * pSetup );
    bool resetPending( void );
    void ResetErrors(void);
    bool cycCalc( int iCycleTime );
    bool GetErrorStatus(void);
    bool hasNewError( int iChannel, int iL1, int iL2 );
    unsigned char getOldErrorStatus( int iChannel );

    void setOnMains( int iSwitch );
    void setOffMains( int iSwitch );

    virtual float getTemp1(){ return CTempData::getTemp1(); };
    virtual float getTemp2(){ return CTempData::getTemp2(); };
    virtual float getTemp3(){ return CTempData::getTemp3(); };
    virtual float getTemp3( int iTable ){ return CTempData::getTemp3( iTable ); };
    virtual float getTemp4(){ return CTempData::getTemp4(); };
    virtual float getTemp5(){ return CTempData::getTemp5(); };
    virtual float getTemp6(){ return CTempData::getTemp6(); };
    virtual float getTemp7(){ return CTempData::getTemp7(); };
    virtual float getTemp8(){ return CTempData::getTemp8(); };
    virtual float getP7Val();   //Return PT100 7 resistance value

    virtual float getTemp1( bool bWithOffset ){ return CTempData::getTemp1(bWithOffset); };
    virtual float getTemp2( bool bWithOffset ){ return CTempData::getTemp2(bWithOffset); };
    virtual float getTemp3( bool bWithOffset ){ return CTempData::getTemp3(bWithOffset); };
    virtual float getTemp4( bool bWithOffset ){ return CTempData::getTemp4(bWithOffset); };

};

#endif