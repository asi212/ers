extern "C"{
  #include "91x_lib.h"
}

#include "CSetup.h"
#include "FS.h"
#include "CAirTable.h"
#include <cstdio>
#include <cstring>

extern u8 FMI_Timeout_Status;

/**
  Default Constructor for CSetup Class, nothing to do inhere
*/
CSetup::CSetup(void){
  bSetupValid = false;
  bPIDValid = false;
  bConfigValid = false;
  m_CoolingSubSys = E_COOLING_SUBSYS_NONE;
  
  static __no_init float tMemSection[40] @ 0x04017F00;
  for( int i = 0; i < 6; i++ ){
    tempParams[i].initPointers( &tMemSection[i*4] );
  }
}

/**
  Function readSetup copies Data from the Flash Mem to this class
  @return always true, reserferf for future use
*/
bool CSetup::readSetup(){
  void* pStartAddress = &(this->setup);
  char cSetupName[] = "Setup.ini";

  FS_FILE * pFile = FS_FOpen ( cSetupName, "rb" );
  if( pFile != 0 ){
      FS_FSeek( pFile, 0, FS_SEEK_SET );
      FS_Read( pFile, pStartAddress, sizeof( setup ));
      FS_FClose( pFile );
      bSetupValid = true;
      return true;
  }

  return false;
}

/**
  get Temp Offset Factor
  @param iSensor Sensor Number form 1 to 8
*/
float CSetup::getTempOffset( int iSensor ){
  if( iSensor > 0 && iSensor <= 8 ){
    return this->setup.fCalTempOffset[iSensor-1];
  }
  else{
    return 0.0;
  }
}

/**
  set Temp Offset Factor
  @param iSensor Sensor Number form 1 to 8
  @param fValue new Offset Correction factor value
*/
bool CSetup::setTempOffset( int iSensor, float fValue ){
  if( iSensor > 0 && iSensor <= 8 ){
    this->setup.fCalTempOffset[iSensor-1] = fValue;
    return true;
  }
  else{
    #ifdef DEBUG
    printf("runtime error CSetup->setTempOffset iSensor out of range\r\n");
    #endif
    return false;
  }
}

/**
  get Temp Offset Factor
  @param iSensor Sensor Number form 1 to 8
  @return Linear Correction Factor for this channel
*/
float CSetup::getTempLinCorr( int iSensor ){
  if( iSensor > 0 && iSensor <= 8 ){
    return this->setup.fCalTempLinear[iSensor-1];
  }
  else{
    #ifdef DEBUG
    printf("runtime error CSetup->getTempLinCorr iSensor out of range\r\n");
    #endif
    return 0.0;
  }
}

/**
  set Temp Offset Factor
  @param iSensor Sensor Number form 1 to 6
  @param fValue new Offset Correction factor value
  @return true if the value could be set succesfully
*/
bool CSetup::setTempLinCorr( int iSensor, float fValue ){
  if( iSensor > 0 && iSensor <= 8 ){
    this->setup.fCalTempLinear[iSensor-1] = fValue;
    return true;
  }
  else{
    #ifdef DEBUG
    printf("runtime error CSetup->setTempLinCorr iSensor out of range\r\n");
    #endif
    return false;
  }
}

/**
  read PID Setup Parameters
  @param iPIDNum PID Setup number from 1 to 6
  @return returns either a pointer to the selecte PID- Data Structure or a 0- Pointer
*/
t_pid_setup * CSetup::getPIDSetup(int iPIDNum ){
  if( iPIDNum > 0 && iPIDNum < 9 ){
   return &m_pid[iPIDNum-1];
  }
  else{
    #ifdef DEBUG
    printf("runtime error CSetup->getPIDSetup iPIDNum out of range\r\n");
    #endif
    return 0;
  }
}

/**
  set PID Kp Setup Parameters
  @param iPIDNum PID Modifies Setup number from 1 to 4
  @param Kp Proportional factor for this PID Channel
  @return returns true on succes false otherwise
*/
bool CSetup::setKpSetup(int iPIDNum, float Kp){
  if( iPIDNum > 0 && iPIDNum < 9 ){
    m_pid[iPIDNum-1].Kp = Kp;
    return true;
  }
  else{
    #ifdef DEBUG
    printf("runtime error CSetup->setKpSetup iPIDNum out of range\r\n");
    #endif
    return false;
  }
}

/**
  set PID Tn Setup Parameters
  @param iPIDNum PID Modifies Setup number from 1 to 4
  @param Tn Integral constant for this channel
  @return returns true on succes false otherwise
*/
bool CSetup::setTnSetup(int iPIDNum, float Tn){
  if( iPIDNum > 0 && iPIDNum < 9 ){
    m_pid[iPIDNum-1].Tn = Tn;
    return true;
  }
  else{
    #ifdef DEBUG
    printf("runtime error CSetup->setTnSetup iPIDNum out of range\r\n");
    #endif
    return false;
  }
}

/**
  set PID Tv Setup Parameters
  @param iPIDNum PID Modifies Setup number from 1 to 4
  @param Tv differential constant for this PID Channel
  @return returns true on succes false otherwise
*/
bool CSetup::setTvSetup(int iPIDNum, float Tv){
  if( iPIDNum > 0 && iPIDNum < 9 ){
    m_pid[iPIDNum-1].Tv = Tv;
    return true;
  }
  else{
    #ifdef DEBUG
    printf("runtime error CSetup->setTvSetup iPIDNum out of range\r\n");
    #endif
    return false;
  }
}

/**
  set PID Process Window Setup Parameters
  @param iPIDNum PID Modifies Setup number from 1 to 4
  @param PWD Process Window width in �C. If the channel is out of
  this windows the controller is either fully cooling or fully heating
  @return returns true on succes false otherwise
*/
bool CSetup::setPwSetup(int iPIDNum, float PWD){
  if( iPIDNum > 0 && iPIDNum < 9 ){
    m_pid[iPIDNum-1].window = PWD;
    return true;
  }
  else{
    #ifdef DEBUG
    printf("runtime error CSetup->setPwSetup iPIDNum out of range\r\n");
    #endif
    return false;
  }
}

/**
  set PID Min Setup Parameters
  @param iPIDNum PID Modifies Setup number from 1 to 4
  @param min smalest value for this channel in �C
  @return returns true on succes false otherwise
*/
bool CSetup::setMinSetup(int iPIDNum, float min){
  if( iPIDNum > 0 && iPIDNum < 9 ){
    m_pid[iPIDNum-1].min = min;
    return true;
  }
  else{
    #ifdef DEBUG
    printf("runtime error CSetup->setMinSetup iPIDNum out of range\r\n");
    #endif
    return false;
  }
}

/**
  set PID Max Setup Parameters
  @param iPIDNum PID Modifies Setup number from 1 to 8
  @param max maximum value allowed for this channel
  @return returns true on succes false otherwise
*/
bool CSetup::setMaxSetup(int iPIDNum, float max){
  if( iPIDNum > 0 && iPIDNum < 9 ){
    m_pid[iPIDNum-1].max = max;
    return true;
  }
  else{
    #ifdef DEBUG
    printf("runtime error CSetup->setMaxSetup iPIDNum out of range\r\n");
    #endif
    return false;
  }
}

/**
  set PID I Init Factor Setup Parameters
  @param iPIDNum PID Modifies Setup number from 1 to 4
  @param fLin linear multiplicator for initializing the integral value on first reaching
  the process window
  @return returns true on succes false otherwise
*/
bool CSetup::setLinSetup(int iPIDNum, float fLin){
  if( iPIDNum > 0 && iPIDNum < 9 ){
    m_pid[iPIDNum-1].Lin = fLin;
    return true;
  }
  else{
    #ifdef DEBUG
    printf("runtime error CSetup->setfLinSetup iPIDNum out of range\r\n");
    #endif
    return false;
  }
}


/**
  get Temp Offset Factor
  @param iLambdaNum Lambda Number form 1 to 6
*/
float CSetup::getLambdaCal( int iLambdaNum ){
  if( iLambdaNum > 0 && iLambdaNum <= 6 ){
    return this->setup.fCalLambda[iLambdaNum-1];
  }
  else{
    #ifdef DEBUG
    printf("runtime error CSetup->getLambdaCal iLambdaNum out of range\r\n");
    #endif
    return 0.0;
  }
}

/**
  set Lambda Maximum Limit
  @param iLambdaNum Lambda Number form 1 to 8
  @param fValue new Offset Correction factor value
*/
bool CSetup::setLambdaCal( int iLambdaNum, float fValue ){
  if( iLambdaNum > 0 && iLambdaNum <= 6 ){
    this->setup.fCalLambda[iLambdaNum-1] = fValue;
    return true;
  }
  else{
    #ifdef DEBUG
    printf("runtime error CSetup->setLambdaCal iLambdaNum out of range\r\n");
    #endif
    return false;
  }
}

/**
  function writeSetup copy data from this class to falsh memory, of course
  delete flash memory first
  @return always true, reserfed for future use
*/
bool CSetup::writeSetup(){
  char cSetupName[] = "Setup.ini";

  void* pStartAddress = &(this->setup);

  FS_FILE * pFile = FS_FOpen ( cSetupName, "wb" );
  if( pFile != 0 ){
      FS_Write( pFile, pStartAddress, sizeof( setup ) );
      FS_FClose( pFile );
      return true;
  }
  else{
    return false;
  }
}

/**
  obtain pointer to valid t_temp_params Class
*/
CTempParams * CSetup::getTempParamSet( int iSet ){
  if( iSet > 0 && iSet <= 6 ){
    return &tempParams[iSet-1];
  }
  else{
    return 0;
  }
}

/**
    Is External Chiller configured
*/
bool CSetup::getExtChiller( void ){
    if((m_config.cControllerType >= m_config.E_CONTOLLER_HWS_300 && m_config.cControllerType <= m_config.E_CONTOLLER_SWS_D600)||
       (m_config.cControllerType == m_config.E_CONTOLLER_SP102Y2D)||(m_config.cControllerType == m_config.E_CONTOLLER_SP102Y2M) )
    {
        return true;
    }
    else
    {
        return false;
    }
}

/**
    Is Internal Chiller present
*/
bool CSetup::getIntChiller( void )
{
    if( m_config.cControllerType >= m_config.E_CHILLER_MST_SWS_600 && m_config.cControllerType <= m_config.E_DUAL_CHILL_MST_SWS_D600 )
    {
        return true;
    }
    else
    {
        return false;
    }
}

/**
    Is proportional pressure control device present?
*/
bool CSetup::getGetPressDev(void)
{
    if( (m_config.cControllerType >= m_config.E_PROP_VALVE_HWS_300 && m_config.cControllerType <= m_config.E_PROP_VALVE_SWS_D600 )||
      (m_CoolingSubSys == E_COOLING_SUBSYS_PROP_VALVE) )
    {
        return true;
    }
    else{
        return false;
    }
}

/**
    get Controller configuration as char
*/
char CSetup::getConConfig( void ){
    return m_config.cControllerType;
}

/**
    set Controller configuration from external
*/
void CSetup::setConConfig( char cConfig )
{
    if( cConfig >= m_config.E_PROP_VALVE_HWS_300 && cConfig < m_config.E_CON_TYPE_TERM )
    {
        m_config.cControllerType = (_s_config::_e_con_type)cConfig;
    }
    else
    {
        m_config.cControllerType = m_config.E_PROP_VALVE_HWS_300;
    }
}

/**
set Current calibration value
*/
bool CSetup::setCurrCal( int iChannel, float fValue ){
  if( iChannel > 0 && iChannel <= 4 ){
    setup.fCalCurrMeas[iChannel-1] = fValue;
    return true;
  }
  else{
#ifdef DEBUG
    printf("Invalid chuck number setCurrCal\n");
#endif
    return false;
  }
}

/**
set Current Limit
*/
bool CSetup::setCurrLimit( int iChannel, float fValue ){
  if( iChannel > 0 && iChannel <= 4 ){
    setup.fLimitCurr[iChannel-1] = fValue;
    return true;
  }
  else{
#ifdef DEBUG
    printf("Invalid chuck number setCurrLimit\n");
#endif
    return false;
  }
}

/**
set Current calibration value
*/
bool CSetup::setVoltCal( int iChannel, float fValue ){
  if( iChannel > 0 && iChannel <= 4 ){
    setup.fCalVoltMeas[iChannel-1] = fValue;
    return true;
  }
  else{
#ifdef DEBUG
    printf("Invalid chuck number setCurrCal\n");
#endif
    return false;
  }
}

/**
set Current Limit
*/
bool CSetup::setVoltLimit( int iChannel, float fValue ){
  if( iChannel > 0 && iChannel <= 4 ){
    setup.fLimitVolt[iChannel-1] = fValue;
    return true;
  }
  else{
#ifdef DEBUG
    printf("Invalid chuck number setCurrLimit\n");
#endif
    return false;
  }
}

/**
  get Current Calibration value
*/
float CSetup::getCurrCal( int iChuck ){
  if( iChuck > 0 && iChuck <= 4 ){
    return setup.fCalCurrMeas[iChuck-1];
  }
  else{
#ifdef DEBUG
    printf("Invalid chuck number getCurrCal\n");
#endif
    return 0.0;
  }
}

/**
  get Current Limit for chuck
*/
float CSetup::getCurrLimit( int iChuck ){
  if( iChuck > 0 && iChuck <= 4 ){
    return setup.fLimitCurr[iChuck-1];
  }
  else{
#ifdef DEBUG
    printf("Invalid chuck number getCurrLimit\n");
#endif
    return 0.0;
  }
}

/**
  get Voltage Calibration value
*/
float CSetup::getVoltCal( int iChuck ){
  if( iChuck > 0 && iChuck <= 4 ){
    return setup.fCalVoltMeas[iChuck-1];
  }
  else{
#ifdef DEBUG
    printf("Invalid chuck number getCurrCal\n");
#endif
    return 0.0;
  }
}

/**
  get Current Voltage for chuck
*/
float CSetup::getVoltLimit( int iChuck ){
  if( iChuck > 0 && iChuck <= 4 ){
    return setup.fLimitVolt[iChuck-1];
  }
  else{
#ifdef DEBUG
    printf("Invalid chuck number getVoltLimit\n");
#endif
    return 0.0;
  }
}


/********************************************************************************************************************
* Method: SetOffsetTable 
* Purpose: Copies the new Table values 
*
* Input:  - tab points to a table of  2 x 20 values
*
* REMARKS: It uses = operator to copy values from the function argument to the class instance variable
********************************************************************************************************************/
bool CSetup::setOffsetTable( int Table, _o_tab tab )
{
    if( Table > 0 && Table <= 3 )
    {
        OffsetTable.table[Table-1] = tab;
        return true;
    }
    else
    {
        return false;
    }
}

/**
read back offset value from table
*/
_o_tab * CSetup::getOffsetTable( int Table ){
  if( Table > 0 && Table <= 3 ){
    return &OffsetTable.table[Table-1];
  }
  else{
    return 0;
  }
}

bool CSetup::readOffsetTable(void)
{
  char cOffsettName[] = "offsett.ini";
  FS_FILE * pFile = FS_FOpen ( cOffsettName, "rb" );
  if( pFile != 0 ){
      FS_FSeek( pFile, 0, FS_SEEK_SET );
      FS_Read( pFile, &OffsetTable, sizeof( _o_table ) );
      FS_FClose( pFile );
      return true;
  }
  return false;
}

bool CSetup::writeOffsetTable(){
  char cSetupName[] = "offsett.ini";
  FS_FILE * pFile = FS_FOpen ( cSetupName, "wb" );
  if( pFile != 0 ){
      FS_Write( pFile, &OffsetTable, sizeof( _o_table ) );
      FS_FClose( pFile );
      return true;
  }
  else{
    return false;
  }
}

/**
Lade Konfiguration
*/
bool CSetup::readConfig(void)
{
  u32 fsize = 0;
  
  char f[] = "config.ini";
  FS_FILE * pFile = FS_FOpen ( f, "rb" );
  if( pFile != 0 ){
      FS_FSeek( pFile, 0, FS_SEEK_SET );
      
      fsize = FS_Read( pFile, &m_config, sizeof( _s_config ) );
      FS_FClose( pFile );
      //Copy data to SRam location
      for( int i = 0; i < 6; i++ ){
        tempParams[i].setMinLimit(m_config.fChanMinVal[i]);
        tempParams[i].setMaxLimit(m_config.fChanMaxVal[i]);
      }

      bConfigValid = true;
      return true;
  }
  return false;
}

/**
Speichere Konfiguration
*/

bool CSetup::writeConfig(void){
  char f[] = "config.ini";
   FS_FILE * pFile = FS_FOpen ( f, "wb" );
   if( pFile != 0 ){
      //Copy data from SRam location to flash location
      for( int i = 0; i < 6; i++ ){
        m_config.fChanMinVal[i] = tempParams[i].getMinLimit();
        m_config.fChanMaxVal[i] = tempParams[i].getMaxLimit();
      }
      FS_Write( pFile, &m_config, sizeof( _s_config ) );
      FS_FClose( pFile );
      return true;
  }
  else{
    return false;
  }
}

/**
 * Writes the name of a certain pid-file into given buffer.
 * The buffer must have at least size PID_FILE_NAME_LEN!!!
 *
 * Which pid name to be given is defined by i, can be 0 to 99
 */
void CSetup::getPidFileName( char* buf, int i)
{
	strncpy( buf, "pid00.ini", PID_FILE_NAME_LEN );
	
  buf[3] += (i/10)%10;
  buf[4] += (i/ 1)%10;  	
}

/**
Lade PID Setup Nummer, von 0..99 m�glich
*/
bool CSetup::readPIDSet( int i )
{
	char f[PID_FILE_NAME_LEN] = {0};
	getPidFileName( f, i);
	FS_FILE * pFile = FS_FOpen ( f, "rb" );
  if( pFile != 0 ){
      FS_FSeek( pFile, 0, FS_SEEK_SET );
      FS_Read( pFile, m_pid, sizeof( m_pid ) );
      FS_FClose( pFile );
      bPIDValid = true;
      return true;
  }
  return false;
}


/**
Speichere PID Setup Nummer, von 1..99 m�glich
*/

bool CSetup::writePIDSet( int i ){
	char f[PID_FILE_NAME_LEN] = {0};
	getPidFileName( f, i);
  FS_FILE * pFile = FS_FOpen ( f, "wb" );
  if( pFile != 0 ){
      FS_Write( pFile, m_pid, sizeof( m_pid ) );
      FS_FClose( pFile );
      return true;
  }
  else{
    return false;
  }
}
void CSetup::WriteDefaultOffsetTables(void)
{
    _o_tab tab;
    float f = - 100.0;
    int i;
     
    for( i= 0; i < 20; i++ )
    {
      f += 20;
      tab.temp[i] = f;
      tab.offsett[i] = f;
    }
    tab.temp[0] = -60.0;
    tab.offsett[0] = -60.0;
    tab.temp[1] = -50.0;
    tab.offsett[1] = -50.0;
  
    setOffsetTable( 1, tab );
    f = -50;
    for(  i = 0; i < 20; i++ )
    {
      f += 10;
      tab.temp[i] = f;
      tab.offsett[i] = f;
    }
    setOffsetTable( 2, tab );
    setOffsetTable( 3, tab );
    writeOffsetTable();  
}
void CSetup::WriteDefaultPIDs(void)
{
      
    for(int i = 0; i < 2; i++)
    {
        m_pid[i].Kp = 50;
        m_pid[i].Tn = 8000;
        m_pid[i].Tv = 0.1;
        m_pid[i].window = 1.2; 
        m_pid[i].min = 0;
        m_pid[i].max =100; 
        m_pid[i].Lin = 35;
        m_pid[i].Db  = 0;				
        m_pid[i].Ta  = 35;
    }   
    for(int i = 2; i < 16; i++)
    {
        m_pid[i].Kp = 80;
        m_pid[i].Tn = 160;
        m_pid[i].Tv = 2;
        m_pid[i].window = 1.2; 
        m_pid[i].min = 0;
        m_pid[i].max =100; 
        m_pid[i].Lin = 0;
        m_pid[i].Db	 = 0;				
        m_pid[i].Ta	 = 10;
    }  
    // 2 and 5
    m_pid[1].Kp = 30;
    m_pid[1].Lin = 32;
    m_pid[4].Kp = 0.2;
   
    writePIDSet(1);
    writePIDSet(2);
    writePIDSet(3);
}
/*******************************************************************************
* Method Name  	 : WriteDefaultAirTables
* Description    : Initialize the Default tables and saves them to file system
*
*                  The tables are defined as constants in the header file.
*
*
* Return         : None
*******************************************************************************/
void CSetup::WriteDefaultAirTables(void)
{
    CAirTable *pa = new  CAirTable();
    
    pa->InitialAirTable(E_AT_OPTION300);
    pa->saveAirTable(AirTabelFile_300); /* Initiliaze default table. */
    
    pa->InitialAirTable(E_AT_OPTION200);
    pa->saveAirTable(AirTabelFile_200); 
    
    pa->InitialAirTable(E_AT_OPTION150);
    pa->saveAirTable(AirTabelFile_150);
    
    delete[]pa;
}

bool CSetup::WriteDefaultSettings(void)
{
    int i;
    // Chuck Limits
    tempParams[0].setMinLimit(-70.5);
    tempParams[0].setMaxLimit(+310.50);
    // Chiller Limits
    tempParams[1].setMinLimit(-100.0);
    tempParams[1].setMaxLimit(+100.0);
     // Iniside Temp Limits
    tempParams[2].setMinLimit(0);
    tempParams[2].setMaxLimit(+60);
    // KTY (Chuck bottom) Limits
    tempParams[3].setMinLimit(-70.5);
    tempParams[3].setMaxLimit(+180.0);
    //Channel 5
    tempParams[4].setMinLimit(-70.5);
    tempParams[4].setMaxLimit(+310.50);
 
    m_config.cControllerType = m_config.E_CHILLER_MST_SWS_D600;
    m_config.proto_type = m_config.E_TELP8_ASCII;
    m_config.options.has_DewPoint = false;
    m_config.options.allow_LowNoise = false;
    for( i = 0; i < 5; i++ )
    {
        ((bool*)&m_config.screens)[i] =  true;
    }
    
   ((bool*)&m_config.screens)[1] = false; // now Dewpoint
    m_config.pid_set = 1;
    m_config.air_table = m_config.E_AIR_300;
    
    writeConfig(); // Save config file.
    
    // START SETUP INI 
    for( i = 0; i < 4; i++ )
    {
        setup.fLimitVolt[i]   = 60.0;
        setup.fCalVoltMeas[i] =  48.2;
        setup.fLimitCurr[i]   =  7.0;
        setup.fCalCurrMeas[i] = 4.42;
    }
    for( i = 0;  i < 8; i++ )
    {
         setup.fCalTempOffset[i] = -0.01;
         setup.fCalTempLinear[i] = 1.0013;
    }
    setup.fCalTempOffset[4] = -1.67; // Chilller PT100
    setup.fCalTempLinear[4] = 1.0011;
  
    for( i = 0;  i < 6; i++ )
    {
        if (i<4) setup.fCalLambda[i] = 0.5;
        else setup.fCalLambda[i] = 0.494;
    }
    writeSetup();
    WriteDefaultOffsetTables(); // Table offsets
    WriteDefaultPIDs();
    WriteDefaultAirTables();
    
    return true; // not clean !
}
 

/**
Abfrage des Bidlschimr Status
*/
bool CSetup::getScreenStatus( _s_config::_s_screens::_e_screens s )
{
    if( s <= _s_config::_s_screens::TC )
    {
        return ((bool*)&m_config.screens)[s];
    }
    return false;
}

unsigned char CSetup::getScreenStatus(void)
{
    unsigned char c = 0;
    for( int i = 0; i < 5; i++ )
    {
        if( ((bool*)&m_config.screens)[i] )
        {
            c += 0x01<<i;
        }
    }
    return c;
}

void CSetup::setScreenStatus( _s_config::_s_screens::_e_screens s, bool bStatus )
{
    if( s <= _s_config::_s_screens::TC )
    {
        ((bool*)&m_config.screens)[s] = bStatus;
    }    
}

void CSetup::setScreenStatus( unsigned char c )
{
    for( int i = 0; i < 5; i++ )
    {
        ((bool*)&m_config.screens)[i] = (( c & 0x01<<i) != 0) ? true : false;
    }
}

/**
Protokollsteuerung
*/
CSetup::_s_config::_e_proto_type CSetup::getProtocollType()
{
    return m_config.proto_type;
}

void CSetup::setProtocollType( _s_config::_e_proto_type p )
{
    m_config.proto_type = p;
}

/**
Optionene
*/

#define OPT_HAS_DEWPOINT 		0x01
#define OPT_ALLOW_LOWNOISE	0x02 

unsigned char CSetup::getOptions(void)
{
    unsigned char c = 0;
    for( int i = 0; i < 5; i++ )
    {
        if( ((bool*)&m_config.options)[i] )
        {
            c += 0x01<<i;
        }
    }
    return c;
   
}


void CSetup::setOptions(unsigned char c)
{
    for( int i = 0; i < 8; i++ )
    {
        ((bool*)&m_config.options)[i] = (( c & 0x01<<i) != 0) ? true : false;
    }    
}

bool CSetup::getDewPointInstalled( void )
{
	  return ((bool*)&m_config.options)[0] ; 
}