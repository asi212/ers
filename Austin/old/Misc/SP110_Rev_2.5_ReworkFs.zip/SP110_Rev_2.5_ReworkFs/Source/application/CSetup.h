#ifndef CSETUP_H
#define CSETUP_H
#include "CTempParams.h"
#include "IPIDController.h"


#define SETUP_NUM_PID_SETS 16
#define PID_FILE_NAME_LEN	 10		// Length including teminating \0

/**
Class CSetup.h
*/
typedef enum
{
  E_COOLING_SUBSYS_NONE,
  E_COOLING_SUBSYS_INT_CHILLER,
  E_COOLING_SUBSYS_EXT_CHILLER,
  E_COOLING_SUBSYS_PROP_VALVE,
  E_COOLING_SUBSYS_INT_DUAL
}E_COOLING_SUB_SYSTEM;

struct _o_tab{
  float temp[20];
  float offsett[20];
  public:
  _o_tab & operator =( const _o_tab & exTab)
  {
    for( int i = 0; i < 20; i++ ){
      this->temp[i] = exTab.temp[i];
      this->offsett[i] = exTab.offsett[i];
    }
    return *this;
  }
};

struct _o_table{
  _o_tab table[3];
};

class CSetup{
    public:
    struct _s_setup {
      float fCalTempOffset[8]; // 0.0
      float fCalTempLinear[8]; // 1.0
      float fCalLambda[6];     // 0.1
      float fCalCurrMeas[4];   // 5.0
      float fLimitCurr[4];     // 6.0
      float fCalVoltMeas[4];   // 50
      float fLimitVolt[4];     // 60
    };
    
    struct _s_config{
      unsigned short pid_set;    		// Nummer des PID- Setups f�r diesne Chuck
      float fChanMinVal[8];      		// Kanal Limit minimal temperatur    // -80
      float fChanMaxVal[8];      		// Kanal Limit maximal temperatur    // +160
      enum _e_con_type
			{          										// Controller Types:
          E_PROP_VALVE_HWS_300,  		// Has only proportional valve
          E_PROP_VALVE_HWS_D300, 		// Has only proportional valve
          E_PROP_VALVE_SWS_600,  		// Has only proportional valve
          E_PROP_VALVE_SWS_D600, 		// Has only proportional valve
          E_CONTOLLER_HWS_300,   		// Is stand alone controller extern chiller
          E_CONTOLLER_HWS_D300,  		// Is stand alone controller extern chiller
          E_CONTOLLER_SWS_600,   		// Is stand alone controller extern chiller
          E_CONTOLLER_SWS_D600,  		// Is stand alone controller extern chiller  (default)
          E_CHILLER_MST_SWS_600, 		// Is Chiller as Master
          E_CHILLER_MST_SWS_D600,		// Is Chiller as Master
          E_DUAL_CHILL_MST_SWS_D600,      // Is Dual-Chiller as Master
          E_CONTOLLER_SP102Y2D,           // Replacement for SP92Y2 Serie with External Chiller and Proportional Valve 
          E_CONTOLLER_SP102Y2M,           // Replacement for SP92Y2 Serie with External Chiller and automatic Dewpoint Defrost function
          E_CHILLER_SLV,         		// Is Chiller in slave mode: Not used in code
          E_AUTO_CON,            		// Is Controller automatically switching beetween Valve Controlling and external chiller
          E_ANA_ONE,              	// Controls one Analog Amplifier: Not used in code
          E_ANA_TWO,              	// Controls two Analog Amplifier: Not used in code
          E_ANA_THREE,            	// Controls three Analog Amplifier: Not used in code
          E_ANA_FOUR,             	// Controls four Analog Amplifier: Not used in code
					
          E_CON_TYPE_TERM           // Must be last enum. Only used to terminate the list
      } cControllerType; 
      enum _e_air_table
      {
          E_AIR_300,   // default
          E_AIR_200,
          E_AIR_150,
          E_AIR_none
      } air_table;
      //Aktivierung der Bildschirme
      struct _s_screens
      {
          bool enable_HS;       //Hold Mode, Standby Mode Bildschirm aktiv   (1)
          bool enable_CDCS;     //CDCS Bildschimr aktiv  (0)
          bool enable_TDC;      //TDC Bildschirm aktiv
          bool enable_SCC;      //SCC Bildschirm aktiv
          bool enable_TC;       //Temperaturkompensationsbildschirm aktiv
          //Namen f�r die Positionen
          enum _e_screens
          {
              HS,   // default
              CDCS,
              TDC,
              SCC,
              TC
          };
      } screens;
          
      //Zus�tzlich Optionen
      struct _s_options
      {
          bool has_DewPoint;    //Taupunktioption aktivieren    // 0
          bool allow_LowNoise;  //low Noise Regelung erlaubt    // 0
          bool allow_;          //Weiter Optionen, weis ich jetzt noch nicht
          bool hasxx3;          //Weiter Optionen, weis ich jetzt noch nicht
          bool hasxx4;          //Weiter Optionen, weis ich jetzt noch nicht
          bool hasxx5;          //Weiter Optionen, weis ich jetzt noch nicht
          bool hasxx6;          //Weiter Optionen, weis ich jetzt noch nicht
          bool hasxx7;          //Weiter Optionen, weis ich jetzt noch nicht
      } options;
      //Einstellung des Kommunikationsprotokols
      enum _e_proto_type{
          E_TELP8_ASCII,  // default
          E_TELP12_ASCII,
          E_TELP8_ENACQ,
          E_TELP12_ENACQ,
          E_EG_ASCII,
          E_EG_ENACQ,
          E_TSK_ASCII,
          E_TSK_ENACQ
      } proto_type;
      
    } m_config;
		
    private:
    _s_setup setup;
    _o_table OffsetTable;
    t_pid_setup m_pid[SETUP_NUM_PID_SETS];
    E_COOLING_SUB_SYSTEM m_CoolingSubSys; 
      
    bool bSetupValid;
    bool bPIDValid;
    bool bConfigValid;

  protected:
    CTempParams tempParams[6];
    int iBreakCouter;

  public:
    CSetup(void);
    bool  readSetup();
    bool  writeSetup();
    bool  readConfig();
    bool  writeConfig();
    bool  readOffsetTable();
    bool  writeOffsetTable();
    bool  readPIDSet( int set );
    bool  writePIDSet( int set );
    
    bool WriteDefaultSettings(void);
    void WriteDefaultOffsetTables(void);
    void WriteDefaultPIDs(void);
    void WriteDefaultAirTables(void);
    
    float getTempOffset( int iSensor );
    bool  setTempOffset( int iSensor, float fValue );
    float getTempLinCorr( int iSensor );
    bool  setTempLinCorr( int iSensor, float fValue );
    float getLambdaCal( int iLambdaNum );
    bool  setLambdaCal( int iLambdaNum, float fValue );

    t_pid_setup * getPIDSetup(int iPIDNum);
    bool setKpSetup(int iPIDNum, float Kp);
    bool setTnSetup(int iPIDNum, float Tn);
    bool setTvSetup(int iPIDNum, float Tn);
    bool setPwSetup(int iPIDNum, float Tn);
    bool setMinSetup(int iPIDNum, float Tn);
    bool setMaxSetup(int iPIDNum, float Tn);
    bool setLinSetup(int iPIDNum, float fLin);
    bool setOffsetTable( int iTable, _o_tab table );
    _o_tab * getOffsetTable( int iTable );

    bool getExtChiller( void );
    bool getIntChiller( void );
    bool getGetPressDev(void);
    char getConConfig( void );
    void setConConfig( char cConfig );   
    E_COOLING_SUB_SYSTEM GetCoolingSubSys(void){return m_CoolingSubSys;};
    void SetCoolingSubSys( E_COOLING_SUB_SYSTEM ecs){ m_CoolingSubSys = ecs;};
 
    bool setCurrCal( int iChannel, float fValue );
    bool setCurrLimit( int iChannel, float fValue );
    bool setVoltCal( int iChannel, float fValue );
    bool setVoltLimit( int iChannel, float fValue );
    float getCurrCal( int iChannel );
    float getCurrLimit( int iChannel );
    float getVoltCal( int iChannel );
    float getVoltLimit( int iChannel );
    
    bool getScreenStatus( _s_config::_s_screens::_e_screens s );
    unsigned char getScreenStatus(void);
    void setScreenStatus( _s_config::_s_screens::_e_screens s, bool bStatus );
    void setScreenStatus( unsigned char c);
    _s_config::_e_proto_type getProtocollType();
    void setProtocollType( _s_config::_e_proto_type );
    bool getOptionDewPoint(){ return m_config.options.has_DewPoint; };
    unsigned char getOptions(void);
    void setOptionDewPoint(bool b){ m_config.options.has_DewPoint = b;};
    void setOptions(unsigned char c);
		bool getDewPointInstalled( void );
    _s_config::_e_air_table getAirTable(){ return m_config.air_table; };
    void setAirTable(_s_config::_e_air_table t){ m_config.air_table = t;};
    unsigned short getPidSetNr(){ return m_config.pid_set; };
    void setPidSetNr(unsigned short n){ m_config.pid_set = n; };

    CTempParams * getTempParamSet( int iSet );
    bool bIsValid(void){ return bSetupValid && bPIDValid && bConfigValid; };
    int iSetupSize(){ return sizeof(setup); };
		void getPidFileName( char* buf, int i);


};



#endif