#include "CChillerCom.h"


#include <cstdlib>
#include <cstdio>
#include <cstring>

extern "C"{
  #include "91x_lib.h"
}


// Global variables
#define LF   0x0A
#define CR   0x0D

/**Inti pointers */
unsigned char * const CSpeaCom::pRReg = (unsigned char*)(0x34000090);
unsigned char * const CSpeaCom::pWReg = (unsigned char*)(0x34000091);
unsigned char * const CSpeaCom::pISZ  = (unsigned char*)(0x34000092);
unsigned char * const CSpeaCom::pOSZ  = (unsigned char*)(0x34000093);
unsigned char * const CSpeaCom::pIBOX = (unsigned char*)(0x34000094);
unsigned char * const CSpeaCom::pOBOX = (unsigned char*)(0x34000095);

/**
 Standard constructor
*/
CSpeaCom::CSpeaCom( CSetup * pSetup, void * pCallback ){
  ptNotifyIfcEvent = (bool(*)(CSpeaCom::ifc_event, void*))pCallback;
  index = 0;
  bPacketReady = false;
  strncpy(istascii[0],"+0260",5);
  bNewValue = false;
  cLockMode = 0x30;
  strcpy( sErrorMsg, "000" );
  this->pSetup = pSetup;
}

/************************************************************************************
*
* Task          : UartTask
* Purpose       : manages Communictation between chiller and Controller
**************************************************************************************/
bool CSpeaCom::cycExec(void){
  for( ; *pISZ > 0; index++){
    *pRReg = 1;
    waitForFGPARx();
    //additionaly safety for index checking
    if( index >= BUF_SIZE ){
      index = BUF_SIZE-1;
    }
    MsgRxBuf[index] = *pIBOX;
    if( MsgRxBuf[index] == LF ){
      bPacketReady = true;
      break;
    }
  }
  if( bPacketReady ){
     InterpreteCmd(&MsgRxBuf[0],&MsgTxBuf[0]);
     index=0;
     do{
       ch =  MsgTxBuf[index++];
        SendUARTChar(ch);
     }while( ch != LF );
     index = 0;
     bPacketReady = false;
  }
  return true;
}

/**
  check if there is a new setpoint for the system
*/
int CSpeaCom::hasNewValue( void ){
  if( bNewValue ){
    bNewValue = false;
    return iChanSel;
  }
  else{
    return 0;
  }
}

int CSpeaCom::getValue( void ){
  bNewValue = false;
  return sollbin;
}

void CSpeaCom::SetTempValue( int iTemp, float fValue ){
  int iValue = (int)(fValue * 10.0);
  sprintf( istascii[iTemp-1], "%+0.4d", iValue );
}

void CSpeaCom::TerminateString(char *buf, int index)
{
    buf[index] = CR;
    buf[index+1] = LF;
    buf[index + 2] = 0;
}

void CSpeaCom::NotOK(char *buf)
{
        buf[0] = '?';
        buf[1] = CR;
        buf[2] = LF;
}

void CSpeaCom::WasOK(char *buf)
{
        buf[0] = 'O';
        buf[1] = 'K';
        buf[2] = CR;
        buf[3] = LF;

}


void CSpeaCom::InterpreteCmd(char *buf, char *sendbuf){
  bool cmd = false;
  char cTemp;
  char aTemp[4];
  float fTemp;
  signed char sTemp[4];
  if( buf[0] == 'S')  {
    switch(buf[1])  {
      case 'T':
        if( (buf[7] == CR) || (buf[7] == LF) ){
          if ((buf[2] == '+') || (buf[2] == '-')){
            cmd = true;
            buf[7] = 0;
            sollbin = 10 * atoi(&buf[2]); /* Ascii->binaer */
            fTemp = (float)sollbin / 100.0; //Calback soll in zukunft das bl�de sollbin ersetzen
            iChanSel = 1;
            ptNotifyIfcEvent( CSpeaCom::NEW_TEMP, (void*)&fTemp );
            bNewValue = true;
          }
        }
      break;

      case 'O':
        cTemp = atoi(&buf[2]);
        if( ptNotifyIfcEvent( CSpeaCom::NEW_MODE, (void*)&cTemp )){
            cmd = true;
        }
        else{
          cmd = false;
        }
      break;

      case 'L':
        cTemp = atoi(&buf[2]);
        if( ptNotifyIfcEvent( CSpeaCom::NEW_LOCK, (void*)&cTemp )){
            cLockMode = cTemp;
            cmd = true;
        }
        else{
          cmd = false;
        }
      break;

      case 'A':
        aTemp[0] = buf[2] - 0x30;
        aTemp[1] = buf[3] - 0x30;
        aTemp[2] = buf[4] - 0x30;
        aTemp[3] = buf[5] - 0x30;
        if( ptNotifyIfcEvent( CSpeaCom::NEW_CSTT, (void*)aTemp )){
            cmd = true;
        }
        else{
          cmd = false;
        }
      break;
      
      case 'M':
        buf[ 5] = 0x00;  //split string for atio function
        buf[ 9] = 0x00;
        buf[13] = 0x00;
        sTemp[0] = atoi(&buf[2]);
        sTemp[1] = atoi(&buf[6]);
        sTemp[2] = atoi(&buf[10]);
        sTemp[3] = atoi(&buf[14]);
        if( ptNotifyIfcEvent( CSpeaCom::NEW_OFST, (void*)sTemp )){
            cmd = true;
        }
        else{
          cmd = false;
        }
      break;

      case 'P':
        cTemp = atoi(&buf[2]);
        if( ptNotifyIfcEvent( CSpeaCom::NEW_PIDS, (void*)&cTemp )){
            cmd = true;
        }
        else{
          cmd = false;
        }
      break;

      case 'U':
        cTemp = atoi(&buf[2]);
        if( ptNotifyIfcEvent( CSpeaCom::NEW_SFIL, (void*)&cTemp )){
            cmd = true;
        }
        else{
          cmd = false;
        }
      break;

      default:
      break;
    }
    if( cmd == true ){
      WasOK(sendbuf);
    }
    else{
      NotOK(sendbuf);
    }
  }
  //Read commands starting with R
  else if( buf[0] == 'R'){
    switch (buf[1]){
      case 'C':
        cmd = true;
        sendbuf[0] = 'C';
        switch( buf[2] ){
          case '1':
            sendbuf[1] = '1';
            strncpy(&sendbuf[2], istascii[0], 5);
            TerminateString(&sendbuf[0], 7);
          break;
          case '2':
            sendbuf[1] = '2';
            strncpy(&sendbuf[2], istascii[1], 5);
            TerminateString(&sendbuf[0], 7);
          break;
          case '3':
            sendbuf[1] = '3';
            strncpy(&sendbuf[2], istascii[2], 5);
            TerminateString(&sendbuf[0], 7);
          break;
          case '4':
            sendbuf[1] = '4';
            strncpy(&sendbuf[2], istascii[3], 5);
            TerminateString(&sendbuf[0], 7);
          break;
          case '\r':
          case '\n':
            strncpy(&sendbuf[1], istascii[4], 5);
            TerminateString(&sendbuf[0], 6);
          break;
          default:
            cmd = false;
          break;
        }
      break;
      case 'S':
        cmd = true;
        sendbuf[0] = 'S';
        sendbuf[1] = buf[2];
        switch( buf[2] ){
          case '1':
            sendbuf[2] = buf[3];
            switch( buf[3] ){
              case '0':
                strncpy(&sendbuf[3], istascii[17], 5);
                TerminateString(&sendbuf[0], 8);
              break;
              case '1':
                strncpy(&sendbuf[3], istascii[18], 5);
                TerminateString(&sendbuf[0], 8);
              break;
              case '2':
                strncpy(&sendbuf[3], istascii[19], 5);
                TerminateString(&sendbuf[0], 8);
              break;
              case '3':
                strncpy(&sendbuf[3], istascii[20], 5);
                TerminateString(&sendbuf[0], 8);
              break;
              case '4':
                strncpy(&sendbuf[3], istascii[21], 5);
                TerminateString(&sendbuf[0], 8);
              break;
              case '5':
                strncpy(&sendbuf[3], istascii[22], 5);
                TerminateString(&sendbuf[0], 8);
              break;
              case '6':
                strncpy(&sendbuf[3], istascii[23], 5);
                TerminateString(&sendbuf[0], 8);
             break;
              default:
                strncpy(&sendbuf[2], istascii[8], 5);
                TerminateString(&sendbuf[0], 7);
              break;
            }
            return;

          case '2':
            strncpy(&sendbuf[2], istascii[9], 5);
          break;
          case '3':
            strncpy(&sendbuf[2], istascii[10], 5);
          break;
          case '4':
            strncpy(&sendbuf[2], istascii[11], 5);
          break;
          case '5':
            strncpy(&sendbuf[2], istascii[12], 5);
          break;
          case '6':
            strncpy(&sendbuf[2], istascii[13], 5);
          break;
          case '7':
            strncpy(&sendbuf[2], istascii[14], 5);
          break;
          case '8':
            strncpy(&sendbuf[2], istascii[15], 5);
          break;
          case '9':
            if( buf[3] == '9' ){
              for( int i = 0; i < 16; i++ ){
                sprintf(&sendbuf[i*9], "S%0.2d", i + 1);
                strncpy(&sendbuf[(i*9) + 3], istascii[i+8], 5);
                sendbuf[(i*9) + 8] = '\r';
              }
              TerminateString(&sendbuf[0], 143);
              cmd = true;
              return;
            }
            else{
              strncpy(&sendbuf[2], istascii[16], 5);
            }
          break;
          default:
            cmd = false;
          break;
        }
        TerminateString(&sendbuf[0], 7);
      break;
      case 'O':
        sendbuf[0] = 'O';
        sendbuf[1] = sMode[0];
        sendbuf[2] = sMode[1];
        TerminateString(&sendbuf[0], 3);
        cmd = true;
      break;
      case 'E':
        sendbuf[0] = 'E';
        sendbuf[1] = sError[0];
        sendbuf[2] = sError[1];
        sendbuf[3] = sError[2];
        sendbuf[4] = sError[3];
        TerminateString(&sendbuf[0], 5);
        cmd = true;
      break;
      case 'e':
        sprintf( &sendbuf[0], "e%s\r\n", sErrorMsg);
        cmd = true;
      break;
      case 'A':
        sendbuf[0] = 'C';
        sendbuf[1] = sCOnOff[0] + 0x30;
        sendbuf[2] = sCOnOff[1] + 0x30;
        sendbuf[3] = sCOnOff[2] + 0x30;
        sendbuf[4] = sCOnOff[3] + 0x30;
        TerminateString(&sendbuf[0], 5);
        cmd = true;
      break;
      case 'L':
        sendbuf[0] = 'L';
        sendbuf[1] = cLockMode;
        TerminateString(&sendbuf[0], 2);
        cmd = true;
      break;

      case 'U':
        sendbuf[0] = 'U';
        sendbuf[1] = cSelSetup;
        TerminateString(&sendbuf[0], 2);
        cmd = true;
      break;

      case 'M':
        sprintf( &sendbuf[0], "O%+0.2d\r%+0.2d\r%+0.2d\r%+0.2d\r\n", (int)(pSetup->getOffsetTable(1)*10.0),
                (int)(pSetup->getOffsetTable(2)*10.0), (int)(pSetup->getOffsetTable(3)*10.0), (int)(pSetup->getOffsetTable(4)*10.0) );
        cmd = true;
      break;

      case 'P':
        sendbuf[0] = 'P';
        sendbuf[1] = '1';
        TerminateString(&sendbuf[0], 2);
        cmd = true;
      break;

      case 'V':
        sprintf( &sendbuf[0], "%s\r\n", REV );
        cmd = true;
      break;

    }
    if( cmd == false){
      NotOK(sendbuf);
    }
  }
}


int CSpeaCom::SendUARTChar( char ch){
  *pOBOX = ch;
  *pWReg = 1;
  waitForFGPATx();
  return EDC_OK;
}

void CSpeaCom::setCHMode( char cMode ){
  sprintf( sMode, "%0.2d", cMode );
}

void CSpeaCom::setCHError( int iError ){
  sprintf( sError, "%0.3d", iError );
}

void CSpeaCom::setCHError( char pBuff[5] ){
  memcpy( sError, pBuff, 5 );
}

void CSpeaCom::setCHOnOff( char pBuff[4] ){
  memcpy( sCOnOff, pBuff, 4 );
}

void CSpeaCom::setErrorString( char * pSource ){
  strcpy( sErrorMsg, pSource );
}

#pragma optimize=none
void CSpeaCom::waitForFGPARx(void){
  //Problems with constant pointer, is optimized to nonsens from the compiler
  while( (unsigned char)0x01 == (unsigned char)(*pRReg));
}
#pragma optimize=none
void CSpeaCom::waitForFGPATx(void){
  //Problems with constant pointer, is optimized to nonsens from the compiler
  while( (unsigned char)0x01 == (unsigned char)(*pWReg));
}



