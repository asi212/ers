#include "CTempParams.h"

/**
  Default Constructor for CSetup Class, nothing to do inhere
*/
CTempParams::CTempParams(void){

}

void CTempParams::initPointers( float * p ){
  pfTemp = p;
  pfLimMin = p+1;
  pfLimMax = p+2;
}

float CTempParams::getSetTemp(void){
  return *pfTemp;
}

float CTempParams::getMinLimit(void){
  return *pfLimMin;
}

float CTempParams::getMaxLimit(void){
  return *pfLimMax;
}

bool CTempParams::setSetTemp(float f ){
  if( f < (*pfLimMin - 0.06)){
    *pfTemp = *pfLimMin - 0.05;
  }
  else if( f > (*pfLimMax + 0.06 ) ){
    *pfTemp = *pfLimMax + 0.06;
  }
  else{
    if( f < 0.0 ){
      f -= 0.05;
    }
    else if( f > 0.0 ){
      f += 0.05;
    }
    *pfTemp = f;
    return true;
  }
  return false;
}

void CTempParams::setMinLimit( float f ){
  *pfLimMin = f;
}

void CTempParams::setMaxLimit( float f ){
  *pfLimMax = f;
}

