#ifndef _CTEMP_PARAMS
#define _CTEMP_PARAMS

/**
Class t_temp_params
*/

class CTempParams{

  private:
    float * pfTemp;
    float * pfLimMin;
    float * pfLimMax;

  public:
    CTempParams(void);
    void initPointers( float * p );
    float getSetTemp(void);
    float getMinLimit(void);
    float getMaxLimit(void);

    bool setSetTemp(float f );
    void setMinLimit( float f );
    void setMaxLimit( float f );
};

#endif