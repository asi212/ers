#include <stdio.h>
#include <stdarg.h>
#include "CTerminal.h"


/*******************
* METHOD: CTerminal
*
* DESCRIPTION:
*  Constructor
*
* CREATED: 08.05.2013, by KLaus M�ller
*
* FILE: CTerminal.cpp
*/
CTerminal::CTerminal()
{
	uart 		 = TERM_UART;
	port_485 = TERM_RS485_EN_PORT;
	pin_485  = TERM_RS485_EN_PIN;
}

/*******************
* METHOD: Enable
*
* DESCRIPTION:
*  Enables the terminal view
*
* CREATED: 08.05.2013, by Klaus M�ller
*
* FILE: CTerminal.cpp
*/
void CTerminal::Enable ( void )
{
	return;
};


/*******************
* METHOD: Disable
*
* DESCRIPTION:
*  Disables the terminal view
*
* CREATED: 08.05.2013, by Klaus M�ller
*
* FILE: CTerminal.cpp
*/
void CTerminal::Disable ( void )
{
	return;
};


/*******************
* METHOD: Clear
*
* DESCRIPTION:
*  Clears the terminal and positions curser in the upper left
*
* CREATED: 08.05.2013, by Klaus M�ller
*
* FILE: CTerminal.cpp
*/
void CTerminal::Clear ( void )
{
	vector<char> cmd;
	string str;

	// Switch-On display and position curser in the upper left
	pushing_back( &cmd, "#TE\f", 4 );
	DispSendDc1( &cmd );

	// Define the terminal size
	TERM_CMD_TW(str);   // Macro to compose the command from defines
	pushing_back( &cmd, str.c_str(), str.size() );
	DispSendDc1( &cmd );
	
	return;
};


/*******************
* METHOD: Pos0
*
* DESCRIPTION:
*  Set Cursor to upper lefr corner without Clearing the terminal
*
* CREATED: 06.06.2013, by Klaus M�ller
*
* FILE: CTerminal.cpp
*/
void CTerminal::Pos0 ( void )
{
	vector<char> cmd;
	string str;

	// Switch-On display and position curser in the upper left
	pushing_back( &cmd, "#TP1,1,", 7 );
	DispSendDc1( &cmd );
	
	return;
};


/*******************
* METHOD: Printf
*
* DESCRIPTION:
*  Prints a formatted string to the terminal, ending with a new line
*
* PARAMETERS
*  Same as used for standard C printf: a format string, and a list of values
*
* CREATED: 08.05.2013, by Klaus M�ller
*
* FILE: CTerminal.cpp
*/
void CTerminal::Printf ( const char* format, ...  )
{
	va_list vl;                     // A place to store the list of arguments
	va_start( vl, format );         // Initializing arguments to store all values after format	
	char str[TERM_LINE_WIDTH+1] = {'\0'};	 // Buffer for composing the printed string 
	
	vsnprintf(str, TERM_LINE_WIDTH, format, vl);
	
	va_end(vl);
	
	vector<char> cmd;
	for (int i=0;;i++)
	{
		if( str[i] == '\0' ) break;
		 cmd.push_back(str[i]);
	}
	cmd.push_back('\r');
	cmd.push_back('\n');
	DispSendDc1( &cmd );

	return;
};

/*******************
* METHOD: DispSendDc1
*
* DESCRIPTION:
*  Prints a formatted string to the terminal, ending with a new line
*
* CREATED: 08.05.2013, by Klaus M�ller
*
* FILE: CTerminal.cpp
*/
char CTerminal::DispSendDc1( vector<char>* data )
{
	char c=0;
	static long j=0;
	
	// siehe Datenblatt:
	// data = <DC1> + Byteanzahl + Daten
	data->insert(data->begin(), (unsigned char)data->size());
	// data = <DC1> + Daten
	data->insert(data->begin(), 0x11);
	// data = <DC1> + Byteanzahl + Daten + CRC16
	data->push_back(generate_bcc(data));
     
	// Activate Driver and Deactivate Receiver of 'SN75176':
	GPIO_WriteBit(GPIO6, GPIO_Pin_2, Bit_SET);
        
       
	// Send the Data:
	for (int i=0; i < data->size(); i++)
	{
		while( SET == UART_GetFlagStatus(uart, UART_FLAG_Busy)); //wait active here while data been send
		UART_SendData(uart, data->at(i));
	}
	while(SET == UART_GetFlagStatus(uart, UART_FLAG_Busy) || RESET == UART_GetFlagStatus(uart,UART_FLAG_TxFIFOEmpty));//wait active here while data been send        
  
	// Deactivate Driver and activate Receiver of 'SN75176':
	GPIO_WriteBit(GPIO6, GPIO_Pin_2, Bit_RESET);
	
	// Catch answer of display, but stop waiting after a certain timeout
	long tout = 10000;
	while( (RESET == UART_GetFlagStatus(uart, UART_FLAG_RxFIFOFull)) && (tout-- > 0) );
	c = UART_ReceiveData(uart);
	
	data->clear();
//	data->pop_back();
//	data->erase(data->begin());
//	data->erase(data->begin());
	return c;
}