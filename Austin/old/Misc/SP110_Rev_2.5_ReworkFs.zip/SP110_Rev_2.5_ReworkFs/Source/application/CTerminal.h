/*******************
 * CLASS: CTerminal
 *
 * DESCRIPTION:
 *  Implents a terminal on the LCD display
 *
 *  The implementation runs without support of FreeRTOS, which enables
 *  it to be used at system start for e.g. self diagnosis output.
 *  Therefore, if must NOT be used wihtin a task!
 *
 * CREATED: 08.05.2013, by Klaus M�ller
 *
 * FILE: CTerminal.h
 */

#ifndef CTERMINAL_H
#define CTERMINAL_H


/* include C/C++-libraries */
#include <vector>
#include <string>

/* Include classes */	
#include "CSystem.h"
#include "sysinit.h"
#include "toolbox.h"
#include "EAeDIPTFT43A.h"


extern "C"
{
/* Includes Libraries */
#include "91x_lib.h"
#include "displaymacros.h"
}

/**
 * Konfiguration
 */

#define TERM_UART							UART2
#define TERM_RS485_EN_PORT		GPIO6
#define TERM_RS485_EN_PIN			GPIO_Pin_2 
#define TERM_FONT_8X8				  1
#define TERM_FONT_8X16				2
#define TERM_FONT						  TERM_FONT_8X16
#define TERM_LINE_WIDTH				60
#define TERM_NUM_LINES				13

/**
 * MACRO to compose LCD display command #TW from defines above
 */

#define TERM_CMD_TW(cmd)			 			\
		cmd  = "#TW"; 		 			        \
		cmd += STR(TERM_FONT);	    		\
		cmd += ",1,1,"			;           \
		cmd += STR(TERM_LINE_WIDTH);	  \
		cmd += ",";					            \
		cmd += STR(TERM_NUM_LINES);	    \
		cmd += ",";

/**
 * Terminal class for printing lines to terminal
 */
class CTerminal
{
public:
  CTerminal(); 						// Constructor
  ~CTerminal();						// Destructor                         	
  
	void Enable  ( void ); 	// Enables the terminal view
	void Disable ( void ); 	// Disables the terminal view
	void Clear   ( void );  // Clears the terminal view
	void Pos0    ( void );  // Repositions cursor in upper left
	void Printf  ( const char* format, ...  );  // Prints a formatted line
	
protected:

private:	
	char DispSendDc1( vector<char>* data );	// Sends a DC1 command to display
	
	UART_TypeDef* uart;			// The UART the terminal is connected to
	GPIO_TypeDef* port_485; // The port used for RS485 enable
	u8 pin_485;							// The pin used for RS485 enable
	
};


#endif // CTERMINAL_H