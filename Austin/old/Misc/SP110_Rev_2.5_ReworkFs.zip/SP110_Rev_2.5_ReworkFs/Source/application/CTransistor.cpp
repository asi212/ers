#include "CTransistor.h"

/**
Constand declarations
*/
const float CTransistor::fFSRVal = (5.0)/0x7FFFFF00;
int CTransistor::iInstCount = 0;

/**
  Class CTransistor constructor
*/
CTransistor::CTransistor( unsigned short * pSetVal,
                          long * pCurrVal,
                          CSetup * pSetup){
  this->pSetVal = pSetVal;
  this->pCurrVal = pCurrVal;
  this->pSetup = pSetup;
  this->iFSM = 5000;          //Startup- Process 5 seconds
  this->iInstance = ++this->iInstCount;
}

/**
 Function cycExec
 @iCycleTime, execution task cycle time im ms
*/
void CTransistor::cycExec( int iCycleTime ){
  //Startup Logic
  if( iFSM > 0 ){
    iFSM-= iCycleTime;
    Calibrate();        //Execute offset calibaration
    fSetVal = 0.0;      //Current limit have to be 0
    //Check calibration limits in the last second
    if( iFSM < 1000 ){
      if( fCurrCal > 2.7 || fCurrCal < 2.4 ){
        error.flags.initE = 1;
      }
    }
    else{
      error.cError = 0;
    }
  }
  else{
    fCurVal = CalcCurr();
  }

  /**
  Check for Errors only if Transistor ins not in error state already
  */
  if( error.cError == 0 ){
    /**
    Check for over current. 100% Current is a system dependent variable.
    */
    if(fSetVal > 10.0 && (fSetVal * pSetup->getCurrLimit(iInstance) * .012) < fCurVal){
      iErrorCounter -= iCycleTime * 30.0;  //Delay for short circuit to 2 sec
      if(iErrorCounter < 0 ){
        error.flags.oCurr = 1;
      }
    }
    /**
    Check for open output delay for 1 second
    */
    else if((fSetVal > 60.0 && (fSetVal * pSetup->getCurrLimit(iInstance) * 0.008) > fCurVal) ||
            (fSetVal > 30.0 && fSetVal <= 60.0 && (fSetVal * pSetup->getCurrLimit(iInstance) * 0.005) > fCurVal) ||
            (fSetVal > 10.0 && fSetVal <= 30.0 && (fSetVal * pSetup->getCurrLimit(iInstance) * 0.003) > fCurVal)){
      iErrorCounter -= iCycleTime;  //Deleay for open circuit to 60 sec
      if(iErrorCounter < 0 ){
        error.flags.uCurr = 1;
      }
    }
    else{
      iErrorCounter = 60000; //60 sec error delay time
    }
  }

  /**
  Limit set value on error
  */
  if( error.flags.oCurr != 0 || error.flags.initE != 0 ){
    fSetVal = 0.0;        //On overcurrent shut down the transistor
  }
  else if( error.flags.uCurr != 0 ){
    fSetVal = 0.5;       //On open output set ouput voltage to a very low level
  }

  //Write Set-Value to DAC- Register
  long lTemp = (long)(fSetVal*655.35*pSetup->getLambdaCal(iInstance));
  *pSetVal = (unsigned short)lTemp;
}

/**
 CalcCurr
*/
float CTransistor::CalcCurr(void){
  float fVoltage = fFSRVal * calcFIR(*pCurrVal);
  float fMeassC = (fVoltage - fCurrCal) * pSetup->getCurrCal(iInstance);
  return fMeassC;
}

/**
 Function bSetSetVal
*/
bool CTransistor::setSetVal( float fVal ){
  fSetVal = fVal;
  if( error.cError == 0 ){
    if( fSetVal > 100.0 ){
      fSetVal = 100.0;
    }
    else if ( fSetVal < 0.0  ){
      fSetVal = 0.0;
    }
    return true;
  }
  else{
    return false;
  }
}

/**
getSetVal
*/
float CTransistor::getSetVal( void ){
  return fSetVal;
}

/**
 Get measured current
*/
float CTransistor::getCurrent( void ){
  return fCurVal;
}

/**
 Function Calibrate
*/
void CTransistor::Calibrate( void ){
  fCurrCal = fFSRVal * calcFIR(*pCurrVal);
}

/**
  Function calfFIR
*/
long CTransistor::calcFIR( long lCurVal ){
  long lTemp = 0;
  for( int i = FIR_SIZE - 1; i >= 0; i-- ){
    if( i == 0 ){
      lFIR[0] = lCurVal / FIR_SIZE;
    }
    else{
      lFIR[i] = lFIR[i-1];
    }
    lTemp += lFIR[i];
  }
  return lTemp;
}

/**
  return Transistor Errro status
*/
uTraError CTransistor::getError( void ){
  return error;
}

/**
reset transistor errors
*/
void CTransistor::reset(void){
  error.cError = 0;
  iErrorCounter = 1000;
}
