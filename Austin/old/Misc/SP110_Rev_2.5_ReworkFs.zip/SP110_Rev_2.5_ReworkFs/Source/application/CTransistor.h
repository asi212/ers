#ifndef TRANSISTOR_H
#define TRANSISTOR_H
#include "CSetup.h"

#define FIR_SIZE 10


union uTraError{
  unsigned char cError;
  struct{
    unsigned char initE: 1;
    unsigned char oCurr: 1;
    unsigned char uCurr: 1;
  } flags;
};

class CTransistor{
  private:
    static const float fFSRVal;  //Constant, ADC Ful Scale divider for Voltage

    static int iInstCount;
    int iInstance;

    int iFSM;                  //Startup state register
    unsigned short * pSetVal; //Pointer to DAC- Register
    long * pCurrVal;          //Pointer to current measurement adc value
    CSetup * pSetup;            //Pointer to Setup
    float fSetVal;            //Voltage set point in percent
    float fCurrCal;           //Current Offset calibration factor
    float fCurVal;            //Measured current value
    long lFIR[FIR_SIZE];      //FIR- Filter storage for current measurement
    uTraError error;          //Transitor error flag
    int iErrorCounter;        //Timer variable to surpress transitor fault

  protected:
    void Calibrate( void );
    long calcFIR( long lCurVal );
    float CalcCurr(void);


  public:
    CTransistor( unsigned short * pSetVal, long * pCurrVal, CSetup * pSetup );
    void cycExec( int iCylceTime );
    void reset(void);
    bool  setSetVal( float fVal );
    float getSetVal( void );
    float getCurrent( void );
    uTraError getError( void );
};

#endif