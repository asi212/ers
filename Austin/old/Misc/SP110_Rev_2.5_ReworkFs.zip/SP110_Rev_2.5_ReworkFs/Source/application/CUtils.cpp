#include "CUtils.h"

unsigned short crc::getCRC16( unsigned char * pSource, int iLen ){

  unsigned short crc_16_poly = 0x8005;
  unsigned short crc_16 = 0x0;

  for( int i = 0; i < iLen; i++ ){
    unsigned short cData = pSource[i];
    for( int j = 7; j >= 0; j-- ){
      if( (crc_16&0x8000) != ((cData<<(15-j))&0x8000)){
        crc_16 = (crc_16 << 1) ^ crc_16_poly;
      }
      else{
        crc_16 =  crc_16 << 1;
      }
    }
  }
  return crc_16;
}

