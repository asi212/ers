#ifndef CUTILS_H
#define CUTILS_H



class crc{

  private:

  public:
    unsigned short getCRC16( unsigned char * pSource, int iLen );


};


#endif //CUTILS_H