#include "CAirPressureSensor.h"
extern float AirPressure;

// Konstruktor der Klasse
CAirPresssureSensor::CAirPresssureSensor( void )
{
      mApStartDelay    = APS_SENSOR_STARTUP_SAMPLES;
      mApErrSensorMissing = true;
      mApErrUnderPressure = false;
      mAirPressure = 0.0;
		m_sendValCount = 0;
}

// Initialisierung der Klasse
void CAirPresssureSensor::Init( CEventManager* pEventManager, const char *dev_name )
{
		//Registrierung der Ereignisse
    m_pEventManager = pEventManager;
    m_pEventManager->AddEventHandler( CEventNames::air_pressure_adc, CAirPresssureSensor::air_pressure_adcEventWrapper, this );
}


// Event Handler f�r neuen Messwert
void CAirPresssureSensor::air_pressure_adcEvent( short val )
{
	// Air Pressure Berechnung (Dreisatz)
	float fMulti  =  ( APS_SENSOR_MAX - APS_SENSOR_MIN ) / ( APS_ADCVAL_MAX - APS_ADCVAL_MIN );
	float fAPress =  ( val - APS_ADCVAL_MIN ) * fMulti;
	
	// FIR-Filterung
	mAirPressure = apFIR(fAPress + APS_SENSOR_MIN);

	// Start der Messung erst, nachdem Hardware und Sensor eingeschwungen sind
	if( mApStartDelay > 0 )
	{
			mApStartDelay--;
	}
	else 
	{		
		// Erkennung eines fehlenden oder kaputten Sensors 
		if( mAirPressure <= APS_ADCVAL_MISSING )
		{
			mApErrSensorMissing = true;
		}	
		else
		{
			mApErrSensorMissing = false;				
		}
	}
}

// FIR Filter f�r den Eingangs-Luftdruck
float CAirPresssureSensor::apFIR( float f )
{
  float fAP = 0.0;
  for( int i = 0; i < APS_FIR_FILTER_LENGTH; i++ ){
    if( i < ( APS_FIR_FILTER_LENGTH -1 ) ){
      mApFIR[i] = mApFIR[i+1];
    }
    else{
      mApFIR[i] = f / (float) APS_FIR_FILTER_LENGTH;
    }
    fAP += mApFIR[i];
  }
  return fAP;
}

// Zyklischer Aufruf, Fehler setzen/r�cksetzen
void CAirPresssureSensor::cycCalc( void ) 
{ 
	if ( mApStartDelay == 0 )
	{
                  AirPressure = mAirPressure;
		// Fehler setzen bei unterschreiten Schwellwert, Ber�cksichtigung Hysterese
		if ( !mApErrUnderPressure && (mAirPressure <  (APS_LOW_PRESSURE_THRESHOLD * (1.0 - APS_HYSTERESIS))) )
		{
			_event<int> e("CAirPresssureSensor", CEventNames::set_error, ERR_AIRPRESS_LOW );
			m_pEventManager->RaiseEvent(e);
			mApErrUnderPressure = true;
		}
		
		// Fehler r�cksetzen bei �berschreiten Schwellwert, Ber�cksichtigung Hysterese
		if ( mApErrUnderPressure && (mAirPressure >= (APS_LOW_PRESSURE_THRESHOLD * (1.0 + APS_HYSTERESIS))) )
		{
			_event<int> e("CAirPresssureSensor", CEventNames::reset_error, ERR_AIRPRESS_LOW );
			m_pEventManager->RaiseEvent(e);
			mApErrUnderPressure = false;
		}
		
		// Cyklisch neuen Wert senden
    portTickType t = xTaskGetTickCount();
		if( t - m_sendValCount > 1000 ) // every second:
		{
			// Reset counter
			m_sendValCount = t;

			// Send value
			_event<float> e( "CAirPresssureSensor", CEventNames::air_pressure_new_val, mAirPressure );
			m_pEventManager->RaiseEvent(e);
		}
	}
}
