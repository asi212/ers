/******************** (C) ERS Electronic GmbH **********************************
* File Name          : CAirPresssureSensor.h
* Author             : Klaus M�ller
* Date First Issued  : 24.04.2012 : Version 1.0
* Description        : Class for Air Pressure Sensor device 
**==============================================================================
* Comment:
*   For more info see Doxygen Description below
********************************************************************************
* History:
* 24.04.2012 : Version 1.0
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef AIR_PRESSURE_SENSOR_H
#define AIR_PRESSURE_SENSOR_H

#include "IDevice.h"
#include "../../MailboxSystem/CEventManager.h"
#include "CErrorNums.h"


/*
 * Konstanten fuer die Berechnung des Drucks aus dem A/D-Wert
 *
 * Der A/D-Wandler hat eine Referenz-Spannung von 3.3V ( -> Doku STM912-Tochterkarte)
 * Die Aufl�sung betr�gt 10-Bit
 *   0 bar -> 4mA, nach anloger Verst�rkung 0.54V am A/D-Eingang -> 167
 *  10 bar-> 20mA, nach anloger Verst�rkung 2.66V am A/D-Eingang -> 825
 */

/** Minimaler Druck des Sensors in bar bei 4 mA  \todo Clarify pressure at 4mA */
#define APS_SENSOR_MIN 	  0.0
/** Maximaler Druck des Sensors in bar bei 20mA */
#define APS_SENSOR_MAX 	 10.0
/** A/D-Wandler-Wert bei  4mA bzw. 0.54V */
#define APS_ADCVAL_MIN 	167.0
/** A/D-Wandler-Wert bei 10mA bzw. 2.66V */
#define APS_ADCVAL_MAX 	825.0
/** \def A/D-Wert, bei dem wir einen fehlenden Sensor vermuten */
#define APS_ADCVAL_MISSING 100.0

/** \def Anzahl der Abtastwerte, bis Messwert stabil */ 
#define APS_SENSOR_STARTUP_SAMPLES 50

/** \def L�nge des FIR-Filters */
#define APS_FIR_FILTER_LENGTH 20

/** \def Luftdruck in bar, der eine Unterdruck-Warnung ausl�st */
#define APS_LOW_PRESSURE_THRESHOLD 2.0

/** \def Hyterese, als Faktor des Schwellwertes, also z.B. 
  *        Unterschreitung = Schwellwert * (1 - Hysterese)
  *        �berschreitung  = Schwellwert * (1 + Hysterese)
  */
#define APS_HYSTERESIS 0.02 

/**
 * \class CAirPresssureSensor
 * \brief Handles events related to the air pressure sensor
 *
 * \page air_pressure_sensor Air Pressure Sensor
 *		The <b>Air Pressure Sensor</b> measures the pressure of the air input to 
 *    the chiller. Because the chiller rquires a minimum of 4 bar air
 *    pressure to work, the air pressure has to be controlled. 
 *    In case of low pressure, a warning has to be displayed.
 *
 */
class CAirPresssureSensor : public IDevice
{
	public:
		/** Konstruktur */
		CAirPresssureSensor( void );
		/** Initialisierung der Klasse, der Pointer auf den zust�ndigen Event-Manager wird �bergeben */
		void Init( CEventManager* pEventManager, const char *dev_name );
		/** Zyklischer Aufruf. Wird vom Device-Manager regelm��ig aufgerufen. Managed die Anzeige der Warnung */
		void cycCalc( void ); 
		/** Wrapper f�r das Event "air_pressure_adc" */
		static void air_pressure_adcEventWrapper( void * pObject, short p ){ ((CAirPresssureSensor*)pObject)->air_pressure_adcEvent( p ); };
		/** Event "air_pressure_adc": Ein neuer Messwert f�r den Eingangs-Luftdruck wurde gelesen */
		void air_pressure_adcEvent( short p );
		
	protected:
		/** Pointer auf globalen EventHandler */
		CEventManager* m_pEventManager;
		
	private:
		
		/** Der aus den A/D-werten berechnete und gefiltert Luftdruck */
		float mAirPressure;
		
		/** Z�hler f�r Delay, bis Messwerte stabil sind */
		unsigned int mApStartDelay;
		
		/** Flag, das das Fehlen des Sensors signalisiert */
		bool mApErrSensorMissing;

		/** Flag, das das den Unterdruck signalisiert */
		bool mApErrUnderPressure;
		
		/** Speicher f�r den FIR-Filter */
		float mApFIR[APS_FIR_FILTER_LENGTH];
		
		/** Z�hler f�r periodisches Senden neuer Werte */
		portTickType m_sendValCount;
		
		/** 
		 * FIR Filterung des A/D-gewandelten Messwertes  
		 *  
		 * \todo Optimize FIR-Filter-Algorithm for real measured values
		 */
		float apFIR( float f );

	
};

#endif // AIR_PRESSURE_SENSOR_H