#include "CDewPointSensor.h"
#include "CSetup.h"
#include "CErrorNums.h"

extern CSetup * p_CSetup;

CDewPointSensor::CDewPointSensor( CEventManager* pEventManager )
{
    m_EventManager = pEventManager;
    m_DewPointTime = 1000;
    m_ConStable = false;    //Sp�ter noch an Ereigniss koppeln
        
}
//Konstantendefinition
#define PANAMETRICS_MIN  -80.0
#define DEW_POINT_ERROR -105.5
#define DEW_POINT_PAN_ERROR -103.5
const float CDewPointSensor::m_DewMin = -100.0;
const float CDewPointSensor::m_DewMax =  20.0;
const float CDewPointSensor::m_MaxADC = 829.0;
const float CDewPointSensor::m_MinADC = 167.0;

void CDewPointSensor::Init()
{
    //Registrierung der Ereignisse
    m_EventManager->AddEventHandler( CEventNames::dew_point_adc, CDewPointSensor::dew_point_adcEventWrapper, this );
    m_EventManager->AddEventHandler( CEventNames::set_temp1_changed, CDewPointSensor::set_temp1_changedEventWrapper, this );
    m_EventManager->AddEventHandler( CEventNames::chuck_temp, CDewPointSensor::chuck_tempEventWrapper, this );
    m_EventManager->AddEventHandler( CEventNames::controller_stable, CDewPointSensor::controller_stableEventWrapper, this );
    m_dpFIR[0] = 0.0;
}

//Event Handler
void CDewPointSensor::dew_point_adcEvent( short i )
{
    //Dew Point Calc
   float fMulti;
   float fDPoint;
   static int err_delay = 100;
   float error = DEW_POINT_ERROR;
  
   if( p_CSetup-> GetCoolingSubSys() != E_COOLING_SUBSYS_EXT_CHILLER)
   { 
      fMulti  =  (m_DewMax-m_DewMin) / (m_MaxADC-m_MinADC);
      fDPoint = (i - m_MinADC) * fMulti;
      m_DPoint = dpFIR(fDPoint + m_DewMin);
      error = DEW_POINT_ERROR;
   }
   else // alle andere combinationen
   {
        fMulti  =  (m_DewMax-PANAMETRICS_MIN) / (m_MaxADC-m_MinADC);
        fDPoint = (i - m_MinADC) * fMulti;
        m_DPoint = dpFIR(fDPoint + PANAMETRICS_MIN);
        error = DEW_POINT_PAN_ERROR;
   }
    //Dew Point Init Timer and error
    if( m_DewPointTime > 1 )
    {
        m_DewPointTime--;
    }
    else
    {
        if( m_DPoint  < error ) // Kabel abgerrisen
        {
        if( err_delay > 0) 
          err_delay--;
        else
        {  
           m_DPError = true;
           err_delay = 500;
        }
        }
        else
        {
            if(  m_DPError == true)
            {
                if( err_delay > 0) 
                    err_delay--;
                else
                {  
                    m_DPError = false;
                    err_delay = 500;
                }          
            }
        } 
    }
}

void CDewPointSensor::set_temp1_changedEvent( float f )
{
    m_SetTemp = f;
}

void CDewPointSensor::chuck_tempEvent( float f )
{
    m_Temp = f;
}

void CDewPointSensor::controller_stableEvent( bool b )
{
  m_ConStable = b;
}

//FIR Filter f�r den Taupunkt
float CDewPointSensor::dpFIR( float f )
{
  float fDP = 0.0;
  /*
  for( int i = 0; i < 20; i++ )
  {
      if( i < 19 )
      {
            m_dpFIR[i] = m_dpFIR[i+1];
      }
      else
      {
            m_dpFIR[i] = f / 20.0;
      }
      fDP += m_dpFIR[i];
  }
  */
  fDP = (f + m_dpFIR[0])/2;
  m_dpFIR[0] = fDP; 
  
  return fDP;
}

CDewPointSensorStd::CDewPointSensorStd( CEventManager* pEventManager ) : CDewPointSensor( pEventManager )
{
    
}

/*******************************************************************************
* Method:   CycCalc  - (Dewpoint mointoring routine)
* Input:    None
* Output:   None
*
* Remarks:
*  Standarvariant for Dewpoint-Alarm
*  The Dewpoint is only monitored when the Set temperature is below +14.5�C
*  The Dewpoint value is read from the Dewpoint sensor and its value is compared
*  against the Chuck present (Ist)temperature. If the dewpoint is within a defined
*  range fDewPointOffset or less than the chuck temperature then, the set
*  temperature is set as follows.
* 1. new SetTemp = dewpoint temperature + dewpointoffset. A dewpoint WARNING is given out
* 2. If the dewpoint changes rapidly and detoriates by 8�c or 16 �C the Alarm 1 or
*    Alarm 2 is raised. Currently commented out, because handling of alarms may 
*    cause damage to testpins
*
* \todo Currently, dewpoint warning is handled outside. Should be moved to this class
********************************************************************************/
void CDewPointSensorStd::cycCalc()
{
  
	if ( p_CSetup->getOptionDewPoint() ) 
	{
		//Dew Point derivation to generate error
		if( ( m_DPoint > m_Temp + 8.0 ) && m_SetTemp < 14.5 )
		{
			/*	if( !m_DPError_1 )
				{
					_event<int> e("CDewPointSensorStd", CEventNames::set_error, ERR_DEWP_ALARM_1 );
					m_EventManager->RaiseEvent(e);
				}*/
				 m_DPError_1 = false; // Changed from  m_DPError_1=true Entscheidung KR, ob drinlassen oder nicht */  
		}
		//Fehler zur�cksetzen wenn aufgeheizt und 5�K < max
		if( m_Temp >= 18.0 )
		{
			/*	if( m_DPError_1 )
				{
					_event<int> e("CDewPointSensorStd", CEventNames::reset_error, ERR_DEWP_ALARM_1 );
					m_EventManager->RaiseEvent(e);
				}*/
				m_DPError_1 = false; //Changed from  m_DPError_1=true
		}
				 
		if( ( m_DPoint > m_Temp + 16.0 ) && m_SetTemp < 14.5 )
		{
			/*	if( !m_DPError_2 )
				{
					_event<int> e("CDewPointSensorStd", CEventNames::set_error, ERR_DEWP_ALARM_2 );
					m_EventManager->RaiseEvent(e);
				}*/
				 m_DPError_2 = false; // Changed from  m_DPError_2=true  Entscheidung KR, ob drinlassen oder nicht */
		}
		//Fehler zur�cksetzen wenn aufgeheizt und 5�K < max
		if( m_Temp >= 50.0 )
		{
			/*	if( m_DPError_2 )
				{
					_event<int> e("CDewPointSensorStd", CEventNames::reset_error, ERR_DEWP_ALARM_2 );
					m_EventManager->RaiseEvent(e);
				}*/
				m_DPError_2 = false;
		}
	}
}


/*********************************************************************************
*  Method Name  : MonitorDewPoint
*  Description  : Monitors the Dewpoint and sets an Alarm when the Dew Point detoriates.
*                   
* Input:    None
* Output:   None
*
* Comment:  Dewpoint is only monitored when the Set Temperature is below +14.5�C 
*           A Dewpoint windows is used to monitor an error status. The Standard
*           tracking offset is 0.5�C. 5�C is also used by some customers. 
*   This is how it works:
*   To ensure that now DEW is formed on the Chuck the Depoint Temperature not supposed to 
*   lower that the Present Value (Chuck Temperature). When the Dewpoint Temperature is just
*   within tracking window, the Set Temperature is set to Dewpoint Temp. + Tracking offset.
*   When this happens the chuck is heated a bit so that the Dewpoint is allowed to improve.
*
*   IMPORTANT: The System should continue cooling so that the Dewpoint can improve 
*********************************************************************************************/

//Maximvarinte des Taupunktalarms
void CDewPointSensorMaxim::cycCalc()
{
    int iCycleTime = 10;
  //Dew Point derivation to generate error
  if( m_DPErrorTime > 20000 )
  {
      //erste Ableitung
      //printf( "Timer Call, DewPoinMax = %f\n", m_DPMax );
      m_DPErrorTime = 0;
      m_dDPoint = m_DPoint - m_DPoint_h1;
      m_DPoint_h1 = m_DPoint;
      if( (m_dDPoint > 5 || m_DPoint > m_Temp ) && m_ConStable && m_SetTemp < 14.5  )
      {
          m_DPError_2 = true;
          //printf("DP Error 1\n");

      }
      //Maximum speichern
      if( m_DPError_2 == false)
      {  
        m_DPMax = m_DPoint;
      }
      else if( m_DPoint > m_DPMax )
      { 
        m_DPMax = m_DPoint;
      }
      //Fehler zur�cksetzen wenn aufgeheizt und 5�K < max
      if(( m_Temp >= 50.0 && m_DPoint < (m_DPMax - 5.0)) ||
         ( m_Temp > 14.5 && m_SetTemp > 14.5)){
          m_DPError_2 = false;
          //printf("DP Error 0\n");
      }
  }
  else{
      m_DPErrorTime += iCycleTime;
  }
}