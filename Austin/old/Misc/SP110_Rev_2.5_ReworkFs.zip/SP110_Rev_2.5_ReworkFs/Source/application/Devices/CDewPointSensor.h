#ifndef DEW_POINT_SENSOR_H
#define DEW_POINT_SENSOR_H

#include "../../MailboxSystem/CEventManager.h"


//Abstrakte Basisklasse f�r alle Taupunktsensoren
class CDewPointSensor
{

    public:
        CDewPointSensor( CEventManager* pEventManager );
        virtual void Init();        //Init unbedingt in dem PID aufrufen in dem cycCalc verwendet wird
        virtual void cycCalc() = 0;
        //Event Handler        
        static void dew_point_adcEventWrapper( void * pObject, short p ){ ((CDewPointSensor*)pObject)->dew_point_adcEvent( p ); };
        void dew_point_adcEvent( short p );
        static void set_temp1_changedEventWrapper( void * pObject, float f ){ ((CDewPointSensor*)pObject)->set_temp1_changedEvent( f ); };
        void set_temp1_changedEvent( float f );
        static void chuck_tempEventWrapper( void * pObject, float f ){ ((CDewPointSensor*)pObject)->chuck_tempEvent( f ); };
        void chuck_tempEvent( float f );
        static void controller_stableEventWrapper( void * pObject, bool b ){ ((CDewPointSensor*)pObject)->controller_stableEvent( b ); };
        void controller_stableEvent( bool b );

        
        //Sp�ter auf EventHandler legen
        float getDewPoint(){ return m_DPoint; };
        bool getDPError(){ return m_DPError; };
        bool getDP1Error(){ return m_DPError_1; };
        bool getDP2Error(){ return m_DPError_2; };
    
    protected:
        //Konstante
        static const float m_DewMin;
        static const float m_DewMax;
        static const float m_MaxADC;
        static const float m_MinADC;

        CEventManager* m_EventManager;      //Pointer auf globalen EventHandler
        float m_SetTemp;                    //Aktueller Sollwert f�r Auswertung
        float m_Temp;                       //Aktuelle Chucktemperatur f�r Auswertung
        bool m_ConStable;
        float m_DPoint;                     //der eigentliche Taupunkt
        bool m_DPError;                     //Taupunktsensor fehler
        int m_DewPointTime;                 //Startup- Zeit f�r Taupunktfehlerunterdr�ckung
        int m_DPErrorTime;                  //Zeitverz�gerung f�r Dew Point Alarm
        float m_DPoint_h1;                  //Speicher f�r tn-1 Wert zum ableiten
        float m_dDPoint;                    //Erste Ableitung des Taupunkts
        bool m_DPError_1;                   //Taupunktfehler 1
        bool m_DPError_2;                   //Taupunktfehler 2
        
        
    private:
        float dpFIR( float );               //FIR Funktion
        float m_dpFIR[20];                  //Speicher f�r FIR- Filter des Taupunkts
    
};

//Konkrete Klasse f�r Standard Taupunkt�berwachung
class CDewPointSensorStd : public CDewPointSensor
{
    public:
        CDewPointSensorStd( CEventManager* pEventManager );
        virtual void cycCalc();
};

//Konkrete Klasse f�r Maxim Sondertaupunktl�sung
class CDewPointSensorMaxim : public CDewPointSensor
{
    public:
        CDewPointSensorMaxim( CEventManager* pEventManager );
        virtual void cycCalc();

    private:
        float m_DPMax;    
}; 

#endif //DEW_POINT_SENSOR_H