#include "CLambda.h"
#include "CErrorNums.h"
#include <cmath>

#define max(A,B) (((A)>(B))?(A):(B))

//Initialisierung der Konstanten
unsigned short * const CLambda::m_pLmbSetVal = (unsigned short*)(0x34000034);
set_lmb * const CLambda::m_pLmbSet = (set_lmb*)(0x34000043);
get_lmb * const CLambda::m_pLmbGet = (get_lmb*)(0x34000044);
const float CLambda::m_FSRVal = (5.0)/0x7FFFFF00;

CLambda::CLambda( CEventManager * pEventManager, int Channel, CSetup * pSetup, int CurrChan, long * const lpHCIVal, long * const lpHCVVal)
{
    m_pEventManager = pEventManager;
    m_pSetup = pSetup;
    m_pHC_IVal = lpHCIVal;
    m_pHC_VVal = lpHCVVal;
    m_Channel = Channel;
    m_CurrChan = CurrChan;
    m_oCurrTim = DELAY_ERR_O_CURR_MS;
    m_ErrNum = 0;
    m_Error.cFlags = 0;
    
    m_FSM = init;
    m_LastTickCount = xTaskGetTickCount();
}

void CLambda::Init()
{
    m_pEventManager->AddEventHandler( (CEventNames::_event_name)(CEventNames::set_power_suppply_1_set_voltage + m_Channel-1), CLambda::set_power_supply_set_voltageEventWrapper, this );    
    m_pEventManager->AddEventHandler( (CEventNames::_event_name)(CEventNames::set_power_supply_1_active + m_Channel-1), CLambda::set_power_supply_activeEventWrapper, this );    
}

/**
Event Handler
*/
void CLambda::set_power_supply_set_voltageEvent( float p )
{
    m_SetValue = p;
    if( m_SetValue > 100.0 )
    {
        m_SetValue = 100.0;
    }
    else if (  m_SetValue < 0.0  )
    {
        m_SetValue = 0.0;
    }
    long lTemp = (long)(m_SetValue*655.35*m_pSetup->getLambdaCal(m_Channel));
    m_pLmbSetVal[m_Channel-1] = (unsigned short)lTemp;
}

void CLambda::set_power_supply_activeEvent( bool p )
{
    m_Active = p;
    //Bei �ndereung des Zusatands auf jeden Fall nochmals initialisieren
    m_FSM = init;
    m_LastTickCount = xTaskGetTickCount();
}

void CLambda::cycCalc()
{
    //Aktuelle Zykluszeit bestimmen
    m_CycleTime = xTaskGetTickCount() - m_LastTickCount;
    m_LastTickCount = xTaskGetTickCount();
    
    float fCurr = getCurr();
    float fVolt = getVolt();
    
    //Schrittkette
    switch( m_FSM )
    {       
         //Erster Schritt, Initalwerte zuweisen
         case init:
            m_IOffsett = 0.0;
            m_VOffsett = 0.0;
            m_Timer1 = 1000;
            SetOff();
            //Nur wenn der Kanal aktive ist intiasisieren, ansonsten einfach hier warten
            if( m_Active )
            {
                //Wenn keine Strom�berwachung zugeordnet ist, dann sofort in den RUN- Modus wechseln
                if( m_pHC_IVal != 0 && m_pHC_VVal != 0 )
                {
                    m_FSM = calibrate;
                }
                else
                {
                    m_FSM = start;
                }
            }
        break;
        //Zweiter Schritt, Kalibrierwerte ermitteln
        case calibrate:
            m_IOffsett = m_FSRVal * (*m_pHC_IVal);            
            m_VOffsett = m_FSRVal * (*m_pHC_VVal);
            if( m_Timer1 > 0 )
            {
                m_Timer1 -= m_CycleTime;
            }
            else
            {
                //Achtung hier muss noch eine Fehlerpr�fung rein falls die Kalibrierwerte zu weit von der Norm abweichen
                m_FSM = start;
            }
        break;
        case start:
            SetOn();
            m_Timer1 = NEW_VALUE_PERIOD_MS;
            m_FSM = run;
        break;
        //Normaler Wandlerbetrieb und Fehlerpr�fung
        case run:            
            //Fehlerpr�fungen
            checkErrors();
            
            //Pr�fe zuerst ob eine Strom - und Spannungsmessung zugeordnet ist
            if( m_CurrChan > 0 && m_pHC_IVal != 0 && m_pHC_VVal != 0 )
            {
                //Alle 100ms ein Stromereigniss absenden
                if( m_Timer1 <= 0 )
                {
                    _event<float> e_i( "CLambda", (CEventNames::_event_name)(CEventNames::power_suppply_1_current + (m_CurrChan -1)), fCurr );
                    m_pEventManager->RaiseEvent(e_i);
                    _event<float> e_v( "CLambda", (CEventNames::_event_name)(CEventNames::power_suppply_1_voltage + (m_CurrChan -1)), fVolt );
                    m_pEventManager->RaiseEvent(e_v);
                    m_Timer1 = NEW_VALUE_PERIOD_MS;
                }
                else
                { 
                    m_Timer1 -= m_CycleTime;
                }
                //Fehlerpr�fung auf den Strom
                checkCurrent();
            }
            
        break;
        //Zur Sicherheit:
        default:
            m_FSM = init;
        break;
        
    }
}

float CLambda::getPower(void)
{
    return m_SetValue;
}
          
void CLambda::SetOn()
{
  m_pLmbSet->cByte &= ~(0x01<<m_Channel-1);
}

void CLambda::SetOff()
{
  m_pLmbSet->cByte |= (0x01<<m_Channel-1);
}


/**
  Check on Lambda- Erros
  @param iLmbNum Check lambda number for error
*/
void CLambda::checkErrors()
{
    //Zuerst festellen ob das Lambda ein ist aber keine R�ckmeldung da
    bool bLmbFailure = ((m_pLmbSet->cByte)>>(m_Channel-1) & 0x01) == 0 &&
      ((m_pLmbGet->cByte)>>(m_Channel-1) & 0x01) == 1 ? true : false;
    //Fehlepr�fung nur wenn das Lambda ein ist und mindestens 5% Anstuerpsannung da sind
    if( bLmbFailure && m_SetValue > 5.0 ){
      if( m_Timer2 <= 0 )
      {
#ifndef TUEV
        m_Error.b.FBFail = 1;
#endif
      }
      else
      {
          m_Timer2 -= m_CycleTime;
      }
    }
    else
    {
      m_Timer2 = 10000;     //Delay 10 Sekunden
      m_Error.b.FBFail = 0;
    }
}

_LError CLambda::getError(void)
{
    return m_Error;
}

float CLambda::getCurr(void)
{   
  float fVoltage = m_FSRVal * (*m_pHC_IVal);
  float fMeassC = (fVoltage - m_IOffsett) * m_pSetup->getCurrCal(m_CurrChan);
  return fMeassC;
}

float CLambda::getVolt(void)
{
  float fVoltage = m_FSRVal * (*m_pHC_VVal);
  float fMeassV = (fVoltage - m_VOffsett) * m_pSetup->getVoltCal(m_CurrChan);
  return fMeassV;
}
/*
void CLambda::checkCurrent(void)
{	
		int ErrNum;
	
    //Erwarteten Strom Berechnen
    float fExpCurr  = abs(m_pSetup->getCurrLimit(m_CurrChan) * m_SetValue / 100.0);
    float fPresCurr = abs(getCurr());
		
    //�berstrompr�fung , Lambda sollte mindestens 10% Stellwert haben ansonsten kommt es
    //zu Fehlausl�sungen, Schwellwert ist bei 20% �ber den erwarteten Strom
    //�berstrom ist nicht reversible, das heisst ein Reset ist notwendig.
		
		// Fehlernummer f�r �berstrom abh�ngig vom Heizkreis
		if (m_CurrChan==1) ErrNum = ERR_OV_CURR_HC_1; else
		if (m_CurrChan==2) ErrNum = ERR_OV_CURR_HC_2;
		
		if (fPresCurr > max(fExpCurr * 1.2, 2.0)) {
//			if( m_SetValue > 10.0 && (abs(fExpCurr / getCurr()) < 0.8) ){
				if(  m_oCurrTim <= 0 )
				{
						if( m_Error.b.oCurr == 0 )
						{   
								_event<int> e( "CLambda", CEventNames::set_error, ErrNum );
								m_pEventManager->RaiseEventSync(e);
						}
						m_Error.b.oCurr = 1;
				}
				else
				{
						m_oCurrTim -= m_CycleTime;
				}
		}
		// Commented out, because over-current is a critical dead-end error
		// which shall not be reset by software, but only by user interaction
    else
    {
#if 0
        if( m_Error.b.oCurr == 1 )
        {
            _event<int> e( "CLambda", CEventNames::reset_error, ErrNum );
            m_pEventManager->RaiseEventSync(e);
        }
        m_Error.b.oCurr = 0;
#endif
        m_oCurrTim = DELAY_ERR_O_CURR_MS;
    }

    //Mindeststrompr�fung, Lambda sollte mindestens 10% Stellwert haben ansonsten kommt es
    //zu Fehlausl�sungen, Schwellwert ist bei 20% unter dem erwarteten Strom

    // Fehlernummer f�r Mindeststrom abh�ngig vom Heizkreis. Error codes 62/82
    // Zwei Zust�nde sind mit voller Aussteurung zu pr�fen:
    // 1. Volle Spannung liegt am Ausgang und es fliesst keinen Strom
    // 2. Es wird keine Spannung und keinen Strom gemessen
    if (m_CurrChan==1) ErrNum = ERR_UN_CURR_HC_1; else
    if (m_CurrChan==2) ErrNum = ERR_UN_CURR_HC_2;

    if( m_SetValue > 10.0 && (abs(fExpCurr / getCurr()) > 1.2) ){
        if( m_uCurrTim <= 0 ){
            if( m_Error.b.uCurr == 0 )
            {
                _event<int> e( "CLambda", CEventNames::set_error, ErrNum );
                m_pEventManager->RaiseEventSync(e);
            }
            m_Error.b.uCurr = 1;
        }
        else{
            m_uCurrTim -= m_CycleTime;
        }
    }
    else
    {
        if( m_Error.b.uCurr == 1 )
        {
            _event<int> e( "CLambda", CEventNames::reset_error, ErrNum );
            m_pEventManager->RaiseEventSync(e);
        }
        m_Error.b.uCurr = 0;
        m_uCurrTim = 10000;
    }
}
*/

/*********************************************************************************
* Method: checkShortCircuit
* 
* Description: Checks for the Power status
*
* Input          : None
* Output         : Errorcode  in case of error and sets  m_Error.b.oCurr = 1
*
* Return         : true, if short circuited
*
*******************************************************************************/
void CLambda::checkShortCircuit(void)
{
    float fPresCurr = abs(getCurr());
     
    if( (fPresCurr > 9.0)||((m_SetValue < 10.0)&&(fPresCurr > 4.0)) )
    {
        if(  m_oCurrTim <= 0 )
        {
                m_ErrNum =  (m_CurrChan==1) ?  ERR_OV_CURR_HC_1 : ERR_OV_CURR_HC_2;

                if( m_Error.b.oCurr == 0 )
                {   
                    _event<int> e( "CLambda", CEventNames::set_error, m_ErrNum );
                    m_pEventManager->RaiseEventSync(e);
                }

                m_Error.b.oCurr = 1;
        }
        else
        {
            m_oCurrTim -= m_CycleTime;
        }
    }  
    else // Commented out, because over-current is a critical dead-end error. which shall not be reset by software, but only by user interaction
    {
#if 0
        if( m_Error.b.oCurr == 1 )
        {
            _event<int> e( "CLambda", CEventNames::reset_error, ErrNum );
            m_pEventManager->RaiseEventSync(e);
        }
        m_Error.b.oCurr = 0;
        m_ErrNum = 0;        
#endif
        m_oCurrTim = DELAY_ERR_O_CURR_MS;
    }    
}


/*********************************************************************************
* Method: checkCurrent
* 
* Description: Checks for the Power status
*
* Input          : None
* Output         : Errorcode  in case of error
*
* Return         : none
*
*******************************************************************************/
void CLambda::checkCurrent(void)
{	
    int ErrNum  = 0; // reset error code
 
    //Erwarteten Strom Berechnen
    float fExpCurr  = abs(m_pSetup->getCurrLimit(m_CurrChan) * m_SetValue / 100.0);
    float fPresCurr = abs(getCurr());
    float fCurrVolt = abs(getVolt());
    float fMaxVolt  = abs(m_pSetup->getVoltLimit(m_CurrChan) * 0.8); // 80% of maximum Voltage 
                          
   // �berpr�fen, ob einen Kurzschluss vorliegt. Wenn ja, keine weitere  Pr�fungen mehr!
    checkShortCircuit();
    if(m_Error.b.oCurr == 0) // Only chuck for other errors if there is no Overcurrent Errors!
    {
        //Mindeststrompr�fung, Lambda sollte mindestens 10% Stellwert haben ansonsten kommt es
        //zu Fehlausl�sungen, Schwellwert ist bei 20% unter dem erwarteten Strom
    
        // Fehlernummer f�r Mindeststrom abh�ngig vom Heizkreis. Error codes 62/82
        // Zwei Zust�nde sind mit voller Aussteurung zu pr�fen:
        // 1. Volle Spannung liegt am Ausgang und es fliesst keinen Strom
        // 2. Es wird keine Spannung und keinen Strom gemessen
      
        if( m_SetValue == 100.0 ) // volle Aussteuerung, bedeutet maximale Spannung am Ausgang
        {
            if(fCurrVolt >= fMaxVolt) // Volle Spannung am Ausgang!
            {
                if( fPresCurr < 1.0) // weniger als 500mA 63/83
                ErrNum =  (m_CurrChan==1) ? ERR_UN_CURR_HC_1 : ERR_UN_CURR_HC_2;
             }
            else // Es liegt keine Spannung und keinen Strom vor! Error 62/82
            {
              ErrNum  =  (m_CurrChan==1) ? ERR_PWR_DEFECT_1 : ERR_PWR_DEFECT_2;
            }
        }    
   
				// Wenn ein Fehler detektiert wurde
        if(  ErrNum  > 0 )
        {
						// und die Mindestfehlerzeit �berschritten wurde 
            if( m_uCurrTim <= 0 )
            {
                if( (m_Error.b.uCurr == 0 ) && ( (ErrNum == ERR_UN_CURR_HC_1) || (ErrNum == ERR_UN_CURR_HC_2) ) )
                {
                   m_Error.b.uCurr = 1;
                   _event<int> e( "CLambda", CEventNames::set_error, ErrNum );
                   m_pEventManager->RaiseEventSync(e);
                }

                if( (m_Error.b.pDefect == 0 ) && ( (ErrNum == ERR_PWR_DEFECT_1) || (ErrNum == ERR_PWR_DEFECT_2) )	)
                {
                   m_Error.b.pDefect = 1;
                   _event<int> e( "CLambda", CEventNames::set_error, ErrNum );
                   m_pEventManager->RaiseEventSync(e);
                }
            }
            else
            {
                m_uCurrTim -= m_CycleTime;
            }         
        }
        else
        {
            if( (m_Error.b.uCurr == 1) || (m_Error.b.pDefect == 1) )
            {
              if(m_Error.b.uCurr == 1)
                 ErrNum = (m_CurrChan==1) ? ERR_UN_CURR_HC_1 : ERR_UN_CURR_HC_2;
              else
                 ErrNum = (m_CurrChan==1) ? ERR_PWR_DEFECT_1 : ERR_PWR_DEFECT_2;
                 
              _event<int> e( "CLambda", CEventNames::reset_error, ErrNum );
              m_pEventManager->RaiseEventSync(e);
            }
            m_Error.b.uCurr   = 0;
            m_Error.b.pDefect = 0; 
            m_uCurrTim = 10000;
        }
    }
}