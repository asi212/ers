#ifndef C_LAMBDA_H
#define C_LAMBDA_H

extern "C"
{
    #include "FreeRTOS.h"
    #include "task.h"
}

#include "../../MailboxSystem/CEventManager.h"
#include "../CSetup.h"

#define DELAY_ERR_O_CURR_MS  10000
#define NEW_VALUE_PERIOD_MS    500		// Period in ms, in which we send new values for measured current and voltage       

/**
 Structs to Lamda Control Byte
*/
union set_lmb {
  unsigned char cByte;
  unsigned char
    spare : 2,
    b6On : 1,
    b5On : 1,
    b4On : 1,
    b3On : 1,
    b2On : 1,
    b1On : 1;
};

union get_lmb{
  unsigned char cByte;
  unsigned char
    spare  : 2,
    b6IsOn : 1,
    b5IsOn : 1,
    b4IsOn : 1,
    b3IsOn : 1,
    b2IsOn : 1,
    b1IsOn : 1;
};

//Globale Strktur der m�glichen Lamba- Fehler
union _LError{
  unsigned char cFlags;
  struct{
    unsigned char
    FBFail : 1,  //Feedback Failure
    FSFail : 1,  //Fuse Feddback Failure if available
    oCurr  : 1,
    uCurr  : 1,
    pDefect: 1,
		: 3;
  } b;
};

class CLambda
{
    public:
        CLambda( CEventManager * pEventManager, int Channel = 1, CSetup * pSetup = 0, int CurrChan = 0, long * const lpHCIVal = 0, long * const lpHCVVal = 0);
        void Init();
        void cycCalc();
        
        //Diagnose Funktionen
        float getCurr(void);
        float getVolt(void);
        float getPower(void);
        
        void SetOn(void);
        void SetOff(void);
        _LError getError(void);
        
        //EventHandler
        static void set_power_supply_set_voltageEventWrapper( void * pObject, float p ){ ((CLambda*)pObject)->set_power_supply_set_voltageEvent(p);};
        void set_power_supply_set_voltageEvent( float p );
        static void set_power_supply_activeEventWrapper( void * pObject, bool p ){ ((CLambda*)pObject)->set_power_supply_activeEvent(p);};
        void set_power_supply_activeEvent( bool p );


        
    protected:
        CSetup * m_pSetup;
        CEventManager * m_pEventManager;
        void checkErrors(void);
        void checkCurrent(void);
        void checkShortCircuit(void);
        
    private:                         
        portTickType m_LastTickCount;       //Speicher zum brechnen der Zykluszeit
        int m_CycleTime;                    //Berechnete Zykluszeit in diesem Durchlauf
        int m_Channel;                      //Hardwarekanal auf dem das Lambda betrieben wird
        int m_CurrChan;                     //Hardwarekanal f�r die Stromlesung, notwendig um die Ereignisse richtig zuzuordnen
        static unsigned short * const m_pLmbSetVal;  //Pointer auf Adresse des ersten DACS f�r den Stellwert
        static const float m_FSRVal;        //Konstante zum Umrechnen des ADC- Wertes in eine Spannung
        long * m_pHC_IVal;                  //Pointer auf Strommessung
        long * m_pHC_VVal;                  //Pointer auf Spannungsmessung
        static set_lmb * const m_pLmbSet;   //Pointer auf Adresse f�r Schalteingang des Lambdas
        static get_lmb * const m_pLmbGet;   //Pointer auf Adresse f�r R�ckmeldung des Lambdazustands
        
        int m_Timer1;                       //Speicher f�r Timerzeiten
        int m_Timer2;                       //Speicher f�r Timerzeiten
        int m_oCurrTim;                     //Speicher f�r Timer �berstrom
        int m_uCurrTim;                     //Speicher f�r Timer Mindeststrom
        float m_IOffsett;                   //Offset f�r die Strommessung, sollte etwa bei 2.5 Volt sein
        float m_VOffsett;                   //Offset f�r die Spannungsmessung, sollte etwa bei 2.5 Volt sein
        
        float m_SetValue;                   //Speicher f�r Stellwert
        bool m_Active;                      //Definiert ob das Neztteil aktiv ist und Meldungen sendet    
        _LError m_Error;                    //Fehlerspeicher des Lambdas
        int m_ErrNum ;                       // Fehler code
        enum _fsm_lmb                       //Ablaufschrittkette f�r den Startup
        {           
            init,
            calibrate,
            start,
            run
        } m_FSM;
        

};

#endif //C_LAMBDA_H