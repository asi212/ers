#include "COverTemperatureSensor.h"
#include "sysinit.h"

// Konstruktor der Klasse
COverTemperatureSensor::COverTemperatureSensor( void )
{
		mOtStartDelay         = OT_SENSOR_STARTUP_SAMPLES;
		mOtErrOverTemperature = false;
}

// Initialisierung der Klasse
void COverTemperatureSensor::Init( CEventManager* pEventManager, const char *dev_name )
{
		//Registrierung der Ereignisse
    m_pEventManager = pEventManager;
    m_pEventManager->AddEventHandler( CEventNames::over_temp_adc, COverTemperatureSensor::over_temp_adcEventWrapper, this );
		
		m_name = dev_name;
}


// Event Handler f�r neuen Messwert
void COverTemperatureSensor::over_temp_adcEvent( short val )
{
	// �ber-Temperature Berechnung (Dreisatz)
	float fMulti =  ( OT_SENSOR_MAX - OT_SENSOR_MIN ) / ( OT_ADCVAL_MAX - OT_ADCVAL_MIN );
	float fOtemp =  ( val - OT_ADCVAL_MIN ) * fMulti;
	
	// FIR-Filterung
	mOverTemperature = otFIR(fOtemp + OT_SENSOR_MIN);

	// Start der Messung erst, nachdem Hardware und Sensor eingeschwungen sind
	if( mOtStartDelay > 0 )
	{
			mOtStartDelay--;
	}
}

// FIR Filter f�r den Eingangs-Luftdruck
float COverTemperatureSensor::otFIR( float f )
{
  float fOT = 0.0;
  for( int i = 0; i < OT_FIR_FILTER_LENGTH; i++ ){
    if( i < ( OT_FIR_FILTER_LENGTH -1 ) ){
      mOtFIR[i] = mOtFIR[i+1];
    }
    else{
      mOtFIR[i] = f / (float) OT_FIR_FILTER_LENGTH;
    }
    fOT += mOtFIR[i];
  }
  return fOT;
}

// Zyklischer Aufruf, Fehler setzen/r�cksetzen
void COverTemperatureSensor::cycCalc( void ) 
{ 
  
    UserSettings us = SysInit::GetUserSettings();
    if( us.SystemEnabled == true)
    {
          if ( mOtStartDelay == 0 )
          {
                // Fehler setzen bei unterschreiten Schwellwert, Ber�cksichtigung Hysterese
                if ( !mOtErrOverTemperature && (mOverTemperature >  (OT_OVER_TEMP_THRESHOLD * (1.0 + OT_HYSTERESIS))) )
                {
                      _event<int> e("COverTemperatureSensor", CEventNames::set_error, THERMAL_CUT_OUT );
                      m_pEventManager->RaiseEvent(e);
                      mOtErrOverTemperature = true;
                }
                
                // Fehler r�cksetzen bei �berschreiten Schwellwert, Ber�cksichtigung Hysterese
                if ( mOtErrOverTemperature && (mOverTemperature <= (OT_OVER_TEMP_THRESHOLD * (1.0 - OT_HYSTERESIS))) )
                {
                      _event<int> e("COverTemperatureSensor", CEventNames::reset_error, THERMAL_CUT_OUT );
                      m_pEventManager->RaiseEvent(e);
                      mOtErrOverTemperature = false;
                }
          }
    }
      
}


bool COverTemperatureSensor::getError( void )
{
	return mOtErrOverTemperature;
}