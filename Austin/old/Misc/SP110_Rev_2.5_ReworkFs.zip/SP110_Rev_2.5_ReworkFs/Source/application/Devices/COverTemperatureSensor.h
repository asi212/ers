/******************** (C) ERS Electronic GmbH **********************************
* File Name          : COverTemperatureSensor.h
* Author             : Klaus M�ller
* Date First Issued  : 08.05.2012 : Version 1.0
* Description        : Class for Over-Temperature device 
**==============================================================================
* Comment:
*   For more info see Doxygen Description below
********************************************************************************
* History:
* 08.05.2012 : Version 1.0
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef OVER_TEMP_SENSOR_H
#define OVER_TEMP_SENSOR_H

#include "IDevice.h"
#include "../../MailboxSystem/CEventManager.h"
#include "CErrorNums.h"


/*
 * Konstanten fuer die Berechnung der �bertemperatur aus dem A/D-Wert
 *
 * Der JUMO Temperaturw�chter hat ein Relais, das wiederum das Relais
 * f�r die LAMDA-Versorgung schaltet. Im Gutfall, also einer normalen
 * Betriebstemperatur, leigen am A/D-Eingang 24V an. Bei �bertemperatur 
 * ist der A/D-Eingang offen.
 * 
 * Der A/D-Wandler hat eine Referenz-Spannung von 3.3V ( -> Doku STM912-Tochterkarte)
 * Die Aufl�sung betr�gt 10-Bit
 *   Gut -> 24V, nach anloger Verst�rkung 3.0V am A/D-Eingang  -> 930
 *  Scjhlecht -> 0V, nach anlog. Verst�rkung 0V am A/D-Eingang -> 0
 */

/** Minimale Spannung des Sensors in V bei �bertemperatur */
#define OT_SENSOR_MIN 	  0.0
/** Minimale Spannung des Sensors in V bei normaler Temperatur */
#define OT_SENSOR_MAX 	 24.0
/** A/D-Wandler-Wert bei  0V */
#define OT_ADCVAL_MIN 		0.0
/** A/D-Wandler-Wert bei 24V */
#define OT_ADCVAL_MAX 	930.0

/** \def L�nge des FIR-Filters */
#define OT_FIR_FILTER_LENGTH 10

/** \def Anzahl der Abtastwerte, bis Messwert stabil */ 
#define OT_SENSOR_STARTUP_SAMPLES OT_FIR_FILTER_LENGTH

/** \def Spannung in V, die eine �bertemperatur-Warnung ausl�st */
#define OT_OVER_TEMP_THRESHOLD 12.0

/** \def Hyterese, als Faktor des Schwellwertes, also z.B. 
  *        Unterschreitung = Schwellwert * (1 - Hysterese)
  *        �berschreitung  = Schwellwert * (1 + Hysterese)
  */
#define OT_HYSTERESIS 0.02 

/**
 * \class COverTemperatureSensor
 * \brief Handles events related to the Jumo over temperature sensor
 *
 * \page over_temperature_sensor Over-Temperature Sensor
 *
 *		The <b>Jumo Over-Temperature Sensor</b> measures the air temperature
 *   	within the AC3 case. If the temperature raises above a defined 
 *    threshold, the sensors switches-off the Lambdas. 
 *
 *    To inform User and Software about that event, the sensor is additionally 
 *    connected to an analog input (AIN2). The sensor returns 24V in case of 
 *    normal temperature, and 0V (open circuit) in case of overtemperature. 
 *     
 *    In case of over temperature, a warning has to be displayed in the display.
 *
 */
class COverTemperatureSensor : public IDevice
{
	public:
		/** Konstruktur */
		COverTemperatureSensor( void );
		/** Initialisierung der Klasse, der Pointer auf den zust�ndigen Event-Manager wird �bergeben */
		void Init( CEventManager* pEventManager, const char *dev_name );
		/** Zyklischer Aufruf. Wird vom Device-Manager regelm��ig aufgerufen. Managed die Anzeige der Warnung */
		void cycCalc( void ); 
		/** Gibt den Error-Status zur�ck */
		bool getError( void );
		
		/** Wrapper f�r das Event "over_temp_adc" */
		static void over_temp_adcEventWrapper( void * pObject, short p ){ ((COverTemperatureSensor*)pObject)->over_temp_adcEvent( p ); };
		/** Event "over_temp_adc": Ein neuer Messwert des Sensors wurde gelesen */
		void over_temp_adcEvent( short p );

	
	protected:
		/** Pointer auf globalen EventHandler */
		CEventManager* m_pEventManager;
		
	private:
		
		/** Die aus den A/D-Werten berechnete und gefiltert Sensorspannung */
		float mOverTemperature;
		
		/** Z�hler f�r Delay, bis Messwerte stabil sind */
		unsigned int mOtStartDelay;
		
		/** Flag, das die �bertemperatur signalisiert */
		bool mOtErrOverTemperature;
		
		/** Speicher f�r den FIR-Filter */
		float mOtFIR[OT_FIR_FILTER_LENGTH];
		
		/** 
		 * FIR Filterung des A/D-gewandelten Messwertes  
		 *  
		 * \todo Optimize FIR-Filter-Algorithm for real measured values
		 */
		float otFIR( float f );

	
};

#endif // OVER_TEMP_SENSOR_H