#include "CValve.h"
#include "../../MailboxSystem/CEventManager.h"


extern CEventManager EventManager;

CValve::CValve( unsigned short * pOutput )
{
    m_pOutput = pOutput;
}

/**
Event writes Output to the DAC
*/
void CValve::ValvePValueEvent( float f )
{    
    if( f > 100.0 ){
        f = 100.0;
    }
    else if (  f < 0.0  ){
        f = 0.0;
    }
    m_SetValue = f;
    long lTemp = (long)((m_SetValue*655.35)*0.6); //28.06.2012 PM: changed from (long)(m_SetValue*655.35); Because 10V was overdriving the valve
    																					  
    //29.08.2012 KM: changed from (long)(m_SetValue*655.35)/2, because 5V lead to a too low air flow. 6V leads to 6 bar, which is the minimum pressure requirement at customers site.
    *m_pOutput = (unsigned short)lTemp;
}

CLanyValve::CLanyValve( unsigned short * pOutput, int ValveNum ) : CValve(pOutput)
{
    //Assign default calibration values
    m_ValveNum = ValveNum;
    fI0Cal = 0.0; 
    fIFCal = 10.0; 
    fO0Cal = 0.0; 
    fOFCal = 10.0; 
    
    m_ErrorEventIn = true;
    m_ErrorEventOut = true;
}

//event handler for ADC Event on joucomatic valve
void CLanyValve::ValveADCInEvent( short NativeValue )
{
    //Calc Valve Values
    m_IPress = ((NativeValue / 1024.0) - fI0Cal)*fIFCal;
    
    //get Tick Count for error Calc Timer
    portTickType t = xTaskGetTickCount();
    if( m_IPress < 5.0 ){
        if(t - m_InTickCount  > 10000)
        {
            if( !m_ErrorEventIn )
            {
                _event<int> e("Lany In Valve", CEventNames::VALVE_IN_PRESS_ERROR, m_ValveNum);
                EventManager.RaiseEvent(e);                  
                m_ErrorEventIn = true;
            }
        }
    }
    else
    {   
        if( m_ErrorEventIn )
        {
            _event<int> e("Lany In Valve", CEventNames::VALVE_IN_PRESS_OK, m_ValveNum);
            EventManager.RaiseEvent(e);                  
            m_ErrorEventIn = false;
        }            
        m_InTickCount = t;
    }
}

//event handler for ADC Event on joucomatic valve
void CLanyValve::ValveADCOutEvent( short NativeValue )
{
    //Calc Valve Values
    m_OPress = ((NativeValue / 1024.0) - fO0Cal)*fOFCal;   
    //get Tick Count for error Calc Timer
    portTickType t = xTaskGetTickCount();
    
    if( m_OPress < 5.0 ){
        if(t - m_InTickCount  > 10000)
        {
            if( !m_ErrorEventOut )
            {
                _event<int> e("Lany Out Valve", CEventNames::VALVE_OUT_PRESS_ERROR, m_ValveNum);
                EventManager.RaiseEvent(e);                  
                m_ErrorEventIn = true;
            }
        }
    }
    else
    {   
        if( m_ErrorEventOut )
        {
            _event<int> e("Lany Out Valve", CEventNames::VALVE_OUT_PRESS_OK, m_ValveNum);
            EventManager.RaiseEvent(e);                  
            m_ErrorEventIn = false;
        }            
        m_InTickCount = t;
    }
}

void CJoucomaticValve::ValvePValueEvent( float f )
{    
    //bei Joucumatic ist die Anage in Liter, deshalb wird durch 330 geteilt, 330 liter ensprechen 100% oder 10V Ausgangsspannung
    if( f > 330.0 ){
        f = 330.0;
    }
    else if (  f < 0.0  ){
        f = 0.0;
    }
    m_SetValue = f;
    long lTemp = (long)((m_SetValue/3.3)*655.35);
    *m_pOutput = (unsigned short)lTemp;
}

CJoucomaticValve::CJoucomaticValve( unsigned short * pOutput, int ValveNum ) : CValve(pOutput)
{
    //Assign default calibration values
    fI0Cal = 0.0; 
    fIFCal = 106.35; 
    fO0Cal = 0.0; 
    fOFCal = 3.545;
    m_ValveNum = ValveNum;
    m_ErrorEvent = true;
}


//event handler for ADC Event on joucomatic valve
void CJoucomaticValve::ValveADCInEvent( short NativeValue )
{
       //Calc Valve Values
    m_Flow = ((NativeValue *  3.3 / 1024.0) - fI0Cal)*fIFCal;
    
    //get Tick Count for error Calc Timer
    portTickType t = xTaskGetTickCount();
    if ( m_SetValue > 10.0 && m_Flow/(m_SetValue * 3.0) < 0.5) //50 % is OK
    { 
        if( t - m_TickCount > 10000 )
        {
            if( !m_ErrorEvent )
            {
                _event<int> e("Joucomatic Valve", CEventNames::VALVE_FLOW_ERROR, m_ValveNum);
                EventManager.RaiseEvent(e);                  
                m_ErrorEvent = true;
            }
        }
    }
    else
    {   
        if( m_ErrorEvent )
        {
            _event<int> e("Joucomatic Valve", CEventNames::VALVE_FLOW_OK, m_ValveNum);
            EventManager.RaiseEvent(e);                  
            m_ErrorEvent = false;
        }            
        m_TickCount = t;
    } 
}

//event handler for ADC Event on joucomatic valve
void CJoucomaticValve::ValveADCOutEvent( short NativeValue )
{

}
