#ifndef C_VALVE_H
#define C_VALVE_H

extern "C"{
    #include "FreeRTOS.h"
    #include "task.h"
}

class CValve
{
    public :
        CValve( unsigned short * pOutput );
        
        static void ValveADCInEventWrapper( void * pObject, short parameter){ ((CValve*)pObject)->ValveADCInEvent(parameter);};
        virtual void ValveADCInEvent( short NativeValue ) = 0;
        static void ValveADCOutEventWrapper( void * pObject, short parameter){ ((CValve*)pObject)->ValveADCOutEvent(parameter);};
        virtual void ValveADCOutEvent( short NativeValue ) = 0;
        static void ValvePValueEventWrapper( void * pObject, float parameter){ ((CValve*)pObject)->ValvePValueEvent(parameter);};
        virtual void ValvePValueEvent( float f );
        float getIPress(){ return m_IPress;};  //Get Input Pressure in bar
        float getOPress(){ return m_OPress;};  //Get Output Pressure in bar
        float getFlow(){ return m_Flow;};      //Get Flow in l/min
        float getSetValue(){ return m_SetValue;};
        unsigned short * m_pOutput;
        
    protected:
        float fI0Cal;      //Valve Output offset calibration
        float fIFCal;      //Valve Output full sacel calibration
        float fO0Cal;      //Valve Output offset calibration
        float fOFCal;      //Valve Output full sacel calibration
        
        float m_IPress;
        float m_OPress;
        float m_Flow;
        float m_SetValue;   //Set Value from 0 to 100%

};

class CLanyValve : public CValve
{
    public:
        
        CLanyValve( unsigned short *, int );
        virtual void ValveADCInEvent( short NativeValue );
        virtual void ValveADCOutEvent( short NativeValue );
   
    protected:
        portTickType m_InTickCount;    
        portTickType m_OutTickCount;
        bool m_ErrorEventIn;
        bool m_ErrorEventOut;
        int m_ValveNum;
    
};

class CFestoValve : public CValve
{
    public:
        CFestoValve();
        virtual void ValveADCInEvent( short NativeValue );
        virtual void ValveADCOutEvent( short NativeValue );
    
};

class CJoucomaticValve : public CValve
{
    public:
        CJoucomaticValve( unsigned short *,int);
        virtual void ValveADCInEvent( short NativeValue );
        virtual void ValveADCOutEvent( short NativeValue );
        virtual void ValvePValueEvent( float f );
    protected:
        int m_ValveNum;
        portTickType m_TickCount;
        bool m_ErrorEvent;
    
};









#endif