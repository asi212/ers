#include "IPIDController.h"

IPIDController::IPIDController( void ){
  return;
}

void IPIDController::cycCalc( float fSV, float fPV, float T ){ return; }

float IPIDController::getY(void){ return 0.0; }
bool IPIDController::getPWMHeat(void){ return false; }
bool IPIDController::getPWMCool(void){ return false; }

int IPIDController::getMode(void){ return 0; }

float IPIDController::getI(void){ return 0.0; }
float IPIDController::getP(void){ return 0.0; }
float IPIDController::getD(void){ return 0.0; }
float IPIDController::getM(void){ return 0.0; }
bool  IPIDController::isStable(void){ return false; };

bool IPIDController::bSetIVal( float fI ){ return false; };
void IPIDController::setProgressiveMode( bool progFlag ){ return; }

