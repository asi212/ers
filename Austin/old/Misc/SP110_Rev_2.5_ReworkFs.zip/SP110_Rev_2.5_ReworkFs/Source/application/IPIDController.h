#ifndef IPIDCONTROLLER_H
#define IPIDCONTROLLER_H



/**
  Structures
*/
struct  t_pid_setup{
	float Kp;
	float Tn;
	float Tv;
	float min;
	float max;
	float window;
	float Lin;
	float Db;
	float Ta;	
	float Res1;
	float Res2;
	float Res3;
	float Res4;
	float Res5;
	float Res6;
	float Res7;
};

/**
  Interface CPIDController contains only inline funktions
*/
class IPIDController{

private:
  t_pid_setup * pPIDSetup;
  float e[4];  //Array f�r D und I Anteilberechnung
  float uk;    //Stellwert
  float ukFIR; //Stellwert gefiltert

  float fFIRuk[10];

  float fOldSV;     //Merker f�r D-Bildung �ber PV
  float fDiffIIR;   //IIR- Filter f�r Differnentialbildung
  float fIInitRem;

  bool bWasUpWindow;
  bool bWasDownWindow;
	bool bProgressive;


protected:

  void calFIR( void );
  long lInterval;
  long lActTime;
  bool bCool;
  bool bHeat;

  int  iMode;

  float p, i, d;


public:

  IPIDController( void );

  virtual void cycCalc( float fSV, float fPV, float T );

  virtual float getY(void);
  virtual bool getPWMHeat(void);
  virtual bool getPWMCool(void);

  virtual int getMode(void);

  virtual float getI(void);
  virtual float getP(void);
  virtual float getD(void);
  virtual float getM(void);
	virtual bool isStable(void);
  virtual bool bSetIVal( float fI );
	virtual void setProgressiveMode( bool progFlag );

};


#endif