#ifndef IPROCESSDATA_H
#define IPROCESSDATA_H


/**
Interface f�r Prozessdaten
*/
class IProcessData{
  public:
    virtual float getTemp1() = 0;
    virtual float getTemp2() = 0;
    virtual float getTemp3() = 0;
    virtual float getTemp3(int) = 0;
    virtual float getTemp4() = 0;
    virtual float getTemp5() = 0;
    virtual float getTemp6() = 0;
    virtual float getTemp7() = 0;
    virtual float getTemp8() = 0;

};



#endif