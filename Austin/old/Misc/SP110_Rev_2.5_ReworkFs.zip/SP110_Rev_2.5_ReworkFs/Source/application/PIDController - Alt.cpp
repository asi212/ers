#include "PIDController.h"
#include <math.h>

#define PWM_TIME_SEC 30
/**
  Konstruktor needs pointer to Setup Structure
*/
PIDController::PIDController( t_pid_setup * pPIDSetup, bool bCoolApproach ) : bCoolApproach(bCoolApproach) {
  fCycleTime = 1.0;
  this->pPIDSetup = pPIDSetup;
  e[0] = 0.0;
  e[1] = 0.0;
  e[2] = 0.0;
  ukFIR = 0.0;
  for( int i = 0; i < 10; i++) fFIRuk[i] = 0.0;

  fIInitRem = 0.0;
  uk = 0.0;
	ukTot = 0.0;

  bWasUpWindow   = false;
  bWasDownWindow = false;
  fOldSV = 0.0;

}


void PIDController::SetControlReadyStatus( float fSV, float fPV)
{
   float diff =  fPV - fSV;
   float rangepos = pPIDSetup->window;
   float rangeneg = 0.0 - pPIDSetup->window;
   
    if( (diff >= rangeneg) && (diff <=rangepos) )
    {
        m_controlStatusReady = 0;
    }
    else 
    {
        if( diff < 0 )
            m_controlStatusReady = 1;
        else 
            m_controlStatusReady = 2;
    }
  
}
/**
Zyklische Berechnung des PID- Algrithmus
*/
void PIDController::cycCalc( float fSV, float fPV, float T ){

     /**
    PID Algorithmus
    */
    fCycleTime = T/1000.0;
    float Ki = pPIDSetup->Kp/pPIDSetup->Tn;
    float Kd = pPIDSetup->Tv*pPIDSetup->Kp;
    e[0] = fSV - fPV;
    e[1] = e[1] + e[0];
    p = pPIDSetup->Kp * e[0];
    i = Ki * fCycleTime * e[1];
    d = Kd * (e[0] - e[2])/fCycleTime;
    ukTot = p + i + d;
    e[2] = e[0];

    //I- Begrenzung
    if( !isnormal(e[1]) ){
      e[1] = 0.0;
    }
    else if(e[1] < (pPIDSetup->min/(Ki*fCycleTime))){
      e[1] = pPIDSetup->min/(Ki*fCycleTime);
    }
    else if(e[1] > (pPIDSetup->max/(Ki*fCycleTime))){
      e[1] = pPIDSetup->max/(Ki*fCycleTime);
    }

    //Stellwertbegrenzung
    if( ukTot > pPIDSetup->max ){
      uk = pPIDSetup->max;
    }
    else if( ukTot < pPIDSetup->min ){
      uk = pPIDSetup->min;
    }
    else if ( !isnormal(ukTot) ){
      uk = 0;
    }
		else uk = ukTot;
		
    //Prozessheranf�hrung
    if( e[0] > pPIDSetup->window ){
      uk = pPIDSetup->max;
      bWasDownWindow = true;
      iMode = 1;
    }
    else if( e[0] < 0.0 - pPIDSetup->window || bCoolApproach && (bWasUpWindow && e[0] < 0.0)){
      uk = pPIDSetup->min;
      bWasUpWindow = true;
      iMode = 2;
    }
    else{
      if( bWasUpWindow ||  bWasDownWindow ){
        if((bWasDownWindow && e[1] < fIInitRem) || (bWasUpWindow && e[1] > fIInitRem)){
          e[1] = fIInitRem;
        }
        bWasUpWindow = false;
        bWasDownWindow = false;
        fDiffIIR = 0.0;
      }
      if( !isnormal(fIInitRem) ){
        fIInitRem = 0.0;
      }
      else{
        fIInitRem = fIInitRem * 0.999 + uk * 0.001/(Ki*fCycleTime);     //Recalculate I- Init factor through IIR Algorithm
      }
      iMode = 3;
    }
    
    //I Value init factor after reaching setpoint
    if( fSV != fOldSV ){
      fOldSV    = fSV;
      fIInitRem = fSV*pPIDSetup->Lin/(Ki*fCycleTime);
    }

    calFIR();

    //Update for PWM algoritm
    lInterval = (long)(PWM_TIME_SEC * 1000.0 / T);
    if( lActTime >= lInterval ){
      lActTime = 0;
      bCool = true;
      bHeat = true;
    }
    else{
      lActTime++;
    }
    float Y = this->getY();
    long lCmpVal = (long((float)lInterval * Y / pPIDSetup->max));
    if( Y <= 0 || lActTime > lCmpVal ){
      bHeat = false;
    }
    Y =  -Y;
    lCmpVal = (long((float)lInterval * Y / -pPIDSetup->min));
    if( Y <= 0 || lActTime > lCmpVal ){
      bCool = false;
    }
    
    SetControlReadyStatus( fSV, fPV); // Set the Ready signal
}

float PIDController::getY(void){
  return ukFIR;
}

void PIDController::calFIR(void){
  float tempUK = 0.0;
  for( int i = 10 - 1; i >= 0; i-- ){
    fFIRuk[i] = i > 0 ? fFIRuk[i-1] : uk / 10;
    tempUK += fFIRuk[i];
  }
  ukFIR = tempUK;
}

bool PIDController::getPWMHeat(void){
  return bHeat;
}


bool PIDController::getPWMCool(void){
  return bCool;
}

int PIDController::getMode(void){
  return iMode;
}

float PIDController::getI(void){
  return i;
}

float PIDController::getP(void){
  return p;
}

float PIDController::getD(void){
  return d;
}

float PIDController::getM(void){
  return fIInitRem;
}

bool PIDController::bSetIVal( float fValue ){
    //Zur�ckrechner des I- Anteils so das sto�freie �bernahme m�glich ist
    e[1] = (fValue/pPIDSetup->Kp - e[0] ) * pPIDSetup->Tn / fCycleTime;
    return true;
}

