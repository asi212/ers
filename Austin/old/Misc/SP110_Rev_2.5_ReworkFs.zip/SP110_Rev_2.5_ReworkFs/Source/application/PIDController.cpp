#include "PIDController.h"
#include <math.h>
#include <algorithm>

//#define PWM_TIME_SEC    	30

#define PID_UNSTABLE_ERR  0.25    // Control error, where controller status changes from stable to unstable
#define PID_STABLE_ERR    0.05    // Control error, where controller status changes from unstable to stable
#define PID_STABLE_SLOPE  0.10    // Control output slope where controller status changes from unstable to stable 
#define PID_STABLE_SEC   	  30    // Time in s, that the stable criteria must be fulfilled before the controller is assumed to be stable
#define PID_DPART_TF 		  1.00    // Time constant of D-part low pass filer in seconds.

// TODO: The defines should be changed to PID parameters, available in LabView, or at least moved to constructor parameters

/**
  Konstruktor needs pointer to Setup Structure
*/
PIDController::PIDController( t_pid_setup * pPIDSetup, bool bCoolApproach, float maxSlope, float offSet ) : 
			bCoolApproach(bCoolApproach), 
			fMaxSlope(maxSlope), 
			fOffSet(offSet) 
{
  fCycleTime = 1.0;  
  this->pPIDSetup = pPIDSetup;
  e[0] = 0.0;   // e[0]: Controling error 
  e[1] = 0.0;   // e[1]: Integrated error 
  e[2] = 0.0;   // e[2]: Last controlling error, used for D-Controller
	e[3] = 0.0;   // e[3]: Feedback error, due to limiting output signal slope and amplitude
	xd   = 0.0;   // Interim variable for D-Part calculation
  ukFIR = 0.0;
  for( int i = 0; i < 10; i++) fFIRuk[i] = 0.0;

	//dumax =  PID_MAX_SLOPE * fCycleTime; 
	
	fCntStable = PID_STABLE_SEC;
	bControlStable = false;
	bProgressive = false;
	fRelChange = 0;
	
  fIInitRem = 0.0;
  uk = 0.0;
	ukTot = 0.0;

  bWasUpWindow   = false;
  bWasDownWindow = false;
  fOldSV = 0.0;

}


void PIDController::SetControlReadyStatus( float fSV, float fPV)
{
   float diff =  fPV - fSV;
   float rangepos = pPIDSetup->window;
   float rangeneg = 0.0 - pPIDSetup->window;
   
    if( (diff >= rangeneg) && (diff <=rangepos) )
    {
        m_controlStatusReady = 0;
    }
    else 
    {
        if( diff < 0 )
            m_controlStatusReady = 1;
        else 
            m_controlStatusReady = 2;
    }
}

/**
Zyklische Berechnung des PID- Algrithmus
*/
void PIDController::cycCalc( float fSV, float fPV, float T ){

    // PID Algorithmus
	
		// Compute some constants
    fCycleTime = T/1000.0;
    float Ki = pPIDSetup->Kp/pPIDSetup->Tn;
    float Kd = pPIDSetup->Tv*pPIDSetup->Kp;
		float Md = fCycleTime / PID_DPART_TF; 
		
		// Control error
		e[0] = fSV - fPV;
		
		// Proportional part
    p = pPIDSetup->Kp * e[0];

		// Integrating part
	  e[1] = e[1] + e[0] - e[3]; 									
    i = Ki * fCycleTime * e[1];
    
//		d = Kd * (e[0] - e[2])/fCycleTime;
//    e[2] = e[0];

		// Differential part low pass filter 2nd order to smooth controller error
		// The Transfer Function of the differential part used in the PID controller is given as
		// 
		// G(s) = (s*Tv) / (1 + s*1,75*Tf + (s*Tf)^2)
		// 
		// This function represents a 2nd order low pass filtering the control error and the differentiation of the error,
		// where Tv is the derivative action time, and Tf is the time constant of the 2nd order low pass
		
		float  e2old = e[2];      										// Edold   = Ed[idx];
		e[2] = e2old + Md *  xd;  										// Ed[idx] = Edold   + Md1[idx] * Xd[idx];
		xd   =    xd + Md * (e[0] - e[2] - 1.75*xd);	// Xd[idx] = Xd[idx] + Md1[idx] * (E - Edold - 1.75*Xd[idx]);

		// Differential part, based on filtered control error
		d = Kd * (e[2] - e2old) / fCycleTime;  // Yd = Md2[idx]*(Ed[idx] - Edold);

    // Add all parts
		ukTot = p + i + d + fOffSet;
		
		// Eingeschwungen, wenn Stellgr��e kleiner 10% von max Ausschlag �ber 30 sec
		fRelChange = fRelChange*0.99 + 0.01*abs(ukFIR - ukFIROld)/abs(pPIDSetup->max - pPIDSetup->min)/fCycleTime;

		// Two possibilities to be unstable:
		// a) Controller is unstable and control goal not reached (low diff, low control signal slope)
		// b) Controller is stabel and control controll diff too high 
		if ( (bControlStable && abs(e[0])>PID_UNSTABLE_ERR) || (!bControlStable && (abs(e[0])>PID_STABLE_ERR || fRelChange>PID_STABLE_SLOPE)) ) {
			bControlStable = false;
			fCntStable = PID_STABLE_SEC;
		}
		// Control goal reached and stable for a certain time
		else if (fCntStable < 1 ) {
			bControlStable = true;
			fCntStable     = 0;
		}
		// Control goal reached, but we have hold control goal for a certain time
		else if (!bControlStable) {
			fCntStable -= fCycleTime;
		}			
		
    // Stellwertbegrenzung
		float umax = pPIDSetup->max;
		float umin = pPIDSetup->min;

		// a) maximaler Stellwert durch maximale Flankensteilheit
	  //    Wird erst wirksam, wenn Regler im Control-Modus
		if (bControlStable && !bProgressive)
		{
			dumax =  fMaxSlope * fCycleTime; 
			umax = uk + dumax;
			umin = uk - dumax;
		}		
		// b) maximaler Stellwert durch absolute Amplituden-Limits
		umax = min(umax,pPIDSetup->max);
		umin = max(umin,pPIDSetup->min);
		
    // c) Begrenzung
    if( ukTot > umax ){
      uk = umax;
    }
    else if( ukTot <umin ){
      uk = umin;
    }
    else if ( !isnormal(ukTot) ){
      uk = 0;
    }
		else uk = ukTot;
				
    // Reglerstatus: Heizen, K�hlen oder Regeln
    if( e[0] > pPIDSetup->window ){
      iMode = 1;    // Heizen
    }
    else if( e[0] < 0.0 - pPIDSetup->window ){
      iMode = 2;    // K�hlen
    }
    else{
      iMode = 3;    // Regeln
    }
		
		// Anti-Windup Feedback-Fehler
		e[3] = (ukTot - uk) / pPIDSetup->Kp;
		//e[3] = 0;
    
		// Smooth controler output, even if no slope limit is applied
    calFIR();
    //uk = ukFIR;
		
    SetControlReadyStatus( fSV, fPV); // Set the Ready signal
}

float PIDController::getY(void){
	return uk;
//  return ukFIR;
}

void PIDController::calFIR(void){
  float tempUK = 0.0;
	ukFIROld = ukFIR;
  for( int i = 10 - 1; i >= 0; i-- ){
    fFIRuk[i] = i > 0 ? fFIRuk[i-1] : uk / 10;
    tempUK += fFIRuk[i];
  }
  ukFIR = tempUK;
}

bool PIDController::getPWMHeat(void){
  return bHeat;
}


bool PIDController::getPWMCool(void){
  return bCool;
}

int PIDController::getMode(void){
 // return iMode;
  return  m_controlStatusReady;
}

float PIDController::getI(void){
  return i;
}

float PIDController::getP(void){
  return p;
}

float PIDController::getD(void){
  return d;
}

float PIDController::getM(void){
  return fIInitRem;
}

bool PIDController::isStable(void) {
	return bControlStable;
}

bool PIDController::bSetIVal( float fValue ){
    //Zur�ckrechner des I- Anteils so das sto�freie �bernahme m�glich ist
    e[1] = ((fValue-fOffSet)/pPIDSetup->Kp - e[0] ) * pPIDSetup->Tn / fCycleTime;
    return true;
}

void PIDController::setProgressiveMode(bool progFlag) {
	bProgressive = progFlag;
}