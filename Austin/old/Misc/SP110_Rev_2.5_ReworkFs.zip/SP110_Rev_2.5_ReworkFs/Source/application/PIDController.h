#ifndef PIDCONTROLLER_H
#define PIDCONTROLLER_H


#include "IPIDController.h"

/**
  Class CPIDController contains all Information releted to temperature in the system.
*/
class PIDController : public IPIDController{

private:
  float fCycleTime;
  t_pid_setup * pPIDSetup;
  float e[4];  // Array f�r D und I Anteilberechnung
	float xd;		 // Zwischenvariable f�r die Berechnung des D-Anteils
  float ukTot; // Stellwert vor Begrenzung
  float uk;    // Stellwert
	float dumax; // Maximale absolute �nderung der Stellgr��e
  float ukFIR; // Stellwert gefiltert
  float ukFIROld; // Stellwert gefiltert, vom vorigen Aufruf

	float fCntStable;
	bool  bControlStable;
	float fRelChange;	// Mittelwert speicher f�r die relative Stellwertgr��en-�nderung
	
  float fFIRuk[10];

  float fOldSV;     //Merker f�r D-Bildung �ber PV
  float fDiffIIR;   //IIR- Filter f�r Differnentialbildung
  float fIInitRem;

  bool bWasUpWindow;
  bool bWasDownWindow;
	bool bProgressive;
  
  const bool  bCoolApproach; // Ann�herungsverhalten beim K�hlen, wenn False k�hlen bis sollwert unterschritten ansonsten nur K�hlen bis Regelfenster
	const float fMaxSlope;     // Absolute maximale �nderung der Stellgr��e pro Sekunde
  const float fOffSet;			 // Aufschlaggr��e auf die Stellgr��e 

protected:

  void calFIR( void );
  long lInterval;
  long lActTime;
  bool bCool;
  bool bHeat;
  int m_controlStatusReady;
  int iMode;

  float p, i, d;


public:


      PIDController(t_pid_setup * pPIDSetup, bool bCoolApproach, float maxSlope, float offSet);
      virtual void cycCalc( float fSV, float fPV, float T );
      
      virtual float getY(void);
      virtual bool getPWMHeat(void);
      virtual bool getPWMCool(void);
      virtual bool bSetIVal( float fI );
      
      virtual int getMode(void);
      
      virtual float getI(void);
      virtual float getP(void);
      virtual float getD(void);
      virtual float getM(void);
      virtual void SetControlReadyStatus( float fSV, float fPV);
      virtual bool isStable(void);
      int GetControlReadyStatus(void) {return m_controlStatusReady;};
      void setProgressiveMode(bool progFlag);
      float GetKp(void){return pPIDSetup->Kp;}   

};


#endif