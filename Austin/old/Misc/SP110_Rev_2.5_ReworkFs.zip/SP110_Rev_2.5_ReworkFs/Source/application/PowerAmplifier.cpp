#include "PowerAmplifier.h"
#include <cstdio>
#include <cmath>

/**Pointer to Lambda Group 1 setpoint value native hex code*/
unsigned short * const CLambdaData::uLmb1SetVal = (unsigned short*)(0x34000034);
/**Pointer to Lambda Group 2 setpoint value native hex code*/
unsigned short * const CLambdaData::uLmb2SetVal = (unsigned short*)(0x34000036);
/**Pointer to Lambda Group 3 setpoint value native hex code*/
unsigned short * const CLambdaData::uLmb3SetVal = (unsigned short*)(0x34000038);
/**Pointer to Lambda Group 4 setpoint value native hex code*/
unsigned short * const CLambdaData::uLmb4SetVal = (unsigned short*)(0x3400003A);
/**Pointer to Lambda Group 5 setpoint value native hex code*/
unsigned short * const CLambdaData::uLmb5SetVal = (unsigned short*)(0x3400003C);
/**Pointer to Lambda Group 6 setpoint value native hex code*/
unsigned short * const CLambdaData::uLmb6SetVal = (unsigned short*)(0x3400003E);

unsigned char * const CLambdaData::pMains  = (unsigned char*)(0x34000040);
set_lmb * const CLambdaData::pLmbSet = (set_lmb*)(0x34000043);
get_lmb * const CLambdaData::pLmbGet = (get_lmb*)(0x34000044);

long * const CLambdaData::lpHC1_IVal = (long*)(0x3400001C);
long * const CLambdaData::lpHC1_VVal = (long*)(0x34000020);
long * const CLambdaData::lpHC2_IVal = (long*)(0x34000024);
long * const CLambdaData::lpHC2_VVal = (long*)(0x34000008);

const float CLambdaData::fFSRVal = (5.0)/0x7FFFFF00;


/**
  Constructor, intializing pointers und default values
*/
CLambdaData::CLambdaData( CSetup * pSetup )
{
  this->pSetup = pSetup;
  iInitFSM = 20;
  resetErrors();
  for( int i = 0; i < 6; i++ )
  {
      m_oCurrTim[i] = 100;
      m_uCurrTim[i] = 100;
  }
}

/**
  Cyclyc calculations for Lambdas
*/
bool CLambdaData::cycCalc( ){
    if( iInitFSM > 0 ){
        Calibrate();
        iInitFSM--;
    }
    if( iCheckCnt < 1 || iCheckCnt > 6 ){
        iCheckCnt = 1;
    }
    checkErrors( iCheckCnt++ );
    //MB Tempor�r
    float fExpCurr = pSetup->getCurrLimit(1) * fPowerLevels[4] / 100.0;
    if( fPowerLevels[4] > 10.0 && ((fExpCurr / abs(getHC1Curr())) > 1.2) ){
        if(  m_uCurrTim[4] <= 0 ){
            sErrors[4].errors.b.uCurr = 1;
        }
        else{
            m_uCurrTim[4]--;
        }
    }
    else
    {
        sErrors[4].errors.b.uCurr = 0;
        m_uCurrTim[4] = 100;
    }

    if( fPowerLevels[4] > 10.0 && (abs(fExpCurr / abs(getHC1Curr())) < 0.8) ){
        if( m_oCurrTim[4] <= 0 ){
            sErrors[4].errors.b.oCurr = 1;
        }
        else{
            m_oCurrTim[4]--;
        }
    }
    else
    {
        m_oCurrTim[4] = 100;
    }
    return true;
}

/**
 Function Calibrate
*/
void CLambdaData::Calibrate( void ){
  fADCOffsets[0] = fFSRVal * (*lpHC1_IVal);
  fADCOffsets[1] = fFSRVal * (*lpHC1_VVal);
  fADCOffsets[2] = fFSRVal * (*lpHC2_IVal);
  fADCOffsets[3] = fFSRVal * (*lpHC2_VVal);
  fADCOffsets[4] = 0.0;
  fADCOffsets[5] = 0.0;
  fADCOffsets[6] = 0.0;
  fADCOffsets[7] = 0.0;
}

/**
  Check on Lambda- Erros
  @param iLmbNum Check lambda number for error
*/
void CLambdaData::checkErrors( int iLmbNum ){

    bool bLmbFailure = ((this->pLmbSet->cByte)>>(iLmbNum-1) & 0x01) == 0 &&
      ((this->pLmbGet->cByte)>>(iLmbNum-1) & 0x01) == 1 ? true : false;
    if( bLmbFailure && fPowerLevels[iLmbNum - 1 ] > 5.0 ){
      if( sErrors[iLmbNum-1].iDelayError <= 0 ){
        sErrors[iLmbNum-1].errors.b.FBFail = 1;
      }
      else
      {
          sErrors[iLmbNum-1].iDelayError--;
      }
    }
    else{
      sErrors[iLmbNum-1].iDelayError = ERROR_COUNT;
      sErrors[iLmbNum-1].errors.b.FBFail = 0;
    }
}

/**
Reset Errors
*/
void CLambdaData::resetErrors(void){
  for( int i = 0; i < 6; i++ ){
    sErrors[i].iDelayError = ERROR_COUNT;
    sErrors[i].errors.cFlags = 0;
  }
}


/**
  Set Lambda group 1 power level, valid range from 0-100
  return Value -> true if operation was succesfull false otherwise
*/
bool CLambdaData::SetHC1Power(float fLevel){
  fPowerLevels[0] = fLevel;
  if( fPowerLevels[0] > 100.0 ){
    fPowerLevels[0] = 100.0;
  }
  else if (  fPowerLevels[0] < 0.0  ){
    fPowerLevels[0] = 0.0;
  }
  long lTemp = (long)(fPowerLevels[0]*655.35*pSetup->getLambdaCal(1));
  *uLmb1SetVal = (unsigned short)lTemp;
  return true;
}

/**
  Get currenct HC1 Power Level
  @return current power level off lambda 1
*/
float CLambdaData::getHC1Power(void){
  return fPowerLevels[0];
}

/**
  Set Lambda group 2 power level, valid range from 0-100
  return Value -> true if operation was succesfull false otherwise
*/
bool CLambdaData::SetHC2Power(float fLevel){
  fPowerLevels[1] = fLevel;
  if( fPowerLevels[1] > 100.0 ){
    fPowerLevels[1] = 100.0;
  }
  else if (  fPowerLevels[1] < 0.0  ){
    fPowerLevels[1] = 0.0;
  }
  long lTemp = (long)(fPowerLevels[1]*655.35*pSetup->getLambdaCal(2));
  *uLmb2SetVal = (unsigned short)lTemp;
  return true;
}

/**
  Get currenct HC2 Power Level
  @return current power level off lambda 1
*/
float CLambdaData::getHC2Power(void){
  return fPowerLevels[1];
}

/**
  Set Lambda group 2 power level, valid range from 0-100
  return Value -> true if operation was succesfull false otherwise
*/
bool CLambdaData::SetHC3Power(float fLevel){
  fPowerLevels[2] = fLevel;
  if( fPowerLevels[2] > 100.0 ){
    fPowerLevels[2] = 100.0;
  }
  else if (  fLevel < 0.0  ){
    fPowerLevels[2] = 0.0;
  }
  long lTemp = (long)(fPowerLevels[2]*655.35*pSetup->getLambdaCal(3));
  *uLmb3SetVal = (unsigned short)lTemp;
  return true;
}

/**
  Get currenct HC3 Power Level
  @return current power level off lambda 1
*/
float CLambdaData::getHC3Power(void){
  return fPowerLevels[2];
}

/**
  Set Lambda group 2 power level, valid range from 0-100
  return Value -> true if operation was succesfull false otherwise
*/
bool CLambdaData::SetHC4Power(float fLevel){
  fPowerLevels[3] = fLevel;
  if( fPowerLevels[3] > 100.0 ){
    fPowerLevels[3] = 100.0;
  }
  else if (  fPowerLevels[3] < 0.0  ){
    fPowerLevels[3] = 0.0;
  }
  long lTemp = (long)(fPowerLevels[3]*655.35*pSetup->getLambdaCal(4));
  *uLmb4SetVal = (unsigned short)lTemp;
  return true;
}

/**
  Get currenct HC4 Power Level
  @return current power level off lambda 1
*/
float CLambdaData::getHC4Power(void){
  return fPowerLevels[3];
}

/**
  Set Lambda group 2 power level, valid range from 0-100
  return Value -> true if operation was succesfull false otherwise
*/
bool CLambdaData::SetHC5Power(float fLevel){
  fPowerLevels[4] = fLevel;
  if( fPowerLevels[4] > 100.0 ){
    fPowerLevels[4] = 100.0;
  }
  else if (  fPowerLevels[4] < 0.0  ){
    fPowerLevels[4] = 0.0;
  }
  long lTemp = (long)(fPowerLevels[4]*655.35*pSetup->getLambdaCal(5));
  *uLmb5SetVal = (unsigned short)lTemp;
  return true;
}

/**
  Get currenct HC5 Power Level
  @return current power level off lambda 1
*/
float CLambdaData::getHC5Power(void){
  return fPowerLevels[4];
}

/**
  Set Lambda group 2 power level, valid range from 0-100
  return Value -> true if operation was succesfull false otherwise
*/
bool CLambdaData::SetHC6Power(float fLevel){
  fPowerLevels[5] = fLevel;
  if( fPowerLevels[5] > 100.0 ){
    fPowerLevels[5] = 100.0;
  }
  else if (  fPowerLevels[5] < 0.0  ){
    fPowerLevels[5] = 0.0;
  }
  long lTemp = (long)(fPowerLevels[5]*655.35*pSetup->getLambdaCal(6));
  *uLmb6SetVal = (unsigned short)lTemp;
  return true;
}

/**
  Get currenct HC6 Power Level
  @return current power level off lambda 1
*/
float CLambdaData::getHC6Power(void){
  return fPowerLevels[5];
}

/**
  Switch on main relais
*/
void CLambdaData::setOnMains( int iSwitch ){
  *pMains |= (0x01<<iSwitch-1);
}

void CLambdaData::setOffMains( int iSwitch ){
  *pMains &= ~(0x01<<iSwitch-1);
}

unsigned char CLambdaData::GetLamdaStatus(){

  return pLmbGet->cByte;
}

void CLambdaData::SetLambdaOn(int iLambda){
  pLmbSet->cByte &= ~(0x01<<iLambda-1);
}

void CLambdaData::SetLambdaOff(int iLambda){
  pLmbSet->cByte |= (0x01<<iLambda-1);
}

float CLambdaData::getHC1Curr(void){   
  float fVoltage = fFSRVal * (*lpHC1_IVal);
  float fMeassC = (fVoltage - fADCOffsets[0]) * pSetup->getCurrCal(1);
  return fMeassC;
}

float CLambdaData::getHC1Volt(void){
  float fVoltage = fFSRVal * (*lpHC1_VVal);
  float fMeassV = (fVoltage - fADCOffsets[1]) * pSetup->getVoltCal(1);
  return fMeassV;
}

float CLambdaData::getHC2Curr(void){
  float fVoltage = fFSRVal * (*lpHC2_IVal);
  float fMeassC = (fVoltage - fADCOffsets[2]) * pSetup->getCurrCal(2);
  return fMeassC;
}

float CLambdaData::getHC2Volt(void){
  float fVoltage = fFSRVal * (*lpHC2_VVal);
  float fMeassV = (fVoltage - fADCOffsets[3]) * pSetup->getVoltCal(2);
  return fMeassV;
}

uLError CLambdaData::getLErrorStatus( int iLmbNum ){
  return sErrors[iLmbNum-1].errors;
}


/***********************************************************************************************
Class PowerAmplifier
*/
CPowerAmplifier::CPowerAmplifier( CSetup * pSetup ) :
  CLambdaData( pSetup ){
  trans[0] = new CTransistor( (unsigned short*)(0x34000034), (long*)(0x3400001C), pSetup );
  trans[1] = new CTransistor( (unsigned short*)(0x34000036), (long*)(0x34000020), pSetup );
  trans[2] = new CTransistor( (unsigned short*)(0x34000038), (long*)(0x34000024), pSetup );
  trans[3] = new CTransistor( (unsigned short*)(0x3400003A), (long*)(0x34000008), pSetup );
}

/**
Cyclic calculations
*/
bool CPowerAmplifier::cycCalc( int iCycleTime ){

  for( int i = 0; i < 4; i++ ){
    trans[i]->cycExec( iCycleTime );
  }
  CLambdaData::cycCalc();
  SetHC6Power();
  return true;
}

/**
  Set Lambda group 1 power level, valid range from 0-100
  return Value -> true if operation was succesfull false otherwise
*/
bool CPowerAmplifier::SetHC1Power(float fLevel){
  return trans[0]->setSetVal( fLevel );
}

/**
  Set Lambda group 1 power level, valid range from 0-100
  return Value -> true if operation was succesfull false otherwise
*/
bool CPowerAmplifier::SetHC2Power(float fLevel){
  return trans[1]->setSetVal( fLevel );
}
/**
  Set Lambda group 1 power level, valid range from 0-100
  return Value -> true if operation was succesfull false otherwise
*/
bool CPowerAmplifier::SetHC3Power(float fLevel){
  return trans[2]->setSetVal( fLevel );
}
/**
  Set Lambda group 1 power level, valid range from 0-100
  return Value -> true if operation was succesfull false otherwise
*/
bool CPowerAmplifier::SetHC4Power(float fLevel){
  return trans[3]->setSetVal( fLevel );
}

/**
  Set Lambda group 1 power level, valid range from 0-100
  return Value -> true if operation was succesfull false otherwise
*/
bool CPowerAmplifier::SetHC6Power( void ){
  float fLmbLevel = 0.0;
  for( int i = 0; i < 4; i++ ){
    if( trans[i]->getSetVal() > fLmbLevel ){
      fLmbLevel = trans[i]->getSetVal();
    }
  }
  fPowerLevels[5] = fLmbLevel + 5.0;

  if( fPowerLevels[5] > 100.0 ){
    fPowerLevels[5] = 100.0;
  }
  if( fPowerLevels[5] < 18.0 ){ //Minimum 8 Volt because of Transitor Dead Look Condition
    fPowerLevels[5] = 18.0;
  }

  long lTemp = (long)(fPowerLevels[5]*655.35*pSetup->getLambdaCal(6));
  *uLmb6SetVal = (unsigned short)lTemp;
  return true;
}

/**

*/
float CPowerAmplifier::getHC1Curr(void){
  return trans[0]->getCurrent();
}

/**

*/
float CPowerAmplifier::getHC2Curr(void){
  return trans[1]->getCurrent();
}

/**

*/
float CPowerAmplifier::getHC3Curr(void){
  return trans[2]->getCurrent();
}

/**

*/
float CPowerAmplifier::getHC4Curr(void){
  return trans[3]->getCurrent();
}

/**
Return error union from transitor
*/
uTraError CPowerAmplifier::getTraErrorStatus( int iTraNum ){
  if( iTraNum > 0 && iTraNum < 5 ){
    return trans[iTraNum-1]->getError();
  }
  else{
#ifdef DEBUG
    printf( "ERROR, Transistor number invalid in class CPowerAmplifier::getTraErrorStatus");
#endif
    uTraError temp;
    temp.cError = 0xFF;
    return temp;
  }
}

/**
Reset all errors
*/
void CPowerAmplifier::resetErrors(void){
  CLambdaData::resetErrors();
  for( int i = 0; i < 4; i++ ){
    trans[i]->reset();
  }
}

