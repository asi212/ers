#ifndef POWERAMPLIFIER_H
#define POWERAMPLIFIER_H


#include "CSetup.h"
#include "CTransistor.h"
#include "Devices/CLambda.h"

#define ERROR_COUNT 50

/**
 Structs to Lamda Control Byte
*/


union uLError{
  unsigned char cFlags;
  struct{
    unsigned char
    FBFail : 1,  //Feedback Failure
    FSFail : 1,  //Fuse Feddback Failure if available
    oCurr  : 1,
    uCurr  : 1;
  } b;
};

/**
  Struct containing Lambda Error Informations
*/
struct sLError{
  uLError errors;
  int iDelayError;
};

/**
  Class CLamdaData contains all Information related to the Lamda Power Supply
*/
class CLambdaData{
  private:


    static unsigned char * const pMains;
    static set_lmb * const pLmbSet;
    static get_lmb * const pLmbGet;

    static const float fFSRVal;
    static long * const lpHC1_IVal;
    static long * const lpHC1_VVal;
    static long * const lpHC2_IVal;
    static long * const lpHC2_VVal;

    int iCheckCnt;
    int m_oCurrTim[6];
    int m_uCurrTim[6];
    int iInitFSM;
    float fADCOffsets[8];

  protected:
    static unsigned short * const uLmb1SetVal;
    static unsigned short * const uLmb2SetVal;
    static unsigned short * const uLmb3SetVal;
    static unsigned short * const uLmb4SetVal;
    static unsigned short * const uLmb5SetVal;
    static unsigned short * const uLmb6SetVal;

    bool cycCalc();

    float fPowerLevels[6];
    CSetup * pSetup;

    sLError sErrors[6];
    void checkErrors( int iSensNum );
    void resetErrors(void);
    void Calibrate(void);


  public:
    CLambdaData( CSetup * pSetup );
    bool SetHC1Power(float fLevel);
    bool SetHC2Power(float fLevel);
    bool SetHC3Power(float fLevel);
    bool SetHC4Power(float fLevel);
    bool SetHC5Power(float fLevel);
    bool SetHC6Power(float fLevel);

    void setOnMains( int iSwitch );
    void setOffMains( int iSwitch );
    unsigned char GetLamdaStatus();
    void SetLambdaOn(int iLambda);
    void SetLambdaOff(int iLambda);

    float getHC1Curr(void);
    float getHC1Volt(void);
    float getHC2Curr(void);
    float getHC2Volt(void);

    float getHC1Power(void);
    float getHC2Power(void);
    float getHC3Power(void);
    float getHC4Power(void);
    float getHC5Power(void);
    float getHC6Power(void);

    uLError getLErrorStatus( int iLmbNum );

};

class CPowerAmplifier : protected CLambdaData{

  private:
    CTransistor * trans[4];

  protected:
    bool SetHC6Power(void);
    bool cycCalc( int iCycleTime );

  public:
    CPowerAmplifier( CSetup * pSetup );

    bool SetHC1Power(float fLevel);
    bool SetHC2Power(float fLevel);
    bool SetHC3Power(float fLevel);
    bool SetHC4Power(float fLevel);

    float getHC1Power(void){ return trans[0]->getSetVal(); };
    float getHC2Power(void){ return trans[1]->getSetVal(); };
    float getHC3Power(void){ return trans[2]->getSetVal(); };
    float getHC4Power(void){ return trans[3]->getSetVal(); };
    float getHC5Power(void){ return CLambdaData::getHC5Power(); };
    float getHC6Power(void){ return CLambdaData::getHC6Power(); };


    float getHC1Curr(void);
    float getHC2Curr(void);
    float getHC3Curr(void);
    float getHC4Curr(void);

    void setOnMains( int iSwitch ) { CLambdaData::setOnMains(iSwitch ); };
    void setOffMains( int iSwitch ){ CLambdaData::setOffMains(iSwitch ); };
    void SetLambdaOn(int iLambda)  { CLambdaData::SetLambdaOn(iLambda ); };
    void SetLambdaOff(int iLambda) { CLambdaData::SetLambdaOff(iLambda ); };

    uTraError getTraErrorStatus( int iTraNum );
    uLError getLErrorStatus( int iLmbNum ){ return CLambdaData::getLErrorStatus( iLmbNum );};

    void resetErrors(void);

};

#endif