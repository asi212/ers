//Standard Library Includes
#include <stdio.h>
#include <vector>
#include "../system_wide_defs.h"
#include "Devices/CDewPointSensor.h"
#include "Devices/CLambda.h"

#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstdarg>
extern "C"{
    #include "JLINKDCC.h" 
}

//Project Includes
#include "FreeRTOS.h"
#include "task.h"
#include "SP110_aggregate.h"
#include "CProcessData.h"
#include "PIDController.h"
#include "CDiagCom.h"
#include "CAirTable.h"
#include "CSetup.h"
#include "CChillerCom.h"
#include "CFiles.h"
#include "CDataLogger.h"
#include "Devices\CValve.h"
#include "CErrorMsgs.h"
#include "CCanIO.h"

#include "..\system_wide_defs.h"
#include "..\DeviceManager\CDeviceManager.h"
#include "..\DisplayManager\CDisplayManager.h"
#include "..\Toolbox\toolbox.h"

#include "..\ComManager\OS_SerialPort.h"
#include "..\ComManager\OS_SerialPort.h"
#include "..\ComManager\probercmds.h"
#include "..\ComManager\protocolmgr.h"

#include "..\MailboxSystem\CEventManager.h"

/* interrupt handler */

void UART0_IRQHandler(void);
__arm void UART0_IRQHandler(void);

void UART2_IRQHandler(void);
__arm void UART2_IRQHandler(void);


/*
  Local function definitions and callbacks
*/
bool ptNotifyChillerEvent( CChillerCom::ifc_event e, void * pParam );
void loadSetup();
void DisplayRefresh(void);
void UpdateDiagnosticData(void);
void UpdateSystemStatus(void);
void evalControlStatus( _string & Text );
bool evalERSMessages( char * pMsg );
bool evalERSMessages( char * pMsg, void * dstBuf, int * i );

int iConTimer; //Timer to define switch beetwenn fine an corease controllin
int iConTimer2;
int iConTimer3; //Timer for HoldMode
bool bCtrlFine;
bool bCtrlVeryFine;
bool bHoldMode = false;
bool bHoldEnable = false;
bool bAllowStandard = true;
bool bAllowLowNoise = true;
bool cMacConfigDone = 0;

bool bAirTableLoaded = false;
bool bAirTableSave = false;


//Globals
MODE mode = BOOT;
//MODE mode_i = BOOT;     //store current mode
char gcMemException = 0;
//int  mode_con = 0;
bool bInStandby = false;
bool bTOutError = false;
bool bSaveSetup = false;
bool bDewPointWarning = false;
char cTemp[3000] @ "EXRAM";
char display_update_flag;
extern xQueueHandle xHDiagRxChars;
extern xQueueHandle xHDiagTxChars;
float fDewPointOffset = 5.0;
char sMac[20];

int iOffsettTable = 0;

bool b_temp_surpress_set_temp_change = false;
bool b_is_lany_detected = false;
//TCP Globals
float tcp_chucktemp, tcp_chillertemp, tcp_ktytemp, tcp_, tcp_interntemp, tcp_current1, tcp_current2;

//Gobal Instances
CSetup        c_CSetup;
CProcessData  c_CPData( 66, &c_CSetup );
CChillerCom   c_ChillerCom((void*)ptNotifyChillerEvent, &EventManager);
CDiagCom      c_CDiagCom(  &c_CSetup, &c_CPData );
CFiles        c_CFiles;
//CDataLogger   c_CLogger @ "EXRAM";
CAirTable     c_AirTable;

CSetup        * p_CSetup = &c_CSetup;
CProcessData  * p_CPData = &c_CPData;
CChillerCom   * p_ChillerCom = &c_ChillerCom;
CDiagCom      * p_CDiagCom = & c_CDiagCom;
CFiles        * p_CFiles = &c_CFiles;
//CDataLogger   * p_CLogger = &c_CLogger;
CAirTable     * p_AirTable = &c_AirTable;
PIDController * p_con1 = NULL;
PIDController * p_con2 = NULL;
PIDController * p_con3 = NULL;
PIDController * p_con4 = NULL;
PIDController * p_con5 = NULL;
PIDController * p_con6 = NULL;

CLambda * p_Lambdas[6];

//Ventile im System
CLanyValve m_lany1( (unsigned short*)(0x34000030), 1 );
CJoucomaticValve m_jouco1( (unsigned short*)(0x34000030), 1 );
CJoucomaticValve m_jouco2( (unsigned short*)(0x34000032), 2 );

//Anzulegende Objekte:

CEventManager EventManager;
string name;
CDeviceManager device_manager( &EventManager );
CDisplaymanager displaymanager(&EventManager);
CDeviceManager *pDevicemanager;
CDisplaymanager *pDisplaymanager;
CDewPointSensorStd d( &EventManager );
CDewPointSensor * pDewPointSensor = &d ;
OS_SerialPort sPort;
OS_SerialPort * p_serDevice = &sPort;
CCanIO c_CanIo;
int controlstatus = 0;

/**
  IO- Task is responsible for Digital IOs and Error Handling
*/
void IO_Task(void *pvParameters) {
  mode = BOOT;
  char cTemp[10];
  static int iSErrorCnt = 1000;
  static int iTogle = 0;

  p_Lambdas[0] = new CLambda( &EventManager, 1, p_CSetup );
  p_Lambdas[1] = new CLambda( &EventManager, 2, p_CSetup );
  p_Lambdas[2] = new CLambda( &EventManager, 3, p_CSetup );
  p_Lambdas[3] = new CLambda( &EventManager, 4, p_CSetup );
  p_Lambdas[4] = new CLambda( &EventManager, 5, p_CSetup, 1, (long*)0x3400001C, (long*)0x34000020);
  p_Lambdas[5] = new CLambda( &EventManager, 6, p_CSetup, 2, (long*)0x34000024, (long*)0x34000008);
  
  for( int i = 0; i < 6; i++ )
  {
      p_Lambdas[i]->Init();
      p_Lambdas[i]->SetOff();
  }

  while(  !p_CSetup->bIsValid()  ) vTaskDelay(10);
  
  p_CPData->setOffMains(1);
  p_CPData->setOffMains(2);
  p_CPData->setOffMains(3);
  p_CPData->setOffMains(4);
  p_ChillerCom->Init( p_CSetup->getConConfig() >= CSetup::_s_config::E_CONTOLLER_HWS_D300 && p_CSetup->getConConfig() <= CSetup::_s_config::E_CONTOLLER_SWS_D600 );
  
  while(1){
    EventManager.HandlePID();
    for( int i = 0; i < 6; i++ )
    {
      p_Lambdas[i]->cycCalc();
    }

    switch( mode ){
      case BOOT:
        p_ChillerCom->setInit( true );
        if( !p_CPData->isCalibrating()){
          mode = INIT;
          p_CPData->ResetErrors();
          _event<bool> e( "IO_Task", CEventNames::compressor_status, true );
          EventManager.RaiseEvent(e);
        }
      break;

      case INIT:
        if( p_CSetup->getExtChiller()){  
            if( p_ChillerCom->getTemp() < -40.0 ){
                p_ChillerCom->setInit( false );
                mode = AUTO;
            }
        }
        else if( p_CSetup->getIntChiller()){
            if( p_CPData->getTemp5() < -40.0 ){
                mode = AUTO;
            }
        }
        else{
            mode = AUTO;
        }
      break;

      default:

      break;
    }

    //Chiller On / Off Control
    if( mode == INIT || mode == AUTO || mode == EXTEST ){
      p_CPData->setOnMains(2);  //switch on compressor;
    }
    else{
      p_CPData->setOffMains(2); //switch off compressor;
    }

    //Main Power Relais logic
    if( mode != BOOT &&  p_CPData->getTemp3(iOffsettTable) > 310.0 ){
      if( iSErrorCnt > 0 ){
        iSErrorCnt --;
      }
      else{
        mode = SERROR;
      }
    }
    else{
      iSErrorCnt = 1000;
    }

    //Check Chiller
    if( mode != BOOT && mode != SERROR && p_CSetup->bIsValid() && p_CSetup->getExtChiller() ){
        if( p_ChillerCom->getError() )
        {
            p_ChillerCom->setInit( true );
            mode = INIT;
        }
    }

    //Check Chuck Temperature for Error
    if( p_CPData->getTErrorStatus(3).cFlags != 0 && mode != BOOT ){
        mode = SERROR;
    }
    
    //Lamda ein aus
    if( mode == AUTO || mode == GOSTANDBY || mode == EXTEST || mode == PURGE || mode == MDEFROST )
    {
      p_CPData->setOnMains(1); 
    }
    else
    {
      p_CPData->setOffMains(1);
    }


    //Lambda on conditions
    if( mode != INIT  
       && mode != BOOT 
       && mode != STANDBY 
       && mode != SERROR 
    ){
      if( p_CPData->getTErrorStatus(3).cFlags == 0 &&
          p_Lambdas[4]->getError().b.oCurr == 0 &&
          p_Lambdas[5]->getError().b.oCurr == 0 )          
      {
        p_Lambdas[4]->SetOn();
        p_Lambdas[5]->SetOn();
      }
      else{
        p_Lambdas[4]->SetOff();
        p_Lambdas[5]->SetOff();
      }
    }
    else
    {
        for( int i = 0; i < 6; i++ )
        {
            p_Lambdas[i]->SetOff();
        }
    }
    
    
    //Bypass Valve Logic
    //Defined 12.04.2011 KR Reitinger,
    //Implemented by Michael Brunner
    if( mode == AUTO && p_con1->getMode() != 2  ){
        if( p_CPData->getTemp3(iOffsettTable) > 14.5 ){
              p_CPData->setOnMains(3);
        }
        else if( p_CPData->getTemp3(iOffsettTable) < 13.5 ){
              p_CPData->setOffMains(3);
        }
    }
    else{
        p_CPData->setOffMains(3);
    }

    //Relais 4, in Controller Mode Chiller is connected to this port
    if( p_CSetup->getExtChiller()){
        if( mode != SERROR || true ){
            p_CPData->setOnMains(4);
        }
        else{
            p_CPData->setOffMains(4);
        }
    }
    //In any other mode Bypass Valve my be connected to this port
    else{                
        //Chuck Bypass Logic
        if( p_CPData->getTemp3(iOffsettTable) > 200.0 ){
            p_CPData->setOffMains(4);
        }
        else if( p_CPData->getTemp3(iOffsettTable) < 190.0){
            p_CPData->setOnMains(4);
        }
    }

    //Set Chiller Mode
    if( pDewPointSensor->getDP1Error() )
    {
        _event<char> e( "aggregate", CEventNames::new_chiller_mode, '6' );
        EventManager.RaiseEvent(e);
    }
    else if( pDewPointSensor->getDP2Error() )
    {
        _event<char> e( "aggregate", CEventNames::new_chiller_mode, '7' );
        EventManager.RaiseEvent(e);
    }
    else if( bDewPointWarning )
    {
        _event<char> e( "aggregate", CEventNames::new_chiller_mode, '5' );
        EventManager.RaiseEvent(e);
    }
    else
    {
        switch( mode ){
            
            case BOOT:
            case INIT:
              {
                _event<char> e( "aggregate", CEventNames::new_chiller_mode, 'R' );
                EventManager.RaiseEvent(e);
              }
            break;
            
            case AUTO:
                switch( p_con1->getMode()){
                    //Heating
                    case 1:
                      {
                        _event<char> e( "aggregate", CEventNames::new_chiller_mode, '1' );
                        EventManager.RaiseEvent(e);
                      }
                    break;
                    //colling:
                    case 2:
                      {
                        _event<char> e( "aggregate", CEventNames::new_chiller_mode, '2' );
                        EventManager.RaiseEvent(e);
                      }
                    break;
                    //controlling
                    case 3:
                      {
                        _event<char> e( "aggregate", CEventNames::new_chiller_mode, '0' );
                        EventManager.RaiseEvent(e);
                      }
                    break;
                }                
            break;
            
            case PURGE:
              {
                _event<char> e( "aggregate", CEventNames::new_chiller_mode, '4' );
                EventManager.RaiseEvent(e);
              }
            break;
            
            case MDEFROST:
              {
                _event<char> e( "aggregate", CEventNames::new_chiller_mode, 'D' );
                EventManager.RaiseEvent(e);
              }
            break;
            
        }
    }
    p_ChillerCom->cycExec( 10 );

    //Heart Beat signal zum FPGA, noch nicht sauber aber funktioniert
    unsigned char *pHBeat = (unsigned char*)0x34000084;
    if( *pHBeat != 0 ){
      *pHBeat = 0;
    }
                
    vTaskDelay (10);
  }
}

/**
Callbackfunktion to handle Chiller Interface Events
*/
bool ptNotifyChillerEvent( CChillerCom::ifc_event e, void * pParam ){
  MODE mNew;
  char cTemp;
  signed char *sTemp;
  int iChuckCount;
  int iChuckEnable;
  switch( e ){

    case CChillerCom::NEW_MODE:
      mNew = *((MODE*)pParam);
      switch( mNew ){
        case AUTO:        //on case auto go to INIT first
          p_CPData->ResetErrors();
          //resetErrors();
          mode = INIT;
          return true;

        case GOSTANDBY:
        case MDEFROST:
        case PURGE:
        case STOP:
          mode = mNew;
          return true;

        default:
          return false;
      }

    case CChillerCom::NEW_DPOINT:
        fDewPointOffset = *((float*)pParam);
        return true;
    
  default:
      return false;
  }
}

/**
Diagnose kommunication task
*/
void SetTemp1ChangedEventDiagTask( float f ){
    p_CSetup->getTempParamSet(1)->setSetTemp(f); //aktuelle Temperatur, 'double' wird erwartet
}
void DiagTask(void *pvParameters){
    char c;
    int iBlockCnt = 100;
    bool bIPDiag = false;
    bool bComDiag = false;
    EventManager.AddEventHandler( CEventNames::set_temp1_changed, SetTemp1ChangedEventDiagTask );
    while( 1 ){
        EventManager.HandlePID();
        int iMsgSize = 0;
        if( !bComDiag && uxQueueMessagesWaiting( xHDiagRxChars ) >= 1 ){
            while( xQueueReceive( xHDiagRxChars, &cTemp[iMsgSize++], 0) == pdTRUE );
            short iLen = p_CDiagCom->processPacket( &cTemp[2], &cTemp[2], cTemp[1]) + 2;
            portENTER_CRITICAL();
            c = (char)(iLen>>8);
            xQueueSend( xHDiagTxChars, &c, 0 );
            c = (char)(iLen&0xFF);
            xQueueSend( xHDiagTxChars, &c, 0 );
            for( int i = 0; i < iLen; i++ ){
                xQueueSend( xHDiagTxChars, &cTemp[i], 0 );
            }
            portEXIT_CRITICAL();
            iBlockCnt = 1000;
            bIPDiag = true;
        }
        else if( bSaveSetup ){
            p_CSetup->writeSetup();
            p_CSetup->writeConfig();
            p_CSetup->writePIDSet(0);
            bSaveSetup = false;
        }
        else if( !bIPDiag ){
            if( p_CDiagCom->processPacket() )
            {
                iBlockCnt = 1000;
                bComDiag = true;
            }
        }
        
        if( iBlockCnt < 1 ){
            bIPDiag = false;
            bComDiag = false;
        }
        else{
            iBlockCnt--;
        }
        
        vTaskDelay(5);
    }
}

/*********************************************************************
*
* FSTask Handles all file system functionality
*/
void FSTask(void *pvParameters){
  char cBuf[40];
  char cAFile[20] = {0};
  bAirTableSave = false;
  p_CFiles->logEvent( CFiles::event_startup, 1, 0 );
  loadSetup();
  switch( p_CSetup->getAirTable() )
  {
      case CSetup::_s_config::E_AIR_300:
        strcpy( cAFile, "a300.air" );
        break;
      case CSetup::_s_config::E_AIR_200:
        strcpy( cAFile, "a200.air" );
        break;
      case CSetup::_s_config::E_AIR_150:
        strcpy( cAFile, "a150.air" );
        break;
  }
  if( strlen(cAFile) > 0 )
  {
    p_AirTable->loadAirTable( cAFile );
    bAirTableLoaded = true;
  }
      
  if( (p_CSetup->getConConfig() >= CSetup::_s_config::E_PROP_VALVE_HWS_300 &&
      p_CSetup->getConConfig() <= CSetup::_s_config::E_CHILLER_MST_SWS_D600) ||
      p_CSetup->getConConfig() == CSetup::_s_config::E_AUTO_CON
     )
  {
    _event<bool> e( "FileTask", CEventNames::set_power_supply_5_active, true );
    EventManager.RaiseEvent(e);
  }
  if( p_CSetup->getConConfig() == CSetup::_s_config::E_PROP_VALVE_HWS_D300 ||
      p_CSetup->getConConfig() == CSetup::_s_config::E_PROP_VALVE_SWS_D600 ||
      p_CSetup->getConConfig() == CSetup::_s_config::E_CONTOLLER_HWS_D300 ||
      p_CSetup->getConConfig() == CSetup::_s_config::E_CONTOLLER_SWS_D600 ||
      p_CSetup->getConConfig() == CSetup::_s_config::E_CHILLER_MST_SWS_D600 
     )
  {
    _event<bool> e( "FileTask", CEventNames::set_power_supply_6_active, true );
    EventManager.RaiseEvent(e);
  }
  while(1){
    //Neue Lufttabllenwerte speichern
    if( bAirTableSave )
    {
        p_AirTable->saveAirTable( cAFile );
        bAirTableSave = false;      
    }
   //Write Data Logger File
  if( mode == AUTO ){
      /* Datenlogger vorerst nicht aktiv
    for( int i = 1; i <= 2; i++ ){
      if( p_CPData->getLErrorStatus(i).cFlags != 0 ){
        //p_CFiles->saveLoggerFile( 16, &cLogger );
       }
     }
      */
   }
   
  
   if(  p_CPData->hasNewError( 1, 1, 0) ){
      p_CFiles->logEvent( CFiles::event_errorch, 1, 0 );
    }
    if(  p_CPData->hasNewError( 2, 2, 0) ){
      p_CFiles->logEvent( CFiles::event_errorch, 2, 0 );
    }
    if(  p_CPData->hasNewError( 3, 3, 0) ){
      p_CFiles->logEvent( CFiles::event_errorch, 3, 0 );
    }
    if(  p_CPData->hasNewError( 4, 4, 0) ){
      p_CFiles->logEvent( CFiles::event_errorch, 4, 0 );
    }
    if(  p_CPData->hasNewError( 5, 0, 0) ){
      p_CFiles->logEvent( CFiles::event_errorch, 5, 0 );
    }
     
  if( p_CFiles->isLoSizeEx()){
      p_CFiles->bakLogFile(cBuf);
    }
    vTaskDelay(5);
  }
}

void loadSetup()
{
  p_CSetup->readOffsetTable();  //Achtung offsettabelle zuerst laden
  p_CSetup->readSetup();
  p_CSetup->readConfig();
  p_CSetup->readPIDSet(0);      //PID Parameter auch zuerst
}

/**
  PID is executing the real time calculations required for PID and FIR Filters
  of the Temperature sensors
*/
void set_hold_modeEvent( bool b )
{
    bHoldEnable = b; //Der User moechte den Hold-Mode aktivieren    
}

void PID_Task(void *pvParameters ) {
  while( !bAirTableLoaded ){
    vTaskDelay(10);
  }
  p_CSetup->getTempParamSet(1)->setSetTemp(25.0);
  p_con1 = new PIDController( p_CSetup->getPIDSetup(1), true );
  p_con2 = new PIDController( p_CSetup->getPIDSetup(2), false );
  p_con3 = new PIDController( p_CSetup->getPIDSetup(3), false );
  p_con4 = new PIDController( p_CSetup->getPIDSetup(4), false );
  p_con5 = new PIDController( p_CSetup->getPIDSetup(5), false );
  p_con6 = new PIDController( p_CSetup->getPIDSetup(6), false );
  
  static long lCycleTime, lOSOldTime;
  sAirValue sAirSetup;
  float fMax = c_AirTable.getAirValue(-100.0).fFlow;
  float fSetTemp = 0.0;
  float fHoldIIR = 0.0;
  float fTrackIIR = 0.0;
  float fKTYIIR = 0.0;
  const float fCurrent = 15.0;      //Percentual minimal current for PRESSURE CONTROOL
  int iPIDTimer = 0;
  int iAirRecalcTimer = 600000; //Save Air Table ervery 60 Minutes
  int iAirSaveTimer = 3600000;
  bool bACTableModified = false;
  const int iTout = 2400000; //Timout 20 minutes
  bAllowStandard = true;
  bAllowLowNoise = true;
  int iDelayAirControllTimer;
  if(p_CSetup->getConConfig() >= CSetup::_s_config::E_PROP_VALVE_HWS_300 &&
      p_CSetup->getConConfig() <= CSetup::_s_config::E_PROP_VALVE_SWS_D600 
     )
  {
    EventManager.AddEventHandler( CEventNames::VALVE_1_SET, m_lany1.ValvePValueEventWrapper, &m_lany1);
    EventManager.AddEventHandler( CEventNames::VALVE_1_ADC2, m_lany1.ValveADCInEventWrapper, &m_lany1);
    EventManager.AddEventHandler( CEventNames::VALVE_1_ADC1, m_lany1.ValveADCOutEventWrapper, &m_lany1);
  }
  else
  {
    EventManager.AddEventHandler( CEventNames::VALVE_1_SET,  CJoucomaticValve::ValvePValueEventWrapper, &m_jouco1);
    EventManager.AddEventHandler( CEventNames::VALVE_1_ADC2, CJoucomaticValve::ValveADCInEventWrapper,  &m_jouco1);
    EventManager.AddEventHandler( CEventNames::VALVE_1_ADC1, CJoucomaticValve::ValveADCOutEventWrapper, &m_jouco1);
    EventManager.AddEventHandler( CEventNames::VALVE_2_SET,  CJoucomaticValve::ValvePValueEventWrapper, &m_jouco2);
    EventManager.AddEventHandler( CEventNames::VALVE_2_ADC2, CJoucomaticValve::ValveADCInEventWrapper,  &m_jouco2);
    EventManager.AddEventHandler( CEventNames::VALVE_2_ADC1, CJoucomaticValve::ValveADCOutEventWrapper, &m_jouco2);
  }
  _event<float> * p_event_cold = new _event<float>( "AIRCON COLD", CEventNames::VALVE_1_SET, 0.0);
  _event<float> * p_event_hot = new _event<float>("AIRCON HOT", CEventNames::VALVE_2_SET, 0.0);
  _event<float> * p_event_setv5 = new _event<float>( "aggregate", CEventNames::set_power_suppply_5_set_voltage, 0.0);
  _event<float> * p_event_setv6 = new _event<float>( "aggregate", CEventNames::set_power_suppply_6_set_voltage, 0.0);
 
  
  while (1) {
    EventManager.HandlePID();
    p_CPData->cycCalc( 10 );
    //write data to dynamic logger
    //p_CLogger->addLogg( p_CPData->getHC1Curr(), p_CPData->getHC2Curr(), p_CPData->getHC3Curr(), p_CPData->getHC4Curr());
    lCycleTime = xTaskGetTickCount()-lOSOldTime;
    lOSOldTime = xTaskGetTickCount();

    if( p_CPData->getTErrorStatus(6).cFlags != 0 )
    {
        mode = SERROR;
    }
    
    float fIPoint = 100.0;
    
    switch( mode ){
      case BOOT:
        p_event_cold->modifyParameter(0.0);
        p_event_hot->modifyParameter(0.0);
        EventManager.RaiseEvent(p_event_cold);                  
        EventManager.RaiseEvent(p_event_hot);                  
      break;


      case INIT:
        p_event_setv5->modifyParameter(0.0);
        EventManager.RaiseEvent(p_event_setv5);
        p_event_setv6->modifyParameter(0.0);
        EventManager.RaiseEvent(p_event_setv6);              

        p_con5->bSetIVal(sAirSetup.fAirTemp);
        p_event_cold->modifyParameter(80.0);
        p_event_hot->modifyParameter(0.0);
        EventManager.RaiseEvent(p_event_cold);                  
        EventManager.RaiseEvent(p_event_hot);                  
      break;

      default:
        sAirSetup = p_AirTable->getAirValue(p_CSetup->getTempParamSet(1)->getSetTemp());
        //Setpoint related to dewpoint
        fSetTemp = p_CSetup->getTempParamSet(1)->getSetTemp();
        if( !pDewPointSensor->getDPError() && fSetTemp < pDewPointSensor->getDewPoint() && !bCtrlFine){
          if((pDewPointSensor->getDewPoint() + fDewPointOffset) > p_CPData->getTemp3(iOffsettTable) && !bCtrlFine){
            bDewPointWarning = true;
            fSetTemp = pDewPointSensor->getDewPoint() + fDewPointOffset;
          }
          else{
            bDewPointWarning = false;
          }
        }
        else{
          bDewPointWarning = false;
        }
        
        if( pDewPointSensor->getDP1Error() )
        {
          fSetTemp = 18.5;
        }
        
        if( pDewPointSensor->getDP2Error() )
        {
          fSetTemp = 50.5;
        }

        //Call to controller algorithms
        p_con1->cycCalc( fSetTemp,p_CPData->getTemp3(iOffsettTable), lCycleTime );  //Temperature 1
        p_con2->cycCalc( fSetTemp,p_CPData->getTemp3(iOffsettTable), lCycleTime );  //Temperature 1
        p_con3->cycCalc( fSetTemp,p_CPData->getTemp3(iOffsettTable), lCycleTime );  //Temperature 1
        if(p_con1->getMode() == 3 && !bDewPointWarning ){
            //First step vor fine contorlling
            if( abs(fSetTemp-p_CPData->getTemp3(iOffsettTable)) < 0.25 && bAllowStandard){               
                if( iConTimer > 0 ){
                    iConTimer -= lCycleTime;
                    p_con2->bSetIVal( p_con1->getY() );
                }
                else{
                    bCtrlFine = true;
                    p_con1->bSetIVal( p_con2->getY() );
                }   
            }
            else{
                iConTimer = 60000;  //milseconds to wait until switch to fine controlling
                bCtrlFine = false;
                bHoldMode = false;
            }
            //Second step for fine controlling
            if( (abs(fSetTemp-p_CPData->getTemp3(iOffsettTable)) < 0.10) && bCtrlFine && bAllowLowNoise){               
                if( iConTimer2 > 0 ){
                    iConTimer2 -= lCycleTime;
                    p_con3->bSetIVal( p_con2->getY() );
                    iConTimer3 = 120000;
                }
                else{
                    bCtrlVeryFine = true;
                    p_con2->bSetIVal( /*p_con3->getY()*/ fTrackIIR );
                    if( bHoldEnable )
                    {
                      if( iConTimer3 > 0 ){
                        iConTimer3 -= lCycleTime;
                        bHoldMode = false;
                      }
                      else
                      {                      
                        bHoldMode = true;
                      }
                    }
                }   
            }
            else{
                iConTimer2 = 60000;  //milseconds to wait until switch to fine controlling
                if( !bHoldMode )
                {
                  bCtrlVeryFine = false;
                }
            }
        }
        else        //Wenn nicht im Regeln dann auch Feinregeln deaktivieren
        {
            bCtrlFine = false;
            bCtrlVeryFine = false;
        }
        
        if( bHoldMode )
        {   
          if( !isnormal(fHoldIIR) ){
            fHoldIIR = 0.0;
          }
          fHoldIIR = fHoldIIR * 0.9999 + p_con3->getY() * 0.0001;
          p_event_setv5->modifyParameter(fHoldIIR);
          EventManager.RaiseEvent(p_event_setv5);
          p_event_setv6->modifyParameter(fHoldIIR);
          EventManager.RaiseEvent(p_event_setv6);              

          fIPoint = fHoldIIR;
        }
        else if( bCtrlFine && !bCtrlVeryFine ){
            p_event_setv5->modifyParameter(p_con2->getY());
            EventManager.RaiseEvent(p_event_setv5);
            p_event_setv6->modifyParameter(p_con2->getY());
            EventManager.RaiseEvent(p_event_setv6);              
            fIPoint = p_con2->getY();
            fTrackIIR = p_con2->getY();
            _event<bool> e("aggregate", CEventNames::controller_stable, true );
            EventManager.RaiseEvent(e);
        }
        else if( bCtrlFine && bCtrlVeryFine ){
            if( !isnormal(fTrackIIR))
            {
              fTrackIIR = 0.0;
            }
            fTrackIIR = fTrackIIR * 0.998 + p_con3->getY() * 0.002;
 
            p_event_setv5->modifyParameter(fTrackIIR);
            EventManager.RaiseEvent(p_event_setv5);
            p_event_setv6->modifyParameter(fTrackIIR);
            EventManager.RaiseEvent(p_event_setv6);              
            fIPoint = fTrackIIR;
            fHoldIIR = fTrackIIR;
        }            
        else{
            p_event_setv5->modifyParameter(p_con1->getY());
            EventManager.RaiseEvent(p_event_setv5);
            p_event_setv6->modifyParameter(p_con1->getY());
            EventManager.RaiseEvent(p_event_setv6);              
            fIPoint = p_con1->getY();
            _event<bool> e("aggregate", CEventNames::controller_stable, false );
            EventManager.RaiseEvent(e);
        }
        p_ChillerCom->setI( fIPoint * 6 / 100.0 );

 
        //Time Monitoring
        if( p_con1->getMode() != 3 ){
          if( iPIDTimer > iTout ){
            bTOutError = true;
          }
          else{            
            iPIDTimer += lCycleTime;
          }
        }
        else{
          iPIDTimer = 0;
          bTOutError = false;
        }
       
			 // Nur Ger�te mit internem Chiller
       if( p_CSetup->getIntChiller() ){
            //Regler im Aufheizmodus
            if( p_con1->getMode() == 1 ){
              //beim Heizen unter 15�C mit voller Warmluft heizen
              if( p_CPData->getTemp3(iOffsettTable) < 15.0  ){            
                _event<float> e_cold("AIRCON HOT", CEventNames::VALVE_2_SET, fMax);
                EventManager.RaiseEvent(e_cold);                  
              }
              else{
                _event<float> e_hot("AIRCON HOT", CEventNames::VALVE_2_SET, 0.0);
                EventManager.RaiseEvent(e_hot);                  
              }
              _event<float> e_hot("AIRCON COLD", CEventNames::VALVE_1_SET, 0.0);
              EventManager.RaiseEvent(e_hot);                  
                iDelayAirControllTimer = 120000;
            }
            //Regler im K�hl- Modus, Volle Kaltluft
            else if( p_con1->getMode() == 2 ){
                _event<float> e_cold("AIRCON COLD", CEventNames::VALVE_1_SET, fMax );
                EventManager.RaiseEvent(e_cold);                  
                _event<float> e_hot("AIRCON HOT", CEventNames::VALVE_2_SET, 0.0);
                EventManager.RaiseEvent(e_hot);
                iDelayAirControllTimer = 240000;
            }
            //Chucktemperatur im Reglefenster
            else{
              //Zusatzluft beim K�hlen von hochen Temperaturen, reiner P- Anteil bezogen auf die Grundplattentemperatur
              float fAirValue = sAirSetup.fFlow;
              if((p_CSetup->getTempParamSet(1)->getSetTemp() + 10) < p_CPData->getTemp7() ){
                  float delta = p_CPData->getTemp7() - (p_CSetup->getTempParamSet(1)->getSetTemp() + 10);
                  if( delta > 20 ){
                      fAirValue += fMax;
                      fKTYIIR = 20.0;
                  }
                  else{
                      fKTYIIR = fKTYIIR * 0.99 + delta * 0.01;
                      fAirValue += (fMax/20.0) * fKTYIIR;
                  }
                  if(fAirValue > fMax ){
                      fAirValue = fMax;
                  }
              }
              else{
                  fKTYIIR = 0.0;
              }
              //Air flow controller
              //Mehr Lufttemperatur als Sollwert macht keine Sinn
              p_CSetup->getPIDSetup(5)->max = p_CSetup->getTempParamSet(1)->getSetTemp();
              if( iDelayAirControllTimer > 0 )
              {
                //Luftwert erst mal halten bis sich die Regelug ein bische
                //stabilisiert hat
                p_con5->bSetIVal(sAirSetup.fAirTemp);
                iDelayAirControllTimer -= lCycleTime;
                //Timer f�r die neuebrechnung der Lufttemperatur vorsichtshalber initalisieren
                iAirRecalcTimer = 600000;
                iAirSaveTimer = 3600000;
              }
              else
              {
                //Dynamische ermittleung der Startlufttemperatur
                if( iAirRecalcTimer > 0 )
                {
                  iAirRecalcTimer-= lCycleTime;
                }
                else
                {
                  //alle 10 Minuten einen neuen Wert berechnen
                  bACTableModified = p_AirTable->recalcTemp( p_CSetup->getTempParamSet(1)->getSetTemp(), p_CPData->getTemp5() );
                  iAirRecalcTimer = 600000;
                }
                if( iAirSaveTimer > 0 )
                {
                  iAirSaveTimer -= lCycleTime;
                }                   
                else
                {
                  bAirTableSave = bACTableModified;
                  bACTableModified = false;
                  iAirSaveTimer = 3600000;
                }
              }
              //Vorregler um ermitteln der ben�tigen Chillertemperatur
              p_con5->cycCalc( fIPoint, fCurrent, lCycleTime );                   
              p_CSetup->getPIDSetup(6)->max = fAirValue;                          //Bei Chillerlufregler gesamtmenge begrenzen auf Tabllenluftmenge
              p_con6->cycCalc( p_con5->getY(), p_CPData->getTemp5(), lCycleTime); //Regler f�r Chillertemperatur
              //Luftregelung nur bei Fluss �ber 80 liter m�glich wegen Problem mit joucomatic 
              if( sAirSetup.fFlow > 80.0 )
              {
                  //Reglerwerte auf Ausgang schreiben
                  float fFlowCold = fAirValue - p_con6->getY();
                  float fFlowHot  = p_con6->getY();
                  _event<float> e_cold("AIRCON COLD", CEventNames::VALVE_1_SET, fFlowCold);
                  EventManager.RaiseEvent(e_cold);                  
                  _event<float> e_hot("AIRCON HOT", CEventNames::VALVE_2_SET, fFlowHot);
                  EventManager.RaiseEvent(e_hot);                  
              }
              else
              {
                  //Ansonsten Werte aus Tabelle einstellen
                  float fFlowCold = fAirValue * sAirSetup.fCold / 100.0;
                  float fFlowHot  = fAirValue * (1 - sAirSetup.fCold / 100.0);
                  _event<float> e_cold("AIRCON COLD", CEventNames::VALVE_1_SET, fFlowCold);
                  EventManager.RaiseEvent(e_cold);                  
                  _event<float> e_hot("AIRCON HOT", CEventNames::VALVE_2_SET, fFlowHot);
                  EventManager.RaiseEvent(e_hot);                                                     
              }
            }
        }
        //Regelunf f�r reine Druckreglung (Druckproportionalventil
        else if( p_CSetup->getGetPressDev() ){    //Lany control
            p_con4->cycCalc( fCurrent, fIPoint, lCycleTime );
            if( p_con1->getMode() == 1 )
            {
                _event<float> e("AIRCON HEAT", CEventNames::VALVE_1_SET, 0.0);
                if( p_CSetup->getTempParamSet(1)->getSetTemp() < 15.0 )
                {
                    e.modifyParameter( 10.0 );
                }
                EventManager.RaiseEvent(e);                  
            }
            else if( p_con1->getMode() == 2 ){
                _event<float> e("AIRCON HEAT", CEventNames::VALVE_1_SET, 100.0);
                EventManager.RaiseEvent(e);                  
            }
            else{
                float f = p_con4->getY();
                if( p_CSetup->getTempParamSet(1)->getSetTemp() < 15.0 && f < 10.0 )
                { 
                    f = 10.0;
                }
                _event<float> e("AIRCON HEAT", CEventNames::VALVE_1_SET, f);
                EventManager.RaiseEvent(e);                  
            }
        }
        else{
            _event<float> e_hot("AIRCON HEAT", CEventNames::VALVE_1_SET, 0.0);
            EventManager.RaiseEvent(e_hot);                  
            _event<float> e_cold("AIRCON COOL", CEventNames::VALVE_2_SET, 0.0);
            EventManager.RaiseEvent(e_cold);                  
        }            
      break;

      case GOSTANDBY:
        if(p_CPData->getTemp3(iOffsettTable) > 15.0 && p_CPData->getTemp3(iOffsettTable) < 40.0){
          mode = STANDBY;
         }
        else{
          p_CSetup->getTempParamSet(1)->setSetTemp( 25.0 );
          p_con1->cycCalc( p_CSetup->getTempParamSet(1)->getSetTemp(), p_CPData->getTemp3(iOffsettTable), lCycleTime );  //Temperature 1
          p_event_setv5->modifyParameter(p_con1->getY());
          EventManager.RaiseEvent(p_event_setv5);
          p_event_setv6->modifyParameter(p_con1->getY());
          EventManager.RaiseEvent(p_event_setv6);              

          //Valve Output
          if(  p_con1->getMode() == 2 ){
            p_event_cold->modifyParameter(fMax);
          }
          else{
            p_event_cold->modifyParameter(0.0);
          }
          p_event_hot->modifyParameter(0.0);
          EventManager.RaiseEvent(p_event_cold);                  
          EventManager.RaiseEvent(p_event_hot);                  
          bInStandby = false;
        }
      break;

      case MDEFROST:
        p_CSetup->getTempParamSet(1)->setSetTemp( 60.0 );
        p_con1->cycCalc( p_CSetup->getTempParamSet(1)->getSetTemp(), p_CPData->getTemp3(iOffsettTable), lCycleTime );  //Temperature 1
        p_event_setv5->modifyParameter(p_con1->getY());
        EventManager.RaiseEvent(p_event_setv5);
        p_event_setv6->modifyParameter(p_con1->getY());
        EventManager.RaiseEvent(p_event_setv6);              
        //Valve Output
        p_event_cold->modifyParameter(fMax);
        p_event_hot->modifyParameter(0.0);
        EventManager.RaiseEvent(p_event_cold);                  
        EventManager.RaiseEvent(p_event_hot);                  
      break;

      case PURGE:
        p_CSetup->getTempParamSet(1)->setSetTemp( 25.0 );
        p_con1->cycCalc( p_CSetup->getTempParamSet(1)->getSetTemp(), p_CPData->getTemp3(iOffsettTable), lCycleTime );  //Temperature 1
        //p_CPData->SetHC5Power( p_con1->getY() );
        //p_CPData->SetHC6Power( p_con1->getY() );
        p_event_setv5->modifyParameter(p_con1->getY());
        EventManager.RaiseEvent(p_event_setv5);
        p_event_setv6->modifyParameter(p_con1->getY());
        EventManager.RaiseEvent(p_event_setv6);              
        //Valve Output
        p_event_cold->modifyParameter(fMax);
        p_event_hot->modifyParameter(0.0);
        EventManager.RaiseEvent(p_event_cold);                  
        EventManager.RaiseEvent(p_event_hot);                  
      break;

      case STANDBY:
      case STOP:
      case SERROR:
        //p_CPData->SetHC1Power( 0.0 );
        //p_CPData->SetHC2Power( 0.0 );
        //p_CPData->SetHC3Power( 0.0 );
        //p_CPData->SetHC4Power( 0.0 );
        //p_CPData->SetHC5Power( 0.0 );
        //p_CPData->SetHC6Power( 0.0 );
        //Netzteile
        p_event_setv5->modifyParameter(p_con1->getY());
        EventManager.RaiseEvent(p_event_setv5);
        p_event_setv6->modifyParameter(p_con1->getY());
        EventManager.RaiseEvent(p_event_setv6);              

        //Ventile
        p_event_cold->modifyParameter(0.0);
        p_event_hot->modifyParameter(0.0);
        EventManager.RaiseEvent(p_event_cold);                  
        EventManager.RaiseEvent(p_event_hot);                  

      break;
      
      case EXTEST:
      
      break;      

    }
    
    if(mode == AUTO )
    {
        _event<float> e("aggregate", CEventNames::new_chiller_settemp, fSetTemp );
        EventManager.RaiseEvent(e);
    }
    else
    {
        _event<float> e("aggregate", CEventNames::new_chiller_settemp, p_CSetup->getTempParamSet(1)->getSetTemp() );
        EventManager.RaiseEvent(e);
    }
    
    //raise cyclic events
    _event<int> e0("aggregate", CEventNames::new_chiller_ctrl, p_con1->getMode());
    EventManager.RaiseEvent(e0);
    _event<float> e1("aggregate", CEventNames::temp_1, p_CPData->getTemp3());
    EventManager.RaiseEvent(e1);
    _event<float> e2("aggregate", CEventNames::temp_2, p_CPData->getTemp5());    //Chiller Temp
    EventManager.RaiseEvent(e2); 
    _event<float> e3("aggregate", CEventNames::temp_3, p_CPData->getTemp7());    //KTY or any other
    EventManager.RaiseEvent(e3);
    _event<float> e4("aggregate", CEventNames::temp_4, p_CPData->getTemp6());    //Inside Temp
    EventManager.RaiseEvent(e4);
            

    vTaskDelay (66);
  }
}


/********************************************************************/
/* ++++++++++++++++++ Start ++++++++++++++++++++++++++++++++++++++++*/
void new_chiller_statusEvent( _string s )
{
    if(s == "Purge")
    {
        if( mode == PURGE ){
            p_ChillerCom->setInit(true);
            mode = INIT;
            _event<_string> e( "aggregat", CEventNames::chiller_status, "INIT" );
            EventManager.RaiseEvent(e);
        }
        else{
            mode = PURGE;
            _event<_string> e( "aggregat", CEventNames::chiller_status, "Purge" );
            EventManager.RaiseEvent(e);
        }
    }
    else if( s == "Defrost")
    {
        if( mode == MDEFROST ){
            p_ChillerCom->setInit(true);
            mode = INIT;
            _event<_string> e( "aggregat", CEventNames::chiller_status, "INIT" );
            EventManager.RaiseEvent(e);
        }
        else{
            mode = MDEFROST;
            _event<_string> e( "aggregat", CEventNames::chiller_status, "Defrost" );
            EventManager.RaiseEvent(e);
        }
            
        _event<int> e1("aggregate", CEventNames::DEFROST_CHANGED, MDEFROST ? 1 : 0);
        EventManager.RaiseEvent(e1);
    }
}

void sendOffsetTable( int iNum, void* p )
{
    _o_tab tab;
    float *p_table[2];
    p_table[0] = p;
    p_table[1] = ((float*)p)+20;
    for( int i = 0; i < 20; i++ ){
      tab.temp[i] = p_table[0][i];
      tab.offsett[i] = p_table[1][i];
    }
    p_CSetup->setOffsetTable( iNum, tab );
    p_CSetup->writeOffsetTable();  
}

void sendTable1Event( void* p )
{
    sendOffsetTable( 1, p ); 
}
void sendTable2Event( void* p )
{
    sendOffsetTable( 2, p ); 
}
void sendTable3Event( void* p )
{
    sendOffsetTable( 3, p ); 
}

void getAllOffsettTables( bool b )
{
    _event<void*> e1( "aggregat", CEventNames::receive_table1, p_CSetup->getOffsetTable(1) );
    _event<void*> e2( "aggregat", CEventNames::receive_table2, p_CSetup->getOffsetTable(2) );
    _event<void*> e3( "aggregat", CEventNames::receive_table3, p_CSetup->getOffsetTable(3) );
    EventManager.RaiseEvent(e1);
    EventManager.RaiseEvent(e2);
    EventManager.RaiseEvent(e3);    
}

void set_active_comp_tableEvent( int i )
{
    iOffsettTable = i; //0=keine aktiv, 1,2,3= jeweilige Tabelle aktiv
}

void enterDiagEvent( bool b )
{
    
}

void leftDiagEvent( bool b )
{
    if( mode == EXTEST ){
        mode = INIT;
    }    
}

void enterPower1Event( int i )
{
    mode = EXTEST;
    _event<float> e( "Aggregate", CEventNames::set_power_suppply_5_set_voltage, (float)i );
    EventManager.RaiseEvent(e);
}

void enterPower2Event( int i )
{
    mode = EXTEST;
    _event<float> e( "Aggregate", CEventNames::set_power_suppply_6_set_voltage, (float)i );
    EventManager.RaiseEvent(e);
}

void set_standby_modeEvent( bool b )
{
    if (b)
    {
      mode = GOSTANDBY;//Der User moechte den Standby-Mode aktivieren
    }
    else
    {
      mode = INIT;//Der User moechte den Standby-Mode deaktivieren
    }
}

void set_con_mode_standardEvent( bool b )
{
    bAllowStandard = true;
    bAllowLowNoise = false;
}

void set_con_mode_progressiveEvent( bool b )
{
    bAllowStandard = false;
    bAllowLowNoise = false;    
}

void set_con_mode_lnoiseEvent(bool b)
{
    bAllowStandard = true;
    bAllowLowNoise = true;  
}

void DSPLTask(void *pvParameters)
{
    static int iTimer = 0;

    //Vorzunehmende Initialisierungen:
    pDevicemanager = &device_manager;
    pDisplaymanager = &displaymanager;

    pDisplaymanager->Init();
    pDevicemanager->Init("device_manager");
    
    pDewPointSensor->Init();
    
    CErrorMessages * pErrorMsgs = new CErrorMessages( &EventManager );  //Fehlermeldungsobjekt anlegen
    pErrorMsgs->Init();                                                 //Objekt Intialisieren
    
    EventManager.AddEventHandler( CEventNames::new_chiller_status, new_chiller_statusEvent );
    EventManager.AddEventHandler( CEventNames::get_all_comp_tables, getAllOffsettTables);
    EventManager.AddEventHandler( CEventNames::send_table1, sendTable1Event );
    EventManager.AddEventHandler( CEventNames::send_table2, sendTable2Event );
    EventManager.AddEventHandler( CEventNames::send_table3, sendTable3Event );
    EventManager.AddEventHandler( CEventNames::set_active_comp_table, set_active_comp_tableEvent ); 
    EventManager.AddEventHandler( CEventNames::user_entered_diag, enterDiagEvent );
    EventManager.AddEventHandler( CEventNames::user_left_diag, leftDiagEvent );
    EventManager.AddEventHandler( CEventNames::hit_power_suppply_1_set_voltage, enterPower1Event );
    EventManager.AddEventHandler( CEventNames::hit_power_suppply_2_set_voltage, enterPower2Event ); 
    EventManager.AddEventHandler( CEventNames::set_standby_mode, set_standby_modeEvent ); 
    EventManager.AddEventHandler( CEventNames::set_con_mode_standard, set_con_mode_standardEvent ); 
    EventManager.AddEventHandler( CEventNames::set_con_mode_progressive, set_con_mode_progressiveEvent ); 
    EventManager.AddEventHandler( CEventNames::set_con_mode_lnoise, set_con_mode_lnoiseEvent );
    
    
    
    while(1)
    {
        EventManager.HandlePID();
        pDevicemanager->cycCalc();
        pDisplaymanager->cycCalc();     //Display Manager �ffters aufrufen
        pDewPointSensor->cycCalc();
        pErrorMsgs->cycCalc();
        
        if( p_CSetup->bIsValid() ){
            if( iTimer > 30 ){
                iTimer = 10;
            }
            else if( iTimer == 0 ){
                _set_limits_EventArgument a;
                a.limitMax = p_CSetup->getTempParamSet(1)->getMaxLimit();
                a.limitMin = p_CSetup->getTempParamSet(1)->getMinLimit();
                _event<_set_limits_EventArgument > e( "aggregate", CEventNames::set_limits_1, a );
                EventManager.RaiseEvent(e);
            }
            else if( iTimer == 2 ){
                 _set_limits_EventArgument a;
                a.limitMax = 100;
                a.limitMin = 0;
                _event<_set_limits_EventArgument > e( "aggregate", CEventNames::set_power_supply_1_voltage_limits, a );
                EventManager.RaiseEvent(e);
                _event<_set_limits_EventArgument > e1( "aggregate", CEventNames::set_power_supply_2_voltage_limits, a );
                EventManager.RaiseEvent(e1);

            }
            else if( iTimer == 3 ){
                //==============================================================================
                // Die Versionsnummer usw. auf dem Hauptmenue setzen (Darstellung erfolgt dann automatisch):
                //(Sollte noch keine Version gesendet sein befindet sich an der betreffenden Stelle nichts)
                _event<_string> e( "aggregat", CEventNames::set_version_info, _string(REV));
                EventManager.RaiseEvent( e );
								// Ausgabe der IP-Adresse
								extern int ipAddr[4];
								char ipstr[20];
								sprintf(ipstr,"IP=%03d.%03d.%03d.%03d",ipAddr[0], ipAddr[1], ipAddr[2], ipAddr[3]);
                _event<_string> e4( "aggregat", CEventNames::set_ip_info, _string(ipstr));
                EventManager.RaiseEvent( e4 );								
                //Temperaturkompensation
                _event<void*> e1( "aggregat", CEventNames::receive_table1, p_CSetup->getOffsetTable(1) );
                _event<void*> e2( "aggregat", CEventNames::receive_table2, p_CSetup->getOffsetTable(2) );
                _event<void*> e3( "aggregat", CEventNames::receive_table3, p_CSetup->getOffsetTable(3) );
                EventManager.RaiseEvent(e1);
                EventManager.RaiseEvent(e2);
                EventManager.RaiseEvent(e3);
            }
            else if( iTimer == 5 ){
                _event<bool> b("aggregat", CEventNames::set_con_mode_lnoise, true );
                EventManager.RaiseEvent(b);
                //Anpassung des User-Config-Menues durch Ein- und Ausblenden von Menuebuttons:
                _two_params<int, int> p;
                p.p1 = 0;
                p.p2 = p_CSetup->getScreenStatus( CSetup::_s_config::_s_screens::HS );
                _event< _two_params<int,int> > e( "aggregat", CEventNames::config_window_activation, p );
                EventManager.RaiseEvent(e);             
            }
            else if( iTimer == 6 ){
              _two_params<int, int> p;
              p.p1 = 1;
              p.p2 = p_CSetup->getScreenStatus( CSetup::_s_config::_s_screens::CDCS );
              _event< _two_params<int,int> > e( "aggregat", CEventNames::config_window_activation, p );
              EventManager.RaiseEvent(e);
            }
            else if( iTimer == 7 ){
              _two_params<int, int> p;
              p.p1 = 2;
              p.p2 = p_CSetup->getScreenStatus( CSetup::_s_config::_s_screens::TDC );
              _event< _two_params<int,int> > e( "aggregat", CEventNames::config_window_activation, p );
              EventManager.RaiseEvent(e);
            }
            else if( iTimer == 8 ){
              _two_params<int, int> p;
              p.p1 = 3;
              p.p2 = p_CSetup->getScreenStatus( CSetup::_s_config::_s_screens::SCC );
              _event< _two_params<int,int> > e( "aggregat", CEventNames::config_window_activation, p );
              EventManager.RaiseEvent(e);
            }
            else if( iTimer == 9 ){
              _two_params<int, int> p;
              p.p1 = 4;
              p.p2 = p_CSetup->getScreenStatus( CSetup::_s_config::_s_screens::TC );
              _event< _two_params<int,int> > e( "aggregat", CEventNames::config_window_activation, p );
              EventManager.RaiseEvent(e);
            }
            else if( iTimer == 10 )
            {
              _two_params<int, int> p;
              p.p1 = 5;
              p.p2 = 1;
              _event< _two_params<int,int> > e( "aggregate", CEventNames::config_window_activation, p );
              EventManager.RaiseEvent(e);
           }
           else if( iTimer == 11 )
           {
               _event<float> e( "aggregate", CEventNames::new_dewpoint_offsett, fDewPointOffset );
               EventManager.RaiseEvent(e);
           }            
           else if( iTimer == 20 )
            {
                _string s("blank");
                _event<_string> e1( "aggregate", CEventNames::status_temp_1, s);
                if( mode == AUTO && p_con1 != NULL )
                {
                   
                   switch( p_con1->getMode() )
                   {
                       case 1:
                            s = "heating";
                            e1.modifyParameter(s);
                            EventManager.RaiseEvent(e1);
                       break;
                       case 2:
                            s = "cooling";
                            e1.modifyParameter(s);
                            EventManager.RaiseEvent(e1);
                       break;
                       case 3:
                            s = "even";
                            e1.modifyParameter(s);
                            EventManager.RaiseEvent(e1);
                       break;
                   }
                }
                else{
                    EventManager.RaiseEvent(e1);
                }
            }
            else if( iTimer == 21 ){
                //�ndern des "Contoller-Status"
                _string s;
                char cMsg[3];
                if( evalERSMessages(cMsg)){
                    s = "ERROR ";
                    s += cMsg ;
                }
                else{
                    evalControlStatus( s );
                } 
                _event<_string> e( "aggregate", CEventNames::controller_status, s );
                EventManager.RaiseEvent(e);
            }
            else if( iTimer == 22 ){
                //--------------------------------------------------------------
                // Eine Hinweismeldung im Hauptmenu droppen
                char cMsg[3];
                if( evalERSMessages(cMsg) && false){
                    _string s("");
                    s += " ERROR ";
                    s += cMsg;                   
                    _event<_string> e( "aggregate", CEventNames::drop_infomessage, s );
                    EventManager.RaiseEvent(e);                    
                }
            }
            else if( iTimer == 23 && false ){
                char msgs[20][4] = {0};
                char m[4] = {0};
                int iNum;
                static bool bDropped = false;
                evalERSMessages( m, msgs, &iNum );
                if( !bDropped &&  msgs[0][0] != 0 ){
                    _string s("");
                    for( int i = 0; i < 20 && msgs[i][0] == '0'; i++ )
                    {
                        s += " ERROR ";
                        s += msgs[i];
                        s += "#";
                    }
                    _event<_string> e( "aggregate", CEventNames::drop_errormessage, s );
                    EventManager.RaiseEvent(e);                    
                    bDropped = true;
                }
                if( bDropped && msgs[0][0] == 0 )
                {
                    _event<bool> b("aggregate", CEventNames::remove_errormessage, true );
                    EventManager.RaiseEvent(b);  
                    bDropped = false;
                }
            }
            else if( iTimer == 24 ){
                if( p_CDiagCom->IsDisplayUpdate() || display_update_flag ){
                    _event<bool> b( "aggregate", CEventNames::display_update, true );
                    EventManager.RaiseEvent(b);
                    p_CDiagCom->DipslayUpdateDone();
                    display_update_flag = 0;
                }
            }
            else if( iTimer == 25 && cMacConfigDone != 0 )
            {
                cMacConfigDone = 0;  
                long macL = ENET_MAC->MAL;
                long macH = ENET_MAC->MAH;
                int cMac[] = { ( macH >> 8 ) & 0xff, macH & 0xff, (macL >> 24 ) & 0xff, (macL >> 16) & 0xff, (macL >> 8) & 0xff, macL & 0xff };
                sprintf( sMac, "%x:%x:%x:%x:%x:%x", cMac[5], cMac[4], cMac[3],cMac[2],cMac[1],cMac[0] );
                //Die anzuzeigende Netzwerkadresse, es kann ein beliebiger string sein,
                //denn er wird direkt angezeigt und nicht weiter verarbeitet
                _event<_string> s( "aggreate", CEventNames::set_network_mac, sMac );
                EventManager.RaiseEvent(s);
            }
            else if( iTimer == 26 ){
                _event<float> e("aggregate", CEventNames::NEW_DEWPOINT, pDewPointSensor->getDewPoint());
                EventManager.RaiseEvent(e);
            }
            else if( iTimer == 28 )
            {
              //--------------------------------------------------------------
              //�ndern der aktuellen Kompensierten Temperatur 1,2,3 oder 4
              _event<float> e("aggregate", CEventNames::temp_1_comp, p_CPData->getTemp3(iOffsettTable));
              EventManager.RaiseEvent(e);
            }
            iTimer++;
        }
        else
        {
            iTimer = 0;
        }        
        vTaskDelay (5);
    }
}



void evalControlStatus( _string & Text )
{
  controlstatus = p_con1->GetControlReadyStatus();// Get Ready Status
  
  if( mode == BOOT )
  {
    Text = "BOOT";
  }
  else if( mode == INIT )
  {
    Text = "INIT";
  }
  else if( mode == GOSTANDBY ){
    Text = "GO STANDBY";
  }
  else if( mode == PURGE ){
    Text = "PURGE";
  }
  else if( mode == MDEFROST ){
    Text = "DEFROST";
  }
  else if( mode == STOP ){
    Text = "STOP";
  }
  else if( mode == STANDBY ){
    Text = "STANDBY";
  }
  else if( mode == STANDBY ){
    Text = "STANDBY";
  }
  else if( mode == SERROR ){
    Text = "!!!--ERROR--!!!";
  }
  else if(  p_con1->getMode()  == 1 ){
    Text = "HEATING";
  }
  else if(  p_con1->getMode()  == 2 ){
    Text = "COOLING";
  }
  else{
    if( bHoldMode )
    {
      Text = "HOLD MODE"; 
    }
    else
    {
      Text = "CONTROLLING"; 
    }
  }
  if( bDewPointWarning )
  {
     Text = "DEWP WARNING";   
  }
}

/**

*/
bool evalERSMessages( char * pMsg ){
    int i;
    return evalERSMessages( pMsg, (void*)0,  &i);
}

bool evalERSMessages( char * pMsg, void * dstBuf, int * pMsgNum ){
    char msgs[20][4] = {0};
    int iECNum[20] = {0};
    static int iTimer = 20;
    static int iOffsett = 0;
    bool bNError = false;
    
    
    int iErrorCount = 0;
        
    if( !p_CSetup->getExtChiller() && b_is_lany_detected ){
/*        if( p_CPData->getVErrorStatus(1).cFlags != 0 ){
            iECNum[iErrorCount] = 20;
            strcpy( msgs[iErrorCount++],"020");
        }
        if( p_CPData->getVErrorStatus(2).cFlags != 0 ){
            iECNum[iErrorCount] = 21;
            strcpy( msgs[iErrorCount++],"021");
        }*/
    }
    
    uTError TError = p_CPData->getTErrorStatus(3);
    if( TError.cFlags != 0 ){
        if( TError.b.URange == 0 ){
            iECNum[iErrorCount] = 2;
            strcpy( msgs[iErrorCount++],"002");
            p_ChillerCom->setMErr( 2 );
            //bNError = true;
        }
        else if( TError.b.ORange == 0 ){
            iECNum[iErrorCount] = 3;
            strcpy( msgs[iErrorCount++],"003");
            p_ChillerCom->setMErr( 3 );
            //bNError = true;
        }
        else{ // no additional erros yet
            iECNum[iErrorCount] = 1;
            strcpy( msgs[iErrorCount++],"001");
            p_ChillerCom->setMErr( 1 );
            bNError = true;
        }
    }
    
    if( p_Lambdas[4]->getError().cFlags != 0 ){
        if( p_Lambdas[4]->getError().b.uCurr == 0 ){
            iECNum[iErrorCount] = 61;
            strcpy( msgs[iErrorCount++],"061");
            p_ChillerCom->setMErr( 61 );
            bNError = true;
        }
        else{ // no additional erros yet
            iECNum[iErrorCount] = 62;
            strcpy( msgs[iErrorCount++],"062");
            p_ChillerCom->setMErr( 62 );
            bNError = true;
        }
    }

    if( p_Lambdas[5]->getError().cFlags != 0 ){
        if( p_Lambdas[5]->getError().b.uCurr == 0 ){
            iECNum[iErrorCount] = 81;
            strcpy( msgs[iErrorCount++],"081");
            p_ChillerCom->setMErr( 81 );
            bNError = true;
        }
        else{ // no additional erros yet
            iECNum[iErrorCount] = 82;
            strcpy( msgs[iErrorCount++],"082");
            p_ChillerCom->setMErr( 82 );
            bNError = true;
        }
    }

    if( p_CPData->getTErrorStatus(6).cFlags ){
        iECNum[iErrorCount] = 97;
        strcpy( msgs[iErrorCount++],"097");
        p_ChillerCom->setMErr( 97 );        
        bNError = true;
    }

    if( gcMemException == 1 )
    {
        iECNum[iErrorCount] = 98;
        strcpy( msgs[iErrorCount++],"098");
        p_ChillerCom->setMErr( 98 );
    }
    if( gcMemException == 2 )
    {
        iECNum[iErrorCount] = 99;
        strcpy( msgs[iErrorCount++],"099");
        p_ChillerCom->setMErr( 99 );
    }
    
//    if( p_ChillerCom->getError() == 8 && p_CSetup->getExtChiller() && b_is_lany_detected){
//        iECNum[iErrorCount] = 8;
//        strcpy( msgs[iErrorCount++],"008");
//    }        
   
    if( pDewPointSensor->getDPError() && p_CSetup->getOptionDewPoint() && !b_is_lany_detected)
    {
        iECNum[iErrorCount] = 18;
        strcpy( msgs[iErrorCount++],"018");
        p_ChillerCom->setMErr( 18 );
    }        
    //DewPointe warning message
    if( iTimer-- < 0 ){
        if( ++iOffsett >= iErrorCount ){
            iOffsett = 0;
        }
        iTimer = 5;
    }
    
    if( bNError && dstBuf != 0 && iErrorCount > 0 ){
        memcpy( dstBuf, msgs, sizeof( msgs ));
    }
    
    
    if( iErrorCount > 0 ){
        strcpy ( pMsg, msgs[iOffsett]);
        *pMsgNum = iECNum[iOffsett];
        return true;
    }
    else{
        p_ChillerCom->setMErr( 0 );
        return false;
    }
}

/* ================== END ========================================*/

/**
 Prober Interface task
*/
void ProbTask(void *pvParameters)
{
    ProberCmdSet * p_proberCmdSet;
    Protocol * p_Protocol;
    
    //Warte bis Setup g�ltig ist
    while( !p_CSetup->bIsValid() ){
        vTaskDelay(10);
    }

    //Porber Cmd Objects
    if( p_CSetup->getProtocollType() == CSetup::_s_config::E_EG_ASCII ||
        p_CSetup->getProtocollType() == CSetup::_s_config::E_EG_ENACQ)
    {
        p_proberCmdSet = new ProberCmdSetCascade( &EventManager );
    }
    else
    {
        p_proberCmdSet = new ProberCmdSet( &EventManager );
    }
    
    //Protokoll Manager
    ProtocolManager * p_ProtoMgr = new ProtocolManager( &EventManager, p_proberCmdSet );
    // Initialize Prober communictation Interface
    if( p_CSetup->getProtocollType() == CSetup::_s_config::E_TELP8_ASCII ||
        p_CSetup->getProtocollType() == CSetup::_s_config::E_TELP12_ASCII ||
        p_CSetup->getProtocollType() == CSetup::_s_config::E_EG_ASCII ||
        p_CSetup->getProtocollType() == CSetup::_s_config::E_TSK_ASCII )
    {
        p_Protocol = new ASCII_CRLFProtocol();;
    }
    else
    {
        p_Protocol = new ASCII_ENQACKProtocol();;
    }
     
    p_serDevice->InitSerialProtocol( p_Protocol);
    p_Protocol->InitProtocol( p_serDevice, p_ProtoMgr );
    
    //ProberCmdSet::SetProberCmdSet(E_TELP8_OPTION); // Possible options:  E_TSK_OPTION, ,  E_TELP12_OPTION,
    if( p_CSetup->getProtocollType() == CSetup::_s_config::E_TELP8_ENACQ ||
        p_CSetup->getProtocollType() == CSetup::_s_config::E_TELP8_ASCII)
    {
        p_proberCmdSet->SetProberCmdSet(E_TELP8_OPTION);
    }
    else if( p_CSetup->getProtocollType() == CSetup::_s_config::E_TELP12_ENACQ ||
             p_CSetup->getProtocollType() == CSetup::_s_config::E_TELP12_ASCII)
    {
        p_proberCmdSet->SetProberCmdSet(E_TELP12_OPTION);
    }
    else if (p_CSetup->getProtocollType() == CSetup::_s_config::E_EG_ENACQ ||
             p_CSetup->getProtocollType() == CSetup::_s_config::E_EG_ASCII)
    {
        p_proberCmdSet->SetProberCmdSet(E_EG_OPTION);
    }
    else
    {
        p_proberCmdSet->SetProberCmdSet(E_TSK_OPTION);        
    }
    

    p_proberCmdSet->Init();
    p_ProtoMgr->InitProtocolManager( p_Protocol );
    //Register EventHandler
    EventManager.AddEventHandler( CEventNames::NEW_DEWPOINT, ProtocolManager::DewPointEventWrapper, p_ProtoMgr );
    EventManager.AddEventHandler( CEventNames::DEFROST_CHANGED, ProtocolManager::DefrostEventWrapper, p_ProtoMgr );
    while( 1 ){
        EventManager.HandlePID();
        p_ProtoMgr->ProcessMessages();
        controlstatus = p_con1->GetControlReadyStatus();// Get Ready Status
        p_proberCmdSet->SetControlStatus(controlstatus);
        p_serDevice->cycExec();
        vTaskDelay(5);
    }
}

/**
CAN BUS Task
*/
void CANTask(void *pvParameters)
{
    while(1)
    {
        c_CanIo.cycExec(10);
        vTaskDelay(10);
    }
}

void UART0_IRQHandler( void ){
    if( p_serDevice != 0 ){
        p_serDevice->uart0_handler();
    }
    else{
        UART_ClearITPendingBit(UART0 ,UART_IT_Receive | UART_IT_ReceiveTimeOut | UART_IT_Transmit);
    }
}
    
void DCCHandler( void *pvParameters)
{
  while(1){
    JLINKDCC_Process(); 
    vTaskDelay(1);
  }
}
  