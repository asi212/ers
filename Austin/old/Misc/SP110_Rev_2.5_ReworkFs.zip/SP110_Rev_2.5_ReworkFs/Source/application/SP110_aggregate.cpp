//Standard Library Includes
#include <stdio.h>
#include <vector>
#include "../system_wide_defs.h"
#include "Devices/CDewPointSensor.h"
#include "Devices/CLambda.h"
#include "Devices/COverTemperatureSensor.h"

#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstdarg>
extern "C"{
    #include "JLINKDCC.h"
}

//Project Includes
#include "FreeRTOS.h"
#include "task.h"
#include "SP110_aggregate.h"
#include "CProcessData.h"
#include "PIDController.h"
#include "CDiagCom.h"
#include "CAirTable.h"
#include "CChuckList.h"
#include "CSetup.h"
#include "sysinit.h"
#include "CChillerCom.h"
#include "CFiles.h"
#include "CDataLogger.h"
#include "Devices\CValve.h"
#include "CErrorMsgs.h"
#include "CCanIO.h"
#include "CErrorNums.h"
#include "uIP_Task.h"
#include "..\ethernet\webserver\chillerclient.h"

#include "..\system_wide_defs.h"
#include "..\DeviceManager\CDeviceManager.h"
#include "..\DisplayManager\CDisplayManager.h"
#include "..\Toolbox\toolbox.h"

#include "..\ComManager\OS_SerialPort.h"
#include "..\ComManager\OS_SerialPort.h"
#include "..\ComManager\probercmds.h"
#include "..\ComManager\protocolmgr.h"

#include "..\MailboxSystem\CEventManager.h"



E_COOLING_SUB_SYSTEM Cooling_Sub_Sys =  E_COOLING_SUBSYS_NONE;

/* interrupt handler */

void UART0_IRQHandler(void);
__arm void UART0_IRQHandler(void);

void UART2_IRQHandler(void);
__arm void UART2_IRQHandler(void);


/*
 * Local function definitions and callbacks
 */
bool ptNotifyChillerEvent( CChillerCom::ifc_event e, void * pParam );
void loadSetup();
void DisplayRefresh(void);
void UpdateDiagnosticData(void);
void UpdateSystemStatus(void);
void evalControlStatus( _string & Text );
bool evalERSMessages( char * pMsg );
bool evalERSMessages( char * pMsg, void * dstBuf, int * i );
float considerDewPoint( float fSetTemp );
float controlBaseTemperature( float fAirValue );
void recalcAirTable( long lCycleTime );
void InitializeUserSettings(void);
void ExitStandbyMode(void);
void GoToStandbyMode(void);
void SetByPassVentilStatus(void);
void GetEThernetMachAddress(u32 *addr);
void toggle_standby_modeEvent( bool b );
void toggle_enabled_modeEvent( bool b );
void toggle_purge_modeEvent( bool b );
void toggle_defrost_modeEvent(bool b);


void LPID(void);
float CalcControlPower(void);
float Regeln(void);
void ChillerLuftRegeln(void);
void VentilRegeln(void);
void DetectCoolingSubSystem(void);
void DualChillerLuftRegeln(void);
void set_standby_mode ( bool b );
void set_purge_mode ( bool b );
void set_defrost_mode ( bool b );

void ManageChillerClient(void );
void WATCH_DOG(void);

/*
 * Variable declarations
 */

int iConTimer; //Timer to define switch beetwenn fine an corease controllin
//int iConTimer2;
int iConTimer3= 120000; //Timer for HoldMode
int iOffsettTable = 0;
int final_init_delay = 0;
int idle_relais_off_delay = 0;
bool bCtrlLowNoise = false;
int iLConTimer;
int DiLConTimer;
int CompOFFTimer = 450000; // about 3 Min. and 45 secons = 225 s

#define NET_WORK_TIME_OUT  60000 // 120000 about 1 Minute. Time needed before we connected to Huber Dual Chiller
int NetworkTimer =  NET_WORK_TIME_OUT;
E_CHILLER_CLIENT_CMD cc_cmd = E_CC_NONE;
unsigned char chiller_connected = 0;


bool  bStablePower = false;
int iTrackConTimer = 10000;

bool bCtrlFine = false;
bool bCtrlVeryFine = false;
bool bHoldMode = false;
bool bHoldEnable = false;
bool bAllowStandard = true;
bool bAllowLowNoise = true;
bool cMacConfigDone = -1;
bool bAirTableLoaded = false;
bool bAirTableSave = false;
bool bInStandby = false;
bool bTOutError = false;
bool bSaveSetup = false;
bool bDewPointWarning = false;
bool chuckCableError = false; // Tells us here, if chuck cable error occured. Is used for switching off bypass valve in case of this error
bool b_temp_surpress_set_temp_change = false;
bool b_is_lany_detected = false;
bool leave_idle_mode = false;
bool bChillerInitFinished = false;
bool bDewPointAlarm = false;
bool bDPSensor_Err  = false;
bool bDPAlarm_Err = false;
int  dual_chiller_error = 0;
int  dual_chiller_error_code = 0;
bool error_button_clicked = false;

float AirPressure  = 0;
float fFlowCold    = 0.0;
float fFlowHot     = 0.0;
float fPropAir     = 0.0;

float fAirHoldWarm = 0.0; // hold mode values
float fAirHoldCold = 0.0;
float fPropHoldAir = 0.0;
float fConAirSet = 7.5;
float fConAirPre = 7.5;

float  fHoldIIR    = 0.0; // Propotional Valve

float fMax 	   = 330.0;
float fIPoint = 100.0;
float diff  = 0;		        /* aktuelle Regeldifferenz */
float diff1 = 0;
float diff2 = 0;
float adiff = 0;
float y = 0;
float y1;

float ldiff = 0;		        /* aktuelle Regeldifferenz */
float ldiff1 = 0;
float ldiff2 = 0;
float ladiff = 0;


float ly = 0;
float ly1;
float lK0 = 0;
float lK1 = 0;


float sollreg;   /* Sollwert in 1/100 �C */
static bool delay_current = false;
static int  wasCooling = 0;

sAirValue sAirSetup;
float fSetTemp  = 25.0;
static long lCycleTime, lOSOldTime;  // Variables to compute cycle time
static PID_STATE xPidState = CONTROLLING;
static PeerSystemStatus peerSys;
static unsigned char compressorOperation = 0; // 0 = Normal operation, 1= high temperature waiting for timeout to switch off,
                                // 2 = Compressor Switched off, 3 = Switched on letting in cold air slowly starting with 50l.
                                // 4 = maximum cold air reached.
int MAC_Id = 0;

MODE mode = BOOT;
MODE old_mode = mode;

char modstat = MOD_STAT_RUN | MOD_STAT_HEAT | MOD_STAT_PWR; // Initially, we enable all.
char gcMemException = 0;
char cTemp[3000] @ "EXRAM";
char display_update_flag;
char sMac[20];

extern xQueueHandle xHDiagRxChars;
extern xQueueHandle xHDiagTxChars;

float fDewPointOffset = 5.0;

// TCP Globals
float tcp_chucktemp, tcp_chillertemp, tcp_ktytemp, tcp_, tcp_interntemp, tcp_current1, tcp_current2;

/*
 * Gobal Instances
 */
extern CSetup c_CSetup;   // Declared in module sysinit.cpp
CProcessData  c_CPData( 66, &c_CSetup );
CDiagCom      c_CDiagCom(  &c_CSetup, &c_CPData );
CFiles        c_CFiles;
CAirTable     c_AirTable;
extern CSetup * p_CSetup;  // Declared in module sysinit.cpp
CProcessData  * p_CPData = &c_CPData;
CDiagCom      * p_CDiagCom = & c_CDiagCom;
CFiles        * p_CFiles = &c_CFiles;
CAirTable     * p_AirTable = &c_AirTable;
PIDController * p_con1 = NULL;
PIDController * p_con2 = NULL;
PIDController * p_con3 = NULL;
PIDController * p_con4 = NULL;
PIDController * p_con5 = NULL;
PIDController * p_con6 = NULL;
CLambda 		  * p_Lambdas[6];


#define LUFT_GRENZE				59.0		// Maximal Chuck Temperature we use air. Above, only electrical heating, no air
#define INIT_REPEATS			20			// Number of loop cycles we stay in INIT after all preconditions to leave INIT are fulfilled
#define OFF_REPEATS			 200			// Number of loop cycles we stay in IDLE after releais are switched off
#define COOL_SUBSYS_WAIT            3000
#define CHECK_VALVE                   50

int detect_count = COOL_SUBSYS_WAIT;


//Ventile im System
CLanyValve m_lany1( (unsigned short*)(0x34000030), 1 );
CJoucomaticValve m_jouco1( (unsigned short*)(0x34000030), 1 );
CJoucomaticValve m_jouco2( (unsigned short*)(0x34000032), 2 );

//Anzulegende Objekte:

CEventManager EventManager;
string name;
CChillerCom c_ChillerCom((void*)ptNotifyChillerEvent, &EventManager);
CChillerCom * p_ChillerCom = &c_ChillerCom;
CDeviceManager device_manager( &EventManager );
CDisplaymanager displaymanager(&EventManager);
CDeviceManager *pDevicemanager;
CDisplaymanager *pDisplaymanager;
CDewPointSensorStd d( &EventManager );
CDewPointSensor * pDewPointSensor = &d ;
//COverTemperatureSensor ot;
//COverTemperatureSensor * pCOverTemperatureSensor = &ot ;
COverTemperatureSensor * pCOverTemperatureSensor = NULL;
OS_SerialPort sPort;
OS_SerialPort * p_serDevice = &sPort;
CCanIO c_CanIo;
int controlstatus = 0;

ProberCmdSet * p_proberCmdSet;


/*****************************************************************************************
* Function: DetectCoolingSubSystem
* Purpose: Checks for the presence of an external Chiller. This simply done by sending an
*          ENQ code and reading the the Return code in 2 ms.
* Input: None
* Output: None
* Returns:
*          1. E_COOLING_SUBSYS_EXT_CHILLER: External chiller
*          2. E_COOLING_SUBSYS_PROP_VALVE: Proportional Valve is present
*          3. E_COOLING_SUBSYS_NONE  there is not external chiller and no proportional Valve
*********************************************************************************************/
void DetectCoolingSubSystem(void)
{
    char controllerType = p_CSetup->getConConfig();

    if( p_CSetup->getIntChiller() )
        Cooling_Sub_Sys =  E_COOLING_SUBSYS_INT_CHILLER;
    else if( p_CSetup->getGetPressDev() )
       Cooling_Sub_Sys = E_COOLING_SUBSYS_PROP_VALVE;
////    else if(controllerType == CSetup::_s_config::E_CONTOLLER_SP102Y2M)
////       Cooling_Sub_Sys = E_COOLING_SUBSYS_EXT_CHILLER;
    else
    {
        if( (controllerType == CSetup::_s_config::E_CONTOLLER_HWS_D300)
          ||(controllerType == CSetup::_s_config::E_CONTOLLER_SWS_600)
          ||(controllerType == CSetup::_s_config::E_CONTOLLER_SWS_D600)
          ||(controllerType == CSetup::_s_config::E_CONTOLLER_SP102Y2D)
          ||(controllerType == CSetup::_s_config::E_CONTOLLER_SP102Y2M)
          )
         {
            Cooling_Sub_Sys =  E_COOLING_SUBSYS_NONE;

            if( p_ChillerCom->getTemp() != +999.0 )
                Cooling_Sub_Sys = E_COOLING_SUBSYS_EXT_CHILLER;
            else if( detect_count < CHECK_VALVE )
            {
                m_lany1.ValveADCInEvent(ADC_GetConversionValue(5) );
                if(m_lany1.getIPress() > 1.0)
                    Cooling_Sub_Sys = E_COOLING_SUBSYS_PROP_VALVE;
            }
         }
    }
    if( Cooling_Sub_Sys != E_COOLING_SUBSYS_NONE)
    {
         p_CSetup->SetCoolingSubSys(Cooling_Sub_Sys);
    }
 }

 void WATCH_DOG(void)
 {
     unsigned char *pHBeat = (unsigned char*)0x34000084;
    if( *pHBeat != 0 ){
      *pHBeat = 0;
    }
 }
/**
 * This function is responsible to switch the aggregates state machine to the given mode
 *
 * The SW code is written in a way, that in principal each module can change the state machines code
 * If all modules use this function to switch the state, we ara capable to implement some global
 * rules for code switching here.
 *
 * Example: The IDLE mode in case of TELP12 prober can only be left under certain conditions.
 *
 * @param new_mode, the mode to be set
 * @return mode, the finally set mode
 */

MODE getOperationMode(void)
{
    return mode;
}
MODE switchMode( MODE new_mode )
{
    // Remember the currently set mode
    old_mode = mode;

    if(p_CSetup->getConConfig()== CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600)
    {
        if( chillerclient_connected_status() == 2) // we are the ones communicating with the Chiller.
        {
            if( new_mode ==  MDEFROST) // es ist new Mode.
            {
                chillerclient_switch_compressor(0); // switch off compressor
            }
            if( mode == MDEFROST ) // we are the ones communicating with the Chiller.
            {
                chillerclient_switch_compressor(1); // we are leaving Defrost Mode switch ON compressor
            }
        }
    }
	// Some new_mode have to be set independent of current mode
	/*
	#ifdef PM_DEBUG
			if( new_mode == SERROR)  new_mode = AUTO;
	#else
		 if (new_mode == SERROR ) mode = new_mode; 	// For security, go to SERROR anyway
	#endif
	*/

	if (new_mode == INIT) final_init_delay = INIT_REPEATS;  		 // Set delay if we enter INIT mode
	if (new_mode == IDLE) idle_relais_off_delay = OFF_REPEATS;   // Set delay, if we enter IDLE mode

 // if (new_mode == SERROR ) mode = new_mode;
////	#ifdef PM_DEBUG
////			if( new_mode == SERROR)  new_mode = AUTO;
////	#else
////		 if (new_mode == SERROR ) mode = new_mode; 	// For security, go to SERROR anyway
////	#endif

  // For security, go to SERROR anyway
      if (new_mode == SERROR ) mode = new_mode;
	else if (mode==DISABLED && new_mode!=BOOT) mode = DISABLED;  // From DISABLED, we only can switch to BOOT
	else
	{
		// Dependent on current mode
		switch (mode)
		{
		case INIT:
			// Leave INIT mode only if chiller initialization finished
			if( final_init_delay == 0 )
			{
				if ( p_proberCmdSet->GetProberCmdSet() == E_TELP12_OPTION ) mode = IDLE;
				else mode = new_mode;
			}
			break;

		case IDLE:
			// Mode changed due to SMS command or unlocking display allowed
			if ( leave_idle_mode ) mode = new_mode;
			leave_idle_mode = false;
			break;

		default:
			// Without any rule: just set the mode
			mode = new_mode;
			break;
		}
	}
	// Check, if we really have switched the mode. If yes, inform the system
	if (mode != old_mode)
	{
			_string modestr = "";

			switch (mode)
			{
			case DISABLED: modestr = "DISABLED"; break;
			case BOOT: modestr = "BOOT"; break;
			case AUTO: modestr = "AUTO"; break;
			case GOSTANDBY: modestr = "GOSTANDBY"; break;
			case MDEFROST: modestr = "MDEFROST"; break;
			case PURGE: modestr = "PURGE"; break;
			case STOP: modestr = "STOP"; break;
			case STANDBY: modestr = "STANDBY"; break;
			case SERROR: modestr = "SERROR"; break;
			case INIT: modestr = "INIT"; break;
			case IDLE: modestr = "IDLE"; break;
			case EXTEST: modestr = "EXTEST"; break;
			default: modestr = "";
			}
			_event<_string> e1( "aggregat", CEventNames::controller_mode, modestr );
			EventManager.RaiseEvent(e1);
	}
	// Return with finally set mode
	return mode;
}

/**
  IO- Task is responsible for Digital IOs and Error Handling
*/

// Events, used within IO-Task
void SetErrorChuckCableEvent( int err ){
	if (err==ERR_CHUCKCABLE) chuckCableError = true;
}

void ResetErrorChuckCableEvent( int err ){
	if (err==ERR_CHUCKCABLE) chuckCableError = false;
}

/**
 * @brief This event is called after the TELP12 prober has sent a SMSphr command
 * The module variable modstat is set to the given value
 *
 * @param stat, the new module status
 */
void ModStatusChangedEvent ( char stat )
{
	// Set module variable
	modstat	= stat;

	// Remember, that the following code switch was triggered by a SMS prober command
	leave_idle_mode = true;

	// Got to AUTO only, if all three modes are enabled.
	if ( modstat == (0x00 | MOD_STAT_RUN | MOD_STAT_HEAT | MOD_STAT_PWR ) ) switchMode( AUTO );
	// else: stay or go to IDLE
	else switchMode( IDLE );
}


void DisplayUnlockedEvent( bool unlocked )
{
	if ( mode==IDLE && unlocked )
	{
		leave_idle_mode = true;
		switchMode( AUTO );
	}
        if( mode == INIT && unlocked )
        {
            if( Cooling_Sub_Sys == E_COOLING_SUBSYS_EXT_CHILLER)
	      {
                p_ChillerCom->setInit( false );
}
            final_init_delay = 0;
        }
}
/****************************************************************************************************************
*  Function: SwitchONOFFCompressor
*
*  Purpose: Switch ON or OFF the compressor according to the following conditions.
*
*           The Compressor is only considered when the Cooling subsystem is either an Internal TS010,
*            Dual chiller or Propotional Valve.
*
*           A: Internal Chiller
*              A.1 Compressor is switch ON when the controller is in INIT,IDLE, or AUTO operation modes
*              A.2 The Compressor is always switched off when system is in Defrost or Standy mode

*           B: Proportional Valve
**              B.1 Compressor is always switched ON if the Set temperature is below COMPRESSOR_LIMIT (40�C) and
*                   operation mod is INIT,IDLE, and AUTO
*               B.2. The Compressor is switching ON when cooling and the Chucktemperature is < 230�C and operation mode
*                    is INIT,IDLE, or AUTO
*
*               B.3  The Compressor is always switched off when system is in Defrost or Standy mode
*               B.4  The Compressor is always switched off when system Heating or Controlling and the
*                    Set Temperature > COMPRESSOR_LIMIT
*              (*** B.5  The Compressor is switch off when the Heating and the Chuck Temperature is below 15�C **)
*
*               if( ((fSetTemp > COMPRESSOR_LIMIT )&&(p_con1->GetControlReadyStatus() != 2))
*                  ||( (chucktemp < 15.0)&& (p_con1->GetControlReadyStatus() == 1) ) // heating
******************************************************************************************************************/
#define COMPRESSOR_LIMIT 39.92  // due to non-controllable chiller the ait temperature below 30�C

void  SwitchONOFFCompressor(void)
{
    float chucktemp = p_CPData->getTemp3(iOffsettTable);
    switch(Cooling_Sub_Sys)
    {
        case E_COOLING_SUBSYS_INT_CHILLER:
            if( mode == INIT || mode == IDLE || mode == AUTO || mode == DIAGNOSE_AIR)
            {
                p_CPData->setOnMains(2);  //switch ON compressor;
            }
            else if( mode != EXTEST)
            {
                p_CPData->setOffMains(2); //switch OFF compressor;
            }
        break;
        case E_COOLING_SUBSYS_PROP_VALVE:
            if( (p_CSetup->getTempParamSet(1)->getMinLimit() < 0 )&&( p_CSetup->getConConfig() != CSetup::_s_config::E_CONTOLLER_SP102Y2D)
                                                                  &&( p_CSetup->getConConfig() != CSetup::_s_config::E_CONTOLLER_SP102Y2M)) // System with dumb Chiller
            {
                if( mode == INIT || mode == IDLE || mode == AUTO || mode == DIAGNOSE_AIR)
                {
                   p_CPData->setOnMains(2);  //switch ON compressor;
                }
                else if( mode != EXTEST)
                {
                    p_CPData->setOffMains(2); //switch off compressor;
                }
            }
        break;

        case E_COOLING_SUBSYS_INT_DUAL: // todo: to be implemented later.
        break;
    }
}
void IO_Task(void *pvParameters) {

  char cTemp[10];
  static int iSErrorCnt = 1000;
  static int iTogle = 0;
  static bool bNoCoolingSubSystem = false;
  static bool bExtChiller_wasCooling = false;


  if(SysInit::m_usersettings.SystemEnabled == false)
  {
    switchMode(DISABLED);
  }
  else
    switchMode( BOOT );
//	EventManager.AddEventHandler( CEventNames::, SetTemp1ChangedEventDiagTask );
	  EventManager.AddEventHandler( CEventNames::set_error, SetErrorChuckCableEvent);
  	EventManager.AddEventHandler( CEventNames::reset_error, ResetErrorChuckCableEvent);
  EventManager.AddEventHandler( CEventNames::mod_stat_changed, ModStatusChangedEvent);
  EventManager.AddEventHandler( CEventNames::display_unlocked, DisplayUnlockedEvent);

  p_Lambdas[0] = new CLambda( &EventManager, 1, p_CSetup );
  p_Lambdas[1] = new CLambda( &EventManager, 2, p_CSetup );
  p_Lambdas[2] = new CLambda( &EventManager, 3, p_CSetup );
  p_Lambdas[3] = new CLambda( &EventManager, 4, p_CSetup );
  p_Lambdas[4] = new CLambda( &EventManager, 5, p_CSetup, 1, (long*)0x3400001C, (long*)0x34000020);
  p_Lambdas[5] = new CLambda( &EventManager, 6, p_CSetup, 2, (long*)0x34000024, (long*)0x34000008);

  for( int i = 0; i < 6; i++ )
  {
      p_Lambdas[i]->Init();
      p_Lambdas[i]->SetOff();
  }

  while(  !p_CSetup->bIsValid()  ) vTaskDelay(10);

  p_CPData->setOffMains(1);
  p_CPData->setOffMains(2);
  p_CPData->setOffMains(3);
  p_CPData->setOffMains(4);

  p_CPData->setOnMains(4);

  if((p_CSetup->getConConfig() == CSetup::_s_config::E_CONTOLLER_SP102Y2D)||
     (p_CSetup->getConConfig() == CSetup::_s_config::E_CONTOLLER_SP102Y2M)) // SP102Y2D can use either an external Chiller or Prop. valve
  {
       p_CPData->setOnMains(4);// Therefore try to switch it on before detecting it
  }

  DetectCoolingSubSystem();

    if( Cooling_Sub_Sys == E_COOLING_SUBSYS_NONE )
    {
         // maxe sure not Air flows on the proportional ventil
        _event<float> e("AIRCON CONTROL", CEventNames::VALVE_1_SET, fPropAir);
        EventManager.RaiseEvent(e);
    }

   if( (Cooling_Sub_Sys == E_COOLING_SUBSYS_EXT_CHILLER)||( p_CSetup->getConConfig() == CSetup::_s_config::E_CONTOLLER_SP102Y2D)||
       (p_CSetup->getConConfig() == CSetup::_s_config::E_CONTOLLER_SP102Y2M) ||
       ( p_CSetup->getConConfig() == CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600 ))// Only when it is the external Cooling Subsystem!
  {
        p_ChillerCom->Init(true);

   }
  // Initialize User Settings.

  InitializeUserSettings();


  while(1){
    EventManager.HandlePID();
    for( int i = 0; i < 6; i++ )
    {
      p_Lambdas[i]->cycCalc();
    }

    // Boot up sequence dependent on chiller temperature
    switch( mode )
    {

        case DISABLED:
            p_Lambdas[4]->SetOff();
            p_Lambdas[5]->SetOff();
            p_CPData->setOffMains(3);
            p_CPData->setOffMains(4);
        break;
        case BOOT:
            if( Cooling_Sub_Sys == E_COOLING_SUBSYS_NONE )
            {
                DetectCoolingSubSystem();
            }
            if( (Cooling_Sub_Sys == E_COOLING_SUBSYS_EXT_CHILLER)||
                ( p_CSetup->getConConfig() == CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600 ))// Only when it is our Cooling Subsystem!
            {
                p_ChillerCom->setInit( true ); 
            }
            if( !p_CPData->isCalibrating())
            {
                p_CPData->ResetErrors();
                switchMode( INIT );
                _event<bool> e( "IO_Task", CEventNames::compressor_status, true );
                EventManager.RaiseEvent(e);
            }
        break;

        case INIT:
            if( p_CSetup->getIntChiller())
            {
                if( p_CPData->getTemp5() < -40.0 )
                {
                    if( final_init_delay == 0 ) switchMode( AUTO );
                    else final_init_delay--;
                }
                if(  p_CSetup->getConConfig() == CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600 )
                {
                    p_ChillerCom->setInit( false );
                    p_ChillerCom->setInitialized(true);
                }
            }
            else if (Cooling_Sub_Sys == E_COOLING_SUBSYS_PROP_VALVE)
            {
                final_init_delay--;
            }
            else if( Cooling_Sub_Sys == E_COOLING_SUBSYS_EXT_CHILLER)
            {

//                if( p_ChillerCom->getTemp() < -40.0 )
//                {
                    char controllerType = p_CSetup->getConConfig();
                    if((controllerType != CSetup::_s_config::E_CONTOLLER_SP102Y2M)&& (controllerType != CSetup::_s_config::E_CONTOLLER_SP102Y2D))
                    {
                        p_ChillerCom->setInit( false );
                        p_ChillerCom->setInitialized(true);
                        if( final_init_delay == 0 ) switchMode( AUTO );
                        else final_init_delay--;
                    }    
                    else
                    {
                      final_init_delay = 0;
                      switchMode( AUTO );
                    }
//                }
            }
            else if( Cooling_Sub_Sys == E_COOLING_SUBSYS_NONE )
            {
                DetectCoolingSubSystem();
                if( Cooling_Sub_Sys != E_COOLING_SUBSYS_NONE )
                {
                    _event<int> e("CChillerCom", CEventNames::reset_error, ERR_NO_COOL_SUBSYS );
                    EventManager.RaiseEvent(e);
                    bNoCoolingSubSystem = false;
                }
                else if(bNoCoolingSubSystem == false)
                {
                    if( detect_count > 0)
                        detect_count--;
                    else
                    {
                        _event<int> e("CChillerCom", CEventNames::set_error, ERR_NO_COOL_SUBSYS );
                        EventManager.RaiseEvent(e);
                        bNoCoolingSubSystem = true;
                    }
                }
            }
        // After initialization finished, goto AUTO or IDLE dependent on prober type
            if( final_init_delay == 0 )
            {
                if ( p_proberCmdSet->GetProberCmdSet() == E_TELP12_OPTION )  switchMode( IDLE );
                    switchMode( AUTO );
            }

      break;


      default:
      	break;
    }

    //Chiller Compressor On / Off Control

     SwitchONOFFCompressor();


    // Main Power Relais logic
		// We hardcode a limit here, because it may happen, that the user configures
		// accidently a limit of e.g. 400�C which would possibly destroy the chuck.
		// 330�C is definitly the highest temperature we will allow!
		// 29.8.2012 KM: Changed value from 310.0 to 330.0
    if( mode != BOOT && mode != DISABLED && p_CPData->getTemp3(iOffsettTable) > 330.0 )
    {
        if( iSErrorCnt > 0 )
        {
            iSErrorCnt --;
        }
        else
        {
            switchMode( SERROR );
        }
    }
    else
    {
      iSErrorCnt = 1000;
    }

    //Check Chiller
    if( mode != BOOT && mode != SERROR && p_CSetup->bIsValid() && ( Cooling_Sub_Sys == E_COOLING_SUBSYS_EXT_CHILLER) ) //p_CSetup->getExtChiller() ){
    {
        if( p_ChillerCom->getError() )
        {
////            p_ChillerCom->setInit( true );
////             switchMode( INIT ); // NO Initialization
        }
    }

    // Check Chuck Temperature for Error. Ignore under-temperature error as critical error!
    if( (p_CPData->getTErrorStatus(3).cFlags & (FLAG_TERR_WIRE_BREAK | FLAG_TERR_O_RANGE | FLAG_TERR_HOLD ) ) != 0 && mode != BOOT && mode != DISABLED  )
    {
       switchMode( SERROR );
    }

    // Lambda Relais ein/aus
    // a) If module status HEAT OFF, switch relais off, independent of mode
    // b) else switch on relais for certain defined modes
    if( mode == AUTO || mode == GOSTANDBY  || mode == PURGE || mode == MDEFROST || mode == DIAGNOSE_AIR )
    {
      p_CPData->setOnMains(1);
    }//c) off in all other cases except EXTEST, where we leave the mains as they are
    else if ( (mode==IDLE && idle_relais_off_delay--==0) || (mode!=IDLE && mode!=EXTEST) )
    {
      p_CPData->setOffMains(1);
    }

    // Lambda on conditions
    if (  mode != INIT && mode != BOOT && mode != STANDBY && mode != SERROR && mode != IDLE && mode != DISABLED)
    {
        if( (p_CPData->getTErrorStatus(3).cFlags & (FLAG_TERR_WIRE_BREAK | FLAG_TERR_O_RANGE | FLAG_TERR_HOLD )) == 0 &&
            p_Lambdas[4]->getError().b.oCurr == 0 &&
            p_Lambdas[5]->getError().b.oCurr == 0 )
        {
            p_Lambdas[4]->SetOn();
            p_Lambdas[5]->SetOn();
        }
        else
	  {
            switchMode( SERROR );
        }
    }	// INIT, BOOT, STANDBY, SERROR, IDLE or module status Run off or Pwr off
    else
    {
        for( int i = 0; i < 6; i++ )
        {
            p_Lambdas[i]->SetOff();
        }
    }
    if (  mode != EXTEST ) SetByPassVentilStatus();

    // Switch Relais 4, but only, if we are not in EXTEST mode (Service or Diagnosis mode)
    if (  mode != EXTEST )
    {
        if(Cooling_Sub_Sys == E_COOLING_SUBSYS_EXT_CHILLER)// In Controller Mode Chiller is connected to this port
        {
            if( mode != SERROR || true )
            {
                p_CPData->setOnMains(4);
            }
            else
            {
                p_CPData->setOffMains(4);
            }
        }
	  else if( mode != DISABLED)// In any other mode Bypass Valve my be connected to this port
        {
		//Chuck Bypass Logic
            // 1) Switch off bypass valve in case of chuck cable error.
            //    Hinders output of pressurised air through open tube in case chuck is removed
            if (chuckCableError)
            {
                p_CPData->setOffMains(4);
            }
            // 2) Switch off bypass in case of
            else if( p_CPData->getTemp3(iOffsettTable) > 200.0 )
            {
                p_CPData->setOffMains(4);
            }
            else if( p_CPData->getTemp3(iOffsettTable) < 190.0)
            {
                p_CPData->setOnMains(4);
            }
        }
    }

    //Set Chiller Mode
    if( pDewPointSensor->getDP1Error() )
    {
        _event<char> e( "aggregate", CEventNames::new_chiller_mode, '6' );
        EventManager.RaiseEvent(e);
    }
    //  else if( pDewPointSensor->getDP2Error() )
    else if( bDewPointAlarm )
    {
        _event<char> e( "aggregate", CEventNames::new_chiller_mode, '7' );
        EventManager.RaiseEvent(e);
    }
    else if( bDewPointWarning )
    {
        _event<char> e( "aggregate", CEventNames::new_chiller_mode, '5' );
        EventManager.RaiseEvent(e);
    }
    else
    {
        switch( mode ){

            case BOOT:
            case INIT:
              {
                _event<char> e( "aggregate", CEventNames::new_chiller_mode, 'R' );
                EventManager.RaiseEvent(e);
              }
            break;

            case AUTO:
                switch( p_con1->getMode()){
                    //Heating
                    case 1:
                      {
                        _event<char> e( "aggregate", CEventNames::new_chiller_mode, '1' );
                        EventManager.RaiseEvent(e);
                        bExtChiller_wasCooling = false;
                      }
                    break;
                    //cooling:
                    case 2:
                      {
                        _event<char> e( "aggregate", CEventNames::new_chiller_mode, '2' );
                        EventManager.RaiseEvent(e);
                        bExtChiller_wasCooling = true;
                      }
                    break;
                    //controlling
                    case 0:
                      {
                        if( bExtChiller_wasCooling == true)
                        {
                           if( (p_CPData->getTemp3(iOffsettTable)-
                                p_CSetup->getTempParamSet(1)->getSetTemp()) < 0.2)
                             bExtChiller_wasCooling = false;
                        }
                        else
                        {
                        _event<char> e( "aggregate", CEventNames::new_chiller_mode, '0' );
                        EventManager.RaiseEvent(e);
                      }
                      }
                    break;
                }
            break;

            case PURGE:
              {
                _event<char> e( "aggregate", CEventNames::new_chiller_mode, '4' );
                EventManager.RaiseEvent(e);
              }
            break;

            case MDEFROST:
              {
                _event<char> e( "aggregate", CEventNames::new_chiller_mode, 'D' );
                EventManager.RaiseEvent(e);
              }
            break;

        }
    }
    //Heart Beat signal zum FPGA, noch nicht sauber aber funktioniert
    if( (Cooling_Sub_Sys == E_COOLING_SUBSYS_EXT_CHILLER)||(Cooling_Sub_Sys == E_COOLING_SUBSYS_NONE) ||
      ( p_CSetup->getConConfig() == CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600 ))// Only when an external Chiller is required!
    {

        if( p_CSetup->getConConfig() == CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600 )
        {
            if( mode != BOOT) // if( (mode != BOOT)&&( mode != INIT) )
            {
                p_ChillerCom->SetOperationControlMode(mode,controlstatus,chillerclient_connected_status(),compressorOperation);
                p_ChillerCom->cycExec( 10 );

                 if( (peerSys.controller == false)&&(chiller_connected == 0)) // we are responsible
                 {
                        ManageChillerClient();
                 }
            }
        }
        else
        {
            p_ChillerCom->SetOperationMode(mode);
            p_ChillerCom->cycExec( 10 );
        }
    }
    unsigned char *pHBeat = (unsigned char*)0x34000084;
    if( *pHBeat != 0 ){
      *pHBeat = 0;


    }

    vTaskDelay (10);
  }
}
/*******************************************************************************************************************
* 13.02.2013
* Method: SetByPassVentilSonderFall
* This is a special handling routine that should be modified after Software-Refactoring.
* This was written to manage air conditions for TS08 System with a dumb Chiller
********************************************************************************************************************/
void SetByPassVentilSonderFall(void)
{
    float ist_temp =  p_CPData->getTemp3(iOffsettTable) ;
    float soll_temp =  p_CSetup->getTempParamSet(1)->getSetTemp();

    if( mode == AUTO)
    {
        switch(p_con1->getMode())
        {
            case  1: // heating
                if( ist_temp > 13.5 )
                {
                    p_CPData->setOnMains(3);
                }
                else if( ist_temp < 12.5 )
                {
                    p_CPData->setOffMains(3);
                }
                iLConTimer = 8000; // warten.(5secs)
            break;

            case 2: // cooling
              if(  iLConTimer < 0 )
              {
                    p_CPData->setOffMains(3);
               }
               else
                 iLConTimer-= lCycleTime;
            break;

            case 0: // controlling
                if(  soll_temp > 14.5 )
                    p_CPData->setOnMains(3);

                iLConTimer = 8000; // warten.(5secs)
            break;
        }
    }
}

void SetByPassVentilStatus(void)
{

    float ist_temp =  p_CPData->getTemp3(iOffsettTable) ;
    float soll_temp =  p_CSetup->getTempParamSet(1)->getSetTemp();

   if( (mode != BOOT) && ( mode != INIT) &&( mode != IDLE) )// wait until p_con4 is initialized
   {
       if( p_CSetup->getGetPressDev() )// Entweder SP110 oder TS09
       {
         if(p_CSetup->getTempParamSet(1)->getMinLimit() < 0  )
         {
           SetByPassVentilSonderFall();
         }
         else
         {
             float f = m_lany1.getSetValue();  // Druckproportionalventil;
             if( f < 50 )
                 p_CPData->setOnMains(3);
             else if( f > 60 )
                 p_CPData->setOffMains(3);
         }
       }
       else   // TS010
       {
            if( mode == AUTO)
            {
                  switch(p_con1->getMode())
                  {
                        case  1: // heating
                              if( ist_temp > 13.5 )
                              {
                                    p_CPData->setOnMains(3);
                              }
                              else if( ist_temp < 12.5 )
                              {
                                    p_CPData->setOffMains(3);
                              }
                        break;

                        case 2: // cooling
                              if(  m_jouco1.getFlow() > 150 ) // PM. 15.11.2012  make sure the air is already flowing before switching off
                                  p_CPData->setOffMains(3);
                              if( soll_temp > 14.5 )
                              {
                                    if( (ist_temp - soll_temp ) < 2.4 )
                                       p_CPData->setOnMains(3);
                              }
                        break;

                        case 0: // controlling
                          if(  soll_temp > 14.5 )
                             p_CPData->setOnMains(3);
                        break;


                  }
            }

       }
   }
	// ON, when in INIT, BOOT or IDLE
	else p_CPData->setOnMains(3);
}

/**
Callbackfunktion to handle Chiller Interface Events
*/
bool ptNotifyChillerEvent( CChillerCom::ifc_event e, void * pParam ){
  MODE mNew;
  char cTemp;
  signed char *sTemp;
  int iChuckCount;
  int iChuckEnable;
  switch( e ){

    case CChillerCom::NEW_MODE:
      mNew = *((MODE*)pParam);
      switch( mNew ){
        case AUTO:        //on case auto go to INIT first
          p_CPData->ResetErrors();
          //resetErrors();
          switchMode( INIT );
          return true;

        case GOSTANDBY:
        case MDEFROST:
        case PURGE:
        case STOP:
          switchMode( mNew );
          return true;

        default:
          return false;
      }

    case CChillerCom::NEW_DPOINT:
    //    fDewPointOffset = *((float*)pParam);
        return true;

  default:
      return false;
  }
}

/************************************************************************************************
* Function: OperationModeChangedEvent( int new_mode)
*
* Description: Operation Mode set through the Prober Interface
*              When a new Mode is received, the function establishes present Operation Mode and takes
*              the necessary steps before changing it.
*
*      How it works:
*      1. New Operation Mode is the same as the present one. Action => do nothing
*      2. New Operation Mode Normal Mode (1) and present is Standby mode . Action => diactivate Standby Mode
*      3. New Operation Mode Normal Mode (1) and present is Defrost mode. Action => diactivate Defrost Mode
*      4. New Operation Mode Standby Mode(2) and present is Normal Mode. Action =>  activate Standby Mode
*      5. New Operation Mode Standby Mode(2) and present is Defrost Mode. Action =>  deactivate Defrost Mode and activate Standby Mode
*      6. New Operation Mode Defrost Mode(3) and present is Normal Mode. Action =>  activate Defrost Mode
*      7. New Operation Mode Defrost Mode(3) and present is Standby Mode. Action =>  deactivate Standby Mode and activate Defrost Mode
*
*
* Input: new operate Mode
* Output: None.
*
* Comments:
*   This Event has been defined in wrong position. It should later be strimlined
*  so that ONLY ONE entry point to Operation changes are handled!!
****************************************************************************************/
void OperationModeChangedEvent( int new_mode)
{
     switch(mode)
     {
        case GOSTANDBY:
        case STANDBY:
          toggle_standby_modeEvent(false); //set_standby_mode(false); 		// deactive Standby Mode
        	break;
        case MDEFROST:
            toggle_defrost_modeEvent(false);//set_defrost_mode(false); 	// deactivate Defrost Mode
	        break;
        case PURGE:
		 toggle_purge_modeEvent(false);//set_purge_mode(false); 			// deactivate PURGE Mode
	  break;
    }
    // set new Modes
    if( new_mode == 1)
      switchMode(AUTO);
    if( new_mode == 2)
      toggle_standby_modeEvent(true);//set_standby_mode(true); 				// active Standby Mode
    else if( new_mode == 3)
			toggle_defrost_modeEvent(true);// set_defrost_mode(true); 				// activate Defrost Mode
    else if( new_mode == 4 )
	 toggle_purge_modeEvent(true);//		set_purge_mode(true); 					// activate PURGE Mode
}

/**
 * Diagnose communication task
 */
void SetTemp1ChangedEventDiagTask( float f ){
    p_CSetup->getTempParamSet(1)->setSetTemp(f); //aktuelle Temperatur, 'double' wird erwartet
}
void DiagTask(void *pvParameters){
    char c;
    int iBlockCnt = 100;
    bool bIPDiag = false;
    bool bComDiag = false;
    EventManager.AddEventHandler( CEventNames::set_temp1_changed, SetTemp1ChangedEventDiagTask );
     EventManager.AddEventHandler(CEventNames::operation_mode_changed, OperationModeChangedEvent );
    while( 1 ){
        EventManager.HandlePID();
        int iMsgSize = 0;
        if( !bComDiag && uxQueueMessagesWaiting( xHDiagRxChars ) >= 1 ){
            while( xQueueReceive( xHDiagRxChars, &cTemp[iMsgSize++], 0) == pdTRUE );
            short iLen = p_CDiagCom->processPacket( &cTemp[2], &cTemp[2], cTemp[1]) + 2;
            portENTER_CRITICAL();
            c = (char)(iLen>>8);
            xQueueSend( xHDiagTxChars, &c, 0 );
            c = (char)(iLen&0xFF);
            xQueueSend( xHDiagTxChars, &c, 0 );
            for( int i = 0; i < iLen; i++ ){
                xQueueSend( xHDiagTxChars, &cTemp[i], 0 );
            }
            portEXIT_CRITICAL();
            iBlockCnt = 1000;
            bIPDiag = true;
        }
        else if( bSaveSetup ){
            p_CSetup->writeSetup();
            p_CSetup->writeConfig();
            p_CSetup->writePIDSet(p_CSetup->getPidSetNr());
            bSaveSetup = false;
        }
        else if( !bIPDiag ){
            if( p_CDiagCom->processPacket() )
            {
                iBlockCnt = 1000;
                bComDiag = true;
            }
        }

        if( iBlockCnt < 1 ){
            bIPDiag = false;
            bComDiag = false;
        }
        else{
            iBlockCnt--;
        }

        vTaskDelay(5);
    }
}

/*********************************************************************
*
* FSTask Handles all file system functionality
*/
void FSTask(void *pvParameters){
  char cBuf[40];
  char cAFile[AIR_FILE_NAME_LEN] = {0};
  bAirTableSave = false;
  p_CFiles->logEvent( CFiles::event_startup, 1, 0 );
  //loadSetup();
	p_AirTable->getAirTableName(cAFile, (AIR_TABLE_OPTION)p_CSetup->getAirTable());
  if( strlen(cAFile) > 0 )
  {
    p_AirTable->loadAirTable( cAFile );
    bAirTableLoaded = true;
  }

  if( p_CSetup->getConConfig() <= CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600 ||
      p_CSetup->getConConfig() == CSetup::_s_config::E_AUTO_CON ||
      p_CSetup->getConConfig() == CSetup::_s_config::E_CONTOLLER_SP102Y2D ||
      p_CSetup->getConConfig() == CSetup::_s_config::E_CONTOLLER_SP102Y2M
     )
  {
    _event<bool> e( "FileTask", CEventNames::set_power_supply_5_active, true );
    EventManager.RaiseEvent(e);
  }
  if( p_CSetup->getConConfig() == CSetup::_s_config::E_PROP_VALVE_HWS_D300 ||
      p_CSetup->getConConfig() == CSetup::_s_config::E_PROP_VALVE_SWS_D600 ||
      p_CSetup->getConConfig() == CSetup::_s_config::E_CONTOLLER_HWS_D300 ||
      p_CSetup->getConConfig() == CSetup::_s_config::E_CONTOLLER_SWS_D600 ||
      p_CSetup->getConConfig() == CSetup::_s_config::E_CHILLER_MST_SWS_D600 ||
	p_CSetup->getConConfig() == CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600
     )
  {
    _event<bool> e( "FileTask", CEventNames::set_power_supply_6_active, true );
    EventManager.RaiseEvent(e);
  }
  while(1){
    //Neue Lufttabllenwerte speichern
    if( bAirTableSave )
    {
        p_AirTable->saveAirTable( cAFile );
        bAirTableSave = false;
    }
   //Write Data Logger File
  if( mode == AUTO ){
      /* Datenlogger vorerst nicht aktiv
    for( int i = 1; i <= 2; i++ ){
      if( p_CPData->getLErrorStatus(i).cFlags != 0 ){
        //p_CFiles->saveLoggerFile( 16, &cLogger );
       }
     }
      */
   }


   if(  p_CPData->hasNewError( 1, 1, 0) ){
      p_CFiles->logEvent( CFiles::event_errorch, 1, 0 );
    }
    if(  p_CPData->hasNewError( 2, 2, 0) ){
      p_CFiles->logEvent( CFiles::event_errorch, 2, 0 );
    }
    if(  p_CPData->hasNewError( 3, 3, 0) ){
      p_CFiles->logEvent( CFiles::event_errorch, 3, 0 );
    }
    if(  p_CPData->hasNewError( 4, 4, 0) ){
      p_CFiles->logEvent( CFiles::event_errorch, 4, 0 );
    }
    if(  p_CPData->hasNewError( 5, 0, 0) ){
      p_CFiles->logEvent( CFiles::event_errorch, 5, 0 );
    }

  if( p_CFiles->isLoSizeEx()){
      p_CFiles->bakLogFile(cBuf);
    }
    vTaskDelay(5);
  }
}

void loadSetup()
{
  p_CSetup->readOffsetTable();  //Achtung offsettabelle zuerst laden
  p_CSetup->readSetup();
  p_CSetup->readConfig();
  p_CSetup->readPIDSet(p_CSetup->getPidSetNr());      //PID Parameter auch zuerst
}

/**
  PID is executing the real time calculations required for PID and FIR Filters
  of the Temperature sensors
*/
void set_hold_modeEvent( bool b )
{
    bHoldEnable = b; //Der User moechte den Hold-Mode aktivieren
}


/*****************************************************************************************
* Function: AutoDefrostDewPointTracking
* Purpose: Tracks the DewPointSensor values. If the Dewpoint Value changes rapidly then
*          an Alarm Signal is Set. This routine is only used when an External Chiller is
*          selected and AutoDefrost function has been selected.
*
*  NOTE: The transistor number 2 used (setOnMains(2)/setOfMains(2). This same transitor is
*        used for switch on/off the Compressor in TS010 Systems (intern Chiller)
*
* Description: Dewpoint tracking and Autodefrost happens when:
*              1. Set Temperature is > 14.5�C
*              2. When the System is in Auto Mode
*
*  This how the tracking is carried out:
*
*
*  1. Tracking Dewpoint Loop
*     The tracking range is described as the range within which the Dewpoint Temperature must be cooler than the Chucktemperature.
*     The Standard Range is TR = 5�C
*
*     TPdiff = ChuckTemp - DewpointTemp.
*     if TPdiff < TR  then the DewpointTemp. has detoriated; therefore we must raise the chucktemperature, while waiting for the
*     the Dewpoint to improve.
*
*     Example: Set Temperature  = -20�C
*              a)  Chuck Temperature = - 15�C
*                  Dewpoint Temperature = -21�C
*                  Action: Everything is O.K. Do nothing

*              b) Chuck Temperature = - 15�C
*                  Dewpoint Temperature = -14�C
*                  Action: Set Temperature =  -14+5 = -9�C, continue cooling
*
* 2. Auto Defrost Dewpoint Loop
*
*    While tracking the Dewpoint Temperature it establish, that the Dewpoint Temperature has detoriated by more than
*    5�C whin a very short time of 1 Minute, then we must defrost immediately.
*
* Input: None
* Output: None
* Returns: None
*
*********************************************************************************************/
#define TP_WAIT 720 // 1/10 second
#define TPA_WAIT 20

#define TP_LESS_WAIT 100 // 1 minute
#define defrost_limit 5.0
#define Auto_defrost_temp 50.05

float  AutoDefrostDewPointTracking( float fset_temp )
	{
    static float tpmin = 50.0;
    static float tpmax = -200.0;

    static unsigned long dpTimer = 0;
    static unsigned long lastInterval = 0;
    static long dpTrackingTime = TP_WAIT; // 1/10 second
    static long dpAlarmTime = TP_WAIT;

    float staubin = pDewPointSensor->getDewPoint();
    float dp_istbin =  p_CPData->getTemp3(iOffsettTable);
    float tpdiff = dp_istbin - staubin;
    unsigned long delay = 0;

    if( fset_temp < 14.5 )
    {
 	    dpTimer++;

           if((staubin + fDewPointOffset) > dp_istbin )
		{
                 if( dpTrackingTime <= 0)
			{
			  bDewPointWarning = true;
			}
                 else
                   dpTrackingTime -= lCycleTime;
			}
		else
			{
			bDewPointWarning = false;
                  dpTrackingTime = TP_WAIT;
			}

            if( (p_con1->GetControlReadyStatus() == 0 )||(bDewPointAlarm == true) )  // During controlling and Dewpoint Alarm!
			{
                if( staubin < tpmin)
				{
                    tpmin = staubin; // track minimum Dewpoint
                    lastInterval = 0;
					}
			else
			{
                    if( ( staubin > tpmin) && (lastInterval == 0) )// The first time the Dewpoint starts warmin up
      {
                        lastInterval = dpTimer;
			}
			}
                if( ((staubin - tpmin) >= defrost_limit)&&(bDewPointAlarm == false)) // Alarm not yet set!
			{
                    delay = dpTimer - lastInterval;
                    if( delay > TP_LESS_WAIT ) // The Change took longer than 1 Minute, therefore nor alarm.
                    {
                        tpmin = staubin; // Set new tpmin two this new point. In the field, the Dewpoint detoriates after some time.
			}
                    else // it was below a minute!
			{
                       if( delay > TPA_WAIT ) // not immediately !!
					{
                            fset_temp = Auto_defrost_temp;
                            bDewPointAlarm = true;
                            bDewPointWarning = false;
                            dpAlarmTime =  TP_WAIT;
                            tpmax = staubin;
                            dpTrackingTime = TP_WAIT;
                            p_CPData->setOnMains(2); // Switch ON Alarm Signal.
					}

					}
					}
					}
            else // heating or cooling
				{
                tpmin = staubin;
				}
            // handle a special case here. Dewpoint detoraites while we are already tracking!
             if((p_con1->GetControlReadyStatus() == 1)&&(bDewPointWarning == true) )
			{
                if( staubin > dp_istbin) // Dewpoint is warmer than Chucktemperature.
                {
                    fset_temp = Auto_defrost_temp;
                    bDewPointAlarm = true;
                    bDewPointWarning = false;
                    tpmax = staubin;
                    dpTrackingTime = TP_WAIT;
                    dpAlarmTime =  TP_WAIT;

                    p_CPData->setOnMains(2); // Switch ON Alarm Signal.
						}
				}

            // let us now handle error conditions correctly
            if( bDewPointWarning == true )
				{
                if( (tpdiff > (fDewPointOffset +(fDewPointOffset/2)))||( (fset_temp - staubin)> fDewPointOffset ) )
          		  fset_temp =  p_CSetup->getTempParamSet(1)->getSetTemp(); // restore set Temp.
					else
                fset_temp = staubin + fDewPointOffset;
					 }
            else if( bDewPointAlarm == true )
			{
                fset_temp = Auto_defrost_temp; // defrost Temperature
                if( staubin > tpmax)
                    tpmax = staubin; // tracking detoriating Dewpoint

                if( (dp_istbin -  Auto_defrost_temp) > - 1.0 ) // within range
			{
                    if( (tpmax - staubin)>=  defrost_limit ) // improving. e.g if tpmax was 20�C and staubin in now <= 15�C then
                    {
                        if( dpAlarmTime >= 0)
                            dpAlarmTime -= lCycleTime;
        else
        {
                            bDewPointAlarm = false;
                            fset_temp =  p_CSetup->getTempParamSet(1)->getSetTemp(); // restore set Temp
                            p_CPData->setOffMains(2); // Switch OFF Alarm Signal.
          }
          }
        }
        }
        }
        else
        {
        bDewPointAlarm = false;
        bDewPointWarning = false;
        dpTrackingTime = TP_WAIT;
        dpAlarmTime = TPA_WAIT;
        dpTimer = 0;
        lastInterval = 0;
        tpmin = staubin;

        p_CPData->setOffMains(2); // Switch OFF Alarm Signal.
        fSetTemp  = p_CSetup->getTempParamSet(1)->getSetTemp();
		}


  return fset_temp;
}
/**
 * Evaluates dew point sensor results, and if required, adapts Set Temperature and submits warnings
 *
 * To avoid condensation water, the dew point of the air has to be considered.
 * The set temperature should always be above the current dew point, which depends on
 * air temperature and humidity.
 */
float considerDewPoint( float fset_temp )
{
     if( p_CSetup->getConConfig()== CSetup::_s_config::E_CONTOLLER_SP102Y2M)
        fset_temp = AutoDefrostDewPointTracking(fset_temp);
     else
     {
	if( !pDewPointSensor->getDPError() && fSetTemp < 14.5 )
	{
		if((pDewPointSensor->getDewPoint() + fDewPointOffset) > p_CPData->getTemp3(iOffsettTable))
		{
			bDewPointWarning = true;
                      fset_temp = pDewPointSensor->getDewPoint() + fDewPointOffset;
		}
		else
		{
			bDewPointWarning = false;
		}
	}
	else
	{
		bDewPointWarning = false;
	}

	if( pDewPointSensor->getDP1Error() )
	{
                fset_temp = 18.05;
	}

	if( pDewPointSensor->getDP2Error() )
	{
                fset_temp = 50.05;
	}
}
	return fset_temp;
}

/**
 * Increases AirFlow, if chuck base temperarture is higher then set temperature
 *
 *	At higher temperatures, no air is used normally. It may there not be possible to reach set temperature
 *  in short time, because base is heating chuck until both temperatures are equal
 */
float controlBaseTemperature( float fAirValue )
{
    float fmax = p_AirTable->getAirValue(-100.0).fFlow;
    float fKTYIIR = 0.0; // IIR filter store for cooling air flow in case KTY temp is higher then set temp

    if((p_CSetup->getTempParamSet(1)->getSetTemp() + 10) < p_CPData->getTemp7() )
    {
        float delta = p_CPData->getTemp7() - (p_CSetup->getTempParamSet(1)->getSetTemp() + 10);
        if( delta > 20 )
        {
            fAirValue += fmax;
            fKTYIIR = 20.0;
        }
        else
        {
            fKTYIIR = fKTYIIR * 0.99 + delta * 0.01;
            fAirValue += (fmax/20.0) * fKTYIIR;
        }
        if(fAirValue > fmax )
        {
            fAirValue = fmax;
        }
    }
    else
    {
        fKTYIIR = 0.0;
    }
	return fAirValue;
}


/**
 * Recalculates and saves the air table in certain time periods
 */
void recalcAirTable( long lCycleTime )
{

  static int iAirRecalcTimer =  600000; 	// Recalculate Air Table ervery 10 Minutes
  static int iAirSaveTimer   = 3600000;   // Save Air Table ervery 60 Minutes
  static bool bACTableModified = false;

	//Dynamische ermittleung der Startlufttemperatur
	if( iAirRecalcTimer > 0 )
	{
		iAirRecalcTimer-= lCycleTime;
	}
	else
	{
		//alle 10 Minuten einen neuen Wert berechnen
		bACTableModified = p_AirTable->recalcTemp( p_CSetup->getTempParamSet(1)->getSetTemp(), p_CPData->getTemp5() );
		iAirRecalcTimer = 600000;
	}
	if( iAirSaveTimer > 0 )
	{
		iAirSaveTimer -= lCycleTime;
	}
	else
	{
		bAirTableSave = bACTableModified;
		bACTableModified = false;
		iAirSaveTimer = 3600000;
	}
}




/********************************************************************/
/* ++++++++++++++++++ Start ++++++++++++++++++++++++++++++++++++++++*/

void toggle_purge_modeEvent( bool b )
{
	if( mode != PURGE ) // not in purge mode yet: enter it
	{
		switchMode( PURGE );
	}
	else // in purge mode yet: leave it
	{
            if( Cooling_Sub_Sys == E_COOLING_SUBSYS_EXT_CHILLER) // Only when it is our Cooling Subsystem! 
            {
//                p_ChillerCom->setInit(true); 
                switchMode( AUTO );
            }
            else
                switchMode( INIT );
	}
}

void toggle_defrost_modeEvent( bool b )
{
	if( mode != MDEFROST ) // not in defrost mode yet: enter it
	{
		switchMode( MDEFROST );
		_event<int> e2( "aggregat", CEventNames::DEFROST_CHANGED, 1 );   // Event for prober event-manager
		EventManager.RaiseEvent(e2);
	}
	else	// in defrost mode yet: leave it
	{
		if( Cooling_Sub_Sys == E_COOLING_SUBSYS_EXT_CHILLER) // Only when it is our Cooling Subsystem!
            {
//		    p_ChillerCom->setInit(true);  
                switchMode( AUTO);
            }
            else
		    switchMode( INIT );
		_event<int> e2( "aggregat", CEventNames::DEFROST_CHANGED, 0 );   // Event for prober event-manager
		EventManager.RaiseEvent(e2);
	}
}


void sendOffsetTable( int iNum, void* p )
{
    _o_tab tab;
    float *p_table[2];
    p_table[0] = p;
    p_table[1] = ((float*)p)+20;
    for( int i = 0; i < 20; i++ ){
      tab.temp[i] = p_table[0][i];
      tab.offsett[i] = p_table[1][i];
    }
    p_CSetup->setOffsetTable( iNum, tab );
    p_CSetup->writeOffsetTable();
}

void sendTable1Event( void* p )
{
    sendOffsetTable( 1, p );
}
void sendTable2Event( void* p )
{
    sendOffsetTable( 2, p );
}
void sendTable3Event( void* p )
{
    sendOffsetTable( 3, p );
}

void getAllOffsettTables( bool b )
{
    _event<void*> e1( "aggregat", CEventNames::receive_table1, p_CSetup->getOffsetTable(1) );
    _event<void*> e2( "aggregat", CEventNames::receive_table2, p_CSetup->getOffsetTable(2) );
    _event<void*> e3( "aggregat", CEventNames::receive_table3, p_CSetup->getOffsetTable(3) );
    EventManager.RaiseEvent(e1);
    EventManager.RaiseEvent(e2);
    EventManager.RaiseEvent(e3);
}

void set_active_comp_tableEvent( int i )
{
    iOffsettTable = i; //0=keine aktiv, 1,2,3= jeweilige Tabelle aktiv

    SysInit::m_usersettings.ActiveTemperatureOffsetTable = i;
    SysInit::SaveUserSettings(SysInit::m_usersettings);

// SysInit::m_usersettings.DewpointTrackingActive =
// SysInit::m_usersettings.DewpointTrackingOffset =

}

void enterDiagEvent( bool b )
{

}

void leftDiagEvent( bool b )
{
		// if we was in EXTEST mode, we switch back now, because the user has
	  // left the menue where he was manipulating values manually
    if( mode == EXTEST ){
        switchMode( INIT );
    }
    else 
        switchMode( AUTO );
      
}

// The user has entered a new set value for chuck heating circuit 1
void enterPower1Event( float f )
{
		// We have to leave AUTO mode, bacause the controller would override the manually set values
    switchMode( EXTEST );
		// Set the value at Lamdas
    _event<float> e( "Aggregate", CEventNames::set_power_suppply_5_set_voltage, f );
    EventManager.RaiseEvent(e);
}

// The user has entered a new set value for chuck heating circuit 2
void enterPower2Event( float f )
{
		// We have to leave AUTO mode, bacause the controller would override the manually set values
    switchMode( EXTEST );
		// Set the value at lamdas
    _event<float> e( "Aggregate", CEventNames::set_power_suppply_6_set_voltage, f );
    EventManager.RaiseEvent(e);
}

// The user has entered a new set value for cool air flow
void enterCoolAirEvent( float f )
{
		// We have to leave AUTO mode, bacause the controller would override the manually set values
////	19.03.2013 switchMode( EXTEST );
      switchMode(DIAGNOSE_AIR);	
		// Set the value at valve
		_event<float> e( "Aggregate", CEventNames::VALVE_1_SET, f);
		EventManager.RaiseEvent(e);
}

// The user has entered a new set value for warm air flow
void enterWarmAirEvent( float f )
{
		// We have to leave AUTO mode, bacause the controller would override the manually set values
////	19.03.2013 switchMode( EXTEST );
      switchMode(DIAGNOSE_AIR);	

		// Set the value at valve
		_event<float> e( "Aggregate", CEventNames::VALVE_2_SET, f);
		EventManager.RaiseEvent(e);
}


void toggle_standby_modeEvent( bool b )
{
    if (mode==GOSTANDBY || mode==STANDBY)
    {
      ExitStandbyMode(); // Standby-Mode deaktivieren
    }
    else
    {
 			GoToStandbyMode(); // Standby-Mode aktivieren
		}
}


void toggle_enabled_modeEvent( bool b )
{
    if ( mode==DISABLED )
    {
       switchMode(BOOT); // Enable aggregate, go to BOOT, which is the only way out of DISABLED
        SysInit::m_usersettings.SystemEnabled = true;
    }
    else
    {
 	  switchMode(DISABLED); // Disable aggregate
        p_CPData->ResetErrors();
        SysInit::m_usersettings.SystemEnabled = false;
    }
    SysInit::SaveUserSettings(SysInit::GetUserSettings());
}


/**
 * Sets standby mode
 *
 * Replaces set_standby_modeEvent, which has been rewritten
 * to toggle_standby_modeEvent to support new GUI for
 * User_Config_1.
 *
 * @param b: true - enters STANDBY, false - leaves STANDBY
 */
void set_standby_mode ( bool b )
{
	switch ( mode )
	{
	case GOSTANDBY:
	case STANDBY:
		// Toggle standby mode, if we are in STANDBY or GOSTANDBY and have to leave
		if (b==false)
		{
			_event<bool> e( "Aggregate", CEventNames::toggle_standby_mode, true);
			EventManager.RaiseEvent(e);
		}
		break;
	default:
		// Toggle standby mode, if we are not in STANDBY or GOSTANDBY and have to enter
		if (b==true)
		{
			_event<bool> e( "Aggregate", CEventNames::toggle_standby_mode, true);
			EventManager.RaiseEvent(e);
		}
		break;
	}
}

/**
 * Sets purge mode
 *
 * Replaces set_purge_modeEvent, which has been rewritten
 * to toggle_purge_modeEvent to support new GUI for
 * User_Config_1.
 *
 * @param b: true - enters PURGE, false - leaves PURGE
 */
void set_purge_mode ( bool b )
{
	switch ( mode )
	{
	case PURGE:
		// Toggle standby mode, if we are in PURGE and have to leave
		if (b==false)
		{
			_event<bool> e( "Aggregate", CEventNames::toggle_purge_mode, true);
			EventManager.RaiseEvent(e);
		}
		break;
	default:
		// Toggle purge mode, if we are not in PURGE and have to enter
		if (b==true)
		{
			_event<bool> e( "Aggregate", CEventNames::toggle_purge_mode, true);
			EventManager.RaiseEvent(e);
		}
		break;
	}
}

/**
 * Sets defrost mode
 *
 * Replaces set_defrost_modeEvent, which has been rewritten
 * to toggle_defrost_modeEvent to support new GUI for
 * User_Config_1.
 *
 * @param b: true - enters MDEFROST, false - leaves MDEFROST
 */
void set_defrost_mode ( bool b )
{
	switch ( mode )
	{
	case MDEFROST:
		// Toggle defrost mode, if we are in MDEFROST and have to leave
		if (b==false)
		{
			_event<bool> e( "Aggregate", CEventNames::toggle_defrost_mode, true);
			EventManager.RaiseEvent(e);
		}
		break;
	default:
		// Toggle defrost mode, if we are not in MDEFROST and have to enter
		if (b==true)
		{
			_event<bool> e( "Aggregate", CEventNames::toggle_defrost_mode, true);
			EventManager.RaiseEvent(e);
		}
		break;
	}
}


/*****************************************************************************
* Function name: GoToStandbyMode
* Description: If the Chuck Temperature (PV=Present Value) is above +40�C or
*              below +15�C the set the Set Temperature (Sollwert) to 25�C bevor
*              switching the Compressor and Heating power off. The routine sets
*              Mode to GOSTANDBY
*
*******************************************************************************/
void GoToStandbyMode(void)
{
    if(p_CPData->getTemp3(iOffsettTable) < 15.0 || p_CPData->getTemp3(iOffsettTable) > 40.0)
    {
      p_CSetup->getTempParamSet(1)->setSetTemp( 25.0 );
     _event<float> e( "aggregat", CEventNames::set_temp1_changed, 25.0 );
      EventManager.RaiseEvent(e);
    }
     switchMode( GOSTANDBY );
}
/*****************************************************************************
* Function name: ExitStandbyMode
* Description: Restores normal working conditions
*
*******************************************************************************/
void ExitStandbyMode(void)
{
    p_CPData->setOnMains(1);
    p_Lambdas[4]->SetOn();
    p_Lambdas[5]->SetOn();
    switchMode( AUTO );
}
void set_con_mode_standardEvent( bool b )
{
    bAllowStandard = true;
    bAllowLowNoise = false;
    SysInit::m_usersettings.TemperatureControlMode = E_STANDARD_CONTROL;
    SysInit::SaveUserSettings(SysInit::GetUserSettings());
}

void set_con_mode_progressiveEvent( bool b )
{
    bAllowStandard = false;
    bAllowLowNoise = false;
    SysInit::m_usersettings.TemperatureControlMode = E_PROGRESSIVE_CONTROL;
    SysInit::SaveUserSettings(SysInit::GetUserSettings());
}

void set_con_mode_lnoiseEvent(bool b)
{
    bAllowStandard = true;
    bAllowLowNoise = true;
    SysInit::m_usersettings.TemperatureControlMode = E_LOWNOISE_CONTROL;
    SysInit::SaveUserSettings(SysInit::GetUserSettings());
}

void new_dewpoint_offsettEvent( float f )
{
	fDewPointOffset = f;

  SysInit::m_usersettings.DewpointTrackingOffset = f;
  SysInit::SaveUserSettings(SysInit::m_usersettings);
}

void set_DewPointActivateEvent( bool state)
{
    SysInit::m_usersettings.DewpointTrackingActive = state;
    SysInit::SaveUserSettings(SysInit::m_usersettings);
}
extern int cc_toggle;


void toggleText(_string & Text)
{
  if( cc_toggle == 0)
  {
    Text += " >";
  }
  else
  {
     Text += " <";
  }
}

void DSPLTask(void *pvParameters)
{
    static int iTimer = 0;

    // Vorzunehmende Initialisierungen:
    pDisplaymanager = &displaymanager;
		pDisplaymanager->Init();

    pDevicemanager = &device_manager;
    pDevicemanager->Init("device_manager");

    pDewPointSensor->Init();

    CErrorMessages * pErrorMsgs = new CErrorMessages( &EventManager );  //Fehlermeldungsobjekt anlegen
    pErrorMsgs->Init();                                                 //Objekt Intialisieren

		EventManager.AddEventHandler( CEventNames::toggle_purge_mode, toggle_purge_modeEvent );
		EventManager.AddEventHandler( CEventNames::toggle_defrost_mode, toggle_defrost_modeEvent );
    EventManager.AddEventHandler( CEventNames::get_all_comp_tables, getAllOffsettTables);
    EventManager.AddEventHandler( CEventNames::send_table1, sendTable1Event );
    EventManager.AddEventHandler( CEventNames::send_table2, sendTable2Event );
    EventManager.AddEventHandler( CEventNames::send_table3, sendTable3Event );
    EventManager.AddEventHandler( CEventNames::set_active_comp_table, set_active_comp_tableEvent );
    EventManager.AddEventHandler( CEventNames::user_entered_diag, enterDiagEvent );
    EventManager.AddEventHandler( CEventNames::user_left_diag, leftDiagEvent );
    EventManager.AddEventHandler( CEventNames::hit_power_suppply_1_set_voltage, enterPower1Event );
    EventManager.AddEventHandler( CEventNames::hit_power_suppply_2_set_voltage, enterPower2Event );
    EventManager.AddEventHandler( CEventNames::hit_cool_air_value, enterCoolAirEvent );
    EventManager.AddEventHandler( CEventNames::hit_warm_air_value, enterWarmAirEvent );
    EventManager.AddEventHandler( CEventNames::toggle_standby_mode, toggle_standby_modeEvent );
    EventManager.AddEventHandler( CEventNames::toggle_enabled_mode, toggle_enabled_modeEvent );
    EventManager.AddEventHandler( CEventNames::set_con_mode_standard, set_con_mode_standardEvent );
    EventManager.AddEventHandler( CEventNames::set_con_mode_progressive, set_con_mode_progressiveEvent );
    EventManager.AddEventHandler( CEventNames::set_con_mode_lnoise, set_con_mode_lnoiseEvent );
    // 10.07.2012 PM Added Dewpoint activate event
    EventManager.AddEventHandler( CEventNames::set_active_dewpoint, set_DewPointActivateEvent );
    // 20.02.2013 KM Added new Dewpoint value event
    EventManager.AddEventHandler( CEventNames::new_dewpoint_offsett, new_dewpoint_offsettEvent );
  //   EventManager.AddEventHandler( CEventNames::set_active_dewpoint, set_DewPointActivateEvent );


    while(1)
    {
	static bool toggle_status = true; // Used by several display elements to toggle each loop cycle

				//static size_t hsize = xPortGetFreeHeapSize();

        EventManager.HandlePID();
        pDevicemanager->cycCalc();
        pDisplaymanager->cycCalc();     //Display Manager �ffters aufrufen
        pDewPointSensor->cycCalc();

        if( mode == DISABLED)
          pErrorMsgs->reset_all_errors_Event(0);
        else pErrorMsgs->cycCalc();

        if( p_CSetup->bIsValid() ){
            if( iTimer > 30 )
						{
                iTimer = 11;
								toggle_status = !toggle_status;
            }
            else if( iTimer == 0 ){
                _set_limits_EventArgument a;
                a.limitMax = SysInit::m_usersettings.ChuckTempMaxLimit;
                a.limitMin = SysInit::m_usersettings.ChuckTempMinLimit;
                _event<_set_limits_EventArgument > e( "aggregate", CEventNames::set_limits_1, a );
                EventManager.RaiseEvent(e);
            }
            else if( iTimer == 2 ){
                 _set_limits_EventArgument a;
                a.limitMax = 100;
                a.limitMin = 0;
                _event<_set_limits_EventArgument > e( "aggregate", CEventNames::set_power_supply_1_voltage_limits, a );
                EventManager.RaiseEvent(e);
                _event<_set_limits_EventArgument > e1( "aggregate", CEventNames::set_power_supply_2_voltage_limits, a );
                EventManager.RaiseEvent(e1);

            }
            else if( iTimer == 3 ){
                //==============================================================================
                // Die Versionsnummer usw. auf dem Hauptmenue setzen (Darstellung erfolgt dann automatisch):
                //(Sollte noch keine Version gesendet sein befindet sich an der betreffenden Stelle nichts)
                _event<_string> e( "aggregat", CEventNames::set_version_info, _string(REV));
                EventManager.RaiseEvent( e );
								// Trigger Ausgabe der IP-Adresse auf dem Display
								_event<bool> e4( "aggregat", CEventNames::set_ip_info, true);
								EventManager.RaiseEvent( e4 );
                //Temperaturkompensation
                _event<void*> e1( "aggregat", CEventNames::receive_table1, p_CSetup->getOffsetTable(1) );
                _event<void*> e2( "aggregat", CEventNames::receive_table2, p_CSetup->getOffsetTable(2) );
                _event<void*> e3( "aggregat", CEventNames::receive_table3, p_CSetup->getOffsetTable(3) );
                EventManager.RaiseEvent(e1);
                EventManager.RaiseEvent(e2);
                EventManager.RaiseEvent(e3);
            }
            else if( iTimer == 5 ){
                // TODO: 10.07.2012 PM user settings should be set and saved from well definied functions
                /*    _event<bool> b("aggregat", CEventNames::set_con_mode_lnoise, true );
                EventManager.RaiseEvent(b); */
                //Anpassung des User-Config-Menues durch Ein- und Ausblenden von Menuebuttons:
                _two_params<int, int> p;
                p.p1 = 0;
                p.p2 = p_CSetup->getScreenStatus( CSetup::_s_config::_s_screens::HS );
                _event< _two_params<int,int> > e( "aggregat", CEventNames::config_window_activation, p );
                EventManager.RaiseEvent(e);
            }
            else if( iTimer == 6 ){
              _two_params<int, int> p;
              p.p1 = 1;
              p.p2 = p_CSetup->getScreenStatus( CSetup::_s_config::_s_screens::CDCS );
              _event< _two_params<int,int> > e( "aggregat", CEventNames::config_window_activation, p );
              EventManager.RaiseEvent(e);
            }
            else if( iTimer == 7 ){
              _two_params<int, int> p;
              p.p1 = 2;
              p.p2 = p_CSetup->getScreenStatus( CSetup::_s_config::_s_screens::TDC );
              _event< _two_params<int,int> > e( "aggregat", CEventNames::config_window_activation, p );
              EventManager.RaiseEvent(e);
            }
            else if( iTimer == 8 ){
              _two_params<int, int> p;
              p.p1 = 3;
              p.p2 = p_CSetup->getScreenStatus( CSetup::_s_config::_s_screens::SCC );
              _event< _two_params<int,int> > e( "aggregat", CEventNames::config_window_activation, p );
              EventManager.RaiseEvent(e);
            }
            else if( iTimer == 9 ){
              _two_params<int, int> p;
              p.p1 = 4;
              p.p2 = p_CSetup->getScreenStatus( CSetup::_s_config::_s_screens::TC );
              _event< _two_params<int,int> > e( "aggregat", CEventNames::config_window_activation, p );
              EventManager.RaiseEvent(e);
            }
           else if( iTimer == 10 )
           {
               _event<float> e( "aggregate", CEventNames::new_dewpoint_offsett, fDewPointOffset );
               EventManager.RaiseEvent(e);
           }
            else if( iTimer == 11 )
            {
              _two_params<int, int> p;
              p.p1 = 5;
              p.p2 = 1;
              _event< _two_params<int,int> > e( "aggregate", CEventNames::config_window_activation, p );
              EventManager.RaiseEvent(e);
           }
					 /**
					  * Display of COOLING / EVEN/ HEATING symbol
					  *
					  * Even symbol is blinking, as long as controller is not stable or in hold mode
					  */
						else if( iTimer == 20 )
						{
							// Default event is a even (green '=') status display
						 	_event<_string> e1( "aggregate", CEventNames::status_temp_1, "even");

							// Compute the current status aut of controller states and mofify the event if different
							if (bHoldMode)
							{
									// Hold mode
									// We render a blinking "even" in status display
									if ( toggle_status ) e1.modifyParameter("blank");
							}
							else if( (mode==AUTO || mode==MDEFROST || mode==GOSTANDBY || mode==PURGE) && p_con1 != NULL )
							{
								switch( p_con1->getMode() )
								{
								case 1:
									// Heating
									e1.modifyParameter("heating");
									break;
								case 2:
									// Cooling
									e1.modifyParameter("cooling");
									break;
								case 0:
									// Controlling
									// Blink as long as controller is controlling but not stable
									//if ( toggle_status && !p_con1->isStable()) e1.modifyParameter("blank");
                                                      if ( toggle_status && !bCtrlFine) e1.modifyParameter("blank");
									break;
								}
							}
							// Any other case: grey, blank status element
							else e1.modifyParameter("blank");

							// Display the computed status
							EventManager.RaiseEvent(e1);
           }
           else if( iTimer == 21 )
					 {
							//�ndern des "Contoller-Status"
							_string s;
							char cMsg[3];
							if( evalERSMessages(cMsg))
							{
									s = "ERROR ";
									s += cMsg ;
							}
							else
                                          {
                                	      evalControlStatus( s );

							}
                                                                                 peerSys =  p_ChillerCom->GetPeerStatus();
                                             if( (peerSys.controller == false)&&(chillerclient_connected_status() == 2)) // we are responsible
                                               toggleText(s);

							_event<_string> e( "aggregate", CEventNames::controller_status, s );
							EventManager.RaiseEvent(e);
            }
            else if( iTimer == 22 ){
                //--------------------------------------------------------------
                // Eine Hinweismeldung im Hauptmenu droppen
                char cMsg[3];
                if( evalERSMessages(cMsg) && false){
                    _string s("");
                    s += " ERROR ";
                    s += cMsg;
                    _event<_string> e( "aggregate", CEventNames::drop_infomessage, s );
                    EventManager.RaiseEvent(e);
                }
            }
            else if( iTimer == 23 && false ){
                char msgs[20][4] = {0};
                char m[4] = {0};
                int iNum;
                static bool bDropped = false;
                evalERSMessages( m, msgs, &iNum );
                if( !bDropped &&  msgs[0][0] != 0 ){
                    _string s("");
                    for( int i = 0; i < 20 && msgs[i][0] == '0'; i++ )
                    {
                        s += " ERROR ";
                        s += msgs[i];
                        s += "#";
                    }
                    _event<_string> e( "aggregate", CEventNames::drop_errormessage, s );
                    EventManager.RaiseEvent(e);
                    bDropped = true;
                }
                if( bDropped && msgs[0][0] == 0 )
                {
                    _event<bool> b("aggregate", CEventNames::remove_errormessage, true );
                    EventManager.RaiseEvent(b);
                    bDropped = false;
                }
            }
            else if( iTimer == 24 )
						{
                if( p_CDiagCom->IsDisplayUpdate() || display_update_flag ){
                    _event<bool> b( "aggregate", CEventNames::display_update, true );
                    EventManager.RaiseEvent(b);
                    p_CDiagCom->DipslayUpdateDone();
                    display_update_flag = 0;
                }
            }
            else if( iTimer == 25 && cMacConfigDone != 0 )
            {
                cMacConfigDone = 0;
                u32 p[2];
                GetEThernetMachAddress(p);
                long macL = p[0];
                long macH = p[1];

              //  long macL =  ENET_MAC->MAL;
              //  long macH =  ENET_MAC->MAH;
                int cMac[] = { ( macH >> 8 ) & 0xff, macH & 0xff, (macL >> 24 ) & 0xff, (macL >> 16) & 0xff, (macL >> 8) & 0xff, macL & 0xff };
                MAC_Id = cMac[1] + cMac[0];

                sprintf( sMac, "%02X-%02X-%02X-%02X-%02X-%02X", cMac[5], cMac[4], cMac[3],cMac[2],cMac[1],cMac[0] );
                //Die anzuzeigende Netzwerkadresse, es kann ein beliebiger string sein,
                //denn er wird direkt angezeigt und nicht weiter verarbeitet
                _event<_string> s( "aggreate", CEventNames::set_network_mac, sMac );
                EventManager.RaiseEvent(s);
            }
            else if( iTimer == 26 ){
                _event<float> e("aggregate", CEventNames::NEW_DEWPOINT, pDewPointSensor->getDewPoint());
                EventManager.RaiseEvent(e);
            }
            else if( iTimer == 28 )
            {
              //--------------------------------------------------------------
              //�ndern der aktuellen Kompensierten Temperatur 1,2,3 oder 4
              _event<float> e("aggregate", CEventNames::temp_1_comp, p_CPData->getTemp3(iOffsettTable));
              EventManager.RaiseEvent(e);
            }
            iTimer++;
        }
        else
        {
            iTimer = 0;
        }
        vTaskDelay (5);
    }
}

void GetEThernetMachAddress(u32 *addr)
{
      u32 MACLW;
      u32 MACHW;
      u8 xAddr[6];


     MACHW = FMI_ReadOTPData( FMI_OTP_WORD_4 );
     MACLW = FMI_ReadOTPData( FMI_OTP_WORD_5 );

     xAddr[ 0 ] =  (MACHW >>  0) & 0xFF;
     if(xAddr[0]  != 00 )
     {
        MACHW = FMI_ReadOTPData( FMI_OTP_WORD_6 );
        MACLW = FMI_ReadOTPData( FMI_OTP_WORD_7 );
     }

    /* Configure the MAC address in the uIP stack. */
    xAddr[ 0 ] = (MACHW >>  0) & 0xFF;
    xAddr[ 1 ] = (MACHW >>  8) & 0xFF;
    xAddr[ 2 ] = (MACHW >> 16) & 0xFF;
    xAddr[ 3 ] = (MACHW >> 24) & 0xFF;
    xAddr[ 4 ] = (MACLW >>  0) & 0xFF;
    xAddr[ 5 ] = (MACLW >>  8) & 0xFF;

    addr[0] = ( xAddr[3] << 24 ) | ( xAddr[2] << 16 ) | ( xAddr[1] << 8 ) | ( xAddr[0] );
    addr[1] = ( xAddr[5] << 8 ) | ( xAddr[4] );


}

/**
 * Controller Status is a mixture of intermediate or special modes as BOOT, STOP, ..., the possible
 * PID-modes during AUTO-mode as HOLD, COOLING, and Alarms and Erros
 */
void evalControlStatus( _string & Text )
{
  controlstatus = p_con1->GetControlReadyStatus();// Get Ready Status

  if( mode == DISABLED )
  {
    Text = "DISABLED";
  }
  else if( mode == BOOT )
  {
    Text = "BOOT";
  }
  else if( mode == INIT )
  {
    Text = "INIT";
  }
  else if( mode == IDLE )
  {
    Text = "IDLE";
  }
  else if( mode == GOSTANDBY ){
    Text = "GO STANDBY";
  }
  else if( mode == PURGE ){
    Text = "PURGE";
  }
  else if( mode == MDEFROST ){
    Text = "DEFROST";
  }
  else if( mode == STOP ){
    Text = "STOP";
  }
  else if( mode == STANDBY ){
    Text = "STANDBY";
  }
  else if( mode == STANDBY ){
    Text = "STANDBY";
  }
  else if( mode == SERROR ){
    Text = "!!!--ERROR--!!!";
  }
	else if( bHoldMode )
  {
      Text = "HOLD MODE";
  }
  else if(  controlstatus  == 1 ){
    Text = "HEATING";
  }
   else if( controlstatus  == 2 ){
    Text = "COOLING";
  }
  else
	{
  	Text = "CONTROLLING";
  }
  if( bDewPointWarning )
  {
     Text = "DEWP WARNING";
  }
  if(  bDewPointAlarm)
  {
    Text = "DEWP ALARM 2";
}
}

/**

*/
bool evalERSMessages( char * pMsg ){
    int i;
    return evalERSMessages( pMsg, (void*)0,  &i);
}

bool evalERSMessages( char * pMsg, void * dstBuf, int * pMsgNum ){
    char msgs[20][4] = {0};
    int iECNum[20] = {0};
    static int iTimer = 20;
    static int iOffsett = 0;
    bool bNError = false;


    int iErrorCount = 0;

    if( mode == DISABLED )
    {
      p_CPData->ResetErrors();
      return false;
    }
    if (pCOverTemperatureSensor == NULL) pCOverTemperatureSensor = pDevicemanager->GetDeviceHandle("uebertemperatur_sensor");


    if( !p_CSetup->getExtChiller() && b_is_lany_detected )
		{
/*        if( p_CPData->getVErrorStatus(1).cFlags != 0 ){
            iECNum[iErrorCount] = 20;
            strcpy( msgs[iErrorCount++],"020");
        }
        if( p_CPData->getVErrorStatus(2).cFlags != 0 ){
            iECNum[iErrorCount] = 21;
            strcpy( msgs[iErrorCount++],"021");
        }*/
    }

    uTError TError = p_CPData->getTErrorStatus(3);
    if( TError.cFlags != 0 )
		{
        if( TError.b.URange == 1 )
				{
#ifndef TUEV
					// Inkonsistent: wenn Fehler 004 (Chuckcable), dann wird dieses Flag gesetzt, aber
					// der Fehler in der Liste nicht angezeigt, siehe CDataContainers.cpp, Zeile 232:
					// " else if( iSensNum > 4 && ((lIVal - lSVal <= 0) || (lIVal >= 0x7FFFFE00) || (lIVal <= 0))){ "
					// Deswegen wollen wir ihn auch nicht im Status-Feld sehen (f�r T�V). In einem funktionierenden
					// ErrorManagement muss in Zusammenhang mit Fehler 004 ausgewertet werden.
            iECNum[iErrorCount] = ERR_UNDER_TEMP;
						sprintf(msgs[iErrorCount++],"%03d",ERR_UNDER_TEMP);

            p_ChillerCom->setMErr( ERR_UNDER_TEMP );
            //bNError = true;
#endif
        }
				else if( TError.b.WireBreak == 1 )
				{
            iECNum[iErrorCount] = ERR_CHUCKCABLE;
						sprintf(msgs[iErrorCount++],"%03d",ERR_CHUCKCABLE);
            p_ChillerCom->setMErr( ERR_CHUCKCABLE );
				}
        else if( TError.b.Hold == 1 )
				{
            iECNum[iErrorCount] = ERR_ADC;
						sprintf(msgs[iErrorCount++],"%03d",ERR_ADC);
            p_ChillerCom->setMErr( ERR_ADC );
            //bNError = true;
        }
        else if( TError.b.ORange == 1)
				{
            iECNum[iErrorCount] = ERR_OVER_TEMP;
						sprintf(msgs[iErrorCount++],"%03d",ERR_OVER_TEMP);
            p_ChillerCom->setMErr( ERR_OVER_TEMP );
            bNError = true;
        }
    }

    if( p_Lambdas[4]->getError().cFlags != 0 )
		{
        if( p_Lambdas[4]->getError().b.oCurr == 1 )
				{
            iECNum[iErrorCount] = 61;
            strcpy( msgs[iErrorCount++],"061");
            p_ChillerCom->setMErr( 61 );
            bNError = true;
        }
        else if(p_Lambdas[4]->getError().b.pDefect == 1 )
				{
            iECNum[iErrorCount] = 62;
            strcpy( msgs[iErrorCount++],"062");
            p_ChillerCom->setMErr( 62 );
            bNError = true;
        }
        else if(p_Lambdas[4]->getError().b.uCurr  == 1)
				{ // no additional erros yet
            iECNum[iErrorCount] = 63;
            strcpy( msgs[iErrorCount++],"063");
            p_ChillerCom->setMErr( 63 );
            bNError = true;
    	}
    }

    if( p_Lambdas[5]->getError().cFlags != 0 )
		{
        if( p_Lambdas[5]->getError().b.oCurr == 1 )
				{
            iECNum[iErrorCount] = 81;
            strcpy( msgs[iErrorCount++],"081");
            p_ChillerCom->setMErr( 81 );
            bNError = true;
        }
        else if(p_Lambdas[5]->getError().b.pDefect == 1)
				{
            iECNum[iErrorCount] = 82;
            strcpy( msgs[iErrorCount++],"082");
            p_ChillerCom->setMErr( 82 );
            bNError = true;
        }
        else if(p_Lambdas[5]->getError().b.uCurr  == 1)
				{ // no additional erros yet
            iECNum[iErrorCount] = 83;
            strcpy( msgs[iErrorCount++],"083");
            p_ChillerCom->setMErr( 83 );
            bNError = true;
    	}
    }

    if( p_CPData->getTErrorStatus(6).cFlags )
		{
        iECNum[iErrorCount] = ERR_INT_TEMP;
        strcpy( msgs[iErrorCount++],"070");
        p_ChillerCom->setMErr( ERR_INT_TEMP );
        bNError = true;
    }

    if( gcMemException == 1 )
    {
        iECNum[iErrorCount] = 98;
        strcpy( msgs[iErrorCount++],"098");
        p_ChillerCom->setMErr( 98 );
    }
    if( gcMemException == 2 )
    {
        iECNum[iErrorCount] = 99;
        strcpy( msgs[iErrorCount++],"099");
        p_ChillerCom->setMErr( 99 );
    }

//    if( p_ChillerCom->getError() == 8 && p_CSetup->getExtChiller() && b_is_lany_detected){
//        iECNum[iErrorCount] = 8;
//        strcpy( msgs[iErrorCount++],"008");
//    }


		/**
		 * CHILLER COMM ERROR DISPLAY
		 */
    if((Cooling_Sub_Sys == E_COOLING_SUBSYS_EXT_CHILLER)&& p_ChillerCom->comErr() )
		{
                        iECNum[iErrorCount] =  p_ChillerCom->getComErrNum();
				sprintf(msgs[iErrorCount++],"%03d",p_ChillerCom->getComErrNum());
		}

		/**
		 * THERMAL-CUTOUT ERROR DISPLAY
		 */
    if( pCOverTemperatureSensor->getError() )
		{
       	iECNum[iErrorCount] = THERMAL_CUT_OUT;
				sprintf(msgs[iErrorCount++],"%03d",THERMAL_CUT_OUT);
        p_ChillerCom->setMErr( THERMAL_CUT_OUT );
		}

		/**
		 *  DEWPOINT ERROR DISPLAY
		 *
		 * \todo b_is_lany_detected ist hier falsch??? Kl�ren
		 */
    if(p_CSetup->getConConfig()== CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600)
    {
       if(  dual_chiller_error >= 0)
       {
            if( dual_chiller_error == 1 ) // error set
            {
               dual_chiller_error = 2; // signaled.
                error_button_clicked = false;
               _event<int> e("aggregate", CEventNames::set_error, ERR_CHILLER_ERR );
               EventManager.RaiseEvent(e);
            }
            else if( (dual_chiller_error == 2)&&(error_button_clicked == true)) // error reset
            {
                error_button_clicked = false;
                chillerclient_reset_alarm();
                _event<int> e("aggregate", CEventNames::reset_error,ERR_CHILLER_ERR );
                EventManager.RaiseEvent(e);
                dual_chiller_error = 3;
             }
        }

    }

    if( ((Cooling_Sub_Sys == E_COOLING_SUBSYS_INT_CHILLER)||(Cooling_Sub_Sys == E_COOLING_SUBSYS_EXT_CHILLER))|| (p_CSetup->getConConfig() == CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600 ) )
    {
        if ( p_CSetup->getOptionDewPoint() && SysInit::m_usersettings.DewpointTrackingActive )
        {
            if( pDewPointSensor->getDPError() )
            {
                iECNum[iErrorCount] = ERR_DEWP_SENSOR;
                sprintf(msgs[iErrorCount++],"%03d",ERR_DEWP_SENSOR);
                p_ChillerCom->setMErr( ERR_DEWP_SENSOR );

                // Inform system about setting of error
                _event<int> e("aggregate", CEventNames::set_error, ERR_DEWP_SENSOR );
                EventManager.RaiseEvent(e);
                bDPSensor_Err = true;
            }
            else if( bDPSensor_Err )
            {   // Inform system that error disappeared
                _event<int> e("aggregate", CEventNames::reset_error, ERR_DEWP_SENSOR );
                EventManager.RaiseEvent(e);
                bDPSensor_Err = false;
            }
            if( bDewPointAlarm  )
            {
                iECNum[iErrorCount] = ERR_DEWP_ALARM_2;
                sprintf(msgs[iErrorCount++],"%03d",ERR_DEWP_ALARM_2);

                // Inform system about setting of error
                _event<int> e("aggregate", CEventNames::set_error,ERR_DEWP_ALARM_2 );
                EventManager.RaiseEvent(e);
                bDPAlarm_Err = true;
            }
            else  if( bDPAlarm_Err )
            {// Inform system that error disappeared
                _event<int> e("aggregate", CEventNames::reset_error,ERR_DEWP_ALARM_2 );
                EventManager.RaiseEvent(e);
                bDPAlarm_Err = false;
            }
        }
        else
        {
           if( bDPSensor_Err )
            {   // Inform system that error disappeared
                _event<int> e("aggregate", CEventNames::reset_error, ERR_DEWP_SENSOR );
                EventManager.RaiseEvent(e);
                bDPSensor_Err = false;
            }
        }
        int chErr = p_ChillerCom->getErrorStatus();
        if(  chErr >= 0)
        {
            if( chErr == 1 ) // error set
            {
               _event<int> e("aggregate", CEventNames::set_error, p_ChillerCom->getComErrNum() );
               EventManager.RaiseEvent(e);
               p_ChillerCom->setErrorStatus(2); // Error event raised.
            }
            else if( chErr == 3) // error reset
            {
               _event<int> e("aggregate", CEventNames::reset_error, p_ChillerCom->getComErrNum() );
               EventManager.RaiseEvent(e);
               p_ChillerCom->setErrorStatus(0); // reset Error Status.
            }
        }
    }
    if( iTimer-- < 0 ){
        if( ++iOffsett >= iErrorCount ){
            iOffsett = 0;
        }
        iTimer = 5;
    }

    if( bNError && dstBuf != 0 && iErrorCount > 0 ){
        memcpy( dstBuf, msgs, sizeof( msgs ));
    }


    if( iErrorCount > 0 ){
        strcpy ( pMsg, msgs[iOffsett]);
        *pMsgNum = iECNum[iOffsett];
        return true;
    }
    else{
        p_ChillerCom->setMErr( 0 );
        return false;
    }
}
/*******************************************************************************
* Method Name  	 : InitializeUserSettings
* Description    : Initializes the UserSettings that are read from a Settings.ini file.
*
*
* Input          : None
* Output         : None
* Return         : None
*
*******************************************************************************/
void InitializeUserSettings(void)
{
    UserSettings us = SysInit::GetUserSettings();
    bAllowStandard = false;
    bAllowLowNoise = false;

    switch(us.TemperatureControlMode)
    {
        case  E_STANDARD_CONTROL:
            bAllowStandard = true;
        break;

        case E_LOWNOISE_CONTROL:
              bAllowStandard = true;
              bAllowLowNoise = true;
        break;

        case E_PROGRESSIVE_CONTROL:
        break;
    }

    fDewPointOffset = us.DewpointTrackingOffset;
    iOffsettTable = us.ActiveTemperatureOffsetTable;
    if ( !p_CSetup->getOptionDewPoint() )
	SysInit::m_usersettings.DewpointTrackingActive = false;

}


void SetTemp1ChangedEventPIDTask( float f )
{   
    if(!float_equal(fSetTemp,f,1) )// Settemperature has changed
    {
        fSetTemp = f;
        if( p_CSetup->getPIDSetup(1)->Tn == 9800)
        {
            p_con1->SetControlReadyStatus(fSetTemp,p_CPData->getTemp3(iOffsettTable));
            switch(p_con1->GetControlReadyStatus())
            {
                case 2: // cooling
                    delay_current = true;
                break;
                case 1: 
                    delay_current = false;
                break;
            }
        }
        else
           delay_current = false;
       wasCooling = 0;  
    }
}
#define PID_OPTIMAL_ABS_CURRENT   1.2  // 1.2A
#define PID_OPTIMAL_REL_CURRENT   (PID_OPTIMAL_ABS_CURRENT / p_CSetup->getCurrLimit(1) * 100.0)
#define HEAT_APPROACH_THRESHOLD   2.0  // 2.0 Degree before set temp, we change from heating to heat approach and vice versa
#define COOL_APPROACH_THRESHOLD   1.2  // 1.2 Degree before set temp, we change from cooling to cool approach and vice versa
#define HOT_FLOW_TEMP_LIMIT	    15.0	 // Temperature in �C. If chuck temp is above that limit, we dont use hot air for heating
#define HOLD_MODE_EXIT_TEMPDIFF   5.0	 // Temperature difference, at which we leave hold mode
#define PID_STABLE_TO_HOLD_TIME 120.0  // Time in seconds the controller has to be stable before we change to hold mode

#define DUALCOOL_APPROACH_THRESHOLD 0.5
#define SLOW_COOL_APPROACH_THRESHOLD 0.15

void PID_Task( void *pvParameters )
{
 /*
      static long lCycleTime, lOSOldTime;  // Variables to compute cycle time
      static PID_STATE xPidState = CONTROLLING;

      sAirValue sAirSetup;
      float fSetTemp  = 0.0;
      float fAirValue = 0.0;
      float fFlowCold = 0.0;
      float fFlowHot  = 0.0;
      float fMax 			= 100.0;
      float fHoldIIR  = 0.0;
 */
      float fConAirSet;
      float fConAirPre;

      float fMaxCurrSlope = 0.01 / p_CSetup->getCurrLimit(1) * 100.0;  // Maximal cuurent change: 10mA/s. We compute the relative value here
      float fTempDiff = 0.0;
      bool controlValve = false;

	// Add event handlers, dependent on aggregates configuration
  if( (p_CSetup->getConConfig() <= CSetup::_s_config::E_PROP_VALVE_SWS_D600 )||
    ( p_CSetup->getConConfig() == CSetup::_s_config::E_CONTOLLER_SP102Y2D) ||
    (p_CSetup->getConConfig() == CSetup::_s_config::E_CONTOLLER_SP102Y2M) )
  {
                // We work with LANY prop valve
        EventManager.AddEventHandler( CEventNames::VALVE_1_SET, m_lany1.ValvePValueEventWrapper, &m_lany1);
        EventManager.AddEventHandler( CEventNames::VALVE_1_ADC2, m_lany1.ValveADCInEventWrapper, &m_lany1);
        EventManager.AddEventHandler( CEventNames::VALVE_1_ADC1, m_lany1.ValveADCOutEventWrapper, &m_lany1);
  }
  else
  {
                // We work with Joumatic valves
        EventManager.AddEventHandler( CEventNames::VALVE_1_SET,  CJoucomaticValve::ValvePValueEventWrapper, &m_jouco1);
        EventManager.AddEventHandler( CEventNames::VALVE_1_ADC2, CJoucomaticValve::ValveADCInEventWrapper,  &m_jouco1);
        EventManager.AddEventHandler( CEventNames::VALVE_1_ADC1, CJoucomaticValve::ValveADCOutEventWrapper, &m_jouco1);
        EventManager.AddEventHandler( CEventNames::VALVE_2_SET,  CJoucomaticValve::ValvePValueEventWrapper, &m_jouco2);
        EventManager.AddEventHandler( CEventNames::VALVE_2_ADC2, CJoucomaticValve::ValveADCInEventWrapper,  &m_jouco2);
        EventManager.AddEventHandler( CEventNames::VALVE_2_ADC1, CJoucomaticValve::ValveADCOutEventWrapper, &m_jouco2);
    }
    EventManager.AddEventHandler(  CEventNames::set_hold_mode, set_hold_modeEvent);
    EventManager.AddEventHandler( CEventNames::set_temp1_changed, SetTemp1ChangedEventPIDTask );
    // Define events we will call during controlling to set actors
    _event<float> * p_event_settemp = new _event<float>( "aggregate", CEventNames::set_temp1_changed, 25.0);
    _event<float> * p_event_cold = new _event<float>( "AIRCON COLD", CEventNames::VALVE_1_SET, 0.0);
    _event<float> * p_event_hot = new _event<float>("AIRCON HOT", CEventNames::VALVE_2_SET, 0.0);
    _event<float> * p_event_setv5 = new _event<float>( "aggregate", CEventNames::set_power_suppply_5_set_voltage, 0.0);
    _event<float> * p_event_setv6 = new _event<float>( "aggregate", CEventNames::set_power_suppply_6_set_voltage, 0.0);

    // Wait, until Air-Table is loaded by any other task. We need it for controlling
    // PM. 05.12.2012:: This can cause hanging if the table file doesn't exist! Should be repalaced by a better method!
    while( !bAirTableLoaded ){
        vTaskDelay(10);
    }
    // Setup controllers
    p_CSetup->getTempParamSet(1)->setSetTemp(25.0);
    sAirSetup = p_AirTable->getAirValue(p_CSetup->getTempParamSet(1)->getSetTemp());
    fMax = p_AirTable->getAirValue(-100.0).fFlow;

    p_con1 = new PIDController( p_CSetup->getPIDSetup(1), false, fMaxCurrSlope, PID_OPTIMAL_REL_CURRENT );   // Rough current controller
    p_con2 = new PIDController( p_CSetup->getPIDSetup(2), false, 0, 0 );
    p_con3 = new PIDController( p_CSetup->getPIDSetup(3), false, 0, 0 );
    p_con4 = new PIDController( p_CSetup->getPIDSetup(4), false, 0.05, 50.0 );  // max slope after beeing stable: 0.05%, offset: 50%
    p_con5 = new PIDController( p_CSetup->getPIDSetup(5), false, 0, 0 );
    p_con6 = new PIDController( p_CSetup->getPIDSetup(6), false, 0.05, 0.5 );   // max slope after beeing stable: 0.05 (5%), offset: 0.5 (50%)

     // Now control within an endless loop
    while (1)
    {

        EventManager.HandlePID(); // Handle events
        p_CPData->cycCalc( 10 );// Trigger reading of ADC values

        // Calculate cycle time, the period this task is called
        lCycleTime = xTaskGetTickCount()-lOSOldTime;
        lOSOldTime = xTaskGetTickCount();

        // If we have any error of internal temperature, we go to save error state
        if( p_CPData->getTErrorStatus(6).cFlags != 0 )
        {
            switchMode( SERROR );
        }
				// Set actor states dependent on aggregates mode
				switch( mode )
				{
								case BOOT:
										// Switch off hot and cold air
										p_event_cold->modifyParameter(0.0);
										p_event_hot->modifyParameter(0.0);
										EventManager.RaiseEvent(p_event_cold);
										EventManager.RaiseEvent(p_event_hot);
				break;

				case INIT:
						p_event_settemp->modifyParameter(25.0);
						EventManager.RaiseEvent(p_event_settemp);

						// Set output of both Lamdas to zero
						p_event_setv5->modifyParameter(0.0);
						EventManager.RaiseEvent(p_event_setv5);
						p_event_setv6->modifyParameter(0.0);
						EventManager.RaiseEvent(p_event_setv6);

						// Let flow some cold air to measure chiller temp. Is required to leave init state
						p_event_cold->modifyParameter(80.0);
						EventManager.RaiseEvent(p_event_cold);
						p_event_hot->modifyParameter(0.0);
						EventManager.RaiseEvent(p_event_hot);
						break;

				case DISABLED:
                            p_event_setv5->modifyParameter(0.0);
                            p_event_setv5->modifyParameter(0.0);
                            EventManager.RaiseEvent(p_event_setv5);
                            p_event_setv6->modifyParameter(0.0);
                            EventManager.RaiseEvent(p_event_setv6);
                             p_event_hot->modifyParameter(0.0);
                             EventManager.RaiseEvent(p_event_hot);
                             p_event_cold->modifyParameter(0.0);
                             EventManager.RaiseEvent(p_event_cold);
                        break;
				case IDLE:
						// Set output of both Lamdas to zero
						p_event_setv5->modifyParameter(0.0);
						EventManager.RaiseEvent(p_event_setv5);
						p_event_setv6->modifyParameter(0.0);
						EventManager.RaiseEvent(p_event_setv6);

					// Hot air until chuck temperature >= 18�C, else no air
						p_event_cold->modifyParameter(0.0);
						EventManager.RaiseEvent(p_event_cold);
						if (p_CPData->getTemp3(iOffsettTable) < 18.0) p_event_hot->modifyParameter(100.0);
						else p_event_hot->modifyParameter(0.0);
                                    if(mode == DISABLED )p_event_hot->modifyParameter(0.0);
						EventManager.RaiseEvent(p_event_hot);
						break;

				default: // AUTO MODE

						fIPoint = Regeln();
						// Set current to computed value
						p_event_setv5->modifyParameter(fIPoint);
						EventManager.RaiseEvent(p_event_setv5);
						p_event_setv6->modifyParameter(fIPoint);
						EventManager.RaiseEvent(p_event_setv6);
                                    if( mode != DIAGNOSE_AIR)
                                    {
                                        switch(Cooling_Sub_Sys)
                                        {
                                                    case E_COOLING_SUBSYS_INT_CHILLER:
                                                          if(p_CSetup->getConConfig()== CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600)
                                                                DualChillerLuftRegeln();
                                                          else
                                                                ChillerLuftRegeln();
                                                          // Set valve to computed value
                                                          p_event_cold->modifyParameter(fFlowCold);
                                                          EventManager.RaiseEvent(p_event_cold);
                                                          p_event_hot->modifyParameter(fFlowHot);
                                                          EventManager.RaiseEvent(p_event_hot);
                                                    break;
    
                                                    case E_COOLING_SUBSYS_EXT_CHILLER:
                                                                p_ChillerCom->setI(abs(p_Lambdas[4]->getCurr()) ); // Inform extern chiller about present current
                                                    break;
    
                                                    case E_COOLING_SUBSYS_PROP_VALVE:
                                                                VentilRegeln();
                                                    break;
                                        }
                                    }
						break;

				case GOSTANDBY:
						if(p_CPData->getTemp3(iOffsettTable) > 24.0 && p_CPData->getTemp3(iOffsettTable) < 40.0)
						{
								switchMode( STANDBY );
								_event<int> e( "aggregat", CEventNames::STANDBY_CHANGED, 1 );   // Event for prober event-manager
								EventManager.RaiseEvent(e);
						}
						else
						{
								// Set set-temperature to 25�C
								//p_CSetup->getTempParamSet(1)->setSetTemp( 25.0 );
								p_event_settemp->modifyParameter(25.0);
								EventManager.RaiseEvent(p_event_settemp);
								p_con1->cycCalc( p_CSetup->getTempParamSet(1)->getSetTemp(), p_CPData->getTemp3(iOffsettTable), lCycleTime );  //Temperature 1
								p_event_setv5->modifyParameter(p_con1->getY());
								EventManager.RaiseEvent(p_event_setv5);
								p_event_setv6->modifyParameter(p_con1->getY());
								EventManager.RaiseEvent(p_event_setv6);

								//Valve Output
								if(  p_con1->getMode() == 2 ) 	// Cooling
								{
										p_event_cold->modifyParameter(fMax);
										p_event_hot->modifyParameter(0.0);
								}
								else 														// Heating with hot air only, if chuck-temp is below 15�C
								{
										p_event_cold->modifyParameter(0.0);
										if (p_CPData->getTemp3(iOffsettTable)<HOT_FLOW_TEMP_LIMIT) p_event_hot->modifyParameter(fMax);
										else p_event_hot->modifyParameter(0);
								}
								EventManager.RaiseEvent(p_event_cold);
								EventManager.RaiseEvent(p_event_hot);
								bInStandby = false;
						}
				break;
				case MDEFROST:
						// Set set-temperature to 60�C
						p_event_settemp->modifyParameter(60.0);
						EventManager.RaiseEvent(p_event_settemp);

						p_con1->cycCalc( p_CSetup->getTempParamSet(1)->getSetTemp(), p_CPData->getTemp3(iOffsettTable), lCycleTime );  //Temperature 1
						p_event_setv5->modifyParameter(p_con1->getY());
						EventManager.RaiseEvent(p_event_setv5);
						p_event_setv6->modifyParameter(p_con1->getY());
						EventManager.RaiseEvent(p_event_setv6);

						//Valve Output
                                    if( p_CSetup->getGetPressDev() )  // Lany valve
                                    {
                                        p_event_cold->modifyParameter(20.0);			// Open prop valve 20%
                                    }
                                    // Others
                                    if(p_CSetup->getConConfig()== CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600)
                                    {
                                        p_event_cold->modifyParameter(fMax * 0.72);
                                    }
                                    else
                                    {
                                        p_event_cold->modifyParameter(fMax);
                                    }

						p_event_hot->modifyParameter(0.0);
						EventManager.RaiseEvent(p_event_cold);
						EventManager.RaiseEvent(p_event_hot);
				break;

				case PURGE:
						// Set set-temperature to 25�C
						p_event_settemp->modifyParameter(25.0);
						EventManager.RaiseEvent(p_event_settemp);

						p_con1->cycCalc( p_CSetup->getTempParamSet(1)->getSetTemp(), p_CPData->getTemp3(iOffsettTable), lCycleTime );  //Temperature 1
						p_event_setv5->modifyParameter(p_con1->getY());
						EventManager.RaiseEvent(p_event_setv5);
						p_event_setv6->modifyParameter(p_con1->getY());
						EventManager.RaiseEvent(p_event_setv6);

						//Valve Output
						p_event_cold->modifyParameter(60.0);
						p_event_hot->modifyParameter(60.0);
						EventManager.RaiseEvent(p_event_cold);
						EventManager.RaiseEvent(p_event_hot);
				break;

				case STANDBY:
				case STOP:
				case SERROR:
#ifdef TUEV
						p_event_settemp->modifyParameter(25.0);               // Temp to 25�C
						EventManager.RaiseEvent(p_event_settemp);
						p_event_setv5->modifyParameter(0.0);									// Lamdas off
						p_event_setv6->modifyParameter(0.0);

														// Lany valve
						if( p_CSetup->getGetPressDev() )
						{
								p_event_cold->modifyParameter(30.0);								// Open prop valve 50%  (=> set value 30, found by try and error)
						}
						// Others
						else
						{
										p_event_cold->modifyParameter(0.0);									// Cold air off
										p_event_hot->modifyParameter(120.0);								// Hot air ~50% (=> ~ 120 l/min)
						}
		#else
						//Ventile
						p_event_cold->modifyParameter(0.0);
						p_event_hot->modifyParameter(0.0);
						p_event_setv5->modifyParameter(p_con1->getY());
						p_event_setv6->modifyParameter(p_con1->getY());
		#endif
						EventManager.RaiseEvent(p_event_setv5);
						EventManager.RaiseEvent(p_event_setv6);
						EventManager.RaiseEvent(p_event_cold);
						EventManager.RaiseEvent(p_event_hot);
				break;

				case EXTEST:
				break;
        }

        // Raise cyclic events
        if( mode == AUTO ) {
        _event<float> e1("aggregate", CEventNames::new_chiller_settemp, fSetTemp );
        EventManager.RaiseEvent(e1);
        _event<int> e2( "aggregat", CEventNames::STANDBY_CHANGED, 0 );   // Event for prober event-manager
        EventManager.RaiseEvent(e2);
        }
        else  {
        _event<float> e("aggregate", CEventNames::new_chiller_settemp, p_CSetup->getTempParamSet(1)->getSetTemp() );
        EventManager.RaiseEvent(e);
        }
        _event<int> e0("aggregate", CEventNames::new_chiller_ctrl, p_con1->getMode());
        EventManager.RaiseEvent(e0);
        _event<float> e1("aggregate", CEventNames::chuck_temp, p_CPData->getTemp3());			// Chuck Temp
        EventManager.RaiseEvent(e1);
        if( Cooling_Sub_Sys == E_COOLING_SUBSYS_EXT_CHILLER)
        {
             _event<float> ex2("aggregate", CEventNames::chiller_temp,  p_ChillerCom->getTemp());   // Chiller Temp
             EventManager.RaiseEvent(ex2);
        }
        else
        {
            _event<float> e2("aggregate", CEventNames::chiller_temp, p_CPData->getTemp5());   // Chiller Temp
            EventManager.RaiseEvent(e2);
        }
        _event<float> e3("aggregate", CEventNames::base_temp, p_CPData->getTemp7());    	// KTY or any other
        EventManager.RaiseEvent(e3);
        _event<float> e4("aggregate", CEventNames::intern_temp, p_CPData->getTemp6());    // Inside Temp
        EventManager.RaiseEvent(e4);

        vTaskDelay (66);

    } // end of while (1)
}

#define YMIN 0
#define YMAX -100 * 512
/*******************************************************************************
* Method Name  	 : PID
* Description    : PID algorithm
*
*
*
* Return         : None
*******************************************************************************/

void PID(void)
{
    float off1;
    float off2;
    
    
    float Kpc = p_con1->GetKp();
    float Tac = p_CSetup->getPIDSetup(1)->Lin;
    float Tnc = p_CSetup->getPIDSetup(1)->Tn;
    float Tvc = p_CSetup->getPIDSetup(1)->Tv;

    float Kpc2 = p_con2->GetKp();
    float Tac2 = p_CSetup->getPIDSetup(2)->Lin;
    float Tnc2 = p_CSetup->getPIDSetup(2)->Tn;
    float Tvc2 = p_CSetup->getPIDSetup(2)->Tv;

    // we must work with valid Values!!!

    if( Tac <= 0)
    Tac = 35.0;
    if( Tnc <= 0)
    Tnc = 8000.0;
    if( Tvc < 0 )
    Tvc = 0;

    if( Tac2 <= 0)
    Tac2 = 32.0;
    if( Tnc2 <= 0)
    Tnc2 = 8000.0;
    if( Tvc2 < 0)
    Tvc = 0;

    long Kc0 = (long)(Kpc * 512 * (1 + (Tac / Tnc) + (Tvc / Tac)));
    long Kc1 = (long)(Kpc *  512 *(-1 - 2 * (Tvc / Tac))) - 1;

    long Kc02 = (long)(Kpc2 * 512 * (1 + (Tac2 / Tnc2) + (Tvc2 / Tac2)));
    long Kc12 = (long)(Kpc2 *  512 *(-1 - 2 * (Tvc2 / Tac2))) - 1;

    if( fSetTemp > 10.0 )
    {
        off1 = (Kc0 * diff);
        off2 = (Kc1 * diff1);
    }
    else
    {
        off1 = (Kc02 * diff);
        off2  = (Kc12 * diff1);
    }
    if( !bCtrlLowNoise)
    {
       y += off1;
       y += off2;
    }
    else
    {
       y += (off1/4);
       y += (off2/4);

    }
}
/*******************************************************************************
* Method Name  	 : PID
* Description    : PID algorithm
*
*
*
* Return         : None
*******************************************************************************/

void PIDC(void)
{
    float off1;
    float off2;
    
    
    float Kpc = p_con1->GetKp();
    float Tac = p_CSetup->getPIDSetup(3)->Lin;
    float Tnc = p_CSetup->getPIDSetup(3)->Tn;
    float Tvc = p_CSetup->getPIDSetup(3)->Tv;

    // we must work with valid Values!!!

    if( Tac <= 0)
    Tac = 26.0;
    if( Tnc <= 0)
    Tnc = 8000.0;
    if( Tvc < 0 )
    Tvc = 0;
    
    long Kc0 = (long)(Kpc * 512 * (1 + (Tac / Tnc) + (Tvc / Tac)));
    long Kc1 = (long)(Kpc *  512 *(-1 - 2 * (Tvc / Tac))) - 1;


    off1 = (Kc0 * diff);
    off2 = (Kc1 * diff1);
    if( !bCtrlLowNoise)
    {
       y += off1;
       y += off2;
    }
    else
    {
       y += (off1/4);
       y += (off2/4);

    }
}
/*
void PID2(void)
{
    float off1;
    float off2;
    float off3;

    float Kpc = p_con1->GetKp();
    float Tac = p_CSetup->getPIDSetup(1)->Lin;
    float Tnc = p_CSetup->getPIDSetup(1)->Tn;
    float Tvc = p_CSetup->getPIDSetup(1)->Tv;

    float Kpc2 = p_con2->GetKp();
    float Tac2 = p_CSetup->getPIDSetup(2)->Lin;
    float Tnc2 = p_CSetup->getPIDSetup(2)->Tn;
    float Tvc2 = p_CSetup->getPIDSetup(2)->Tv;

    // we must work with valid Values!!!

    if( Tac <= 0)
    Tac = 35.0;
    if( Tnc <= 0)
    Tnc = 8000.0;
    if( Tvc < 0 )
    Tvc = 0;

    if( Tac2 <= 0)
    Tac2 = 32.0;
    if( Tnc2 <= 0)
    Tnc2 = 8000.0;
    if( Tvc2 < 0)
    Tvc = 0;

    long Kc0 = (long)(Kpc * 512 * (1 + (Tac / Tnc) + (Tvc / Tac)));
    long Kc1 = (long)(Kpc *  512 *(-1 - 2 * (Tvc / Tac))) - 1;
    long Kc2 = (long)(Kpc * 512 * (Tvc / Tac));

    long Kc02 = (long)(Kpc2 * 512 * (1 + (Tac2 / Tnc2) + (Tvc2 / Tac2)));
    long Kc22 = (long)(Kpc2 * 512 * (Tvc2 / Tac2));
    long Kc12 = (long)(Kpc2 *  512 *(-1 - 2 * (Tvc2 / Tac2))) - 1;

    if( fSetTemp > 10.0 )
    {
        off1 = (Kc0 * diff);
        off2 = (Kc1 * diff1);
        off3 = (Kc2 * diff2);
   }
    else
    {
        off1 = (Kc02 * diff);
        off2  = (Kc12 * diff1);
        off3 = (Kc22 * diff2);
    }
    if( !bCtrlLowNoise)
    {
       y += off1;
       y += off2;
       y += off3;
    }
    else
    {
       y += (off1/4);
       y += (off2/4);
       y += (off3/4);

    }
}
*/
/*********************************************************************************************
* Method Name  	: Regeln
* Description    : regulates only current  to the chuck
*
*
*
* Returns         : setvalue. This is the value return for driving the power output
************************************************************************************************/
float  Regeln(void)
{
    float setvalue  = 0.0;
    // Get currently set temperature and corresponding air flow parameters
    fSetTemp  = p_CSetup->getTempParamSet(1)->getSetTemp();
    sAirSetup = p_AirTable->getAirValue(fSetTemp);

    // Adapt set temperature in case of dew point warnings
    if ( p_CSetup->getOptionDewPoint() && SysInit::m_usersettings.DewpointTrackingActive )
    {
         fSetTemp = considerDewPoint( fSetTemp );
    }

    diff  = p_CPData->getTemp3(iOffsettTable)- fSetTemp;
    adiff = abs(diff);

    if (adiff > 0.25)
    {
        bCtrlFine = false;
    }

    if (( (adiff > 0.02)) && ( bCtrlFine == false)) /* Ann�herung mit dem PID-Algorithmus */
    {
        PID();
        iConTimer =40000;

    }
    else
    {
        PID(); // just in case we use a different Controller
    }
    /* Ausgangsgroesse begrenzen */
    if (y > YMIN)
    {
        y = YMIN;
    }
    else if (y < YMAX)
    {
        y = YMAX;
    }

    y1 = y/-512;
    /* diff(t-1) merken */
    if (sollreg !=  fSetTemp)
    {
        diff1 = diff;
        diff2 = diff;
        sollreg =  fSetTemp;
        iConTimer = 40000;
    }
    else
    {
        diff2 = diff1;
        diff1 = diff;
    }

    if( bCtrlFine == false )
    {
        if( adiff  < 0.02 )
        {
            if( iConTimer > 0 )
            {
                iConTimer -= lCycleTime;
                bCtrlFine = false;
                setvalue  = y1;
             }
            else
            {
                bCtrlFine = true;
                iLConTimer =40000;
                iTrackConTimer = 60000;
                setvalue  = y1;
            }
        }
        else
        {
            setvalue  = y1;
            iConTimer = 40000;  //milseconds to wait until we switch to fine controlling
            bHoldMode = false;
        }
        bCtrlLowNoise = false;
    }
    else
    {
        if( bAllowLowNoise &&  bStablePower )
        {
            bCtrlLowNoise = true;
        }
        else
        {
            bCtrlLowNoise = false;
        }
        setvalue  = y1;

    }
    if( bHoldEnable )
    {
        if (bCtrlFine && !bHoldMode)
        {
            bHoldMode = true;
            fHoldIIR = setvalue;
            fAirHoldWarm = fFlowHot;
            fAirHoldCold = fFlowCold;
            fPropHoldAir = fPropAir;
        }
    }
    else
    {
        bHoldMode = false;
        iConTimer3 = 1000;

        fConAirSet = fSetTemp*0.3 + p_Lambdas[4]->getCurr()*0.17*0.7;
        fConAirPre = p_CPData->getTemp3(iOffsettTable)*0.3 + PID_OPTIMAL_ABS_CURRENT*0.17*0.7;

    }
    if( bHoldMode )
    {
        setvalue  = fHoldIIR;
    }

    p_con1->SetControlReadyStatus(fSetTemp,p_CPData->getTemp3(iOffsettTable));
    if( delay_current == true)
    {
      y =  YMIN;
      y1 = 0;
      setvalue = 0;
    }
    return setvalue;
}

/*********************************************************************************************
* Method Name  	:CalcControlPower
* Description    : Calculates the Heating Power from Voltage and Current (U*I)
*
*
*
* Returns         : fpower: Calculated Power.
************************************************************************************************/
float CalcControlPower(void)
{
  float fcurrent =  abs(p_Lambdas[4]->getCurr()); // read current in amps
  float fvolt    =  abs(p_Lambdas[4]->getVolt()); // read Voltage in Volts

  float fpower = fcurrent * fvolt;

  return fpower;
}
/*********************************************************************************************
* Method Name  	:LPID
* Description    : Calculate the SetValue for Air Valves
*
*
*
* Returns         : fpower: Calculated Power.
************************************************************************************************/

void LPID(void)
{

    float LKp = p_con5->GetKp();
    float Ta = p_CSetup->getPIDSetup(5)->Lin;
    float Tn = p_CSetup->getPIDSetup(5)->Tn;
    float Tv = p_CSetup->getPIDSetup(5)->Tv;
    // we must work with valid values!
    if (LKp <= 0 )
        LKp = 0.2;
    if( Ta <= 0)
        Ta = 35;
    if( Tn <= 0)
        Tn = 8000;
    if( Tv < 0 )
        Tv = 0;

    lK0 = (LKp *  (1 + (Ta / Tn) + (Tv / Ta)));
    lK1 = (LKp *  (-1 - 2 * (Tv / Ta))) - 1;

    ly += (lK0 * ldiff);
    ly += (lK1 * ldiff1);

    if( ly < 0)
    {
            ly = 0;
    }
    else if (ly > 100)
    {
            ly = 100;
    }

}


/*******************************************************************************
* Method Name  	 : ChillerLuftRegeln
* Description    : regulates Air volume to the chuck
*
* comments:
* The Airflow-Controller is implemented with controller 6
* It has two control goals, combined with different weights:
*
* 1) Hold chuck temperature at given value
*    KP shall be choosen, that a temp.-difference of 0.2�C leads to a control value of 0.5
*    KP*0.2 = 0.5 => KP = 0.5/0.2 = 2.5
*
* 2) If possible, the chuck current shall be 20% of max value
*    A current difference of 20% shall lead with KP from 1) to a control value of 0.5
*    KP*kc*20 = 0.5 => kc = 0.5/(20*2.5) = 0.01
*
* The two goals will have different weights: We support temp goal with 30% and current goal with 70%

*
* Return         : None
*******************************************************************************/
#define PID_ABS_HIGH_POWER 14.0
#define PID_ABS_LOW_POWER  8.0
#define PID_ABS_OPTIMAL_POWER 12.0
#define PID_ABS_WARM_POWER 3
#define NEED_AIR 90.0

float  fAV = 0.0;
/* PM Additions 09.08.2012 */
#define PID_ABS_HIGH_CURRENT     1.4  // 1.4A
#define PID_ABS_LOW_CURRENT      0.9  // 0.8A
//#define LUFT_GRENZE              50.0 // 50�C
#define VOLL_KALTLUFT_GRENZE   -48.5 // 8" Chuck
#define  DUAL_MIX_TEMPERATURE   120 // if we start cooling with the Chuck temperature above this value we must always mix.
#define  DUAL_COLD_AIR_LIMIT    210 // above this temperature it is alway only warm Air
#define  DUAL_HT_TEMPERATURE   +25  // 25�C
#define  DUAL_LT_TEMPERATURE   -40  // Minimum Temperature for Dual Operation.
#define  DUAL_COLDAIR_STEP      0.2

void ChillerLuftRegeln(void)
{
    static float fAirValue = -100.0;
    float istep;
    static sAirValue sfAV;

    // Get currently set temperature and corresponding air flow parameters
    fSetTemp  = p_CSetup->getTempParamSet(1)->getSetTemp();
    sAirSetup = p_AirTable->getAirValue(fSetTemp);

    int status = p_con1->GetControlReadyStatus();
    float chucktemp =   p_CPData->getTemp3(iOffsettTable);


    switch( status )
    {

        case 1:
          if(  wasCooling == 0)
          {
            if ((fSetTemp - chucktemp) < HEAT_APPROACH_THRESHOLD)
                xPidState = HEAT_APPROACH;
            else
               xPidState = HEATING;
             sfAV.fFlow = 0.0;
          }
        break;

       case 2:
        if( ( chucktemp - fSetTemp) < COOL_APPROACH_THRESHOLD )
         {
                xPidState = COOL_APPROACH;
         }
        else
        {
          xPidState = COOLING;
          if( (p_CSetup->getPIDSetup(1)->Tn == 9800)&&(delay_current == false)) // this is a temperal solution.!!!
                delay_current = true;
        }
        sfAV.fFlow = 0.0;
        break;

    }
    // Steuerung f�r Heiz und K�hlvorg�nge
    switch (xPidState)
    {
        case CONTROLLING:
        // Die Lufttemperatur wird geregelt. Da die Ventile bei kleiner �ffnung nicht gut funktionieren
        // wird bei einem Kaltluftanteil gr��er Null das Ventil auf mind. 25 l/s gesetzt.
            if( fAirValue == -100.0 ) // controller started and we are already in controlling mode
              fAirValue = sAirSetup.fFlow;
            if(fSetTemp > LUFT_GRENZE) // Sollwert ausserhalb
            {
                if( sfAV.fFlow > 0.0 )
                {
                    if(  iLConTimer > 0)
                    {
                        iLConTimer-= lCycleTime;
                    }
                    else
                    {
                        float fpower = CalcControlPower(); // calculate Controlling Power
                        if( (fpower >  PID_ABS_OPTIMAL_POWER)&& (diff < 0.05))
                        {
                            sfAV.fFlow -= 1.0;
                            fAirValue =  sfAV.fFlow;
                            fFlowCold = fAirValue *  sfAV.fCold / 100.0;
                            fFlowHot  = fAirValue * (1 -  sfAV.fCold / 100.0);
                        }
                        iLConTimer = 20000;
                    }
                }
                else  
                {
                    fFlowCold = 0;
                    fFlowHot  = 0;
                    bStablePower = true;
                }
            }
            else
            {
                if( fSetTemp < VOLL_KALTLUFT_GRENZE ) // keine Luft�nderung
                {
                    fFlowHot  = 0;
                    fFlowCold = fMax;
                    bStablePower = true;
                }
                else
                {
                    float fpower = CalcControlPower(); // calculate Controlling Power
                    ldiff = fpower - PID_ABS_OPTIMAL_POWER; // ist - soll. ldiff < 0 => more cold air
                    ldiff1 = ldiff;

                    if( (fpower > PID_ABS_HIGH_POWER)||(fpower < PID_ABS_LOW_POWER) )
                    {
                        if(  iLConTimer > 0)
                        {
                            iLConTimer-= lCycleTime;
                        }
                        else
                        {
                             istep = p_con5->GetKp(); // iStep
                             if( adiff < 0.03 )// nachfolgen
                             {
                                if( fpower > PID_ABS_HIGH_POWER)
                                    ly -= istep;
                                else
                                    ly +=istep;

                                if( ly < 0 ) ly = 0;
                                if( ly > 100) ly = 100;


                                fFlowCold = fAirValue * (ly/100);
                                fFlowHot  = fAirValue - fFlowCold;
                                iLConTimer = 20000;


                            }
                            else //aushalb des Bereiches. diff = ist-soll > 0 => warmer.
                            {
                                if( (diff > 0 )&&((fpower < PID_ABS_LOW_POWER)||( diff > 0.05)) ) // became warm.  More cold Air
                                {
                                    if(fpower > PID_ABS_WARM_POWER)
                                        ly += istep;
                                    else 
                                        ly = 100;
                                }
                                else if( (fpower > PID_ABS_HIGH_POWER)&&(diff < -0.1)) // More warm Air only when the Current is to high and ware to cold!
                                {
                                    ly -= istep;
                                }

                                 if( ly < 0 ) ly = 0;
                                 if( ly > 100) ly = 100;


                                fFlowCold = fAirValue * (ly/100);
                                fFlowHot  = fAirValue - fFlowCold;
                                iLConTimer = 20000; // doppel solange warten.(20secs)
                            }
                    }
                }
                else
                    bStablePower = true;
            }
        }
    break;


    case COOL_APPROACH:
        // Luftstromeinstellungen enstpr. der Lufttabelle, bis Regler stabil. Das f�hrt zu gute Gesamtstabilit�t
        if( fSetTemp < NEED_AIR )
        {
            if( (wasCooling == 0)&&( (chucktemp - fSetTemp) < SLOW_COOL_APPROACH_THRESHOLD ))
            {
                if( fSetTemp >  LUFT_GRENZE)
                    sfAV = p_AirTable->getAirValue(25.0);
                else
                    sfAV = p_AirTable->getAirValue(fSetTemp);
            
                fAV = sfAV.fFlow;
                fAirValue =   sfAV.fFlow;
                fFlowCold = fAirValue *  sfAV.fCold / 100.0;
                fFlowHot  = fAirValue * (1 -  sfAV.fCold / 100.0);
                
                ly =  sfAV.fCold;
                
                iLConTimer =40000;
                wasCooling = 1;
                delay_current = false;
             }
            else 
            {
                if( sfAV.fFlow > 0.0 )
                {
                    if(  iLConTimer > 0)
                    {
                        iLConTimer-= lCycleTime;
                    }
                    else
                    {
                        float fpower = CalcControlPower(); // calculate Controlling Power
                        if( fSetTemp >  LUFT_GRENZE) // if above 59�C
                        {
                            if( (fpower >  PID_ABS_OPTIMAL_POWER) &&(diff < 0.14) )
                            {
                                sfAV.fFlow -= 2.2;
                                fAirValue =  sfAV.fFlow;
                                fFlowCold = fAirValue *  sfAV.fCold / 100.0;
                                fFlowHot  = fAirValue * (1 -  sfAV.fCold / 100.0);
                            }
                        }
                        else
                        {
                            istep = p_con5->GetKp(); // iStep
                            if( (diff > 0 )&&((fpower < PID_ABS_LOW_POWER)||( diff > 0.05)) ) // became warm.  More cold Air
                            {
                                if(fpower > PID_ABS_WARM_POWER)
                                    ly += istep;
                                else 
                                    ly = 100;
                            }
                            else if( (fpower > PID_ABS_HIGH_POWER)&&(diff < -0.1)) // More warm Air only when the Current is to high and ware to cold!
                                ly -= istep;
                            if( ly < 0 ) ly = 0;
                            if( ly > 100) ly = 100;
                                fFlowCold = fAirValue * (ly/100);
                            fFlowHot  = fAirValue - fFlowCold;
                            
                        } 
                        iLConTimer = 20000;   
                    }
                }
            }
        }            
        else //aushalb des Bereiches
        {
           if( (delay_current == true)&&((chucktemp - fSetTemp) < SLOW_COOL_APPROACH_THRESHOLD) )
           {
            fFlowCold = 0;
            fFlowHot  = 0;
            fAirValue = 0;
            delay_current = false;
           }
           else
           {
                fFlowCold = 0;
                fFlowHot  = 0;
                fAirValue = 0;
           }
        }
        if(bCtrlFine == true )
        {
            fAirValue =  fAV;
            iLConTimer = 40000;
            xPidState = CONTROLLING;
            wasCooling = 0;
        }
    break;

    case HEAT_APPROACH:
    // Luftstromeinstellungen enstpr. der Lufttabelle, bis Regler stabil ist. Das f�hrt zu gute Gesamtstabilit�t
        fAirValue = sAirSetup.fFlow;
        if(p_CPData->getTemp3(iOffsettTable) > LUFT_GRENZE)
        {
            fFlowCold = 0;
            fFlowHot  = 0;
        }
        else
        {
            fFlowCold = fAirValue * sAirSetup.fCold / 100.0;
            fFlowHot  = fAirValue * (1 - sAirSetup.fCold / 100.0);
            ly =  sAirSetup.fCold;
        }

        if(bCtrlFine == true )
        {
            xPidState = CONTROLLING;
        }
        bStablePower = false;
    break;

    case COOLING:
        // K�hlen: Volle Kaltluft
        fFlowHot  = 0;
        if(chucktemp > 180.0 )
        {
          fFlowCold = fMax * 0.72; // 72% = 230l
        }
        else
            fFlowCold = fMax;
        wasCooling = 0;
        // Wir n�hern uns dem Endwert: Zur�ckschalten auf Luft aus Tabelle
        if ( (p_CPData->getTemp3(iOffsettTable)-fSetTemp) < COOL_APPROACH_THRESHOLD )
        {
            xPidState = COOL_APPROACH;
            p_con6->bSetIVal(1-(sAirSetup.fCold/100.0));
        }

        iLConTimer = 20000;
        break;

        case HEATING:
            // Heizen: Volle Warmluft f�r Sollwerte < 14.5 �C. Dar�ber bringt die Warmluft nichts
            fFlowCold = 0;
            if (p_CPData->getTemp3(iOffsettTable) < 15.0)
            {
                fFlowHot  = fMax * 0.72;
            }
            else fFlowHot = 0;
            // Wir n�hern uns dem Endwert: Zur�ckschalten auf Luft aus Tabelle
            if (fSetTemp - p_CPData->getTemp3(iOffsettTable) < HEAT_APPROACH_THRESHOLD) xPidState = HEAT_APPROACH;
            iLConTimer = 20000;
            bStablePower = false;
        break;
    }
    if( bHoldMode )
    {
        fFlowHot  = fAirHoldWarm;
        fFlowCold = fAirHoldCold;
    }
}

/*******************************************************************************
* Method Name  : DualChillerLuftRegeln
* Description  : regulates Air volume to the chuck
*
********************************************************************************/
#define  DUAL_COMP_OFF_TEMPERATURE 40
#define  COMPRESSOR_ON_LIMIT 78

void DualChillerLuftRegeln(void)
{
    static float dfAirValue = -100.0;
    float distep;
    static sAirValue dsfAV;
    static float localSetTemp = -200.0;
    static float remoteSetTemp = +2000.0;
    static float coldAirStep = 0.2;
    static bool step_running = false;
    int   ilocalSetTemp, iremoteSetTemp;
    int temp_range;

    // Get currently set temperature and corresponding air flow parameters
    unsigned char connected =  chillerclient_connected_status();
    p_ChillerCom->SetOperationControlMode(mode,controlstatus,connected,compressorOperation);

    fSetTemp  = p_CSetup->getTempParamSet(1)->getSetTemp();
    sAirSetup = p_AirTable->getAirValue(fSetTemp);


    int status = p_con1->GetControlReadyStatus();
    float chucktemp =   p_CPData->getTemp3(iOffsettTable);


    peerSys =  p_ChillerCom->GetPeerStatus();


    peerSys =  p_ChillerCom->GetPeerStatus();
    if( remoteSetTemp == +2000.0)
        remoteSetTemp = peerSys.SetTemp;
    
//// 19.03   if( (peerSys.SetTemp  < DUAL_HT_TEMPERATURE)&&( peerSys.SetTemp >= DUAL_LT_TEMPERATURE) ) // +300 bis -40 �
////    {
////         sAirSetup.fFlow = sAirSetup.fFlow * 0.72 ;
////    }

     /************************************************************************************************/
    // We determine whether were are the masters and we have to control the Chiller compressor

        if((fSetTemp > DUAL_COMP_OFF_TEMPERATURE )&&((peerSys.SetTemp  > DUAL_COMP_OFF_TEMPERATURE )||(p_ChillerCom->getErrorStatus() != 0)) ) // above 40�C
        {
////            if((compressorOperation == 0)||(compressorOperation == 4)) // compressor ON
////              compressorOperation = 1; // start timer before switching off
                compressorOperation = 0; // bleibt aus.
        }
        else if((fSetTemp < COMPRESSOR_ON_LIMIT )||( peerSys.SetTemp  < COMPRESSOR_ON_LIMIT ) ) // below 78�C
        {
            if(compressorOperation == 2) // switched off
              compressorOperation = 3; // switch on compressor
        }
        if( peerSys.controller == false) // we are responsible
        {
           ManageChillerClient();
        }
        else
        {
             compressorOperation = peerSys.compressorOperation; // get from peer
        }

    switch( status )
    {

        case 1:
          if ((fSetTemp - chucktemp) < HEAT_APPROACH_THRESHOLD)
            xPidState = HEAT_APPROACH;
          else
            xPidState = HEATING;
            step_running = false;
        break;

       case 2:
        if( ( chucktemp - fSetTemp) < COOL_APPROACH_THRESHOLD )
         {
                xPidState = COOL_APPROACH;
         }
        else
          xPidState = COOLING;
       break;

        default:
            step_running = false;
        break;
    }
    if( xPidState != COOLING )
    {
       localSetTemp = fSetTemp;
       remoteSetTemp = peerSys.SetTemp;
    }

    // Steuerung f�r Heiz und K�hlvorg�nge
    switch (xPidState)
    {
        case CONTROLLING:
        // Die Lufttemperatur wird geregelt. Da die Ventile bei kleiner �ffnung nicht gut funktionieren
        // wird bei einem Kaltluftanteil gr��er Null das Ventil auf mind. 25 l/s gesetzt.
           distep = p_con5->GetKp(); // iStep
            if( dfAirValue == -100.0 ) // controller started and we are already in controlling mode
              dfAirValue = sAirSetup.fFlow;
            if(fSetTemp > LUFT_GRENZE) // Sollwert ausserhalb
            {
                fFlowCold = 0;
                fFlowHot  = 0;
                bStablePower = true;
            }
            else
            {
                if( fSetTemp < VOLL_KALTLUFT_GRENZE ) // keine Luft�nderung
                {
                    fFlowHot  = 0;
                    fFlowCold = fMax;
                    bStablePower = true;
                }
                else
                {
                    float fpower = CalcControlPower(); // calculate Controlling Power
                    ldiff = fpower - PID_ABS_OPTIMAL_POWER; // ist - soll. ldiff < 0 => more cold air
                    ldiff1 = ldiff;

                    if( (fpower > PID_ABS_HIGH_POWER)||(fpower < PID_ABS_LOW_POWER) )
                    {
                        if(  iLConTimer > 0)
                        {
                            iLConTimer-= lCycleTime;
                        }
                        else
                        {

                             if( adiff < 0.03 )// nachfolgen
                             {
                                if( fpower > PID_ABS_HIGH_POWER)
                                    ly -= distep;
                                else
                                    ly +=distep;

                                if( ly < 0 ) ly = 0;
                                if( ly > 100) ly = 100;


                                fFlowCold = dfAirValue * (ly/100);
                                fFlowHot  = dfAirValue - fFlowCold;
                                iLConTimer = 20000;
                            }
                            else //aushalb des Bereiches. diff = ist-soll > 0 => warmer.
                            {
                                if( (diff > 0 )&&((fpower < PID_ABS_LOW_POWER)||( diff > 0.05)) ) // became warm.  More cold Air
                                {
                                    if(fpower > PID_ABS_WARM_POWER)
                                        ly += distep;
                                    else 
                                        ly = 100;
                                }
                                else if( (fpower > PID_ABS_HIGH_POWER)&&(diff < -0.1)) // More warm Air only when the Current is to high and ware to cold!
                                {
                                    ly -= distep;
                                }

                                 if( ly < 0 ) ly = 0;
                                 if( ly > 100) ly = 100;


                                fFlowCold = dfAirValue * (ly/100);
                                fFlowHot  = dfAirValue - fFlowCold;
                                iLConTimer = 20000; // doppel solange warten.(20secs)
                            }
                    }
                }
                else
                    bStablePower = true;
            }
        }
    break;


    case COOL_APPROACH:
        // Luftstromeinstellungen enstpr. der Lufttabelle, bis Regler stabil. Das f�hrt zu gute Gesamtstabilit�t
            if (( chucktemp - fSetTemp) < DUALCOOL_APPROACH_THRESHOLD)
            {
                if(p_CPData->getTemp3(iOffsettTable) < NEED_AIR )
                {
                    if( wasCooling == 0)
                    {
                        sAirSetup =  p_AirTable->getAirValue(fSetTemp);
                        dfAirValue =  sAirSetup.fFlow;
                        fFlowCold = dfAirValue * sAirSetup.fCold / 100.0;
                        fFlowHot  = dfAirValue * (1 - sAirSetup.fCold / 100.0);
                        ly =  sAirSetup.fCold;

                        iLConTimer = 40000;
                        wasCooling = 1;

                    }
                    fFlowCold = dfAirValue * sAirSetup.fCold / 100.0;
                    fFlowHot  = dfAirValue * (1 - sAirSetup.fCold / 100.0);

                }
                else //aushalb des Bereiches
                {
                    fFlowCold = 0;
                    fFlowHot  = 0;
                    dfAirValue = 0;
                }
        }
        if(bCtrlFine == true )
        {
            dfAirValue =  sAirSetup.fFlow;
            iLConTimer = 40000;
            xPidState = CONTROLLING;
            wasCooling = 0;
        }
    break;

    case HEAT_APPROACH:
    // Luftstromeinstellungen enstpr. der Lufttabelle, bis Regler stabil ist. Das f�hrt zu gute Gesamtstabilit�t
        dfAirValue = sAirSetup.fFlow;

        if(p_CPData->getTemp3(iOffsettTable) > LUFT_GRENZE)
        {
            fFlowCold = 0;
            fFlowHot  = 0;
        }
        else
        {
            fFlowCold = dfAirValue * sAirSetup.fCold / 100.0;
            fFlowHot  = dfAirValue * (1 - sAirSetup.fCold / 100.0);
            ly =  sAirSetup.fCold;
        }

        if(bCtrlFine == true )
        {
            xPidState = CONTROLLING;
        }
        bStablePower = false;
    break;

    case COOLING:
        // K�hlen: Volle Kaltluft
        ilocalSetTemp  = (int)fSetTemp;
        iremoteSetTemp = (int)peerSys.SetTemp;

        if( iremoteSetTemp < DUAL_LT_TEMPERATURE) // Peer System below -40�C, therefore we can only use warm air.We have only ~ 440 liters
        {                                               // of air, and the other system needs 330 liters, we can use 100l.
          fFlowHot  = fMax * 0.34; // we cool with with Hot air only, with 100l
          fFlowCold = fMax * 0.07; // ca. 20 liter Kaltluft
        }
        else
        {

            coldAirStep  =  p_CSetup->getPIDSetup(5)->Tv; // get the cold set.
            if(coldAirStep > 0.8 )
                coldAirStep = 0.2;

            if((chucktemp < DUAL_MIX_TEMPERATURE)&&(step_running == false))
            {
                fFlowHot = 0;
                if( (ilocalSetTemp < DUAL_LT_TEMPERATURE )||((peerSys.ControlState != 2)&&(iremoteSetTemp  >= DUAL_HT_TEMPERATURE)) )
                {
                    fFlowCold = fMax;
                }
                else
                {
                   if((peerSys.ControlState == 2)||((peerSys.ControlState == 0)&&(iremoteSetTemp < DUAL_HT_TEMPERATURE)) ) // peer is also cooling.
                   {
                         fFlowCold  = fMax * 0.72;
                   }
                   else
                   {
                        if(iremoteSetTemp  >= DUAL_HT_TEMPERATURE)
                          fFlowCold = fMax;
                        else
                             fFlowCold  = fMax * 0.72;
                   }
                }
                step_running = false;
            }
            else // Chuck Temperature is warmer as Mixing level.
            {
                if( step_running == false) // beginning
                {

                    if( (peerSys.ControlState == 2) ||((peerSys.ControlState == 0)&&(iremoteSetTemp < DUAL_HT_TEMPERATURE)) )// peer also cooling
                    {
                        fFlowHot = fMax  * 0.72;
                    }
                    else
                    {
                      fFlowHot = fMax;
                    }
                    fFlowCold = 0;
                    step_running = true;
                    DiLConTimer = 500; // 1 sec
                }
                else 
                {
                    if( chucktemp < DUAL_COLD_AIR_LIMIT) 
                    {
                        if( (peerSys.ControlState == 2)||( ( peerSys.ControlState == 0)&&(iremoteSetTemp < DUAL_HT_TEMPERATURE)) )// make coorections as neccessary
                        {
                                if( (fFlowHot + fFlowCold ) > ( fMax *  0.80) )
                                {
                                    fFlowHot = fFlowHot * 0.72;  // we  have to share
                                    fFlowCold =  fFlowCold * 0.72;
                                }
                        }
                        else if(iremoteSetTemp  >= DUAL_HT_TEMPERATURE)
                        {
                            if( (fFlowHot + fFlowCold ) < ( fMax *  0.96) ) // less than Max
                            {
                                fFlowHot = fFlowHot / 0.72;
                                fFlowCold = fFlowCold / 0.72;
                            }
                        }
                        if( (DiLConTimer < 0 )&&( fFlowHot != 0) ) // not yet finished
                        {
    
                            fFlowHot -= coldAirStep;
                            fFlowCold +=  coldAirStep;
                            if( fFlowHot < 0)
                            {
                                fFlowHot   = 0;
                                if( (peerSys.SetTemp  < DUAL_HT_TEMPERATURE)&&( iremoteSetTemp >= DUAL_LT_TEMPERATURE) ) // +300 bis -40 �
                                    fFlowCold  = fMax * 0.72;
                                else
                                    fFlowCold  = fMax;
    
                                 compressorOperation = 0; // maximum cold air reached.
                            }
                            DiLConTimer = 500; //  1 sec (20000 = 40 secs)
                        }
                        else
                        {
                            DiLConTimer -= lCycleTime;
                        }
                   }
                }
            }
        }

        wasCooling = 0;
        // Wir n�hern uns dem Endwert: Zur�ckschalten auf Luft aus Tabelle
        if ( (p_CPData->getTemp3(iOffsettTable)-fSetTemp) < COOL_APPROACH_THRESHOLD )
        {
            xPidState = COOL_APPROACH;
            p_con6->bSetIVal(1-(sAirSetup.fCold/100.0));
        }

        iLConTimer = 20000;
    break;

    case HEATING:
        // Heizen: Volle Warmluft f�r Sollwerte < 14.5 �C. Dar�ber bringt die Warmluft nichts
        fFlowCold = 0;
        if (p_CPData->getTemp3(iOffsettTable) < 15.0)
        {
           fFlowHot = fMax * 0.34; // 72% = 230l
        }
        else fFlowHot = 0;
        // Wir n�hern uns dem Endwert: Zur�ckschalten auf Luft aus Tabelle
        if (fSetTemp - p_CPData->getTemp3(iOffsettTable) < HEAT_APPROACH_THRESHOLD) xPidState = HEAT_APPROACH;
            iLConTimer = 20000;

        bStablePower = false;
    break;
    }
    if( bHoldMode )
    {
        fFlowHot  = fAirHoldWarm;
        fFlowCold = fAirHoldCold;
    }
}

///            if( localSetTemp != fSetTemp) // new SetTemp. only once.
////            {
////                localSetTemp = fSetTemp;
////
////                 if((chucktemp >= DUAL_MIX_TEMPERATURE )||(compressorOperation == 4) ) // below this temperature means we were using some cold air
////                 {
////                    step_running = true;
////                 }
////                 else
////                 {
////                    step_running = false;
////                 }
////            }
////            if( localSetTemp != fSetTemp) // new SetTemp. only once.
////            {
////                localSetTemp = fSetTemp;
////                if((chucktemp >= DUAL_MIX_TEMPERATURE )||(compressorOperation == 4) ) // below this temperature means we were using some cold air
////                {
////                   if( (fFlowHot == 0) || (fFlowCold == 0))
////                   {
////                        if( peerSys.SetTemp  >= DUAL_HT_TEMPERATURE) // 25�C  bzw 30�C irrespective of TEMP_MIN we use full cold Air.
////                        {
////                                if((peerSys.ControlState == 2)&&(fSetTemp >= DUAL_LT_TEMPERATURE))
////                                    fFlowHot = fMax  * 0.72;
////                                else
////                                    fFlowHot  = fMax;
////                       }
////                        else if( (peerSys.SetTemp  < DUAL_HT_TEMPERATURE)&&( peerSys.SetTemp >= DUAL_LT_TEMPERATURE) ) // +300 bis -40 �C
////                            fFlowHot  = fMax * 0.72;
////
////                        fFlowCold = 0;
////                        coldAirStep  =  p_CSetup->getPIDSetup(5)->Tv;
////                        //coldAirStep = DUAL_COLDAIR_STEP;
////                        DiLConTimer = 500; // 1 sec
////                   }
////                }
////                else
////                {
////                    fFlowHot   = 0;
////                    if( peerSys.SetTemp  >= DUAL_HT_TEMPERATURE) // 25�C  bzw 30�C irrespective of TEMP_MIN we use full cold Air.
////                    {
////                        if((peerSys.ControlState == 2)&&(fSetTemp >= DUAL_LT_TEMPERATURE))
////                          fFlowCold = fMax  * 0.72;
////                        else
////                            fFlowCold  = fMax;
////                    }
////                    else if( (peerSys.SetTemp  < DUAL_HT_TEMPERATURE)&&( peerSys.SetTemp >= DUAL_LT_TEMPERATURE) ) // +300 bis -40 �
////                         fFlowCold = fMax  * 0.72;
////                    coldAirStep = 0;
////                }
////                DiLConTimer = 500; // 1 sec
////            }
////            if( (coldAirStep > 0 )&&(fFlowHot > 0) &&(chucktemp < DUAL_COLD_AIR_LIMIT)) //(chucktemp < DUAL_MIX_TEMPERATURE) )
////            {
////              // sanity check
////                if( remoteSetTemp != peerSys.SetTemp ) // remote peer has set a new Temperature.
////                {
////                   if(peerSys.ControlState == 2) // less than old settemp. Peer wants to cool also!
////                   {
////                        if(fSetTemp >= DUAL_LT_TEMPERATURE)
////                        {
////                            if( (fFlowHot + fFlowCold ) > ( fMax *  0.80) )
////                            {
////                                fFlowHot = fFlowHot * 0.72;  // we  have to share
////                                fFlowCold =  fFlowCold * 0.72;
////                            }
////                        }
////                   }
////                   else
////                   {
////                        if(peerSys.SetTemp  >= DUAL_HT_TEMPERATURE)
////                        {
////                            if( (fFlowHot + fFlowCold ) < ( fMax *  0.96) ) // less than Max
////                            {
////                                fFlowHot = fFlowHot / 0.72;
////                                fFlowCold = fFlowCold / 0.72;
////                            }
////                        }
////                   }
////                   remoteSetTemp = peerSys.SetTemp;
////                }
////               if( DiLConTimer < 0 )
////               {
////
////                    fFlowHot -= coldAirStep;
////                    fFlowCold +=  coldAirStep;
////                    if( fFlowHot < 0)
////                    {
////                        fFlowHot   = 0;
////                        if( (peerSys.SetTemp  < DUAL_HT_TEMPERATURE)&&( peerSys.SetTemp >= DUAL_LT_TEMPERATURE) ) // +300 bis -40 �
////                            fFlowCold  = fMax * 0.72;
////                        else
////                            fFlowCold  = fMax;
////
////                        compressorOperation = 0; // maximum cold air reached.
////                    }
////                    DiLConTimer = 500; //  1 sec (20000 = 40 secs)
////               }
////               else
////               {
////                 DiLConTimer -= lCycleTime;
////
////               }
////            }
////            // sanity check
////            if(coldAirStep <= 0)
////            {
////                fFlowHot = 0;
////                if(peerSys.ControlState == 2) // less than old settemp. Peer wants to cool also!
////                {
////                       if((fSetTemp < DUAL_HT_TEMPERATURE)&&(peerSys.SetTemp < DUAL_HT_TEMPERATURE))
////                          fFlowCold = fMax  * 0.72;
////                        else
////                            fFlowCold  = fMax;
////                }
////                else
////                {
////                    if(peerSys.SetTemp >= DUAL_HT_TEMPERATURE)
////                    {
////                       fFlowCold  = fMax;
////                    }
////                    else
////                    {
////                       fFlowCold = fMax  * 0.72;
////                    }
////                }
////            }
////           if(peerSys.ControlState == 2) // ultimate check. If both of us are cooling then we must share the air!!
////           {
////
////           }


/************************************************************************************
*  Function: ChillerClientNotifyOnDataReceived
*  Purpose:  This function is called whenever new data is received from the chiller
*
*
**************************************************************************************/
void ChillerClientNotifyOnDataReceived(struct CHILLER_INFO *info)
{

    chiller_connected = info->connected;
    p_ChillerCom->SetOperationControlMode(mode,controlstatus,info->connected,compressorOperation);


    if( info->connected == 2) // call when connecetd
    {
        if( (info->alarm_code[0] != '0')||(info->alarm_code[1] != '0')|| (info->alarm_code[2] != '0')||(info->alarm_code[3] != '0'))
        {
           dual_chiller_error_code = atoi(&info->alarm_code[0]);
           if( dual_chiller_error == 0)// fire only one event
                dual_chiller_error = 1;
        }
////        if( (info->compressor_state == 'O')&&(compressorOperation == 0))
////        {
////          chillerclient_switch_compressor (1); //switch ON Compressor
////        }
            if(dual_chiller_error == 3)
            {
                chillerclient_switch_compressor (1); //switch ON Compressor
                dual_chiller_error = 0;

            }

    }


}

/************************************************************************************
*  Function:  ManageChillerClient
*  Purpose:  This function is called whenever the System needs to send a new command to chiller
*
*  lCycleTime = 70
*  1 sec ~ 200
* 450000 ~ 3 minutes and 45 seconds
************************************************************************************/
// static volatile size_t freeheap; (6000 about 4 seconds)
#define COMP_OFF_TIMER  120000 //  about 1 Minute

void ManageChillerClient(void)
{
//          freeheap =  xPortGetFreeHeapSize();
    unsigned char connected =  chillerclient_connected_status();
    if( client_chiller_active != 1)
      return;

    if( connected == 2)
    {
        switch(compressorOperation)
        {
            case 0:             // operating normally
              CompOFFTimer = COMP_OFF_TIMER;
            break;
            case 1:         // switch off compressor after timeout
              if(CompOFFTimer < 0)
              {
                chillerclient_switch_compressor(0); // switch off compressor
                compressorOperation = 2;
              }
              else
              {
                    CompOFFTimer -= lCycleTime;
              }
            break;
            case 2:
            break;

            case 3:
               chillerclient_switch_compressor(1);
               compressorOperation = 4;
            break;

            case 4:
           break;
        }
    }
    else if( connected == 0)
    {
      if(NetworkTimer < 0)
      {
        chillerclient_connect();
        NetworkTimer = NET_WORK_TIME_OUT;
      }
      else
          NetworkTimer -= lCycleTime;
    }

}



/*********************************************************************************************
* Method Name  	:VentilRegeln
* Description    : Regulates the Proportional Valve
*
*
*
* Returns         : None
************************************************************************************************/
void VentilRegeln(void)
{

       float chucktemp = p_CPData->getTemp3(iOffsettTable);

       p_con4->cycCalc( fConAirPre, fConAirSet, lCycleTime );

	if( p_con1->getMode() == 1 )  // Heating
	{
		_event<float> e("AIRCON HEAT", CEventNames::VALVE_1_SET, 0.0);
		if( p_CPData->getTemp3(iOffsettTable) < 15.0 )
		{
			e.modifyParameter( 40.0 ); // 40% Air
		}
		EventManager.RaiseEvent(e);

 	}
	else if( p_con1->getMode() == 2 )// Cooling
	{
            if( p_CSetup->getTempParamSet(1)->getMinLimit() < 0) // System with dumb Chiller.
            {
                float a_step = p_CSetup->getPIDSetup(5)->Tv;

                if( chucktemp > 120.0 )
                {
                    fPropAir = 23.0; // 100l
                }
                else
                {
                    if( chucktemp > 80.0 )
                    {
                        fPropAir = 32.0; // 140l
                    }
                    else
                    {
                        if (chucktemp > 65.0 )
                            fPropAir = 38.7;
                        else
                        {
                            if(chucktemp > 50.0 )
                                fPropAir = 44.4;
                            else
                            {
                                if(chucktemp > 40.0 )
                                    fPropAir = 50.1;
                                else
                                {
                                    if(chucktemp > 30.0 )
                                        fPropAir = 61.6;
                                    else
                                    {
                                        if(chucktemp > 20.0 )
                                            fPropAir = 67.3;
                                        else
                                        {
                                            if(chucktemp > 12.0 )
                                                fPropAir = 73.0;
                                            else
                                            {
                                                if(chucktemp > 5.0 )
                                                    fPropAir = 84.4;
                                                else
                                                   fPropAir = 100.0;
                                            }
                                        }
                                    }
                                }
                            }


                        }
                    }
                }
            }
            else
                fPropAir = 100.0;
           if( (p_CSetup->getConConfig() == CSetup::_s_config::E_CONTOLLER_SP102Y2D)||(p_CSetup->getConConfig() == CSetup::_s_config::E_CONTOLLER_SP102Y2M))
                fPropAir = 100.0;

		_event<float> e("AIRCON COOL", CEventNames::VALVE_1_SET, fPropAir);
		EventManager.RaiseEvent(e);
	}
	else // controlling
	{
		fPropAir = p_con4->getY();
		if( fSetTemp < 15.0 && fPropAir < 30.0 )
		{
		  fPropAir = 30.0;
		}
		if(p_CPData->getTemp3(iOffsettTable) > LUFT_GRENZE)
		{
			fPropAir = 0.0;
		}
		else
		{
			if( fPropAir < 0 )
				fPropAir = 0;

		}

            if( bHoldMode )
            {
              fPropAir = fPropHoldAir;
            }
		_event<float> e("AIRCON CONTROL", CEventNames::VALVE_1_SET, fPropAir);
		EventManager.RaiseEvent(e);


	}
}


/*================== END ========================================*/

/**
 Prober Interface task
*/
void ProbTask(void *pvParameters)
{
    Protocol * p_Protocol;

    //Warte bis Setup g�ltig ist
    while( !p_CSetup->bIsValid() ){
        vTaskDelay(10);
    }

    //Porber Cmd Objects
    if( p_CSetup->getProtocollType() == CSetup::_s_config::E_EG_ASCII ||
        p_CSetup->getProtocollType() == CSetup::_s_config::E_EG_ENACQ)
    {
       // p_proberCmdSet = new ProberCmdSetCascade( &EventManager );
          p_proberCmdSet = new ProberCmdSet( &EventManager );
    }
    else
    {
        p_proberCmdSet = new ProberCmdSet( &EventManager );
    }

    //Protokoll Manager
    ProtocolManager * p_ProtoMgr = new ProtocolManager( &EventManager, p_proberCmdSet );
    // Initialize Prober communictation Interface
    if( p_CSetup->getProtocollType() == CSetup::_s_config::E_TELP8_ASCII ||
        p_CSetup->getProtocollType() == CSetup::_s_config::E_TELP12_ASCII ||
        p_CSetup->getProtocollType() == CSetup::_s_config::E_EG_ASCII ||
        p_CSetup->getProtocollType() == CSetup::_s_config::E_TSK_ASCII )
    {
        p_Protocol = new ASCII_CRLFProtocol();;
    }
    else
    {
        p_Protocol = new ASCII_ENQACKProtocol();;
    }

    p_serDevice->InitSerialProtocol( p_Protocol);
    p_Protocol->InitProtocol( p_serDevice, p_ProtoMgr );

    //ProberCmdSet::SetProberCmdSet(E_TELP8_OPTION); // Possible options:  E_TSK_OPTION, ,  E_TELP12_OPTION,
    if( p_CSetup->getProtocollType() == CSetup::_s_config::E_TELP8_ENACQ ||
        p_CSetup->getProtocollType() == CSetup::_s_config::E_TELP8_ASCII)
    {
        p_proberCmdSet->SetProberCmdSet(E_TELP8_OPTION);
    }
    else if( p_CSetup->getProtocollType() == CSetup::_s_config::E_TELP12_ENACQ ||
             p_CSetup->getProtocollType() == CSetup::_s_config::E_TELP12_ASCII)
    {
        p_proberCmdSet->SetProberCmdSet(E_TELP12_OPTION);
    }
    else if (p_CSetup->getProtocollType() == CSetup::_s_config::E_EG_ENACQ ||
             p_CSetup->getProtocollType() == CSetup::_s_config::E_EG_ASCII)
    {
        p_proberCmdSet->SetProberCmdSet(E_EG_OPTION);
    }
    else
    {
        p_proberCmdSet->SetProberCmdSet(E_TSK_OPTION);
    }


    p_proberCmdSet->Init();
    p_ProtoMgr->InitProtocolManager( p_Protocol );
    //Register EventHandler
    EventManager.AddEventHandler( CEventNames::NEW_DEWPOINT, ProtocolManager::DewPointEventWrapper, p_ProtoMgr );
    EventManager.AddEventHandler( CEventNames::DEFROST_CHANGED, ProtocolManager::DefrostEventWrapper, p_ProtoMgr );
    EventManager.AddEventHandler( CEventNames::STANDBY_CHANGED, ProtocolManager::StandbyEventWrapper, p_ProtoMgr );
    while( 1 ){
        EventManager.HandlePID();
        p_ProtoMgr->ProcessMessages();
        controlstatus = p_con1->GetControlReadyStatus();// Get Ready Status
        // p_proberCmdSet->SetControlStatus(controlstatus);
        p_proberCmdSet->SetProberReadySignal(p_CPData->getTemp3(iOffsettTable),p_CSetup->getTempParamSet(1)->getSetTemp());
        p_serDevice->cycExec();
        vTaskDelay(5);
    }
}

/**
CAN BUS Task
*/
void CANTask(void *pvParameters)
{
    while(1)
    {
        c_CanIo.cycExec(10);
        vTaskDelay(10);
    }
}

void UART0_IRQHandler( void ){
    if( p_serDevice != 0 ){
        p_serDevice->uart0_handler();
    }
    else{
        UART_ClearITPendingBit(UART0 ,UART_IT_Receive | UART_IT_ReceiveTimeOut | UART_IT_Transmit);
    }
}

void DCCHandler( void *pvParameters)
{
  while(1){
    JLINKDCC_Process();
    vTaskDelay(1);
  }
}


