#ifndef CH080_AGGREGATE_H
#define CH080_AGGREGATE_H


enum MODE{
  BOOT,
  AUTO,
  GOSTANDBY,
  MDEFROST,
  PURGE,
  STOP,
  STANDBY,
  SPARE7,
  SPARE8,
  SERROR,
  INIT,
  IDLE,
  SPARE11,
  SPAR12,
  EXTEST,
  DISABLED,
  DIAGNOSE_AIR,
  DIAGNOSE_POWER
};

enum PID_STATE{
	CONTROLLING,
	COOL_APPROACH,
	HEAT_APPROACH,
	COOLING,
	HEATING,
};
typedef enum 
{
  E_CC_NONE,
  E_CC_CONNECT,
  E_CC_SWITCH_OFF_CMP,
  E_CC_SWITCH_ON_CMP,
  E_CC_RESET_ALARM,
  E_CC_WAIT
}E_CHILLER_CLIENT_CMD;


void IO_Task(void *pvParameters);
void PID_Task( void *pvParameters);
void PID_Task_New( void *pvParameters );
void DiagTask(void *pvParameters);
void DSPLTask(void *pvParameters);
void FSTask(void *pvParameters);
void ProbTask(void *pvParameters);
void CANTask(void *pvParameters);
void DCCHandler(void *pvParameters);
MODE switchMode( MODE new_mode );
MODE getOperationMode(void);

////void DualSysTask(void);
////void Chiller_clientTask(void);

extern "C" {
    void ChillerClientNotifyOnDataReceived(struct CHILLER_INFO *info);
}
#endif