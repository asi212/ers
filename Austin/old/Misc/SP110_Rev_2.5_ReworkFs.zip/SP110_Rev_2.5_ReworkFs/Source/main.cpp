
//#define DEBUG
/* Standard includes. */
#include <stdio.h>

//#define FOR_BOOTLOADER

extern "C"
{
/* Library includes. */
#include "91x_lib.h"

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

//Dateisystem
//(includes stehen nur hier um in der Main formatieren zu koennen)
#include "FS.h" //PowerPac File System
#include "FS_OS.h" //FreeRTOS-Semaphore-Dateisystem-Verbindung
#include "ff.h" //FAT File System
#include "diskio.h" //FAT File System

#include "FSFormattingtask.h"
#include "uIP_Task.h"
#include "serial.h"
}

#include "CSystem.h"
#include "application/CSetup.h"
#include "application/CFiles.h"
//#include "SP110_Uart.h"
#include "application/SP110_aggregate.h"
#include "sysinit.h"

/* Delays used by the various tasks defined in this file. */
#define mainCHECK_PERIOD		( ( portTickType ) 3000 / portTICK_RATE_MS  )
#define mainSTRING_WRITE_DELAY		( 500 / portTICK_RATE_MS )

/* Constants for the ComTest tasks. */
#define mainCOM_TEST_BAUD_RATE		( ( unsigned long ) 115200 )
#define mainCOM_TEST_LED			( 3 )

/* The maximum number of messages that can be pending to be written to the LCD. */
#define mainLCD_QUEUE_LEN			( 6 )

/* Dimension the buffer used to write the error flag string. */
#define mainMAX_FLAG_STRING_LEN		( 32 )

/* The structure that is passed on the LCD message queue. */
typedef struct
{
	char **ppcMessageToDisplay; /*<< Points to a char* pointing to the message to display. */
	portBASE_TYPE xRow;				/*<< The row on which the message should be displayed. */
} xLCDMessage;
/*-----------------------------------------------------------*/

/*
 * The task that executes at the highest priority and calls
 * prvCheckOtherTasksAreStillRunning().  See the description at the top
 * of the file.
 */
static void vErrorChecks( void *pvParameters );

/*
 * Configure the processor clock and ports.
 */
static void prvSetupHardware( void );

/*
 * Checks that all the demo application tasks are still executing without error
 * - as described at the top of the file.  Called by vErrorChecks().
 */
static void prvCheckOtherTasksAreStillRunning( void );

#ifdef STACK_UIP
	/*
	 * The WEB server task prototype.  The task is created in this file but defined
	 * elsewhere.  STACK_UIP is defined when the uIP stack is used in preference
	 * to the lwIP stack.
	 */
	extern void vuIP_Task(void *pvParameters);
#endif


/*-----------------------------------------------------------*/

// Error status flag.
static unsigned long ulErrorFlags = 0;

/*-----------------------------------------------------------*/
// #LP# Globale Hilfsvariable um herauszubekommen warum FATFS
// keine Lust hat den Flash zu formatieren:
FRESULT g_my_formatting_status = FR_DISK_ERR; //(Die 10 wurde einfach nur so gesetzt)
extern FATFS fatfs;

CSystem cSystem;

int g_my_formatting_flag = 0;
bool dualSys = false;

//Hinzugefuegt um Displayupdatefehler zu unterbinden: //#LP# 27.5.2011
//Zwei Taskhandles der zwei vermutlich problematischen Tasks erstellen
//um diese bei einem Displayupdate pausieren zu koennen.
xTaskHandle PID_Task_xHandle, IO_Task_xHandle;

extern void FS_X_OS_Init   (unsigned MaxNumLocks); //Create Filesystem-Semaphores
extern int ip_addr[4];
extern CSetup * p_CSetup;
extern  unsigned char client_chiller_active;
extern CFiles	*p_CFiles;	/**< Pointer to file system object															*/

extern int gNumSectors;


/*
 * Starts all the other tasks, then starts the scheduler.
 */

void main( void )
{
	#ifdef DEBUG
		debug();
	#endif
	
	/* Setup any hardware that has not already been configured by the low
	level init routines. */
	prvSetupHardware(); //######################################
	cSystem.initHW();
	xSerialPortInit();
        
	/* Initialize file system */
	gNumSectors = 64;
	//FlashUnlockBypassChipErase();
	//for( int b=0; b<64; b++) FlashBlockErase(b); 
	FS_Init();
	//FS_X_AddDevices();  ??
	//FS_X_OS_Init(20);   ??
	//FS_FormatLow( "ERS_DSK_1" );
	//FS_Format("ERS_DSK_1", NULL );
	//for( int b=32; b<64; b++) FlashBlockErase(b); 
	//p_CFiles->mountFileSystem();	
	
	/* Application initialization */
#ifdef _SYS_CONFIG_
	SysInit::LoadDefaultSetup();       	// Create default setup data into filesystem
  #warning "Code is compiled for System Configuration Tool!!!"
#else
//	SysInit::CheckRepairSystem();					// Performs a system check and takes different actions in case of problems
//  SysInit::LoadSetup();        				// Load setup data from file in filesystem
//	SysInit::LoadChuckList();						// Loads chucklist from file CHUCKLST.INI in filesystem
#endif                             
	SysInit::InitializeIPAddress('L');  // Load IP-Address from IPADDR.INI or set default values. L = localhost
  SysInit::LoadUserSettings();        // Load User Settings.
//	SysInit::CheckForDisplayUpdate();		// Checks existance of Display Update files and triggers update
 
//	if( p_CSetup->getConConfig() == CSetup::_s_config::E_DUAL_CHILL_MST_SWS_D600 )
//	{
//				SysInit::InitializeIPAddress('C'); // Chiller IP-Address. 
//				client_chiller_active =1; // Initialize TCP/IP Client.
//				dualSys = true;
//	}
      
	
	//Tasks erstellen:
	xTaskCreate( vuIP_Task,             "uIP", 512, NULL, tskIDLE_PRIORITY + 20, NULL ); // min stack = 408
//	xTaskCreate( PID_Task,     "PID and Calc", 512, NULL, tskIDLE_PRIORITY + 18, &PID_Task_xHandle ); 
//	xTaskCreate( IO_Task,             "IOCON", 1024, NULL, tskIDLE_PRIORITY + 16, &IO_Task_xHandle );
//	xTaskCreate( DSPLTask,       "TSK Displ.", 1024, NULL, tskIDLE_PRIORITY + 14, NULL ); // min Stack = 517 
//	xTaskCreate( DiagTask,     "Diagnose Tsk", 512, NULL, tskIDLE_PRIORITY + 12, NULL );
//	xTaskCreate( ProbTask, "Prober Comm Task", 256, NULL, tskIDLE_PRIORITY + 10, NULL );
//	xTaskCreate( FSFormat_Task, "Format_tAsk", 128, NULL, tskIDLE_PRIORITY +  8, NULL );
//	xTaskCreate( FSTask,   "File System Task", 512, NULL, tskIDLE_PRIORITY +  6, NULL );
//	xTaskCreate( DCCHandler, "JLINK DCC Hand",  64, NULL, tskIDLE_PRIORITY +  4, NULL );
//	xTaskCreate( CANTask,"CAN Interface Task", 128, NULL, tskIDLE_PRIORITY +  2, NULL );

       
	/* Start the scheduler.
	NOTE : Tasks run in system mode and the scheduler runs in Supervisor mode.
	The processor MUST be in supervisor mode when vTaskStartScheduler is
	called.  The demo applications included in the FreeRTOS.org download switch
	to supervisor mode prior to main being called.  If you are not using one of
	these demo application projects then ensure Supervisor mode is used here. */
	vTaskStartScheduler();

	/* We should never get here as control is now taken by the scheduler. */
	for( ;; );
}
/*-----------------------------------------------------------*/

static void prvSetupHardware( void )
{
	/* Configuration taken from the ST code.

	Set Flash banks size & address */
        //FMI_BankRemapConfig( 4, 2, 0, 0x80000 );

	/* FMI Waite States */
	//FMI_Config( FMI_READ_WAIT_STATE_2, FMI_WRITE_WAIT_STATE_0, FMI_PWD_ENABLE, FMI_LVD_ENABLE, FMI_FREQ_HIGH );

	/* Configure the FPLL = 96MHz, and APB to 48MHz. */
	SCU_PCLKDivisorConfig( SCU_PCLK_Div2 );
	SCU_PLLFactorsConfig( 192, 25, 2 );
	SCU_PLLCmd( ENABLE );
	SCU_MCLKSourceConfig( SCU_MCLK_PLL );

	//WDG_Cmd( DISABLE );
        //Watchdog neue Lib Anpassung:
        WDG_TimerModeCmd(DISABLE); //#LP#
	VIC_DeInit();

	/* GPIO8 clock source enable, used by the LCD. */
	SCU_APBPeriphClockConfig(__GPIO8, ENABLE);
	GPIO_DeInit(GPIO8);

	/* GPIO 9 clock source enable, used by the LCD. */
	SCU_APBPeriphClockConfig(__GPIO9, ENABLE);
	GPIO_DeInit(GPIO9);

	/* Enable VIC clock */
	SCU_AHBPeriphClockConfig(__VIC, ENABLE);
	SCU_AHBPeriphReset(__VIC, DISABLE);

}
/*-----------------------------------------------------------*/

static void vErrorChecks( void *pvParameters )
{

}
/*-----------------------------------------------------------*/

static void prvCheckOtherTasksAreStillRunning( void )
{

}
