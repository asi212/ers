/**
 * Includes
 */
#include <stdarg.h>

#include "CSystem.h" 		/**< Lowlevel initialization routines 	*/
#include "CTerminal.h"	/**< Terminal on LCD display	      		*/                     	
#include "sysinit.h"    /**< Highlevel initialization routines 	*/
#include "CSetup.h"			/**< Setup and Configuration storage		*/
#include "CFiles.h"			/**< Files handling											*/
extern "C" {
#include "91x_lib.h"		/**< STM peripheral library        			*/
#include "FS.h" 				/**< PowerPac File System    						*/
#include "FS_NOR_PHY_M29W128G.h"
#include "c2635.h"
}


/**
 * Konfiguration
 */
#define PHYS_BACKUP_SECTOR	127 			/**< Lowest: 64 , highest: 127, 0..63 are occupied by filesystem */
#define CONT_DATA_SIZE	 100000


/**
 * Private function declarations
 */
void init_hardware( void );  			/**< Initializes hardware drivers */
void signal_error( char* pTxt );  /**< Signals error by printing on Terminal */
void signal_warning( char* pTxt );/**< Signals warning by printing on Terminal */
int _OnError(int ErrCode, ...);		/**< Call back for check disk error handling */

extern int _EraseSector(char Unit, unsigned int SectorIndex);
extern int _ReadOff(char Unit, void * pDest, unsigned int Off, unsigned int NumBytes);
/**
 * Instantiate objects
 */
CSystem cSystem;        	/**< Required for low level system init, methods are not static */
extern CTerminal cTerm; 	/**< Terminal object to print debug output on LCD               */
extern CSetup c_CSetup;		/**< Setup object, containing all important configurations			*/
extern CFiles	*p_CFiles;	/**< Pointer to file system object															*/
CSetup c_CSetupBackup;		/**< Setup object read from backup															*/

U32 freefs = 0;
FS_DISK_INFO volinfo;
FS_NOR_DISK_INFO diskinfo;
FS_NOR_SECTOR_INFO secinfo;
int volstatus, volmounted;

U8 cont[CONT_DATA_SIZE] @ "EXRAM" = {'A'};

extern int gNumSectors;

#define CONFIG_INI_SIZE	84

struct {
	U8 config[CONFIG_INI_SIZE];
} all_files;

/**
 * MAIN PROGRAM
 */
void main( void )
{
	unsigned char *pHBeat = (unsigned char*)0x34000084;
	unsigned char volName[100]; 
	U32 size = 0;
  //static U32 _aBuffer[5000] @ "EXRAM";
	U32 v = 0;
	U32 maxOff = 0;
	U8  maxSec = 0, maxErase= 0;
	
	// Initializations
	init_hardware();
	
	
	// Initialize terminal
	cTerm.Clear();
	cTerm.Printf("Repartition of filesytem ... DONT switch-off power!!!!");

 	// Initialize file system
	gNumSectors = 64;
	for( int b=0; b<gNumSectors; b++) FlashBlockErase(b); 
	FS_Init();
	FS_GetVolumeName(0, volName, 100);
	cTerm.Printf("Volume name: %s", volName);
	FS_FormatLow( volName );
	FS_Format(volName, NULL );

	// Now for a long time ...
	cTerm.Clear();
	for (int t=0; t<10000; t++)
	{
		// ... write into a file
		FS_FILE * pFile = FS_FOpen ( "CONFIG.INI", "wb" );
		if( pFile != 0 )
		{
//				for (long f=0; f<(312000/10); f++) FS_Write( pFile, "HalloHallo", 10 ); 
				FS_Write( pFile, &cont[0], CONT_DATA_SIZE );
				FS_FClose( pFile );
		}
		else signal_error("Could not open CONFIG.INI");
		
		// Get and print fs-statistic
		// Compute how many KB are currently occupied. This is done by adding offset and size
		// of the highest physical sector where logical sectors are used.
		v = FS_GetVolumeFreeSpaceKB(volName);
		FS_GetVolumeInfo(volName, &volinfo);
		FS_NOR_GetDiskInfo(0, &diskinfo);
		cTerm.Pos0();
		if (t==2256) {
			cTerm.Printf("Last Loop count: %d", t);
		}
		else cTerm.Printf("Loop count: %d", t);
		for (int i=0; i<diskinfo.NumPhysSectors; i++)
		{
			FS_NOR_GetSectorInfo(0, i, &secinfo);
			if (secinfo.NumUsedSectors != 0) {
				size = secinfo.Off + secinfo.Size;
				maxSec = MAX(maxSec, i+1);
				maxOff = MAX(maxOff, secinfo.Off);
				maxErase = MAX(maxErase, secinfo.EraseCnt);
			}
		}
		cTerm.Printf("Volume free space       : %d KB", v);
		cTerm.Printf("Number of logic sectors : %d", diskinfo.NumLogSectors);
		cTerm.Printf("Number of used log secs : %d", diskinfo.NumUsedSectors);
		cTerm.Printf("Number of total clusters: %d", volinfo.NumTotalClusters);
		cTerm.Printf("Number of used clusters : %d", volinfo.NumTotalClusters - volinfo.NumFreeClusters);
		cTerm.Printf("Number of phys sectors  : %d", diskinfo.NumPhysSectors);
		cTerm.Printf("Max used phys sectors   : %d", maxSec);
		cTerm.Printf("Max phys sectors Offset : %d KB", maxOff / 1024);
		cTerm.Printf("Max sectors erase count : %d", maxErase);
		cTerm.Printf("Filesytem occupies      : %d KB", (size / 1024) );
		
		//for (int p=0; p<1000; p++){;}	// Pause
	}
	
	
	/******** Second try ************
	
	gNumSectors = 64;
	FS_Init();

	FS_GetVolumeName(0, volName, 100);
	cTerm.Printf("Volume name: %s", volName);

	FS_FormatLLIfRequired(volName);
	if (FS_IsHLFormatted(volName) == 0) {
		cTerm.Printf("Performing high level formatting");
		FS_Format(volName, NULL );
	}
	
	
	v = FS_GetVolumeFreeSpace(volName);
	cTerm.Printf("Free space: %d bytes", v);
	
	//while (FS_FAT_CheckDisk("ERS_DSK_1", &_aBuffer[0], sizeof(_aBuffer), 5, _OnError) == 1) {;}
	
	if (!FS_IsVolumeMounted(volName)) FS_Mount(volName);
	if (!FS_IsVolumeMounted(volName)) signal_error("Bigger Filesystem could not be mounted");	
	else
	{
		// Read one file into memory
		FS_FILE * pFile = FS_FOpen ( "CONFIG.INI", "rb" );
		if( pFile != 0 ){
				//FS_FSeek( pFile, 0, FS_SEEK_SET );
				FS_Read( pFile, &all_files.config, CONFIG_INI_SIZE );
				FS_FClose( pFile );
		}
		else signal_error("Could not open CONFIG.INI");
	
		// Reformat filesystem
		//FS_Unmount(volName);
		//for( int b=0; b<64; b++) FlashBlockErase(b); 
		gNumSectors = 32;
		//FS_Init();
		//FS_X_AddDevices();

		//FS_GetVolumeName(0, volName, 100);
		//cTerm.Printf("Volume name: %s", volName);

		cTerm.Printf("Low level reformatting");
//		FS_FormatLLIfRequired(volName);
//		if (FS_IsHLFormatted(volName) == 0) {
//			cTerm.Printf("High level reformatting");
//			FS_Format(volName, NULL );
//		}

		FS_FormatLow(volName);
		FS_Format(volName, NULL );
		
		v = FS_GetVolumeFreeSpace(volName);
		cTerm.Printf("Free space: %d bytes", v);
	
		// Try to mount it
		if (!FS_IsVolumeMounted(volName)) FS_Mount(volName);
		if (!FS_IsVolumeMounted(volName)) signal_error("Smaller Filesystem could not be mounted");	
		else
		{
			// Mounted: Write files from memory to filesystem
			FS_FILE * pFile = FS_FOpen ( "CONFIG.INI", "wb" );
			if( pFile != 0 ){
					FS_Write( pFile, &all_files.config, CONFIG_INI_SIZE );
					FS_FClose( pFile );
			}
			else signal_error("Could not open CONFIG.INI");	
		}
		FS_Unmount(volName);
	}
	**********************************/	

	
	/******** First try ************
	
	// Get some filesystem information
	FS_GetVolumeName(0, volName, 100);
  volstatus = FS_GetVolumeStatus(volName);
	volmounted = FS_IsVolumeMounted(volName);
	
	if (volmounted == 0) FS_Mount(volName);
	volmounted = FS_IsVolumeMounted(volName);
	
	freefs = FS_GetVolumeFreeSpaceKB(volName);
	FS_GetVolumeInfo(volName, &volinfo);
	FS_NOR_GetDiskInfo(0, &diskinfo);
	
	// Compute how many KB are currently occupied. This is done by adding offset and size
	// of the highest physical sector where logical sectors are used.
	for (int i=0; i<diskinfo.NumPhysSectors; i++)
	{
		FS_NOR_GetSectorInfo(0, i, &secinfo);
		if (secinfo.NumUsedSectors != 0) size = secinfo.Off + secinfo.Size;
	}
	cTerm.Printf("Current filesytem occupies %d KB", (size / 1024) );

	// Load data to be backuped from filesystem
	SysInit::LoadSetup();

	// Check, if sector(s) for backupstorage is free and big enough	
	FS_NOR_GetSectorInfo(0, PHYS_BACKUP_SECTOR, &secinfo);
	if ((sizeof(c_CSetup) > secinfo.Size)) signal_error("Backup can not be stored in a single sector");
	if ((secinfo.NumUsedSectors > 0)) signal_warning("Backup-Sector is occupied by Filesystem");
	
//	FS_Unmount(volName);
	
	_EraseSector(0, PHYS_BACKUP_SECTOR);
	cTerm.Printf("Erased physical sector %d for backup storage", PHYS_BACKUP_SECTOR+1 );
	
	// Backup content of the most important files in higher anf hopefully unused part of the flash
	_WriteOff(0, secinfo.Off, (const void*)&c_CSetup, sizeof(c_CSetup));
	_ReadOff(0, (const void*)&c_CSetupBackup, secinfo.Off, sizeof(c_CSetupBackup));

	// Protection
	static ReturnType ret = FlashCheckProtectionMode();
		
	
//	for (int i=0; i<100; i++)
//	{
//		cTerm.Printf("Repartition of filesytem ... DONT switch-off power!!!!");
//		
//	}
	//	vector<char> cmd;
//	pushing_back(&cmd, "#TE\f#TQ\r\nDies ist ein Test", 26);
//	pushing_back(&cmd, "#TI", 3);
//	disp_send_dc1(&cmd, UART2);
//	tprintf("Hello World");
	
	**********************************/	
	
	while (1)
	{

		if( *pHBeat != 0 )
		{
			*pHBeat = 0;
		}

	};
}


/**
 * Configures processor ports and clocks
 */
void init_hardware( void )
{
	// Configure the FPLL = 96MHz, and APB to 48MHz.
	SCU_PCLKDivisorConfig( SCU_PCLK_Div2 );
	SCU_PLLFactorsConfig( 192, 25, 2 );
	SCU_PLLCmd( ENABLE );
	SCU_MCLKSourceConfig( SCU_MCLK_PLL );

	// Disable Watchdog 
  WDG_TimerModeCmd(DISABLE);
	
	// Enable VIC clock
	VIC_DeInit();
	SCU_AHBPeriphClockConfig(__VIC, ENABLE);
	SCU_AHBPeriphReset(__VIC, DISABLE);
	
	// ARM Peripheral bus clokdivisor = 1
	SCU_PCLKDivisorConfig(SCU_PCLK_Div1); 

  cSystem.SCU_Configuration();  /* Configure the system clocks */
  cSystem.EMI_Configuration();  /* Configure the EMI Interface */
  cSystem.GPIO_Configuration(); /* Configure the GPIO ports    */
  cSystem.UART_Configuration(); /* Configure the Uart          */
}


/**
 * Prints an error to terminal and enters endless loop
 */
void signal_error( char* pTxt )
{
	cTerm.Printf("ERROR: %s !", pTxt);
	while(1){;}
}

/**
 * Prints an warning to terminal
 */
void signal_warning( char* pTxt )
{
	cTerm.Printf("WARNING: %s !", pTxt);
}


/**
 * Handles Check disk errors
 */
int _OnError(int ErrCode, ...) 
{
	va_list ParamList;
	const char * sFormat;
	char c;
	char ac[1000];
	sFormat = FS_FAT_CheckDisk_ErrCode2Text(ErrCode);
	if (sFormat) 
	{
		va_start(ParamList, ErrCode);
		vsprintf(ac, sFormat, ParamList);
		cTerm.Printf("%s", ac);
	}
	return 1; // Fix the error anyway
}
